# coding: utf-8
"""
Created on 05-Jul-2022
@author: STEPHIG
Desc: Analyze sepcified report file
"""

# Imports ---------------------------------------------------------------------
import argparse as ap

from ReportAnalysis import Consolidator
from ReportAnalysis import Consolidator_Cloud
from ReportAnalysis import AnalyseReport
from ReportAnalysis.CLI import get_inputs_for_analyzer

from ReportAnalysis.DatabaseHandler import DatabaseDerivedClass
from ReportAnalysis.common import VALID_TEST_TYPES
from ReportAnalysis.common import TEST_TYPE_STRING

from Logger import LogHandler
from ReportAnalysis.SW_VERSION import VERSION as sw_version

# Variables -------------------------------------------------------------------
# Control storing analysis to excel file
# False: Do not create excel (Only log files will be generated)
# True: Save analysis to excel file
ENABLE_EXCEL_REPORT = False

# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)


# Functions -------------------------------------------------------------------

# Command line handler
def cli_handler():
    # Create parser
    parser=ap.ArgumentParser(description="BROP Report analyzer v%s. This tool processes XML test report, extracts relevant data and stores it in a cloud friendly JSON file."%(sw_version.version))
    analyzer_args=parser.add_argument_group("Required arguments")
    
    # Add argument for file path
    analyzer_args.add_argument("-i","--input",
        type=str,
        help="Report file to be analyzed",
        required=True)
    
    # Add argument for test type
    analyzer_args.add_argument('-t', "--type",
        type=str,
        choices=VALID_TEST_TYPES,
        help="Type of test: %s"%TEST_TYPE_STRING,
        required=True)
    
    # Add optional argument to enable upload to database
    parser.add_argument("-u", "--upload",
        action="store_true",
        help="Upload data from report to database")
    
    args = parser.parse_args()
    
    return args.input,args.type,args.upload

# Report analysis:
#     Analyse report file
#     Consolidate the data in an excel file
#     Upload data to an online database
# Arguments: list containing the following
#     filename:(string): Name of XML report to be analysed
#     filetype:(string): Test type of the report (NTS | TLS | HEST | DIVA |GWD)
#     upload: (boolean)
#         True: Upload result to online Database
#         False: Do not Upload result to online Database
def analyze(inputs):
    filename,filetype,upload=get_inputs_for_analyzer(inputs)
    # Validate inputs
    if (filename is not None) \
        and (filetype is not None):
        
        if ENABLE_EXCEL_REPORT:
            analysis = Consolidator(report_file=filename, testtype=filetype)
            analysis.consolidate()
            # Upload to database if requested
            if upload:
                try:
                    uploadobj = DatabaseDerivedClass()
                    uploadobj.extract_info(analysis, report_file=filename, \
                        testtype=filetype)
                    uploadobj.post_result_data(uploadobj, testtype=filetype)
                except Exception as e:
                    logger.error("Encountered exception during upload: %s"%e)
        
        else:
            analysis = Consolidator_Cloud(filename,filetype)
            analysis.consolidate()

    else:
        # Invalid filename or filetype
        pass
    return


# Main analysis function if this file is executed as a standalone
def main():
    # Get inputs from command line
    filename,test_type,upload = cli_handler()
    # Arrange inputs as required
    inputs=[filename,test_type,upload]
    # Analyze report
    logger.info("Report Analysis Tool: %s"%(sw_version.version))
    analyze(inputs)
    return


# Run -------------------------------------------------------------------------

if __name__ =='__main__':
    logger.debug("-"*80)
    main()
    logger.debug("-"*80)
    pass

# End of File ----------------------------------------------------------------
