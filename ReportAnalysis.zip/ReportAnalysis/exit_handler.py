# -*- coding: utf-8 -*-

'''
Created by: ASEMPON
Date: 27-07-2022
Desc: System exit handling API and constants
'''

# importing necessary modules
import sys
from Logger import LogHandler

# EXIT CODE 
ARTIFACT_HANDLER_EXITCODE = 1
VECU_DOWNLOAD_EXITCODE    = 2
MBOS_START_EXITCODE       = 3
ZENZEFI_EXITCODE          = 4
JSON_EXITCODE             = 5 
PIPE_HANDLER_EXITCODE     = 6
GUC_HANDLER_EXITCODE      = 7
WEBUI_HANDLER_EXITCODE    = 8
VMAP_HANDLER_EXITCODE     = 9
UNDEFINED_EXITCODE        = 100

# Artifactory Handler Constants
AUTHENTICATION_ERROR      = 11
FILENAME_ERROR            = 12
UPLOAD_ERROR              = 13
FORMAT_ERROR              = 14
OUTPUTDIR_ERROR           = 15
APP_ERROR                 = 16
INVALID_ERROR             = 17
EXTRACTION_ERROR          = 18
DOWNLOAD_ERROR            = 19

# Start_MBOS Constants
INIT_PIPELINE_ERROR       = 21
SETUP_PIPELINE_ERROR       = 22

# vECU Download Constants
LOAD_DATA_ERROR           = 31
GET_ECUINFO_ERROR         = 32
INCORRECT_RESP_ERROR      = 33
INVALID_ECU_ERROR         = 34
DOWNLOADFILE_ERROR        = 35
DOWNLOADCOMP_ERROR        = 36
CLEANUP_ERROR             = 37
COPYFAIL_ERROR            = 38

# Zenzefi Constants
LOGIN_ERROR               = 41
LOGOUT_ERROR              = 42

# Json Constants
JSON_LOAD_ERROR           = 51

# Pipeline Handler Error codes
PHEC_INIT_RETRY_OVERFLOW = 61
PHEC_INVALID_RUN_STATUS = 62
PHEC_UPDATE_RETRY_OVERFLOW = 63

# Get User Config Constants
GUC_SETUP_ERROR = 71
GUC_EXTRACT_ERROR = 72

# Web UI Constants
WEB_PROCESS_ERROR = 81
WEB_COPY_ERROR = 82
WEB_GET_ERROR = 83
WEB_UNDEFINED_ERROR = 84

# VMAP handling errors
VHE_UNDEFINED_INPUT=91
VHE_DOWNLOAD_FAILED=92
VHE_PROCESS_ERROR=93
VHE_NO_DLL=94
VHE_INVALID_INPUT=95
VHE_FILE_NOT_FOUND=96
VHE_INVALID_DLL=97
VHE_UNKNOWN_ERROR=98

# List of all erros
list_AH_ERRORS = [AUTHENTICATION_ERROR,
                  FILENAME_ERROR,
                  UPLOAD_ERROR,
                  FORMAT_ERROR,
                  OUTPUTDIR_ERROR,
                  APP_ERROR,
                  INVALID_ERROR,
                  DOWNLOAD_ERROR,
                  EXTRACTION_ERROR ]

list_MBOS_ERRORS = [INIT_PIPELINE_ERROR,
                    SETUP_PIPELINE_ERROR]

list_VD_ERRORS = [LOAD_DATA_ERROR,
                  GET_ECUINFO_ERROR,
                  INCORRECT_RESP_ERROR,
                  INVALID_ECU_ERROR,
                  DOWNLOADFILE_ERROR,
                  DOWNLOADCOMP_ERROR,
                  CLEANUP_ERROR,
                  COPYFAIL_ERROR ]

list_ZZ_ERRORS = [LOGIN_ERROR, LOGOUT_ERROR]

list_JSON_ERRORS = [JSON_LOAD_ERROR]

list_PIPE_HANDLER_ERRORS=[PHEC_INIT_RETRY_OVERFLOW,
    PHEC_INVALID_RUN_STATUS,
    PHEC_UPDATE_RETRY_OVERFLOW
    ]

list_GUC_ERRORS = [GUC_SETUP_ERROR, GUC_EXTRACT_ERROR]

list_WEBUI_ERRORS = [WEB_PROCESS_ERROR, 
                     WEB_COPY_ERROR,
                     WEB_GET_ERROR,
                     WEB_UNDEFINED_ERROR]


list_VMAP_HANDLER_ERRORS =[VHE_UNDEFINED_INPUT,
                            VHE_DOWNLOAD_FAILED,
                            VHE_PROCESS_ERROR,
                            VHE_NO_DLL,
                            VHE_INVALID_INPUT,
                            VHE_FILE_NOT_FOUND,
                            VHE_INVALID_DLL,
                            VHE_UNKNOWN_ERROR
                            ]

# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info("%s"%(msg))
    return

def sys_exit(type):
    ''' Handles system exit based on input error '''
    
    # Artifactory handler errors
    if type in list_AH_ERRORS:
        log_info("System exit with Artifactory handler error: %d"%type)
        sys.exit(ARTIFACT_HANDLER_EXITCODE)

    # vECU Download errors
    elif type in list_VD_ERRORS:
        log_info("System exit with vECU Download error: %d"%type)
        sys.exit(VECU_DOWNLOAD_EXITCODE)
    
    # Start MBOS errors
    elif type in list_MBOS_ERRORS:
        log_info("System exit with MBOS Pipeline error: %d"%type)
        sys.exit(MBOS_START_EXITCODE)
    
    # Start Json errors
    elif type in list_JSON_ERRORS:
        log_info("System exit with JSON error: %d"%type)
        sys.exit(JSON_LOAD_ERROR)
        
    # Zenzefi login/logout errors
    elif type in list_ZZ_ERRORS:
        log_info("System exit with Zenzefi error: %d"%type)
        sys.exit(ZENZEFI_EXITCODE)
    
    # Pipeline handler errors
    elif type in list_PIPE_HANDLER_ERRORS:
        log_info("System exit: Error in Pipeline Handler: %d"%type)
        sys.exit(PIPE_HANDLER_EXITCODE)

    # Get user config errors
    elif type in list_GUC_ERRORS:
        log_info("System exit: Error in Get user config: %d"%type)
        sys.exit(GUC_HANDLER_EXITCODE)

    # Web UI errors
    elif type in list_WEBUI_ERRORS:
        log_info("System exit: Error in Web UI: %d"%type)
        sys.exit(WEBUI_HANDLER_EXITCODE)

    # VMAP handler errors
    elif type in list_VMAP_HANDLER_ERRORS:
        log_info("System exit: Error in VMAP handler: %d"%type)
        sys.exit(VMAP_HANDLER_EXITCODE)

    else:
        #TODO: response for undefined error code
        log_info("Undefined error code %d"%type)
        sys.exit(UNDEFINED_EXITCODE)
        pass
