# coding: utf-8
"""
Created on 28-Jun-2022
@author: STEPHIG
Desc: Interface for jenkins report analysis
    - Download report file from MBOS portal.
    - Analyse report file
    - Upload report overview to online Database.
"""

# Imports ---------------------------------------------------------------------
from Logger import LogHandler

import argparse as ap

from analyze import analyze
from mbos import cleanup_report
from mbos import PipelineHandler

from ReportAnalysis.common import VALID_TEST_TYPES
from ReportAnalysis.common import TEST_TYPE_STRING

# Functions -------------------------------------------------------------------

def cli_handler():
    # Create parser
    parser=ap.ArgumentParser(description="Analyze report from last test")
    analyzer=parser.add_argument_group("Required arguments")
    # Add argument for test type
    analyzer.add_argument('-p', "--pipe",
        metavar="PIPE_NAME",
        type=str,
        required=True)
    
    # Add argument for test type
    analyzer.add_argument('-t', "--type",
        metavar="TEST_TYPE",
        type=str,
        choices=VALID_TEST_TYPES,
        help="Type of test: %s"%TEST_TYPE_STRING,
        required=True)
    
    # Add optional argument to enable upload to database
    parser.add_argument("-u", "--upload",
        action="store_true",
        help="Upload data from report to database")
    
    args = parser.parse_args()
    
    return args.pipe,args.type,args.upload

def main(logger):
    pipeline,test_type,upload = cli_handler()
    
    # Get report file from MBOS
    try:
        logger.debug("Start analyzing")
        pipe_handle = PipelineHandler(pipeline)
        report_file = pipe_handle.get_report_file()
    except Exception as e:
        report_file=None
        logger.exception("Exception while getting report: %s"%e)

    # analyse the report
    if report_file is not None:
        analyze(inputs=(report_file,test_type,upload))
    else:
        # No valid report data
        logger.error("No report data to be analysed.")
    # Cleanup before exit
    cleanup_report()
    return

if __name__=='__main__':
    logger=LogHandler()
    logger.setup()
    logger.info('-'*80)
    main(logger)
    logger.info('-'*80)

# End of file -----------------------------------------------------------------
