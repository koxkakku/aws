# coding: utf-8
"""
Created on 02-Aug-2022
@author: STEPHIG
Desc:
    - Get user inputs for a given job ID for the test from the web UI.
    - Download files uploaded by user, if available
Usage:
    python web_ui.py download -j JOB_ID -t TestType -d destination
    python web_ui.py copy -j JOB_ID -t TestType -d destination
    python web_ui.py get -j JOB_ID -d destination
Example:
    python web_ui.py download -j 18_08_2022_05_12_15 -t NEST -d NEST\Database
"""

# Imports ---------------------------------------------------------------------
# Log handler
from Logger import LogHandler

import os
import argparse

import json
import requests
import urllib3

# Test types
from ReportAnalysis.common import VALID_TEST_TYPES
from ReportAnalysis.common import TEST_TYPE_STRING

# common functions
from common import download_file

from copier import copier
from exit_handler import sys_exit
from exit_handler import WEB_PROCESS_ERROR
from exit_handler import WEB_COPY_ERROR
from exit_handler import WEB_GET_ERROR
from exit_handler import WEB_UNDEFINED_ERROR

# Constants -------------------------------------------------------------------
# CLI Subparser type
CLIST_DOWNLOAD="download"
CLIST_COPY="copy"
CLIST_GET="get"

# Base URL
URL_BASE="https://fits-dev.query.api.dvb.corpinter.net/jenkins"
# Enable/Disable SSL verification for cloud
ENABLE_SSL=False

# Filenames
FN_USER_INPUT="user_input.json"

# User input json keys
UIK_TEST_DATA="TestData"
UIK_TEST_STATUS="Status"

# User input: No data
UI_NO_DATA="none"

# Keys for User uploaded data for each test type
UI_TEST_INPUT_KEYS={
    "NTS":["Config"],
    "NEST":["Config"],
    "DIVA":["Config"],
    "DiagGW":["Config"],
    "TLS":["Config"]
}

# Authorization data
CLIENT_ID="DAIVBADM_MICTM_EMEA_PROD_00512"
AUTHROIZATION_TOKEN="REFJVkJBRE1fTUlDVE1fRU1FQV9QUk9EXzAwNTEyOjE1LVBSVnBJNl83Llp1aTNocktDOWIweH5YUzJxUTg0"
TOKEN_URL='https://ssoalpha.dvb.corpinter.net/v1/token'

# Timeout for file download (second)
TIMEOUT_FILE_DOWNLOAD=5*60
TIMEOUT_USER_INPUT=60

# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

# Functions -------------------------------------------------------------------

# Generate token for authorization
def generate_token():
    token = None 
    head = {'Cache-Control' : 'no-cache',
            'Content-Type' : 'application/x-www-form-urlencoded',
            'Authorization' : 'Basic %s' % AUTHROIZATION_TOKEN}
    data = {'client_id': CLIENT_ID ,
            'grant_type' : 'client_credentials',
            'scope': 'openid groups audience'}
    try: 
        response = requests.post(TOKEN_URL,headers=head,data=data) 
        data = json.loads(response.text)
        token = data['access_token']
        logger.debug("Token generated successfully")
    except Exception as e:
        logger.error("Failed to get token: %s"%e) 
    return token

# Load user input file based on job ID
def load_user_inputs(jobid,dest="."):
    retval = None
    filename="%s/%s"%(dest,FN_USER_INPUT)
    # Check if file exists
    if not os.path.exists(filename):
        logger.info("Could not find local copy of user input file.")
        # File not found; Download file
        retval=get_user_input(jobid,dest=dest)
    else:
        # File found. Load inputs from JSON
        logger.info("Found local copy of user input file.")
        try:
            # Load user input JSON file
            with open(filename,"r") as f:
                retval=json.load(f)
        except Exception as e:
            retval = None
            logger.exception("Could not load inputs: %s"%e)
    return retval

# Download test specific files
def download_test_related_files(token,jobid,testtype,user_input,dest):
    status=True
    # Get list of keys to check in JSON
    key_list=UI_TEST_INPUT_KEYS[testtype]
    user_test_data=user_input[UIK_TEST_DATA][testtype]
    
    # Download files
    for _key in key_list:
        item=user_test_data[_key]
        if item.lower() != UI_NO_DATA:
            url="%s/%s/%s/%s" % (URL_BASE,jobid,testtype,item)
            file=os.path.join(dest,item)
            if download_file(token,url,file):
                pass
            else:
                # Failed to download
                status=False
                break
        else:
            # Item marked None
            logger.debug("Item marked None. Skipped download")
    return status

# Download all files
# Ensure that the test type contains something to download. Else will cause 
# an error.
def download_files_for_test(jobid,testtype,token=None,dest="."):
    status=False
    logger.info("Starting file download")
    # generate new token if not available
    if token is None:
        token=generate_token()
    
    if token is not None:
        # Download each file in key reference list
        if testtype in UI_TEST_INPUT_KEYS.keys():
            # Load user input JSON file
            user_input=load_user_inputs(jobid,dest)
            if user_input is not None:
                # Download test related files
                status=download_test_related_files(token,jobid,testtype, \
                    user_input,dest)
            else:
                status=False
                logger.error("Failed to load JSON file")
    else:
        logger.error("Could not generate token")
    return status

# Copy configuration from source given by user to destination
def copy_configuration(jobid,testtype,dest="."):
    status=False
    logger.info("Start copying user files.")
    # Download each file in key reference list
    if testtype in UI_TEST_INPUT_KEYS.keys():
        # Get list of keys to check in JSON
        key_list=UI_TEST_INPUT_KEYS[testtype]
        user_input=None
        # Load user input JSON file
        user_input=load_user_inputs(jobid,dest)
        if user_input is not None:
            user_test_data=user_input[UIK_TEST_DATA][testtype]
            # Copy files
            status=True
            for _key in key_list:
                item=user_test_data[_key]
                if item.lower() != UI_NO_DATA:
                    src=item
                    copier(src,dest)
                else:
                    # Item marked None
                    logger.debug("Item marked None. Skipped copy.")
        else:
            status=False
            logger.error("Failed to load JSON file")
    return status

# Get status of test from input JSON file
def is_test_enabled(user_data,testtype):
    retval=False
    if user_data is not None:
        try:
            _status = user_data[UIK_TEST_DATA][testtype][UIK_TEST_STATUS]
            if _status.lower() == "false":
                retval=False
            elif _status.lower() == "true":
                retval=True
            else:
                logger.info("Unknown test status: %s" % _status)
                retval=False
        except Exception as e:
            logger.exception("Exception when getting test status: %s" % e)
    else:
        logger.error("Could not load User input")
        retval=False
    return retval

# Get user input from web UI
def get_user_input(jobid,token=None,dest="."):
    retval=None
    logger.info("Getting user input JSON")
    
    # Generate token if not available
    if token is None:
        token=generate_token()
    
    # Request JSON file
    if token is not None:
        head = {'Authorization': 'Bearer %s'%(token)}
        url="%s/%s/%s"%(URL_BASE,jobid,FN_USER_INPUT)
        logger.debug("%s"%head)
        try:
            logger.debug("Start request: %s"%url)
            # Disable warning flag is needed
            if not ENABLE_SSL:
                urllib3.disable_warnings( \
                    urllib3.exceptions.InsecureRequestWarning)
            # Request
            response = requests.get(url,headers=head, \
                timeout=TIMEOUT_USER_INPUT,verify=ENABLE_SSL)
            if response.ok:
                retval=json.loads(response.text)
                # Write to JSON file
                file=os.path.join(dest,FN_USER_INPUT)
                with open(file,"w") as f:
                    f.write(json.dumps(retval,indent=4))
                logger.info("Saved user input JSON: %s"%file)
            else:
                retval=None
                logger.error("Failed to get user inputs")
        except Exception as e:
            retval=None
            logger.error("Encountered exception when fetching user inputs: %s"%e)
            logger.debug(e)
    else:
        retval=None
        logger.error("Failed to get token")
    return retval

# Download data uploaded by user from web UI to destination
def download_user_data(jobid,testtype,dest="."):
    status=False
    logger.info("Download user data!!!")
    # Create directory for this job
    if not os.path.exists(dest):
        logger.info("Creating directory: %s"%dest)
        os.makedirs(dest)
    
    # Get bearer token
    token = generate_token()
    if token is not None:
        # Get inputs from user
        user_input = get_user_input(jobid,token,dest)
        logger.debug(user_input)

        # Process inputs, download necessary files
        if user_input is not None:
            # Download files
            if is_test_enabled(user_input,testtype):
                logger.debug("Test is enabled. Proceed to download.")
                if download_files_for_test(jobid,testtype,token,dest):
                    status=True
            else:
                logger.info("Test for %s is disabled." % testtype)
                logger.info("Skipping file download.")
                status=True
    return status

# Copy user data from source mentioned by user in web UI to destination
def copy_user_data(jobid,testtype,dest="."):
    status=False
    logger.info("Copy user data!!!")
    # Create directory for this job
    if not os.path.exists(dest):
        logger.info("Creating directory: %s"%dest)
        os.makedirs(dest)
    
    # Get bearer token
    token = generate_token()
    if token is not None:
        # Get inputs from user
        user_input = get_user_input(jobid,token,dest)
        logger.debug(user_input)

        # Process inputs, copy necessary files
        if user_input is not None:
            # Copy files
            if is_test_enabled(user_input,testtype):
                logger.debug("Test is enabled. Proceed to copy configuration.")
                if copy_configuration(jobid,testtype,dest):
                    status=True
            else:
                logger.info("Test for %s is disabled." % testtype)
                logger.info("Skipping file download.")
                status=True
    return status

# Get user input file from cloud and save to destination
def download_user_input(jobid,dest="."):
    status=False
    logger.info("Get user input!!!")
    
    # Create directory for this job
    if not os.path.exists(dest):
        logger.info("Creating directory: %s"%dest)
        os.makedirs(dest)
    
    # Get bearer token
    token = generate_token()
    if token is not None:
        # Get inputs from user
        user_input = get_user_input(jobid,token,dest)
        if user_input is not None:
            logger.debug(user_input)
            status=True
        else:
            status=False
            logger.error("Failed to get user inputs.")
    else:
        logger.error("Did not get token.")
    return status

# Command line handler for download
def cli_downloader(subparser):
    downloader=subparser.add_parser(CLIST_DOWNLOAD, \
        help="Download user data from UI")
    dargs=downloader.add_argument_group("Arguments for download")

    # Job ID
    dargs.add_argument("-j","--job",
        metavar="jobID",
        help="Job ID for test",
        type=str,
        required=True,
        default=None)
        
    # ECU to test
    dargs.add_argument("-t","--test", \
        help="Type of test: %s"%TEST_TYPE_STRING,
        required=True,
        choices=VALID_TEST_TYPES,
        default=None)
        
    # Destination directory
    dargs.add_argument("-d","--dest", \
        help="Directory to save files.",
        required=True,
        default="UserData")
    
    return

# Command line handler for copier
def cli_copier(subparser):
    copier=subparser.add_parser(CLIST_COPY, \
        help="Copy user data from source")
    cargs=copier.add_argument_group("Arguments for copier")
    
    # Job ID
    cargs.add_argument("-j","--job",
        metavar="jobID",
        help="Job ID for test",
        type=str,
        required=True,
        default=None)
        
    # Type of test
    cargs.add_argument("-t","--test", \
        help="Type of test: %s"%TEST_TYPE_STRING,
        required=True,
        choices=VALID_TEST_TYPES,
        default=None)
        
    # Destination directory
    cargs.add_argument("-d","--dest", \
        help="Directory to save files.",
        required=True,
        default="UserData")
    
    return

# Command line handler for getting user input file
def cli_get_input(subparser):
    copier=subparser.add_parser(CLIST_GET, \
        help="Get user input JSON")
    cargs=copier.add_argument_group("Arguments for getting user input")
    
    # Job ID
    cargs.add_argument("-j","--job",
        metavar="jobID",
        help="Job ID for test",
        type=str,
        required=True,
        default=None)
    
    # Destination directory
    cargs.add_argument("-d","--dest", \
        help="Directory to save files.",
        required=True,
        default="UserData")
    
    return

# Command line interface
# options:
#     - download: Download files uploaded by user
#     - copy: Copy files from path shared by user
#     - get: Get user input from cloud
def cli_handler_main():
    parser = argparse.ArgumentParser()
    subparser=parser.add_subparsers(title="Actions",
        help="List of valid actions",
        dest="actions" )
    
    # Add argument parser for downloader
    cli_downloader(subparser)
    
    # Add argument parser for copier
    cli_copier(subparser)
    
    # Add argument parser for user input
    cli_get_input(subparser)
    
    # Parse arguments
    args = parser.parse_args()
    arguments=list()

    if args.actions == CLIST_DOWNLOAD:
        arguments.append(args.job)
        arguments.append(args.test)
        arguments.append(args.dest)
    elif args.actions == CLIST_COPY:
        arguments.append(args.job)
        arguments.append(args.test)
        arguments.append(args.dest)
    elif args.actions == CLIST_GET:
        arguments.append(args.job)
        arguments.append(args.dest)
    else:
        # Unknown action type
        pass
    
    return args.actions,arguments

# Get input JSON file; Download files uploaded by user for test type
def main():
    action,arguments=cli_handler_main()
    # Check type of action
    if action == CLIST_DOWNLOAD:
        # Arguments = [job,test,dest]
        if download_user_data(arguments[0],arguments[1],arguments[2]):
            logger.info("Successfully processed user inputs!!!")
        else:
            logger.error("Failed to process user inputs!!!")
            sys_exit(WEB_PROCESS_ERROR)
    elif action == CLIST_COPY:
        # Arguments = [job,test,dest]
        if copy_user_data(arguments[0],arguments[1],arguments[2]):
            logger.info("Successfully copied user data!!!")
        else:
            logger.info("Failed to copy user data!!!")
            sys_exit(WEB_COPY_ERROR)
    elif action == CLIST_GET:
        # Arguments = [job,dest]
        if download_user_input(arguments[0],arguments[1]):
            logger.info("Successfully downloaded user input!!!")
        else:
            logger.info("Failed to get user input!!!")
            sys_exit(WEB_GET_ERROR)
    else:
        logger.error("Undefined action type: %s" % action)
        sys_exit(WEB_UNDEFINED_ERROR)
    return

# Get config file path from user input
# Arguments:
#     testtype: Type of test
#     fileinput: path to user input JSON file
# Return: Path to configuration entered by user
def get_config_path(testtype,fileinput):
    retval=None
    logger.info("Get config path from user input!!!")
    logger.debug("Test: %s\t File: %s"%(testtype,fileinput))

    # Check if file path is valid
    if os.path.exists(fileinput) and fileinput.endswith(".json"):
        try:
            # Load inputs from JSON file
            user_input=None
            # user_input = json.loads(fileinput)
            with open(fileinput,"r") as f:
                user_input = json.load(f)
            if user_input is not None:
                # Get path specified by user for test type
                if is_test_enabled(user_input,testtype):
                    logger.debug("Test is enabled. Get config file path.")
                    # Get key to get user input from reference table
                    _key=UI_TEST_INPUT_KEYS[testtype][0]
                    # Get path input by user
                    retval=user_input[UIK_TEST_DATA][testtype][_key]
                else:
                    retval=None
                    logger.info("Test for %s is disabled." % testtype)
            else:
                logger.error("Invalid data in JSON file.")
        except Exception as e:
            logger.exception("Exception when loading user input: %s"%e)
    else:
        retval=None
        logger.error("Did not find input JSON file: %s"%fileinput)
    return retval

# Handle if executed as main script
if __name__ == "__main__":
    logger.info("-"*80)
    main()
    logger.info("-"*80)

# End of File -----------------------------------------------------------------
