# -*- coding: utf-8 -*-

'''
Created by: ASEMPON
Date: 11-07-2022
Desc: 1. Download Artifacts from Jfrog and extract
      2. Download NW Extracts such as arxml from Diagnostic portal

Usage:
    artifactory_handler.exe -e LRR -r B5 -n LRR -v 22_17_00 -f LRR_GEN6_v22.18.33_vecu_v1_BROP-B5 -d C:\\BITS\\General -p LRR_GEN6_v22.18.33_vecu_v1_BROP-B5 -o 2
'''
# ------------------------------------------
# importing necessary modules
import requests, zipfile, io
import os
import argparse
import subprocess
import shutil

from Logger import LogHandler
from artifactory import ArtifactoryPath
from tqdm import tqdm
from zipfile import ZipFile

from exit_handler import sys_exit
from exit_handler import AUTHENTICATION_ERROR
from exit_handler import FILENAME_ERROR
from exit_handler import UPLOAD_ERROR
from exit_handler import FORMAT_ERROR
from exit_handler import OUTPUTDIR_ERROR
from exit_handler import APP_ERROR
from exit_handler import INVALID_ERROR
from exit_handler import DOWNLOAD_ERROR
from exit_handler import EXTRACTION_ERROR

# ------------------------------------------

# comman file with comman functions
from common import extract_7zip

# ECU Extract with STAR_3
from common import ECU_WITH_EXTENSIONS_DICT

# Private Data dict 
_arxmldata = {
    "STATUS": "SUCCESS",
    "ECU_Name": "BC",
    "NCD_Selection": "22_05",
    "ECU_Type": "Physical_ECU/Virtual ECU",
    "Document_Name": "BC_STAR_35",
    "Container_Name": "NET_S3_BC",
    "Document_Type": "ECU_EXTRACT"
}

# Constants
DOWNLOAD_SUCCESS = 0
DOWNLOAD_FAIL = 1
JFROG = 1
DIAG_PORTAL = 2
BOTH = 3

# URL standard path
url = "https://jfrogedc.gsep.daimler.com/artifactory/VirtualTesting-vECUTesting/vECUs-delivery-and-tests/"

# JFrog Constant
artifactory = "https://jfrogedc.gsep.daimler.com/ui/login/"
zipfile_loc = "C:\\BROP\\NTS\\Test1.zip"
USER_NAME = "asempon"
LOGIN_PW = "Itsmeaasai@123"

# Diagnostic portal Constant
DIAGCON_LOAD_TIME = 25
TIMEOUT_DOWNLOAD_ODXD = 3 * 60

# Diagcon.exe path
DIAGCON_PATH = 'C:/Program Files (x86)/DiagCon/DiagConCmd.exe'

# ------------------------------------------
# Loggers ---------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)


def log_debug(msg=''):
    logger.debug(msg)
    return


def log_info(msg=''):
    logger.info(msg)
    return


def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return


def log_error(msg=''):
    logger.error(msg)
    return


# Command line interface
def cli_handler():
    parser = argparse.ArgumentParser()
    # ECU to test
    parser.add_argument("-e", "--vECU", \
                        help="Name of ECU to be tested",
                        required=True,
                        default=None)

    # ECU version
    parser.add_argument("-r", "--rel", \
                        help="Release Version of ECU",
                        required=True,
                        default=None)

    # NW extract name
    parser.add_argument("-n", "--nw", \
                        help="Name of the Network extract to be downloaded",
                        required=True,
                        default=None)

    # NCD version
    parser.add_argument("-v", "--version", \
                        help="NCD Version of ECU",
                        required=True,
                        default=None)

    # Filename
    parser.add_argument("-f", "--filename", \
                        help="find the file to download",
                        required=True,
                        default=None)

    parser.add_argument("-p", "--password", \
                        help="password to unzip the file",
                        required=True,
                        default=None)

    # Destination Folder
    parser.add_argument("-d", "--dest", \
                        help="Destination Folder to copy files",
                        required=True,
                        default=None)

    # Destination Folder
    parser.add_argument("-o", "--option", \
                        help="1. Download from Jfrog\
              2. Download from Diagnostic portal\
              3. Download from Jfrog and DP",
                        required=True,
                        default=3)

    # Parse arguments
    args = parser.parse_args()
    return args.vECU, args.rel, args.nw, args.version, args.filename, args.dest, args.password, args.option


class JfrogArtifactory:
    def __init__(self):
        pass

    def set_url(self, ecu, rel, fname):
        # Function to set dynamic url based on user input
        temp = url + str(rel) + "/" + str(ecu) + "/" + str(fname) + ".zip"
        return temp

    def get_filename(self, url):
        # Split URL to get the file name
        retval = url.split('/')[-1]
        return retval

    def get_filename_wo_extension(self, url):
        retval = None
        basename = None
        filename = None
        try:
            basename = os.path.basename(url)
            filename = basename
            retval = os.path.splitext(filename)[0]
        except Exception as e:
            log_exception("Exception occured ", e)
            sys_exit(FILENAME_ERROR)

        return retval

    def upload_artifacts(self):
        # Function to deploy results into artifactory
        path = ArtifactoryPath(url, auth=(USER_NAME, LOGIN_PW))
        try:
            # deploy package into artifactory
            path.deploy_file(zipfile_loc)
        except Exception as e:
            log_exception("Problem while deploying ", e)
            sys_exit(UPLOAD_ERROR)

    # Downloading the file by sending the request to the URL
    def download_artifacts(self, url, pw, dir):
        log_info("JFROG Authentication In progress")
        retval = False
        resp = None
        try:
            resp = requests.get(url, auth=(USER_NAME, LOGIN_PW), stream=True)
            if resp.ok:
                log_info("JFROG Authentication successful")
                log_info("JFROG Downloading In progress: %s" % url)

                # Get filename and create filepath
                _name = url.split('/')[-1]
                full_name = os.path.join(dir, _name)
                # Download and save to file
                with open(full_name, 'wb') as f:
                    for chunk in resp.iter_content(chunk_size=2 * 1024):
                        if chunk:  # filter out keep-alive new chunks
                            f.write(chunk)
                log_info("Download complete!")
                log_debug("Downloaded: %s" % full_name)

                # Extract file
                if extract_7zip(full_name, dir, pw):
                    retval = True
                else:
                    retval = False
            else:
                retval = False
                log_exception("JFROG Authentication Failure ", resp.status_code)
                sys_exit(AUTHENTICATION_ERROR)

        except Exception as e:
            log_exception("Error while trying to connect JFROG", e)

        return retval

    def extract_zip(self, url, resp, pw, out_dir):
        log_info("Extracting: %s" % str(self.get_filename(url)))
        retval = False
        z = None

        try:
            # if compression type is unsupported artifacts couldn't be downloaded
            z = zipfile.ZipFile(io.BytesIO(resp.content))
        except Exception as e:
            log_exception("Exception while extract ", e)
            sys_exit(FORMAT_ERROR)

        if os.path.isdir(out_dir):
            if os.path.isdir(out_dir + '/' + self.get_filename_wo_extension(url)) is False:
                for file in tqdm(iterable=z.namelist(), total=len(z.namelist())):
                    if (pw is not None) or (pw != "none" or "None"):
                        z.extractall(str(out_dir), members=None, pwd=str(pw).encode())
                        retval = True
                    else:
                        z.extractall(str(out_dir), members=None, pwd=None)
                        retval = True
            else:
                log_info("Already extraction is done")
                retval = True
        else:
            log_exception("Specified path is invalid: ", os.path.isdir(out_dir))
            sys_exit(OUTPUTDIR_ERROR)

        return retval


class DiagPortal:
    def __init__(self):
        pass

    def update_dict(self, vecu, ncd_version):
        """Update the data dict based on user inputs"""

        if "ECU_Name" in _arxmldata:
            _arxmldata["ECU_Name"] = vecu

        if "NCD_Selection" in _arxmldata:
            _arxmldata["NCD_Selection"] = ncd_version

        if "Document_Name" in _arxmldata:
            if vecu in ECU_WITH_EXTENSIONS_DICT.keys():
                _arxmldata["Document_Name"] = ECU_WITH_EXTENSIONS_DICT[vecu]
            else:
                _arxmldata["Document_Name"] = None
                
        if "Container_Name" in _arxmldata:
            _arxmldata["Container_Name"] = "NET_S3_" + vecu

        return True

    def find_file_path(self, filename):
        """ Return the xml directory with file name"""
        # variable to store the diagconxml file path
        diagconfile = None
        # get the current working directory
        filedir = os.getcwd()

        for root, dirs, files in os.walk(filedir):
            for name in files:
                # As we need to get the provided python file,
                # comparing here like this
                if name == filename:
                    diagconfile = os.path.abspath(os.path.join(root, name))

        return diagconfile

    def ecu_extract_downloader(self, dest):
        """ Function to handle arxml download """

        # status variable to show the download 
        dw_flag = None
        resp = None

        # setting NCD details
        km_details = str(_arxmldata['NCD_Selection'])
        km_details = km_details.partition('_')
        relver = (km_details[2].partition('_'))[0]
        subver = (km_details[2].partition('_'))[2]

        container_name = str(_arxmldata['Container_Name'])
        document_type = str(_arxmldata['Document_Type'])
        # concatenate the version details
        version_details = "".join(('20', km_details[0])) + '.' + relver + '.' + subver

        file_name = str(_arxmldata['Document_Name'])
        program = '  "' + DIAGCON_PATH + '"  -download -documentType "' + document_type + '" -containername "' + \
                  container_name + '" -version "' + version_details + '" -documentname "' + file_name + \
                  '"  -directory  "' + dest + '"   '

        try:
            # For arxml file download
            # method run used to run new codes and applications by creating new processes.
            log_info("ARXML Download In progress")
            log_debug("ARXML command: %s" % program)
            resp = subprocess.run(program, shell=True)

            if resp.returncode == DOWNLOAD_SUCCESS:
                dw_flag = True
            else:
                # If returncode is non-zero, raise a CalledProcessError.
                dw_flag = False
                sys_exit(DOWNLOAD_ERROR)

        except Exception as e:
            dw_flag = False
            log_exception("Error occurred during arxml download", e)
            sys_exit(DOWNLOAD_ERROR)

        return dw_flag

    def odx_downloader(self, odx_ver, odx_name, odx_schema, dest):
        """ Function to handle odx file download """
        # Function variables
        odx_flag = None
        resp = None

        # ODX-D Constants
        # document type
        doc_type = "ODX-D"
        # odx version
        odx_version = odx_ver
        # odx container name
        container_name = odx_name

        # odx download command with arguments
        odx_program = '  "' + DIAGCON_PATH + '"  -download -documentType "' + doc_type + '" -containerName "' + \
                      container_name + '" -schema "' + odx_schema + '" -version "' + odx_version + \
                      '"  -directory  "' + dest + '"   '
        try:
            # For ODX file download
            log_info("Downloading ODX-D...")
            log_debug("ODX command: %s" % odx_program)
            resp = subprocess.run(odx_program, shell=True)

            if resp.returncode == DOWNLOAD_SUCCESS:
                odx_flag = True
                log_info("Downloaded ODX-D")
            else:
                # If returncode is non-zero, raise a CalledProcessError.
                odx_flag = False
                log_error("ODX-D File download failed")
                sys_exit(DOWNLOAD_ERROR)

            # Extract odx from downloaded pdx file
            self.extract_odx_file(container_name, odx_version, dest)

        except Exception as e:
            odx_flag = False
            log_exception("Error occurred during odx download", e)
            sys_exit(DOWNLOAD_ERROR)

        return odx_flag

    def cdd_downloader(self, cdd_name, cdd_version, dest_folder):
        """ Function to handle cdd file download """

        # CDD Params
        document_type = "CDD"
        # destination folder
        dest = dest_folder
        # document name
        doc_name = cdd_name
        container_name = cdd_name
        # version of cdd
        version_details = cdd_version
        # Function variables
        cdd_flag = None
        resp = None

        # diagcon execution command with arguments
        program = '  "' + DIAGCON_PATH + '"  -download -documentType "' + document_type + '" -containername "' + \
                  container_name + '" -version "' + version_details + '" -documentname "' + doc_name + \
                  '"  -directory  "' + dest + '"   '

        try:
            # For CDD file download
            # method run used to run new codes and applications by creating new processes.
            log_info("CDD Download In progress")
            log_debug("CDD command: %s" % program)
            resp = subprocess.run(program, shell=True)

            if resp.returncode == DOWNLOAD_SUCCESS:
                cdd_flag = True
            else:
                # If returncode is non-zero, raise a CalledProcessError.
                cdd_flag = False
                sys_exit(DOWNLOAD_ERROR)

        except Exception as e:
            cdd_flag = False
            log_exception("Error occurred during cdd download", e)
            sys_exit(DOWNLOAD_ERROR)

        return cdd_flag

    def extract_odx_file(self, containername, odx_ver, dest_folder):
        """ Function to extract odx file from pdx file"""

        # function variables
        resp = None
        pdx_file = None
        odx_file = None
        fname = None
        l_index = 0
        odx_files_wo_ext = []
        odx_ext = ".odx-d"
        pdx_ext = ".pdx"
        path_str = '\\'
        temp_path = dest_folder + "\\temp"

        # form odx name to search odx file
        odx_name = containername + '_' + odx_ver
        try:
            # find the pdx file
            pdx_file = [x for x in os.listdir(dest_folder) if x.endswith(pdx_ext)]

            # extract the pdx file
            resp = ZipFile(dest_folder + path_str + pdx_file[0]).extractall(temp_path)
            log_info("Extract PDX to get ODX file")

            # Remove the unwanted files in temp path
            odx_file = [f for f in os.listdir(temp_path) if not (f.endswith(odx_ext))]
            for f in odx_file:
                os.remove(os.path.join(temp_path, f))
            log_debug("Temp folder cleanup %s" % temp_path)

            # find the correct file based on odx name
            odx_files = os.listdir(temp_path)

            for f in odx_files:
                odx_files_wo_ext.append(f.strip(odx_ext))

            for odx_file in odx_files_wo_ext:
                if odx_file == odx_name:
                    fname = odx_files[l_index]
                    break
                l_index += 1

            # move odx file to dest_folder before clean-up
            shutil.move(temp_path + path_str + fname, dest_folder)
            log_info("ODX-D File %s extracted and placed in %s directory" % (fname, dest_folder))

            # remove other odx files
            for f in os.listdir(temp_path):
                final = temp_path + path_str + f
                os.remove(final)
            # remove temp directory
            os.rmdir(temp_path)

        except Exception as e:
            log_exception("Exception occurred while finding odx file", e)
            sys_exit(EXTRACTION_ERROR)

        return


if __name__ == '__main__':
    pass
    # getting the user inputs through cli
    # ecu, ecu_ver, nw_ext, ncd_ver, file_name, dest_dir, ex_pw, option = get_json_info()
    # ecu, ecu_ver, file_name, ex_pw, dest_dir = get_json_info()
    # option = '1'

    # # obj for JfrogArtifactory & DiagPortal
    # obj_jfrog = JfrogArtifactory()
    # obj_dp = DiagPortal()

    # # It works if user selects only Jfrog or Jfrog & DP
    # # Option : 1 & 3
    # if int(option) is JFROG or int(option) is BOTH:
    #     # set url to download package from jfrog
    #     url = obj_jfrog.set_url(ecu, ecu_ver, file_name)

    #     # Function to handle download
    #     if obj_jfrog.download_artifacts(url, ex_pw, dest_dir) is True:
    #         log_info("Downlaod artifacts completed")
    #     else:
    #         log_info("Downlaod artifacts failed")

    # # It works if user selects only DP or Jfrog & DP
    # # Option : 2 & 3
    # elif int(option) is DIAG_PORTAL or int(option) is BOTH:
    #     if obj_dp.update_dict(nw_ext, ncd_ver) is True:
    #         log_info("Dict Update completed")

    #         if obj_dp.ecu_extract_downloader() is True:
    #             log_info("ECU Extract download Completed")
    #         else:
    #             log_error("ECU Extract download Failed")
    #     else:
    #         log_error("Dict Update Failed")

    # else:
    #     # To Handle invalid input
    #     log_info("Invalid option: please input valid")
    #     sys_exit(INVALID_ERROR)
