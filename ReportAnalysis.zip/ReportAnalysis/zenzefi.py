'''
Created by: ASEMPON
Date: 17-08-2022
Desc: 1. Functions to handle Zenzefi Login & Logout automatically

Usage:
    python Zenzefi_REST.py --uid username --pw localpwinbase64 --o login
    python Zenzefi_REST.py --uid username --pw localpwinbase64 --o logout
'''

# -----------------------------
# Imports

import json
import os
import argparse
import requests
import urllib3

from Logger import LogHandler
from exit_handler import sys_exit
from exit_handler import LOGIN_ERROR
from exit_handler import LOGOUT_ERROR

# -----------------------------
# Constants

headers = {
    'accept': '*/*',
    'Locale': 'en',
}

json_data = {
    'userName': 'username',
    'userPassword': 'localpwinbase64',
}

# Status code
SUCCESS = 200
ERROR = 406
ALREADY_LOGIN = 412
EXCEPTION = 500

LOGIN = 'login'
LOGOFF = 'logout'
RESET = 'reset'
VALID_INPUTS = [LOGIN, LOGOFF, RESET]

# String of options
INPUT_TYPE_STRING = " | ".join(VALID_INPUTS)

# -------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)


def log_debug(msg=''):
    logger.debug(msg)
    return


def log_info(msg=''):
    logger.info(msg)
    return


def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return


def log_error(msg=''):
    logger.error(msg)
    return


def cli():
    parser = argparse.ArgumentParser()

    parser.add_argument("--uid", help="Enter User ID", required=True, default='None')
    parser.add_argument("--pw", help="Enter Local Password in Base64 format", required=True, default='None')
    parser.add_argument('-o', "--option",
                        metavar="VALID_TYPE",
                        type=str,
                        choices=VALID_INPUTS,
                        help="Type of input: %s" % INPUT_TYPE_STRING,
                        required=True)

    args = parser.parse_args()
    return args.option, args.uid, args.pw


def update_json_data(username, password):
    json_data['userName'] = username
    json_data['userPassword'] = password


def zenzefi_login():
    """
    200: Login success.
    406: Login error.
    412: User already logged in.
    500: Exception message
    :return: None
    """
    ret_code = None 

    try:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        response = requests.post('https://localhost:61000/users/login', headers=headers, json=json_data, verify=False)
        resp_data = json.loads(response.content)
        log_debug(resp_data)

        if response.status_code == SUCCESS:
            log_info("Login Success")
            ret_code = True
        elif response.status_code == ERROR:
            log_info("Login error")
            ret_code = False
        elif response.status_code == ALREADY_LOGIN:
            log_info("User already logged in")
            ret_code = True
        elif response.status_code == EXCEPTION:
            log_info("Exception message")
            ret_code = False
        else:
            log_debug("Unknown code")
            ret_code = False

    except Exception as e:
        log_exception("Exception while login: ", e)
        ret_code = False
    
    return ret_code


def zenzefi_logout():
    ret_code = None

    try:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        response = requests.post('https://localhost:61000/users/logout', headers=headers, verify=False)
       
        if response.status_code == SUCCESS:
            log_info(" Logout success")
            ret_code = True
        else:
            log_debug("Unknown code")
            ret_code = False

    except Exception as e:
        log_exception("Exception while logout: ", e)
        ret_code = False

    return ret_code

def zenzefi_timer_rst():
    """
    Resets the session timeout for the current user session and returns the user details.
    :return: ret_code
    """
    ret_code = None
    try:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        response = requests.post('https://localhost:61000/users/currentUser/timer/reset', headers=headers, verify=False)
        resp_data = json.loads(response.content)
        log_debug(resp_data)
        log_info("Time remaining in seconds")
        log_info(resp_data["remainingSessionSeconds"])

        if response.status_code == SUCCESS:
            log_info("Reset success")
            ret_code = True
        else:
            log_debug("Unknown code")
            ret_code = False

    except Exception as e:
        log_exception("Exception while resetting timer: ", e)

    return ret_code

if __name__ == '__main__':
    # get the user inputs
    opt, uid, pwd = cli()
    # update json data with user inputs
    update_json_data(uid, pwd)

    if 'login' in opt:
        if zenzefi_login() is True:
            log_info("Zenzefi login success")
        else:
            sys_exit(LOGIN_ERROR)
            
    elif 'reset' in opt:
        if zenzefi_timer_rst() is True:
            log_info("Successfully resetted session timeout timer")
        else: 
            log_error("Error occurred during reset")
        
    elif 'logout' in opt:
        if zenzefi_logout() is True:
            log_info("Zenzefi logout success")
        else:
            sys_exit(LOGOUT_ERROR)
