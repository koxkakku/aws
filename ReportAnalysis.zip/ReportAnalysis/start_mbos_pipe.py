# coding: utf-8
"""
Created on 29-Jun-2022
@author: STEPHIG
Desc: Interface for jenkins to start pipeline run
"""

# Imports ---------------------------------------------------------------------
import argparse as ap
from Logger import LogHandler

from mbos import start_pipeline

# Exit handling
from exit_handler import sys_exit
from exit_handler import INIT_PIPELINE_ERROR

# Functions -------------------------------------------------------------------

def cli_handler():
    # Create parser
    parser=ap.ArgumentParser(description="Analyze report from last test")
    
    # Add argument for test type
    parser.add_argument('-p', "--pipe",
        metavar="PIPE_NAME",
        type=str,
        required=True)
    
    args = parser.parse_args()
    
    return args.pipe

def main(logger):
    status=False
    pipeline=cli_handler()
    try:
        logger.info("Start MBOS pipeline.")
        if start_pipeline(pipe_name=pipeline):
            # Pipeline started successfully
            status=True
        else:
            # Failed to start pipeline
            logger.error("Failed to start pipeline.")
            status=False
    except Exception as e:
        logger.exception("Exception while initializing pipeline: %s"%e)
        status=False
    
    # Check status of operation
    if not status:
        sys_exit(INIT_PIPELINE_ERROR)

    return

if __name__=='__main__':
    logger=LogHandler()
    logger.setup()
    logger.info('-'*80)
    main(logger)
    logger.info('-'*80)

# End of file -----------------------------------------------------------------
