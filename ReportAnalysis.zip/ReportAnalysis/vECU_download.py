# coding: utf-8
"""
Created on 07-Jul-2022
@author: VIVKULK,STEPHIG
Desc: Download files related to ECU from MBOS portal
Usage:
    python vECU_download.py -e CIC -d Database

NOTE: 
Currently it only copies DLL files. So this will work for Vector vECUs only.

"""

# Imports ---------------------------------------------------------------------
import os
import argparse
from datetime import datetime as dt

import json
import shutil
import subprocess
import requests
import urllib3
from Logger import LogHandler

# Token master data
from mbos.tokenmaster import PROD_CLIENT_ID
from mbos.tokenmaster import PROD_CODE
from mbos.tokenmaster import CLIENT_TESTING_SERVICE_PROD

from exit_handler import sys_exit
from exit_handler import LOAD_DATA_ERROR
from exit_handler import GET_ECUINFO_ERROR
from exit_handler import INCORRECT_RESP_ERROR 
from exit_handler import INVALID_ECU_ERROR    
from exit_handler import DOWNLOADFILE_ERROR   
from exit_handler import DOWNLOADCOMP_ERROR   
from exit_handler import CLEANUP_ERROR        
from exit_handler import COPYFAIL_ERROR       

# Constants -------------------------------------------------------------------
# Reference file for vECU
REF_MBOS_VECU="Reference/mbos_vECU_reference.json"

# URL for requesting access token
URL_TOKEN="https://ssoalpha.dvb.corpinter.net/v1/token"
URL_ECU_DOWNLOAD="https://ecu.query.api.dvb.corpinter.net/ecus/"

# Token master data
SW_CLIENT_USERNAME=PROD_CLIENT_ID
SW_CLIENT_PWD=PROD_CODE
CLIENT_ID_TESTING_SERVICE=CLIENT_TESTING_SERVICE_PROD

# Reference data for ECUs'
VECU_REFERENCE=dict()

# Path to 7zip exe
SZIP_EXE_PATH='C:\\Program Files\\7-Zip\\7z.exe'
# Constants
DOWNLOAD_SUCCESS = 0
DOWNLOAD_FAIL = 1
# Loggers ---------------------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='',e=''):
    logger.exception("%s: %s"%(msg,e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# End of Loggers --------------------------------------------------------------

# TODO: Get list of files to be downloaded from reference JSON file. Add file 
# types to download based on test type.

# Functions -------------------------------------------------------------------

# Load reference data for ECU applications
def load_reference():
    status = False
    try:
        log_info("Loading vECU reference table: %s" % REF_MBOS_VECU)
        with open(REF_MBOS_VECU,'r') as f:
            global VECU_REFERENCE
            VECU_REFERENCE = json.load(f)
            log_debug("Loaded vECU reference table")
            status = True
    except Exception as e:
        log_exception("Failed to load reference",e)
        sys_exit(LOAD_DATA_ERROR)
    return status

# Get token
def get_token(client_id):
    log_info("Request new token.")
    url = URL_TOKEN
    payload = \
        {
            'grant_type':'client_credentials',
            'client_id':SW_CLIENT_USERNAME,
            'client_secret':SW_CLIENT_PWD,
            'scope':'openid profile groups audience:server:client_id:%s' % \
                (client_id)
                }
    
    headers = {
        'content-type': 'application/x-www-form-urlencoded'
        }
    
    response = requests.post(url, \
                              data=payload, \
                              headers=headers \
                              )
    resp_json = response.json()
    
    if response.ok:
        token = 'Bearer '+ resp_json["access_token"]
    else:
        token=None
    return token

# Get ECU information from reference file based on name of ECU
# Return: List of parameters:
#   Index 0: Application ID (same as MBOS portal)
def get_ecu_download_info(name):
    retval=None
    try:
        if name in VECU_REFERENCE.keys():
            # Found ECU
            log_debug("Found ECU information for %s"%name)
            retval = VECU_REFERENCE[name]
        else:
            log_error("ECU not defined in reference list: %s"%name)
    except Exception as e:
        log_exception("Exception when trying to get ECU information",e)
        sys_exit(GET_ECUINFO_ERROR)
    return retval

# Check if component has to be downloaded
def confirm_component_download(component):
    confirm = False
    name = component['name']
    if (('sil' in name) and ('woPW' not in name)) \
        or ('vECU' in name):
        confirm=True
    elif name.endswith('.arxml') \
        or name.endswith('.odx-d'):
        confirm=True
    return confirm

# Get list of components to be downloaded
def get_download_list(token,ecu_name,version):
    download_list=list()
    log_info("Get list of components to download")
    # Get ECU information
    ecu_info = get_ecu_download_info(ecu_name)
    if ecu_info is not None:
        # Assemble data for request
        url='%s/%s/versions/%s'%(URL_ECU_DOWNLOAD,ecu_info[0],version)
        l_headers = {'Authorization': token}
        http_proxy = 'http://proxy-sifi.rd.corpintra.net:3128'
        https_proxy = "http://proxy-sifi.rd.corpintra.net:3128"
        proxydata = {"http": http_proxy, "https": https_proxy}
        
        # Request
        r = requests.get(url, headers=l_headers, proxies=proxydata)
        
        # Handle response
        if r.ok:
            # process list of components
            components = r.json()['components']
            for component in components:
                if confirm_component_download(component):
                    download_list.append(component)
            # Log list of files to download
            names_list=[component["name"] for component in download_list]
            names=", ".join(names_list)
            log_debug("Components to download: %s" % names)
        else:
            # Incorrect response; Failed to download
            log_error("Get list to download: Invalid response: %s" \
                % (str(r.status_code)) )
            log_error("Failure response: %s" % str(r.text))
            sys_exit(INCORRECT_RESP_ERROR)
    else:
        # Invalid ECU information
        log_error("ECU information was not found in reference table.")
        sys_exit(INVALID_ECU_ERROR)

    return download_list

# Extract 7zip file
def extract_file(filename,directory,password):
    status = False
    sub_resp = None
    l_filename = filename.split('/')[1]
    log_info("Extract %s to %s:"%(filename,directory))
    
    # changing dir to copy the downloaded contents
    os.chdir(directory)
    
    # command to extract the files
    program = '"%s" e "%s" -o"%s" -p"%s" -y' % (SZIP_EXE_PATH, l_filename, directory, password)
    log_debug(program)

    # run the subprocess to execute the program cmd
    sub_resp = subprocess.run(program, shell=True)
    
    # if returncode is non-zero, unsuccessful
    if sub_resp.returncode == DOWNLOAD_SUCCESS:
        status = True
        log_info("7z Download and extraction completed")
    else:
        # If returncode is non-zero, raise a CalledProcessError.
        status = False
        log_error("7z Download and extraction failed")

    return status

# Download file from URL
def download_file(url,fname):
    retval = False
    log_info("Downloading: %s"%fname)
    # proceed to download file
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    resp = requests.get(url=url,stream=True,verify=False)

    # Check for valid response
    if resp.ok:
        with open(fname,'wb') as f:
            for chunk in resp.iter_content(chunk_size=2*1024): 
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)
        log_debug("Download complete!")
        retval = True
    else:
        log_error("Download failed. Response code: %s" % (resp.status_code))
        sys_exit(DOWNLOADFILE_ERROR)

    return retval

# Download component
def download_component(token,component,ecu_name,version,dirname,pwrd):
    retval = False
    comp_id = component['id']
    l_header = {'Authorization': token}
    http_proxy = 'http://proxy-sifi.rd.corpintra.net:3128'
    https_proxy = "http://proxy-sifi.rd.corpintra.net:3128"
    proxydata = {"http": http_proxy, "https": https_proxy}
    try:
        ecu_info = get_ecu_download_info(ecu_name)
        if ecu_info is not None:
            url='%s/%s/versions/%s/components/%s/download' % \
                (URL_ECU_DOWNLOAD,ecu_info[0],version,comp_id)
            resp = requests.get(url,headers=l_header,proxies=proxydata)
            if resp.ok:
                # Get download link
                download_link = resp.headers['Location']
                # Get name of file
                filename=component["name"]
                fname="%s/%s"%(dirname,filename)
                # Download the file
                if download_file(download_link,fname):
                    retval = True
                    if filename.endswith(".zip") or filename.endswith(".7z"):
                        extract_file(fname,dirname,pwrd)
                else:
                    log_error("Failed to download component")
            else:
                log_error("Error while downloading component: \
                    Response code: %s" % (str(resp.status_code)))            
        else:
            # Did not get ECU information
            pass
    except Exception as e:
        log_exception("Exception while downloading component",e)
        sys_exit(DOWNLOADCOMP_ERROR)
    return retval

# copy files to database directory
def copy_to_database(dir_source,dir_dest):
    log_info("Copying files from %s to %s"%(dir_source,dir_dest))
    for root, dirs, files in os.walk(dir_source):
        for file in files:
            if file.endswith(".arxml") \
                or file.endswith(".odx-d") \
                or file.endswith(".vsysvar") \
                or file.endswith(".can") \
                or file.endswith(".xvp") \
                or file.endswith(".cdd") \
                or file.endswith(".dll"):
                file_source=str(root)+'\\'+str(file)
                shutil.copy2(file_source,dir_dest)

    return

# Remove temporary files like downloaded after use
def cleanup(dirname):
    log_info("Cleanup downloads")
    try:
        if os.path.exists(dirname):
            subprocess.check_call(('attrib -R ' + dirname + '\\* /S').split())
            shutil.rmtree(dirname)
    except Exception as e:
        log_exception("Failed to cleanup downloads",e)
        sys_exit(CLEANUP_ERROR)
    return

# Command line interface
def cli_handler():
    parser = argparse.ArgumentParser()
    # ECU to test
    parser.add_argument("-e","--vECU", \
        help="Name of ECU to be tested",
        required=True,
        default=None)
    
    # ECU version
    parser.add_argument("-r","--rel", \
        help="Release Version of ECU",
        required=True,
        default=None)
    
    # Destination Folder
    parser.add_argument("-d","--dest", \
        help="Destination Folder to copy files",
        required=True,
        default='DB')
    
    # Parse arguments
    args = parser.parse_args()
    return args.vECU,args.rel,args.dest

# API -------------------------------------------------------------------------

# Download vECU to database directory
'''
Operation:
    - Load reference table to get download details of ECU.
    - Get bearer token for communication
    - Get list of relevant components to be downloaded for this ECU.
        (arxml,odx-d,zip)
    - Create a new repository with current timestamp to store downloads.
    - Download all components to folder.
    - Move downloaded files to local database directory.
'''
def download_vECU(arg_ecu, arg_ver, arg_dir, arg_pwd):
    ecu_to_test,ecu_ver,dest_dir,zip_pwd = arg_ecu, arg_ver, arg_dir, arg_pwd
    
    log_info("Download vECU components for %s ver: %s"%(ecu_to_test,ecu_ver))
    if load_reference():
        # Get token
        token=get_token(CLIENT_ID_TESTING_SERVICE)
        # Get list of files to be downloaded
        downloads = get_download_list(token,ecu_to_test,ecu_ver)
        
        if len(downloads) > 0:
            # Create new directory for vECU downloads
            time = dt.now().strftime('%m_%d_%Y_%H_%M_%S')
            dirname="vECU_%s_%s"%(ecu_to_test,time)
            if not os.path.exists(dirname):
                os.mkdir(dirname)
            
            # Download components
            download_count = 0
            for component in downloads:
                if download_component(token,component,ecu_to_test, \
                    ecu_ver,dirname,zip_pwd):
                    download_count+=1
            
            # Check if all were files downloaded correctly
            if (download_count == len(downloads)):
                try:
                    # Create destination folder
                    if not os.path.exists(dest_dir):
                        os.mkdir(dest_dir)
                    
                    # Copy downloaded files to folder
                    copy_to_database(dirname,dest_dir)
                except Exception as e:
                    log_exception("Failed to copy downloaded \
                        files to %s"%(dest_dir),e)
                    sys_exit(COPYFAIL_ERROR)
            else:
                log_error("Some files could not be downloaded.")
            
            # cleanup directory
            cleanup(dirname)
            
        else:
            log_error("No files available to download.")
    else:
        # Could not load vECU reference
        pass
    return

if __name__ == '__main__':
    pass
    # log_info('-'*80)
    # try:
    #     download_vECU()
    # except Exception as e:
    #     log_exception("Exception when downloading vECU",e)
    # log_info('-'*80)

# End of File -----------------------------------------------------------------
