"""
Desc: Comman file to store the comman 
functions that are present accross other modules
"""

import os
import requests
import urllib3

from Logger import LogHandler
from exit_handler import sys_exit

from exit_handler import EXTRACTION_ERROR
from exit_handler import FILENAME_ERROR  

# for downloading file 
ENABLE_SSL=False
# Timeout for file download (second)
TIMEOUT_FILE_DOWNLOAD=5*60

# ECU Extract Information ( for reference)
# ECU_STAR3_LIST = ["CAL", "CLT_FL", "INV1", "INV2", "ECM", "PMS", "BMS"]
# ECU_PT_LIST = ["PCCU", "TIC", "CIC", "FP48"]

# Data to update the ecu names whenever requierd 
ECU_WITH_EXTENSIONS_DICT = {
    'CAL' : 'CAL_STAR_3', 
    'CLT_FL' : 'CLT_FL_STAR_3',
    'INV1' : 'INV1_STAR_3',
    'INV2' : 'INV2_STAR_3',
    'ECM' : 'ECM_STAR_3',
    'PMS' : 'PCM_STAR_3',
    'BMS' : 'BMS_STAR_3',
    'PCCU' : 'PCCU_PT4',
    'TIC' : 'TIC_PT4',
    'CIC' : 'CIC_PT4',
    'FP48' : 'FP48_PT4',
    'BAT14': 'BAT14',
    'LRR' : 'LRR_ADAS6',
    'CEIC_C' : 'CEIC_C_STAR_35',
    'CEIC_M' : 'CEIC_M_STAR_35',
    'IDC_M_C' : 'IDC_M_C_STAR_35',
    'CDCC' : 'CDCC_STAR_35',
    'CU' : 'CU_STAR_35',
    'DISP_CDP' : 'DISP_CDP_STAR_35',
    'eATS1.6' : 'eATS1.6_STAR_35',
    'HUD' : 'HUD_STAR_35',
    'MRR' : 'MRR_STAR_35',
    'EPS' : 'EPS_STAR_35',
    'CIVIC VCPU' : 'CIVIC VCPU_STAR_35',
    'LiBB_MMA' : 'LiBB_MMA_STAR_35',
    'BC_MMA' : 'BC_MMA_STAR_35'
}

# Path to 7zip exe
SZIP_EXE_PATH='C:\\"Program Files"\\7-Zip\\7z.exe'

# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='',e=''):
    logger.exception("%s: %s"%(msg,e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# function to extract zip file
def extract_7zip(filename,dest,pwd="None"):
        status=False
        log_debug("Start file extraction: %s to %s; Pwd: %s"%(filename,dest,pwd))
        if os.path.exists(filename):
            try:
                _zip_cmd='%s e "%s" -o"%s" -p"%s" -y' % (SZIP_EXE_PATH,filename,dest,pwd)
                log_debug(_zip_cmd)
                extract_status = os.system(_zip_cmd)
                if (0 == extract_status):
                    log_info("Extraction successful!!")
                    status = True
                else:
                    status=False
                    log_error("Failed to extract file.")
                    sys_exit(EXTRACTION_ERROR)
            except Exception as e:
                log_exception("Exception when trying to extract file: ",e)
                
            finally:
                # Delete the zip file after extraction.
                try:
                    if os.path.isfile(filename):
                        os.remove(filename)
                        log_info("Deleted file: %s"%filename)
                    else:
                        # file not found
                        pass
                except Exception as e:
                    log_exception("Failed to delete file: %s "%(filename),e)
        else:
            log_error("Could not find file to extract.")
            sys_exit(FILENAME_ERROR)

        return status

# Download file from URL
def download_file(token,url,fname):
    retval = False
    logger.info("Downloading: %s"%fname)
    logger.debug("Download URL: %s"%(url))
    # Header for authorization
    head = {'Authorization': 'Bearer %s'%(token)}
    # proceed to download file
    try:
        if not ENABLE_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        resp = requests.get(url=url,headers=head,stream=True, \
            verify=ENABLE_SSL,timeout=TIMEOUT_FILE_DOWNLOAD)
        # Check for valid response
        if resp.ok:
            with open(fname,'wb') as f:
                for chunk in resp.iter_content(chunk_size=2*1024): 
                    if chunk: # filter out keep-alive new chunks
                        f.write(chunk)
            logger.info("Download complete!")
            retval = True
        else:
            logger.error("Download failed. Response code: %s" % (resp.status_code))
    except Exception as e:
        retval = False
        logger.error("Encountered exception when downloading file: %s"%e)
    return retval

if __name__ == "__main__":
    pass

# End of File -----------------------------------------------------------------
