#!/bin/bash

DIR_LOGS="Logs"
DIR_OUTPUT="Output"
PY_CACHE="__pycache__"
# DIR_DIST="dist"
DIR_DB="Database"
DIR_BUILD="build"
DIR_TESTENV="TestEnv"

if [ -d $DIR_LOGS ] 
then
    echo "Deleting $DIR_LOGS"
    rm -rf $DIR_LOGS
fi

if [ -d $DIR_OUTPUT ] 
then
    echo "Deleting $DIR_OUTPUT"
    rm -rf $DIR_OUTPUT
fi

# if [ -d $DIR_DIST ] 
# then
#     echo "Deleting $DIR_DIST"
#     rm -rf $DIR_DIST
# fi

if [ -d $DIR_DB ] 
then
    echo "Deleting $DIR_DB"
    rm -rf $DIR_DB
fi

if [ -d $DIR_TESTENV ] 
then
    echo "Deleting $DIR_TESTENV"
    rm -rf $DIR_TESTENV
fi

if [ -d $DIR_BUILD ] 
then
    echo "Deleting $DIR_BUILD"
    rm -rf $DIR_BUILD
fi

# echo "Deleting Python Cache"
find . -depth -type d -name $PY_CACHE -exec echo "Deleting "{} \;
find . -depth -type d -name $PY_CACHE -exec rm -rf {} \;

# Delete .spec files
find . -depth -type f -name '*.spec' -exec rm -fv {} \;
