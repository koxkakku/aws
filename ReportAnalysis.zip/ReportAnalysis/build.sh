#!/bin/bash

# Constants -------------------------------------------------------------------

LOG="build.log"

# Python files to compile
PY_MBOS_DOWNLOAD="vECU_download.py"
PY_JFROG_DOWNLOAD="artifactory_handler.py"
PY_ECU_DOWNLOAD="download_handler.py"
PY_COPIER="copier.py"
PY_MBOS_PIPE_START="start_mbos_pipe.py"
PY_MBOS_PIPE_SETUP="setup_mbos_pipe.py"
PY_CONFIG_EXTRACTOR="get_user_config.py"
PY_REPORT_GET_ANALYZE="pipe_report_analyzer.py"
PY_ANALYSE_REPORT="analyze.py"
PY_COMPARE_REPORT="compare.py"
PY_ZENZEFI="zenzefi.py"
PY_WEB_UI="web_ui.py"
PY_VMAP_HANDLER="vmap_handler.py"

# Directories for *.exe files
DIR_EXE_SRC="dist"  # EXE will be generated here

# Copy the generated EXE files to the following folder
if [ -z "$1" ]
then
    DIR_EXE_DEST="../EXE"
else
    DIR_EXE_DEST=$1
fi

# Separator text
SEPARATOR=$(printf "%0.s*" {1..80})


# Functions -------------------------------------------------------------------

# Function to move files from source to destination
# Arguments:
#     1: Source
#     2: Destination
move_files()
{
    SRC=$1
    DEST=$2
    echo "Move files from $SRC to $DEST ..."
    
    # Create destination directory if not present
    if ! [ -d $DEST ]
    then
        echo "Creating directory: $DEST"
        mkdir $DEST
    fi

    # Start moving files one at a time
    for file in "$SRC"/*.exe
    do
        echo "$file -> $DEST/$file_to_move"
        file_to_move=$(basename "$file")
        mv $file $DEST/$file_to_move
    done
}


# Execution -------------------------------------------------------------------

# # Compile MBOS download
# echo ""
# echo "$SEPARATOR"
# echo ""
# echo "Building $PY_MBOS_DOWNLOAD..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_MBOS_DOWNLOAD
# echo ""
# echo "$SEPARATOR"
# echo ""

# # Compile Jfrog download
# echo ""
# echo "$SEPARATOR"
# echo ""
# echo "Building $PY_JFROG_DOWNLOAD..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_JFROG_DOWNLOAD
# echo ""
# echo "$SEPARATOR"
# echo ""

# # Compile ECU download handler
# echo ""
# echo "$SEPARATOR"
# echo ""
# echo "Building $PY_ECU_DOWNLOAD..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_ECU_DOWNLOAD
# echo ""
# echo "$SEPARATOR"
# echo ""

# # Compile File copy
# echo ""
# echo "$SEPARATOR"
# echo ""
# echo "Building $PY_COPIER..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_COPIER
# echo ""
# echo "$SEPARATOR"
# echo ""

# # Compile MBOS pipeline start
# echo "Building $PY_MBOS_PIPE_START..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_MBOS_PIPE_START
# echo ""
# echo "$SEPARATOR"
# echo ""

# # Compile MBOS pipeline setup
# echo "Building $PY_MBOS_PIPE_SETUP..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_MBOS_PIPE_SETUP
# echo ""
# echo "$SEPARATOR"
# echo ""

# # Compile pipe report analyzer
# echo "Building $PY_REPORT_GET_ANALYZE..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_REPORT_GET_ANALYZE
# echo ""
# echo "$SEPARATOR"
# echo ""

# # Compile configuration extractor
# echo "Building $PY_CONFIG_EXTRACTOR..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_CONFIG_EXTRACTOR
# echo ""
# echo "$SEPARATOR"
# echo ""

# Compile report analysis tool
echo "Building $PY_ANALYSE_REPORT..."
echo ""
echo "$SEPARATOR"
echo ""
pyinstaller --onefile $PY_ANALYSE_REPORT
echo ""
echo "$SEPARATOR"
echo ""

# Compile report comparison tool
echo "Building $PY_COMPARE_REPORT..."
echo ""
echo "$SEPARATOR"
echo ""
pyinstaller --onefile $PY_COMPARE_REPORT
echo ""
echo "$SEPARATOR"
echo ""

# # Compile zenzefi handler
# echo "Building $PY_ZENZEFI..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_ZENZEFI
# echo ""
# echo "$SEPARATOR"
# echo ""

# # Compile web UI handler
# echo "Building $PY_WEB_UI..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_WEB_UI
# echo ""
# echo "$SEPARATOR"
# echo ""

# # Compile VMAP handler
# echo "Building $PY_VMAP_HANDLER..."
# echo ""
# echo "$SEPARATOR"
# echo ""
# pyinstaller --onefile $PY_VMAP_HANDLER
# echo ""
# echo "$SEPARATOR"
# echo ""

# Move from dist to expected folder
echo "Moving..."
echo ""
echo "$SEPARATOR"
echo ""
move_files $DIR_EXE_SRC $DIR_EXE_DEST
echo ""
echo "$SEPARATOR"
echo ""

# Post build cleanup
echo "Cleaning..."
echo ""
echo "$SEPARATOR"
echo ""
./clean.sh

if [ -d $DIR_EXE_SRC ] 
then
    echo "Deleting $DIR_EXE_SRC"
    rm -rf $DIR_EXE_SRC
fi

echo ""
echo "$SEPARATOR"
echo ""

echo "Build Complete!!!"

# End of file -----------------------------------------------------------------
