# -*- coding: utf-8 -*-
"""
Created on Mon Dec 13 10:45:03 2021

@author: STEPHIG

- Create a log file
- Update events, errors, debug messages in log.
"""

import logging
import os
import time

# Log directory
LOGS_DIR="Logs"
# main logger
LOG_PROJECT_MAIN = "main"
# Name of log file
LOG_FILENAME = "app"

# Enable logging to separate files for every new run
ENABLE_SEGREGATED_LOGS=True

# log levels for handlers
LOG_LEVEL_MAIN = logging.DEBUG
LOG_LEVEL_STREAM = logging.INFO
LOG_LEVEL_FILE = logging.DEBUG

# Log Handler Class ----------------------------------------------------------

'''
Usage:
    - First creation:
        - Do not pass any arguments during this. (name must be None)
        - Execute setup() function to initialize handlers and file
    - For creating further objects of this class in other files you can 
    directly pass strings as argument. DO NOT call setup() in these.
'''

class LogHandler:
    def __init__(self,name=None):
        if name is not None:
            self.logger = logging.getLogger("%s.%s"%(LOG_PROJECT_MAIN,name))
        else:
            # only in main.py
            self.logger = logging.getLogger(LOG_PROJECT_MAIN)
        return
    
    # set log format, handlers
    # NOTE: To be executed ONLY ONCE; ideally in main.py
    def setup(self):
        # initialize logging
        self.logger = logging.getLogger(LOG_PROJECT_MAIN)
        self.logger.setLevel(LOG_LEVEL_MAIN)
        
        # Create log directory
        if not os.path.exists(LOGS_DIR):
            os.makedirs(LOGS_DIR)
        
        # create file handler
        if ENABLE_SEGREGATED_LOGS:
            # Create filename for log file by merging local time and default filename
            ltime = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
            fname = "%s_%s.log"%(LOG_FILENAME,ltime)
        else:
            fname = "%s.log"%(LOG_FILENAME)
        
        file_handler = \
            logging.FileHandler(os.path.join(LOGS_DIR,fname), mode='a')
        # set log level
        file_handler.setLevel(LOG_LEVEL_FILE)
        # Set formatter
        file_format = \
            logging.Formatter( \
                  fmt= \
                  '%(asctime)s -\t%(name)s -\t%(levelname)s -\t%(message)s', \
                  datefmt=('%d-%m-%Y %H:%M:%S') )
        file_handler.setFormatter(file_format)
        
        # Stream handler
        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(LOG_LEVEL_STREAM)
        stream_format = \
            logging.Formatter( \
                  fmt= \
                  '%(asctime)s -\t%(levelname)s -\t%(message)s', \
                  datefmt=('%d-%m-%Y %H:%M:%S') )
        stream_handler.setFormatter(stream_format)
        
        # add handlers to logger
        self.logger.addHandler(file_handler)
        self.logger.addHandler(stream_handler)
        return
    
    def critical(self,msg):
        return self.logger.critical(msg)
    
    def debug(self,msg):
        return self.logger.debug(msg)
    
    def error(self,msg):
        return self.logger.error(msg)
    
    def exception(self,msg):
        return self.logger.exception(msg)
    
    def info(self,msg):
        return self.logger.info(msg)
    
    def warning(self,msg):
        return self.logger.warning(msg)

# End of Log Handler Class ---------------------------------------------------


if __name__ == "__main__":
    pass

# End of File ----------------------------------------------------------------
