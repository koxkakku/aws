Aim: Extract information from XML reports for NEST,NTS,DiVA,GWD,TLS tests.

Phase 1: Extract test overview and fail case information to excel sheet(only NEST test).
Phase 2: Scale up excel test summary generation for all test types.
Phase 3: Report Analysis
    1. Store necessary test data from all releases to a database.
    2. Comparison of data from multiple releases for NEST.
    3. Comparison of data from multiple releases for other test types. 

-------------------------- Phase 1 ---------------------------------------------

XMLHandler:
    API to read (parse) XML report and extract tags, attributes, values etc.

ReportHandler: (Each test type has a different report handler)
    API to extract necessary data from report into memory.

DataExtractor: (Common for all test types)
    API to get specific parameters from extracted data.

ExcelHandler:
    API to add information to Excel sheet.

NESTReportConsolidator:
    Gather necessary data from report and add to excel sheet(or Database).


--------------------------- Consolidation --------------------------------------

XMLHandler                          ExcelHandler
    |                                   |
ReportHandler                           |
    |                                   |
DataExtractor                           |
    |                                   |
ReportAnalysis                          |
    |                                   |
    |_____________      ________________|
                  |    |
            ReportConsolidator


-------------------------------- Comparison ------------------------------------

XMLHandler                          ExcelHandler
    |                                   |
ReportHandlers                          |
    |                                   |
DataExtractor                           |
    |                                   |
compare                                 |
    |                                   |
    |_____________      ________________|
                  |    |
            ComparisonXLGenerator

--------------------------------------------------------------------------------

---------------------------------- Usage ---------------------------------------

Analyze report file:
    python analyze.py -i <TesReport.xml> -t <TestType> -u
    python analyze.py --input <TesReport.xml> --type <TestType> --upload

    For example:
    python analyze.py -i Data\NTS\CIVIC_NTS1.xml -t NTS -u

Compare multiple report files:
    python compare.py -i <TesReport1.xml> <TesReport2.xml> <TesReport3.xml> -t <TestType>
    python compare.py --input <TesReport1.xml> <TesReport2.xml> <TesReport3.xml> --type <TestType>

    For example:
    python compare.py -i Data\NTS\CIVIC_NTS1.xml Data\NTS\CIVIC_NTS2.xml Data\NTS\CIVIC_NTS3.xml -t NTS

--------------------------------------------------------------------------------

-------------------------------- Libraries -------------------------------------
List of libraries used:
    - os
    - json
    - argparse
    - re
    - xml
    - requests
    - urllib3
    - shutil
    - openpyxl
    - zipfile

--------------------------------------------------------------------------------
