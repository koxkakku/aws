# -*- coding: utf-8 -*-
"""
Created by: ASEMPON
Date: 16-08-2022
Desc: File to handle downloading process

CLI: python download_handler.py -testtype NTS -j jsonfilepath -d destinationfolder
"""
# ------------------------------------------
# imports section

import json
import os
import argparse
import time

# Decryption
from base64 import b64decode
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2 

from Logger import LogHandler

# common functions
from common import extract_7zip

from artifactory_handler import JfrogArtifactory
from artifactory_handler import DiagPortal
from vECU_download import download_vECU

from exit_handler import sys_exit
from exit_handler import JSON_LOAD_ERROR
from exit_handler import EXTRACTION_ERROR
from exit_handler import OUTPUTDIR_ERROR
from exit_handler import FILENAME_ERROR

from ReportAnalysis.common import ECU_TEST_TYPE_NEST
from ReportAnalysis.common import ECU_TEST_TYPE_DIVA
from ReportAnalysis.common import VALID_TEST_TYPES
from ReportAnalysis.common import TEST_TYPE_STRING

# ------------------------------------------
# Constants
SUCCESS = 1
FAIL = 0

# File to search 
EXTENSION = '.zip'

# Diagcon application
APP_WAIT_TIME = 3
# ------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# Command line interface
def cli_handler():
    parser = argparse.ArgumentParser()

    parser.add_argument('-t', "--type",
                        metavar="TEST_TYPE",
                        type=str,
                        choices=VALID_TEST_TYPES,
                        help="Type of test: %s" % TEST_TYPE_STRING,
                        required=True)

    # json file path
    parser.add_argument("-j", "--path", \
                        help="Input json file path",
                        required=True,
                        default=None)

    # Schema for odx file
    parser.add_argument("-s", "--schema", \
                        help="Schema for ODX-D File",
                        type=str,
                        required=True,
                        default=None)

    # Destination Folder
    parser.add_argument("-d", "--dest", \
                        help="Destination Folder to copy files",
                        required=True,
                        default=None)

    args = parser.parse_args()

    return args.type, args.path, args.schema, args.dest

def load_json(json_file_dir):
    """
    @summary: find the input json file and load the contents into variable _data
    @return json file data
    """
    retval = None
    global _data

    try:
        with open(json_file_dir, 'r') as file_obj:
            # load file and copy key, values into _data
            _data = json.load(file_obj)
            log_info("UI Json loaded succesfully")
            retval = True

    except Exception as e:
        log_exception("Json File not found ", e)
        retval = False

    finally:
        # close files
        if retval is True:
            file_obj.close()
        else:
            pass

    return retval

def dump_json(input_json_path):
    """
    @summary: Update the input json with new contents
    """
    try:
        # dump the new data into json
        _data.update(_data)
        file = open(input_json_path, "w")
        json.dump(_data, file, indent=4, separators=(',', ': '))
        log_info("UI Json dumped succesfully")

    except Exception as e:
        log_exception("Exception raise while dump json", e)

    finally:
        file.close()

def print_data():
    log_debug(_data)

def read_source_info():
    # read source info from json
    out = None

    try:
        for key, value in _data.items():
            if key == "DownloadInfo":
                for key, value in value.items():
                    if key == "Source":
                        out = value
    except Exception as e:
        log_exception("Exception raise while searching key & value", e)

    return out

def read_src_elements(src_selected):
    # extract the data values from json input and store it 
    # into the dict
    ret_dict = {}

    if src_selected == "JFROG" or "MBOS":
        for key, value in _data.items():
            if key == "DownloadInfo":
                for i_key, i_value in value.items():
                    if i_key == "Data":
                        ret_dict.update([(i_key, i_value)])
    else:
        log_error("Not an valid source %s", src_selected)

    return ret_dict

def flatten(list_input):
    # return flat list out of a list of lists
    return [item for sublist in list_input for item in sublist]

# Decrypt text that was encrypted using cryptographic PBE.
# The Password and salt to be used for decryption are defined in the function.
# Arguments:
#  enc_text: Encrypted text
# Return:
#  Decrypted text
def decrypt_text(enc_text=""):
    DECRYPT_PWD="Mbrdi@123mbos"
    DECRYPT_SALT="electric"
    # Get encrypted text
    data = b64decode(enc_text)
    
    # Start decryption
    bytes = PBKDF2(DECRYPT_PWD.encode("utf-8"), \
        DECRYPT_SALT.encode("utf-8"), 48, 128)
    iv = bytes[0:16]
    key = bytes[16:48]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    text = cipher.decrypt(data)
    text = text[:-text[-1]].decode("utf-8")

    log_debug("Encrypted password: %s" % (enc_text))
    log_debug("Decrypted password: %s" % (text))
    return text

def get_jfrog_info():
    # get the jfrog src elements
    jfrog_dict = {"file_url": "", "pwd": "", "xml_ecu": "", "xml_version": "",
                  "arxml_ver": "", "odx_version": "", "odx_doc_name": "",
                  "cdd_doc_name": "", "cdd_version": ""}

    dict_in = read_src_elements(read_source_info())
    for key, value in dict_in.items():
        if key == 'Data':
            for i_key, i_value in value.items():
                if i_key in jfrog_dict:
                    jfrog_dict[i_key] = i_value
    
    # Decrypt password
    decrypt_pwd = decrypt_text(jfrog_dict["pwd"])
    if decrypt_pwd is not None:
        jfrog_dict["pwd"] = decrypt_pwd
    return list(jfrog_dict.values())

def get_mbos_info():
    # get the mbos src elements
    """ecu, ecu_ver, zip_pwd, xml_ecu_name, xml_ver, arxml_ver, odx_ver, \
    odx_doc_name, cdd_doc_name, cdd_ver
    """
    mbos_dict = {"ecuname": "", "version": "", "pwd": "", "xml_ecu": "",
                 "xml_version": "", "arxml_ver": "", "odx_version": "", "odx_doc_name": "",
                 "cdd_doc_name": "", "cdd_version": ""}

    dict_in = read_src_elements(read_source_info())
    for key, value in dict_in.items():
        if key == 'Data':
            for i_key, i_value in value.items():
                if i_key in mbos_dict:
                    mbos_dict[i_key] = i_value

    return list(mbos_dict.values())

def extract_unzipfiles(dest_dir):
    # After DP download this function will be called
    # to extract the contents into dest folder
    extract_flag = False

    try:
        for file_ in os.listdir(dest_dir):  # loop through items in dir
            if file_.endswith(EXTENSION):  # check for ".zip" extension
                filename = dest_dir + '\\' + os.path.basename(file_)
                log_info("Extracting file: %s" % filename)
                if extract_7zip(filename, dest_dir):
                    extract_flag = True
                else:
                    log_info("Failed to extract zip file: %s" % filename)
    except Exception as e:
        extract_flag = False
        log_exception("Problem while trying to unzip ", e)
        sys_exit(EXTRACTION_ERROR)
    return extract_flag

def odx_cdd_downloader(test_type, odx_doc_name, odx_ver, cdd_doc_name, cdd_ver, schema, dest_folder):
    """ Function to handle the odx-d and cdd download """
    # Function variables
    obj_dp = DiagPortal()

    # ODX download
    if test_type == ECU_TEST_TYPE_NEST:
        if (odx_ver != 'None') and (odx_doc_name != 'None') and (schema != 'None'):
            log_info('-' * 80)
            log_info("ODX Download Started!")
            if obj_dp.odx_downloader(odx_ver, odx_doc_name, schema, dest_folder) is True:
                log_info("ODX Download completed")
                log_info('-' * 80)
                time.sleep(APP_WAIT_TIME)
            else:
                log_error("Error downloading ODX Download ")
        else:
            log_error("No ODX inputs were given. Check all input values {doc_name, version, schema}.")

    # CDD download
    if test_type == ECU_TEST_TYPE_DIVA:
        if (cdd_ver != 'None') and (cdd_doc_name != 'None'):
            log_info('-' * 80)
            log_info("CDD File Download Started!")
            if obj_dp.cdd_downloader(cdd_doc_name, cdd_ver, dest_folder) is True:
                log_info("CDD Download completed:)")
                log_info('-' * 80)
                time.sleep(APP_WAIT_TIME)
            else:
                log_error("Error downloading CDD Download")
        else:
            log_error("No CDD inputs were given")

    return

def arxml_downloader(xml_ecu_name, l_test_type, xml_ver, dest_folder):
    """ Function to handle the arxml download """
    # Function variables
    extract_flag = None
    obj_dp = DiagPortal()

    if l_test_type in VALID_TEST_TYPES:
        if (xml_ecu_name != 'None') and (xml_ver != 'None'):
            if obj_dp.update_dict(xml_ecu_name, xml_ver) is True:
                log_info('-' * 80)
                log_info("ARXML Dict Update completed")
                if (obj_dp.ecu_extract_downloader(dest_folder) is True):
                    extract_flag = SUCCESS
                    log_info("ECU ARXML download Completed")
                    time.sleep(APP_WAIT_TIME)
                else:
                    extract_flag = FAIL
                    log_error("ECU ARXML download Failed")
            else:
                extract_flag = FAIL
                log_error("ARXML Dict Update Failed")
        else:
            extract_flag = FAIL
            log_error("No arxml inputs were given")

    # Extract the unzipped files in destination folder
    if extract_flag == SUCCESS:
        log_info('-' * 80)
        if extract_unzipfiles(dest_folder) is True:
            log_info("Extraction of zipped files completed")
        else:
            log_error("Problem in extracting package")

    return

def handle_jfrog_download(test_type, schema, dest_folder):
    """ handler to download artifacts from jfrog and diagnostic portal (arxml, odx, cdd) """

    # Function variables
    l_test_type = test_type
    obj_jfrog = JfrogArtifactory()

    # extracted values from json
    file_url, file_pwd, xml_ecu_name, xml_ver, arxml_ver, odx_ver, \
    odx_doc_name, cdd_doc_name, cdd_ver = get_jfrog_info()

    # folder cleanup
    setup_folder(dest_folder)

    # Function to handle download artifacts
    if l_test_type in VALID_TEST_TYPES:
        log_info('-' * 80)
        if (file_url != 'None') and (dest_folder != 'None'):
            if obj_jfrog.download_artifacts(file_url, file_pwd, dest_folder) is True:
                log_info("Download artifacts completed")
            else:
                log_info("Download artifacts failed")
        else:
            log_error("No JFrog inputs were given")

    # ARXML download
    arxml_downloader(xml_ecu_name, l_test_type, xml_ver, dest_folder)

    # ODX download # CDD download
    odx_cdd_downloader(l_test_type, odx_doc_name, odx_ver, cdd_doc_name, cdd_ver, schema, dest_folder)

    return

def handle_mbos_download(test_type, schema, dest_folder):
    """ function to download artifacts from mbos """
    # Function variables
    l_test_type = test_type

    ecu, ecu_ver, zip_pwd, xml_ecu_name, xml_ver, arxml_ver, odx_ver, \
    odx_doc_name, cdd_doc_name, cdd_ver = get_mbos_info()

    # folder cleanup
    setup_folder(dest_folder)

    # MB.OS Download
    try:
        download_vECU(ecu, ecu_ver, dest_folder, zip_pwd)
    except Exception as e:
        log_exception("Exception when downloading vECU", e)

    # ARXML download
    if any(fname.endswith('.arxml') for fname in os.listdir(dest_folder)):
        # don't do arxml download
        log_info("Found local arxml file. Skipping arxml download.")
    else:
        # do arxml download
        arxml_downloader(xml_ecu_name, l_test_type, xml_ver, dest_folder)

    # ODX-d download
    if any(fname.endswith('.odx-d') for fname in os.listdir(dest_folder)):
        # don't do arxml download
        log_info("Found local odx file. Skipping odx download.")
    else:
        # ODX download # CDD download
        odx_cdd_downloader(l_test_type, odx_doc_name, odx_ver, cdd_doc_name, cdd_ver, schema, dest_folder)

    return

def rrmdir(path):
    """ function to remove dest folder contents and subfolders """
    try:
        if os.path.exists(path):
            for entry in os.scandir(path):
                if entry.is_dir():
                    rrmdir(entry)
                else:
                    os.remove(entry)
            os.rmdir(path)

        else:
            log_error("System cannot find the specified path")
    except Exception as e:
        log_exception("Exception while removing folder contents", e)

def mkdir(path):
    """ function to make directory on user specified path """
    try:
        if not os.path.exists(path):
            os.makedirs(path)
            log_info("Destination folder created %s" % path)
        else:
            # Directory exists. Do nothing
            pass
    except Exception as e:
        log_exception("Exception while creating a directory", e)
        sys_exit(OUTPUTDIR_ERROR)

def setup_folder(dir):
    """ cleanup the dest folder to avoid overwrite the file contents """
    try:
        mkdir(dir)
    except Exception as e:
        log_exception("Exception while setup the folder", e)

def main():
    """ Main function """
    test_type, json_path, schema, dest_folder = cli_handler()
    log_info("Test type : %s" % test_type)

    if load_json(json_path) is True:
        src = read_source_info()

        if src == 'JFROG':
            handle_jfrog_download(test_type, schema, dest_folder)

        elif src == "MBOS":
            handle_mbos_download(test_type, schema, dest_folder)

        else:
            log_error("Invalid source information")
    else:
        sys_exit(JSON_LOAD_ERROR)


if __name__ == '__main__':
    log_info("Test Inputs Files Download begin")
    main()
    log_info("Test Inputs Files Download wrap up")

# End of File -----------------------------------------------------------------
