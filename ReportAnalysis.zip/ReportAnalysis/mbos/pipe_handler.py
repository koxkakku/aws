# coding: utf-8
"""
Created on 23-Jun-2022
@author: STEPHIG
Desc: 
    API to handle pipelines on MBOS (MIC) portal.
"""

# NOTE: Assumed that necessary permissions are assigned.

import requests
import requests.auth
import urllib3
import json
import os
import shutil
from zipfile import ZipFile
import time

from Logger import LogHandler

# Token master data
from mbos.tokenmaster import NON_PROD_CLIENT_ID
from mbos.tokenmaster import NON_PROD_CODE
from mbos.tokenmaster import CLIENT_TESTING_SERVICE_NONPROD
from mbos.tokenmaster import CLIENT_PMG_NONPROD

# System Exit
from exit_handler import PHEC_INIT_RETRY_OVERFLOW
from exit_handler import PHEC_INVALID_RUN_STATUS
from exit_handler import PHEC_UPDATE_RETRY_OVERFLOW
from exit_handler import sys_exit

# Buffer for refreshing token before expiry
TOKEN_REFRESH_BUFFER_TIME=60  # Refresh token 60 seconds before expiry

# Time between requests for pipeline data
MIN_PIPELINE_REQUEST_TIME=30  # Time in seconds

# Download delay
DELAY_RESULT_DOWNLOAD=30  # Time in seconds

# Timeout (seconds) for Get report state machine
# NOTE: Job completion timeout set to 24 hours
GRSM_TIMEOUT = 24*60*60  # Time is seconds

# Max retry counts (MRC_*)
MRC_PIPE_INIT=5
MRC_PIPE_GET_STATUS=10

# Report extension
FILETYPE_REPORT=".xml"

# URLs
NON_PROD_URL='https://tes-nonprod.query.api.dvb.corpinter.net'
NON_PROD_PMG='https://pmg-nonprod.query.api.dvb.corpinter.net'

# Token master data
SW_CLIENT_USERNAME=NON_PROD_CLIENT_ID
SW_CLIENT_PWD=NON_PROD_CODE
CLIENT_ID_TESTING_SERVICE=CLIENT_TESTING_SERVICE_NONPROD

# Name of zip file for downloading results
RESULTS_DOWNLOAD_FILE="Results"

# Directories
DIR_RESULTS="PipeTemp"
DIR_LOGS="Logs"
# List of possible report folder names
DIR_REPORT=["Report","Reports","TestResults"]

# Run history log file
LOG_RUN_HISTORY="runs.json"

# URLs
URL_REF = NON_PROD_URL
URL_PERMISSION_MGMT = NON_PROD_PMG
URL_TOKEN="https://ssoalpha.dvb.corpinter.net/v1/token"

# Pipe job history key
PJHK_RUN="runs"

# Pipe run keys
PRK_STATUS="status"
PRK_JOBS="jobs"

# Token Response Keys
TRK_ACCESS_TOKEN="access_token"
TRK_VALIDITY="expires_in"

# Pipe Job keys
PJK_ID="id"
PJK_STATUS="status"
PJK_NAME="name"

# Response Job Status text
RJST_INPROGRESS="in-progress"
RJST_COMPLETE="completed"
RJST_CANCELED="canceled"
RJST_FAILED="failed"
RJST_QUEUED="queued"
RJST_READY="ready-for-pickup"

# Job status code
JSC_INVALID=0
JSC_INPROGRESS=1
JSC_COMPLETE=2
JSC_CANCELLED=3
JSC_FAILED=4
JSC_QUEUED=5
JSC_READY=6

# Lookup table for Job/run status
LUT_STATUS={
    RJST_INPROGRESS:JSC_INPROGRESS,
    RJST_COMPLETE:JSC_COMPLETE,
    RJST_CANCELED:JSC_CANCELLED,
    RJST_FAILED:JSC_FAILED,
    RJST_QUEUED:JSC_QUEUED,
    RJST_READY:JSC_READY
}

# Get report States
GRS_INIT=0
GRS_CHECK_STATUS=1
GRS_EXIT=2

# Pipeline defintion data keys
PDDK_ID="id"
PDDK_NAME="name"
PDDK_STEPS="steps"

# Pipeline Test step keys
PTSK_ID="id"
PTSK_NAME="name"
PTSK_TYPE="type"
PTSK_PARA="typeParameters"
PTSK_PARA_CANOE_PATH="canoeProjectPath"

# Loggers ---------------------------------------------------------------------

# Create logger for file
logger=LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='',e=''):
    logger.exception("%s: %s"%(msg,e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# End of Loggers --------------------------------------------------------------

# Pipeline Functions ----------------------------------------------------------

# TODO: Add Exception handling for post, get methods.

# Return values:
# Status of response:
#     False: error
#     True: success
# Reponse JSON
def response_handler(response):
    retval = False
    data = None
    if response.ok:
        # Good response
        retval = True
        # get json from response
        try:
            data = response.json()
        except:
            data = None
    else:
        # Bad response
        data = None
        retval = False
        log_error("Response Error: \n\tstatus%s \n\treason:%s" % \
            (response.status_code,response.reason))
    
    return retval,data

# Get token for testing service
def get_token(client_id):
    url = URL_TOKEN
    payload = \
        {
            'grant_type':'client_credentials',
            'client_id':SW_CLIENT_USERNAME,
            'client_secret':SW_CLIENT_PWD,
            'scope':'openid profile groups audience:server:client_id:%s' % \
                (client_id)
                }
    
    headers = {
        'content-type': 'application/x-www-form-urlencoded'
        }
    
    response = requests.post(url, \
                              data=payload, \
                              headers=headers \
                              )
    resp_json = response.json()
    if response.ok:
        token = 'Bearer '+ resp_json[TRK_ACCESS_TOKEN]
    else:
        token=None
    return token

# Get token for testing service
# Return:
#     bearer token,validity
def mbos_get_token(client_id):
    url = URL_TOKEN
    payload = \
        {
            'grant_type':'client_credentials',
            'client_id':SW_CLIENT_USERNAME,
            'client_secret':SW_CLIENT_PWD,
            'scope':'openid profile groups audience:server:client_id:%s' % \
                (client_id)
                }
    
    headers = {
        'content-type': 'application/x-www-form-urlencoded'
        }
    
    try:
        response = requests.post(url, \
                                data=payload, \
                                headers=headers \
                                )
        resp_json = response.json()
        try:
            token = 'Bearer '+ resp_json[TRK_ACCESS_TOKEN]
            validity = int(resp_json[TRK_VALIDITY])
        except Exception as e:
            token=None
            validity=None
            log_exception("Failed to get token:",e)
    except Exception as e:
        token=None
        validity=None
        log_exception("Failed to request token",e)
    return token,validity

# Get list of all pipelines
def pipeline_get_all(token):
    log_debug('Get all Pipelines')
    
    url = '%s/pipelines'%URL_REF
    l_header = {'Authorization': token}
    
    try:
        resp = requests.get(url,headers=l_header)
        pipelines_list = resp.json()["pipelines"]
    except Exception as e:
        pipelines_list = []
        log_exception("Could not retrieve pipelines:",e)
    
    return pipelines_list

# create a new pipeline
def pipeline_create(token,pipe_name,pipe_desc):
    log_info("Create New Pipeline: %s"%pipe_name)
    
    url = "%s/pipelines"%URL_REF
    l_headers = \
        {
            'Authorization': token,
            'content-type' : 'application/json'
            }
    
    pipeline_data = {"name": pipe_name,"description": pipe_desc}
    json_data = json.dumps(pipeline_data)
    
    r = requests.post(url, data=json_data, headers=l_headers)
    
    # process response
    resp_status,resp_data = response_handler(r)
    pipe_id = ''
    if resp_status:
        if resp_data is not None:
            pipe_id = resp_data["id"]
        log_info( "Pipeline created successfully: %s" % (pipe_id) )
    else:
        pipe_id = ''
        log_error("Failed to create pipeline")
    return pipe_id

# Delete existing pipeline
def pipeline_delete(token,id_pipe):
    log_info("Delete Pipeline: %s"%id_pipe)
    
    url = "%s/pipelines/%s"%(URL_REF,id_pipe)
    l_headers = \
        {
            'Authorization': token, 
            'content-type' : 'application/json'
            }
    
    r = requests.delete(url, headers=l_headers)
    
    # Process response
    resp_status,resp_data = response_handler(r)
    if resp_status:
        log_info("Pipeline deleted")
    else:
        log_error("Failed to delete pipeline")
    return

# Assign permissions to pipeline users
# _id: ID of pipeline
# User: User id (case sensitive)
# role: valid values: 'Owner|TestManager|Tester'
def pipeline_set_permissions(_id, token, user, role):
    log_info("Set permissions: %s\t%s\t%s" % (_id,user,role))
    url = "%s/domains/test-pipeline/resources/%s/rights" % \
        (URL_PERMISSION_MGMT, _id)
    l_headers = \
        {
            'Authorization': token, 
            'content-type' : 'application/json'
            }
    
    config = \
        [ 
            { 
                "operation": "add",
                "roles": [role],
                "user":{"id":user}
                }
            ]
    json_data = json.dumps(config)
    r = requests.put(url,data=json_data,headers=l_headers)
    # process response
    resp_status,resp_data = response_handler(r)
    if resp_status:
        log_debug("Updated permissions")
    else:
        log_debug("Failed to update permissions")
    return

# Get roles assigned to pipeline
def pipeline_get_permissions(_id, token):
    log_info("Get permissions: %s"%_id)
    url = "%s/domains/test-pipeline/resources/%s/rights" % \
        (URL_PERMISSION_MGMT, _id)
    l_headers = \
        {
            'Authorization': token
            }
    
    r = requests.get(url, headers=l_headers)
    # process response
    resp_status,resp_data = response_handler(r)
    if resp_status:
        log_debug("Get permissions: %s"%resp_data)
    else:
        log_debug("Failed to get permission data")
    return resp_data

# Add powershell steps to pipeline
# Argument: 
#     token: Bearer token
#     _id: ID of Pipeline to be updated
#     steps: List of powershell commands
def pipeline_add_step_powershell(token,_id,steps=[]):
    log_info("Adding Steps: %s"%_id)
    
    url = "%s/pipelines/%s/steps" % (URL_REF, _id)
    l_headers = \
        {
            'Authorization': token,
            'content-type' : 'application/json'
            }
    
    # arrange steps in correct format
    data=[]
    for count,step in enumerate(steps):
        temp={
            "type": "POWERSHELL",
            "stepOrder":count+1,
            "name": "Step_%d_Test"%count,
            "typeParameters":{"script":step},
            "isValid":True
            }
        data.append(temp)
    
    json_data = json.dumps(data)
    
    r = requests.put(url, data=json_data, headers=l_headers)
    
    # process response
    resp_status,resp_data = response_handler(r)
    if resp_status:
        log_debug("Added steps!")
    else:
        log_debug("Failed to add step.",r.json())
    
    return

# Run pipeline operation
def pipeline_run(token,_id):
    log_info("Start Pipeline: %s"%_id)
    status = False

    url = "%s/pipelines/%s/trigger-run" % (URL_REF,_id)
    l_headers = \
        {
            'Authorization': token,
            'content-type':'application/json'
            }
        
    data = {
        "installationSkipFlashing":True,
        "skipOrchestration":True,
        "skipStarcUpload":True
        }
    
    json_data = json.dumps(data)
    # request
    resp = requests.post(url,data=json_data,headers=l_headers)
    # process response
    resp_status,resp_data = response_handler(resp)
    if resp_status:
        status = True
        log_info("Pipeline started")
        log_debug("Pipeline Start Response: %s"%str(resp_data))
    else:
        log_error("Failed to start pipeline: %s"%resp.json())
    return status

# Pretty print all pipeline information
# Argument: List of pipelines
def pipelines_display(pipelines):
    for count,pipeline in enumerate(pipelines):
        print("Pipeline:",count)
        print("\tID:",pipeline["id"])
        print("\tName:",pipeline["name"])
    return

# Pretty print data from one pipeline
# Argument: Pipeline to be displayed
def pipeline_display(pipeline):
    print("\tID:",pipeline["id"])
    print("\tName:",pipeline["name"])
    print("\tSteps:",pipeline["steps"])
    return

# Get pipeline run history
def get_pipeline_runs(token,_id):
    retval=None
    url = '%s/pipelines/%s/runs'%(URL_REF,_id)
    l_header = {'Authorization': token}
    try:
        resp = requests.get(url,headers=l_header)
        retval = resp.json()
    except Exception as e:
        retval = None
        log_exception("Could not get pipeline runs:",e)
    return retval

# Get detailed pipeline job result
def get_pipeline_job_results(token,job_result_id):
    retval=[]
    url = '%s/results/jobs/%s'%(URL_REF,job_result_id)
    l_header = {'Authorization': token}
    try:
        resp = requests.get(url,headers=l_header)
        retval = resp.json()
    except Exception as e:
        retval = []
        log_exception("Could not get job results:",e)
    return retval

# Get link to download job results
def pipeline_result_download(token,job_id,filename):
    status=False
    retfile=None

    url = '%s/jobs/%s/artifacts'%(URL_REF,job_id)
    l_header = {'Authorization': token}
    try:
        resp = requests.get(url,headers=l_header)
        if resp.ok:
            # create directory for runner
            if not os.path.exists(DIR_RESULTS):
                os.makedirs(DIR_RESULTS)
            # Get download link
            download_link = resp.headers['Location']
            # Update filename to include directory
            fname="%s/%s.zip"%(DIR_RESULTS,filename)
            # Download file
            if download_file(download_link,fname):
                # Extract file
                if extract_file(fname,DIR_RESULTS):
                    # get report file
                    report_files=get_report_filename(DIR_RESULTS)
                    if report_files is not None:
                        # Get the report file
                        retfile=report_files
                        status=True
                        log_info("Found Report file: %s"%retfile)
                    else:
                        log_error("Could not locate report file in download.")
                else:
                    log_error("Failed to extract report.")
            else:
                log_error("Failed to download report.")
        else:
            log_error("Result download: Invalid response! %s"%resp.status_code)
    except Exception as e:
        status=False
        retfile=None
        log_exception("Could not download results:",e)
    return status, retfile

# get pipeline ID by name
def pipeline_get_id_by_name(token,pipe_name):
    retval = None
    pipelines=pipeline_get_all(token)
    try:
        for pipe in pipelines:
            if pipe[PDDK_NAME] == pipe_name:
                retval = pipe[PDDK_ID]
                break
    except Exception as e:
        retval = None
        log_exception("Error while looking for pipeline by name",e)
    
    if retval is None:
        log_error("Failed to get ID of pipeline: %s" % pipe_name)
    return retval

# get pipeline data by name
def pipeline_get_data_by_name(token,pipe_name):
    retval = None
    pipelines=pipeline_get_all(token)
    try:
        for pipe in pipelines:
            if pipe[PDDK_NAME] == pipe_name:
                retval = pipe
                break
    except Exception as e:
        retval = None
        log_exception("Error while looking for pipeline by name",e)
    
    if retval is None:
        log_error("Failed to get pipeline data: %s" % pipe_name)
    return retval

# Update pipeline data
def pipeline_update(token,pipe_id,pipe_data):
    status=False
    log_info('Send update to Pipeline: %s'%pipe_id)
    log_debug('Data to update: %s'%pipe_data)
    
    url = '%s/pipelines/%s'%(URL_REF,pipe_id)
    l_header = {
        'Authorization': token,
        'content-type' : 'application/json'
        }
    
    try:
        json_data=json.dumps(pipe_data)
        resp = requests.put(url,headers=l_header,data=json_data)
        log_debug("Resp data: %s"%resp.text)
        if resp.ok:
            status=True
    except Exception as e:
        pipe_data = None
        log_exception("Could not update pipeline:",e)
    
    return status

# Get dictionary of step data from pipe data
# Arguments:
# pipe_data: Pipeline definition data
# step_name: Name of step to extract data
def _pipe_step_get(pipe_data,step_name):
    retval=None
    try:
        # Parse list of steps and locate the step name
        for step in pipe_data[PDDK_STEPS]:
            if step[PTSK_NAME] == step_name:
                retval=step
                break
    except Exception as e:
        log_exception("Failed to get step from pipe data",e)
    return retval

# Update step dictionary and return new step data dictionary
def _pipe_step_update(curr_step,update_type,update_parameters):
    log_debug("Update step: %s\t%s"%(update_type,update_parameters))
    # Update step with new data
    try:
        curr_step[PTSK_TYPE]=update_type
        curr_step[PTSK_PARA]=update_parameters
    except Exception as e:
        log_exception("Exception when updating test step:",e)
    return curr_step

# Replace step in pipe
def _pipe_step_replace(pipe_data,step_name,new_step):
    log_debug("Replace step in pipe data")
    try:
        # Ordered list of step names
        name_list=[step[PTSK_NAME] for step in pipe_data[PDDK_STEPS]]
        # Get index of step in pipedata
        if step_name in name_list:
            step_idx=name_list.index(step_name)
            # Replace old step data with new step in list of steps
            pipe_data[PDDK_STEPS][step_idx]=new_step
        else:
            log_error("Failed to locate step in pipeline")
    except Exception as e:
        log_exception("Failed to replace step in pipe data",e)
        
    return pipe_data

# Update test step in pipeline
def pipeline_update_step(token,pipe_name,step_name,new_step_type,new_step_para):
    status=False
    log_debug("Start updating step in pipeline.")
    # get pipeline data
    pipe_data=pipeline_get_data_by_name(token,pipe_name)
    if pipe_data is not None:
        # Get step data by name
        step_data=_pipe_step_get(pipe_data,step_name)
        # Get new step data
        step_data=_pipe_step_update(step_data,new_step_type,new_step_para)
        # Replace this step in the pipe
        pipe_data=_pipe_step_replace(pipe_data,step_name,step_data)
        
        # Update new data to the pipeline
        pipe_id=pipeline_get_id_by_name(token,pipe_name)
        if pipe_id is not None:
            if pipeline_update(token,pipe_id,pipe_data):
                log_info("Successfully updated pipeline step")
                status=True
            else:
                log_error("Failed to update pipeline step")
        else:
            log_error("Failed to update pipeline step: Invalid pipe ID")
    else:
        log_error("Pipeline update step: Invalid pipe data")
    
    return status

# TODO: Add functions to create CANoe, powershell steps
# Get nest step in format expected by MBOS
def _mbos_create_step_nest(path):
    step_type="NEST"
    step_para={
        PTSK_PARA_CANOE_PATH:path
    }
    return step_type,step_para

# End of Pipeline Functions --------------------------------------------------


# Helper Functions -----------------------------------------------------------

# Extract zip file
def extract_file(filename,directory):
    status = False
    log_info("Extract %s to %s:"%(filename,directory))
    try:
        with ZipFile(filename,'r') as zfile:
            zfile.extractall(directory)
            status = True
            log_info("Extraction complete.")
    except Exception as e:
        status = False
        log_error("Exception when trying to extract %s:%s"%(filename,e))
        # log_exception("Exception when trying to extract %s:"%(filename),e)
    return status

# Download file from URL
def download_file(url,fname):
    retval = False
    log_info("Downloading: %s"%fname)
    log_debug("URL: %s"%url)
    # proceed to download file
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    resp = requests.get(url=url,stream=True,verify=False)
    # Check for valid response
    if resp.ok:
        with open(fname,'wb') as f:
            _total_size=len(resp.content)
            _down_size=2*1024
            log_info("Download File size: %d"%_total_size)
            for chunk in resp.iter_content(chunk_size=_down_size): 
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)
        log_info("Download complete!")
        retval = True
    else:
        log_error("Download failed")
    
    return retval

# Get name of downloaded report file
def get_report_filename(directory):
    retval=None
    # report directory
    for report_dir in DIR_REPORT:
        dir = os.path.join(directory,report_dir)
        # Check if this is the correct report folder
        if os.path.exists(dir):
            log_info("Report directory found: %s"%dir)
            try:
                log_debug("Get report filename from: %s"%dir)
                # Get list of files with report extension(XML)
                xml_files=list()
                for path, subdirs, files in os.walk(dir):
                    for file in files:
                        if file.endswith(FILETYPE_REPORT):
                            xml_files.append(os.path.join(path, file))
                log_debug("List of XML files: %s" % str(xml_files))
                retval=xml_files[0]
                # Break: Stop looking for more result directories
                break
            except Exception as e:
                retval=None
                log_error("Could not locate result file: %s" % e)
        else:
            # Report directory not found. Procced to next folder
            log_debug("Report directory not found: %s"%dir)
            retval = None
        
    return retval

# Get run to test from list of runs
def get_run_to_test(run_data,run_idx=0):
    run_under_test = None
    if run_data is not None:
        try:
            # Proceed to process data
            list_of_runs=run_data[PJHK_RUN]
            # Get run that is to be analysed
            run_under_test=list_of_runs[run_idx]
        except Exception as e:
            run_under_test=None
            log_exception("Failed to retrieve run index: %d"%(run_idx), e)
    
    return run_under_test

# Get job id from job data if completed
def get_job_id(job):
    retval=None
    if job is not None:
        try:
            retval = job[PJK_ID]
        except:
            # Could not get job ID
            retval=None
    else:
        # invalid argument
        pass
    return retval

# Get job status from job data
# Return: status of job as JSC_*
def get_job_status(job):
    retval=JSC_INVALID
    if job is not None:
        try:
            retval=LUT_STATUS[job[PJK_STATUS]]
        except Exception as e:
            # Could not get status
            log_error("Unknown job status: %s" % job[PJK_STATUS])
            retval=JSC_INVALID
    else:
        # invalid argument
        pass
    return retval

# Get job ID from run history of the pipeline
'''
{
    "id":123456,
    "status":completed,
    options:[],
    jobs:[
        {
            "id":Pipeline_JOB_ID,  # use this to download results
            "name":NEST
            "status":completed
        }
    ],
    capabilities:[]
}
'''
def get_job_id_from_run(run_under_test):
    retval = None
    if run_under_test is not None:
        # get last job in run
        try:
            # NOTE: Get last job ID; Assuming results are uploaded in the last 
            # job
            idx = len(run_under_test[PRK_JOBS]) - 1
            job_under_test=run_under_test[PRK_JOBS][idx]
        except:
            job_under_test = None
        # get id of job
        retval = get_job_id(job_under_test)
    return retval

# Get status of run from data
# Return: status of job as JSC_*
def get_run_status(run_data,run_idx=0):
    retval = JSC_INVALID
    run_under_test = get_run_to_test(run_data,run_idx)
    if run_under_test is not None:
        # Get status code from lookup table
        try:
            retval = LUT_STATUS[run_under_test[PRK_STATUS]]
        except Exception as e:
            retval = JSC_INVALID
            log_exception("Exception when getting run status:",e)
    else:
        log_error("Get run status: Failed to get run to test.")
        log_debug("Get run status: Data %s"%run_data)
    return retval

# Dump data to json file
def dump(filename,data):
    try:
        with open(filename,'w') as f:
            f.write(json.dumps(data,indent=4))
    except Exception as e:
        log_error("Failed to log data: %s"%e)
    return

# End of Helper Functions ----------------------------------------------------

# API Functions --------------------------------------------------------------

# Clean downloaded report files and logs
def cleanup_report():
    log_info("Cleanup reports and logs.")
    # delete folder with downloads
    try:
        # Downloads
        if os.path.exists(DIR_RESULTS):
            shutil.rmtree(DIR_RESULTS)
        
        # # Logs
        logfile="%s/%s" % (DIR_LOGS,LOG_RUN_HISTORY)
        if os.path.isfile(logfile):
            os.remove(logfile)
    except Exception as e:
        log_exception("Exception during Cleanup",e)
    return

# Initiate a pipeline run. Update path of pipeline if available.
# Argument: Name of pipeline
# Return: Status of initialization
#     False: Failed to start
#     True: Pipeline started
def start_pipeline(pipe_name):
    status =False
    # Get token for testing service
    token_ts = get_token(CLIENT_ID_TESTING_SERVICE)
    
    # Get ID of pipeline from name
    log_info("Get ID of Pipeline: %s"%pipe_name)
    pipeline_id=pipeline_get_id_by_name(token_ts,pipe_name)

    if pipeline_id is not None:
        log_info("Pipeline ID: %s"%pipeline_id)
        # start pipeline
        status = pipeline_run(token_ts,pipeline_id)
    else:
        # Failed to get pipeline ID
        pass
    return status

# Class for pipeline activities
class PipelineHandler:
    def __init__(self,pipe_name,run_idx=0):
        self.token=None
        self.token_expiry=0.0
        self.pipeline_id=None
        self.pipeline_name=pipe_name
        self.run_index=run_idx
        self.report_file=None
        # Time of last pipeline history request
        self.time_grs_status_check=0
        # time record of get report state machine
        self.time_grsm=0
        # Time of state machine init
        self.time_grs_init=0
        # Init count to monitor max repetitions before exiting
        self.count_init=0
        # Status check count to monitor max repetitions before exiting
        self.count_chk_status=0
        # Job status data
        self.jsd_monitor_idx=0
        # exit error code
        self.exit_code=None
        return
    
    # Get token considering token timeout
    def get_token(self):
        # Check if previous token has expired
        # Keep a buffer for validity
        if (self.token_expiry - time.time()) < TOKEN_REFRESH_BUFFER_TIME:
            # Request new token
            token,validity = mbos_get_token(CLIENT_ID_TESTING_SERVICE)
            # Validate token
            if token is not None:
                # Update token
                self.token=token
                # Update expiry time
                self.token_expiry = time.time()+validity
            else:
                # invalid token
                self.token = None
                self.token_expiry=0.0
        else:
            # Token has not expired yet, use the same token
            pass
        return self.token

    # Process completed job
    def process_completed_job(self,run_history):
        # Get job ID
        log_debug("Get Job ID from last run")
        run_under_test = get_run_to_test(run_history,self.run_index)
        if run_under_test is not None:
            job_id=get_job_id_from_run(run_under_test)
            log_info("Job ID: %s"%job_id)

            # Download and extract results
            if job_id is not None:
                # repeat download up to 3 times in case of failure
                repeat_download=3
                while repeat_download > 0:
                    # wait some time before starting download
                    log_info("Wait before result download")
                    time.sleep(DELAY_RESULT_DOWNLOAD)
                    log_debug("Proceed to download result")
                    status,report = \
                        pipeline_result_download(self.get_token(), \
                        job_id, RESULTS_DOWNLOAD_FILE)
                    if (status == True) \
                        and (report is not None):
                        # Get name of report file
                        self.report_file=report
                        # do not repeat download
                        repeat_download = 0
                    else:
                        repeat_download -= 1
                        self.report_file=None
        else:
            log_debug("Processing completed job: Run data: %s"%run_history)
            log_error("Processing completed job: Failed to get run under test")
        return

    # Initialization state handler for get report
    def grs_init_handler(self):
        ret_state = GRS_INIT
        status=False
        
        # Check minimum time before repeating init
        if(time.time() - self.time_grs_init) > MIN_PIPELINE_REQUEST_TIME:
            log_debug("GRS: Initialize")
            # Update init time
            self.time_grs_init = time.time()
            # Create log directory if it does not exist
            if not os.path.exists(DIR_LOGS):
                os.makedirs(DIR_LOGS)
            
            # Get token and update time
            token = self.get_token()
            if token is not None:
                self.pipeline_id = \
                    pipeline_get_id_by_name(token,self.pipeline_name)
                if self.pipeline_id is not None:
                    log_info("Pipeline ID: %s"%self.pipeline_id)
                    status=True
                else:
                    # invalid pipe ID
                    log_error("Invalid pipeline ID")
                    status=False
            else:
                # Invalid token
                log_error("Invalid token")
                status=False
            
            # Error handling
            if status:
                # Reset initialization count
                self.count_init = 0
                # Proceed to check status of run
                ret_state=GRS_CHECK_STATUS
            else:
                # Increment initialization count
                self.count_init += 1
                if self.count_init >= MRC_PIPE_INIT:
                    log_debug("Initialization Retry count: %d"%self.count_init)
                    log_debug("Exit initialization.")
                    self.exit_code=PHEC_INIT_RETRY_OVERFLOW
                    ret_state=GRS_EXIT
                else:
                    log_debug("Retry initialization: %d"%self.count_init)
                    ret_state=GRS_INIT
        else:
            # Wait before repeating initialization
            pass
        
        return ret_state

    # Check status of last run and proceed accordingly
    def grs_check_status_handler(self):
        ret_state=GRS_CHECK_STATUS

        # Check for minimum time before repeating request
        if ( (time.time() - self.time_grs_status_check) > \
            MIN_PIPELINE_REQUEST_TIME ):
            # get run history of pipeline
            log_debug("GRS: Check status")
            run_history=get_pipeline_runs(self.get_token(),self.pipeline_id)
            dump( ("%s/%s" % (DIR_LOGS,LOG_RUN_HISTORY)), run_history)
            
            # Update time
            self.time_grs_status_check = time.time()

            # Status of processing run_history
            _status_run_processing=True

            if run_history is not None:
                # Got valid data
                # Check status of run
                run_status = get_run_status(run_history,self.run_index)
                
                # Proceed to next state based on status of run
                if run_status == JSC_INPROGRESS:
                    # In progress; Repeat status check
                    log_info("Run in progress!")
                    ret_state=GRS_CHECK_STATUS

                elif run_status == JSC_COMPLETE:
                    # Process job
                    log_info("Run completed!")
                    self.process_completed_job(run_history)
                    ret_state = GRS_EXIT

                elif run_status == JSC_CANCELLED:
                    # Proceed to exit
                    log_info("Run was cancelled!")
                    ret_state = GRS_EXIT
                
                elif run_status == JSC_FAILED:
                    # Proceed to exit
                    log_info("Run failed!")
                    ret_state = GRS_EXIT
                
                elif run_status == JSC_QUEUED:
                    # In queue; Repeat status check
                    log_info("Run in queue!")
                    ret_state=GRS_CHECK_STATUS
                
                elif run_status == JSC_READY:
                    # Ready for pickup; Repeat status check
                    log_info("Run ready for pickup!")
                    ret_state=GRS_CHECK_STATUS

                else:
                    # Invalid job state
                    _status_run_processing=False
                    log_error("Invalid Run status code: %s"%run_status)
            
            else:
                # Invalid run history
                _status_run_processing=False
                log_error("Invalid pipeline run data.")
            
            # if failed to process run history repeat status check
            if _status_run_processing == False:
                # Increment retry counter
                self.count_chk_status += 1
                # Repeat operation if not reached max reattempts
                if self.count_chk_status < MRC_PIPE_GET_STATUS:
                    # Retries left
                    ret_state=GRS_CHECK_STATUS
                    log_debug("Repeat status check: %d" \
                        % self.count_chk_status)
                else:
                    # Max retries done
                    # Confirmed issue with connection
                    # Exit operation
                    self.exit_code=PHEC_UPDATE_RETRY_OVERFLOW
                    ret_state=GRS_EXIT
                    log_debug("Status check retry count: %d" % \
                        self.count_chk_status)
                    log_info("Exit status check")
            else:
                # Successfully processed run data
                # Reset counter
                self.count_chk_status=0

        else:
            # Wait some time before requesting new data
            pass
        return ret_state
    
    # Exit report search
    def grs_exit_handler(self):
        ret_state=GRS_EXIT
        log_info("GRS: Exit report retrieval!")
        return ret_state

    # Download report file from last run and get path to report file
    # Return: 
    #   None: Error during download
    #   string: Path to downloaded report file
    def get_report_file(self):
        # State machine handler
        continue_loop=True
        # Initialize state variable
        grs_state=GRS_INIT
        
        # Record start time of state machine
        self.time_grsm = time.time()

        # Reset exit code
        self.exit_code=None

        while continue_loop:
            # Check state
            if grs_state == GRS_INIT:
                grs_state = self.grs_init_handler()
            elif grs_state == GRS_CHECK_STATUS:
                grs_state = self.grs_check_status_handler()
            elif grs_state == GRS_EXIT:
                continue_loop=False
                grs_state = self.grs_exit_handler()
            else:
                log_error("GetReportFile: Undefined state: %d" % \
                    grs_state)
                continue_loop=False
            
            # Check for state machine timeout
            if (time.time() - self.time_grsm) > GRSM_TIMEOUT:
                log_error("State machine timed out.")
                self.report_file=None
                continue_loop=False

        # Check for exit codes
        if self.exit_code is not None:
            sys_exit(self.exit_code)

        return self.report_file

# Update configuration path for test step in MBOS pipeline
def update_test_step(pipe_name,configpath):
    status = False
    log_info("Update test step in pipe: %s" % (pipe_name) )
    # Get token
    token=get_token(CLIENT_ID_TESTING_SERVICE)
    
    if token is not None:
        # Update existing step
        _stepname="vECU_Test"
        _steptype,_steppara=_mbos_create_step_nest(configpath)
        log_debug("Step to update: %s %s %s" \
            % (_stepname,_steptype,str(_steppara)) )
        # Update the step in pipeline
        if pipeline_update_step(token,pipe_name,_stepname,_steptype,_steppara):
            pipe_data=pipeline_get_data_by_name(token,pipe_name)
            log_debug("Updated Pipe definition: %s"%json.dumps(pipe_data))
            status=True
        else:
            status=False
    else:
        # Invalid token
        log_info("Failed to get token")
    return status

# End of API Functions -------------------------------------------------------

if __name__ == '__main__':
    pass

# End of File ----------------------------------------------------------------
