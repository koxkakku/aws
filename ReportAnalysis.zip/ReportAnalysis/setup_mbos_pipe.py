# coding: utf-8
"""
Created on 29-Jun-2022
@author: STEPHIG
Desc: Interface for jenkins to setup pipeline run

Usage:
python setup_mbos_pipe  -p DiVA_Test -t DIVA -i "C:/downloads/user_inputs.json"
"""

# Imports ---------------------------------------------------------------------
import os
import argparse as ap

from Logger import LogHandler
# MBOS pipeline API
from mbos import update_test_step

# Test types
from ReportAnalysis.common import VALID_TEST_TYPES
from ReportAnalysis.common import TEST_TYPE_STRING

# Exit handling
from exit_handler import sys_exit
from exit_handler import SETUP_PIPELINE_ERROR

from web_ui import get_config_path


# Functions -------------------------------------------------------------------

def cli_handler():
    # Create parser
    parser=ap.ArgumentParser(description="Update test step in MBOS pipeline")
    
    # Add argument for test type
    parser.add_argument('-p', "--pipe",
        metavar="PIPE_NAME",
        type=str,
        required=True)
    
    # Type of test
    parser.add_argument("-t","--test", \
        help="Type of test: %s"%TEST_TYPE_STRING,
        required=True,
        type=str,
        choices=VALID_TEST_TYPES)
    
    # Add argument for input json file
    parser.add_argument('-i', "--input",
        metavar="INPUT_JSON",
        type=str,
        help="Path to JSON file with user inputs",
        required=True)
    
    args = parser.parse_args()
    
    return args.pipe,args.input,args.test

def main(logger):
    pipeline,ui_file,testtype=cli_handler()
    status=False

    # Get config file path from user JSON
    configpath=get_config_path(testtype,ui_file)
    
    # Validate the filepath before proceeding
    if (configpath is not None):
        if(os.path.exists(configpath)) \
            and (configpath.endswith(".cfg")):
            # Update test step in pipeline
            status=update_test_step(pipeline,configpath)
        else:
            status=False
            logger.error("Failed to find configuration at path: %s" \
                % (configpath))
    else:
        status=False
        logger.error("Failed to get config file path: %s"%(configpath))
    
    # Check status of operation
    if not status:
        logger.error("Failed to update MBOS pipeline.")
        sys_exit(SETUP_PIPELINE_ERROR)
    return

if __name__=='__main__':
    logger=LogHandler()
    logger.setup()
    logger.info('-'*80)
    main(logger)
    logger.info('-'*80)

# End of file -----------------------------------------------------------------
