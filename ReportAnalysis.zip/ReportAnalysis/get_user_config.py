# coding: utf-8
"""
Created on 14-Jul-2022
@author: STEPHIG
Desc: API to extract user configuration and copy files to sepficied location.
"""

# Imports ---------------------------------------------------------------------
import os
import argparse
import sys

import shutil
from zipfile import ZipFile

from Logger import LogHandler
from exit_handler import GUC_SETUP_ERROR
from exit_handler import GUC_EXTRACT_ERROR
from exit_handler import sys_exit

# Constants -------------------------------------------------------------------
DIR_CONFIG="Config"  # Store configuration here

# Loggers ---------------------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='',e=''):
    logger.exception("%s: %s"%(msg,e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# End of Loggers --------------------------------------------------------------

# Setup directories
def directory_setup(dir_dest):
    status = False
    destpath=''
    try:
        # Get path for detination
        destpath=os.path.join(os.getcwd(),dir_dest)

        # Create config dir if it does not exist
        log_debug("Check directory: %s" % destpath)
        if not os.path.exists(destpath):
            log_debug("Creating directory: %s" % destpath)
            # os.makedirs(destpath)
            os.mkdir(destpath)
        status = True
    except Exception as e:
        log_exception("Failed to setup directory",e)
    
    return status,destpath

# Command line handler
def cli_handler():
    parser = argparse.ArgumentParser()
    
    # Destination Folder
    parser.add_argument("-f","--file", \
        help="Name of configuration file uploaded by user.",
        required=True)

    # Destination Folder
    parser.add_argument("-d","--dest", \
        help="Destination folder to store files in TestEnv",
        required=False,
        default=DIR_CONFIG)
    
    # Parse arguments
    args = parser.parse_args()
    return args.file,args.dest

# Exit with error
def error_exit():
    log_error("Exiting system.")
    sys.exit(1)
    return

# Extract zip file
# Arguments:
#     filename: Zip file to be extracted
#     directory: Path to extract file. MUST BE ABSOLUTE PATH and NOT relative.
# NOTE: Uses a workaround to avoid error when extracting certificates with 
# very long names. Windows has a char limit of 260 char for filepath. 
# Adding \\?\ before the absolute path solves this.
def extract_file(filename,directory):
    status = False
    log_info("Extract %s to %s"%(filename,directory))
    
    # NOTE: This is a Workaround for long filenames
    longdir=r'\\?\ '.strip()+directory
    try:
        # Delete folder if it already exists
        if os.path.isdir(longdir):
            shutil.rmtree(longdir)
        # Extract to folder
        with ZipFile(filename,'r') as zfile:
            zfile.extractall(longdir)
            log_debug("Extraction complete.")
        
        # If only one folder in extract directory then move contents of 
        # this folder to extract directory.
        _contents=os.listdir(longdir)
        if (len(_contents) == 1):
            # Only one item in extract directory
            dir_extracted=os.path.join(longdir,_contents[0])
            if (os.path.isdir(dir_extracted)):
                # Single item in extract directory is a folder

                # Move data from extract folder to actual config directory
                log_debug("Found single directory in extracted folder.")
                log_debug("Moving %s to %s" % (dir_extracted,longdir))
                if os.path.exists(dir_extracted):
                    for item in os.listdir(dir_extracted):
                        item_path=os.path.join(dir_extracted,item)
                        shutil.move(item_path,longdir)
                    # Remove initial extract folder
                    shutil.rmtree(dir_extracted)
            else:
                # Single file found. Do nothing
                log_debug("No rearrangement needed in extracted folder(Single file)")
        else:
            # Multiple files/folders found. Do nothing
            log_debug("No rearrangement needed in extracted folder(0 or more files/folders)")
        # Update return status
        status = True
    except Exception as e:
        status=False
        log_exception("Failed to extract file.",e)
    return status

# API -------------------------------------------------------------------------

# Extract data from user configuration and copy to destination
# Create TestEnv if not available
# Create a Config directory in TestEnv if not available
# NOTE: Assumed that this function will be called from the root directory.
def get_user_config():
    # Get destination folder from arguments
    filename,dir_dest=cli_handler()
    log_info("Get configuration uploaded by user.")
    
    dirsetup_status,destpath=directory_setup(dir_dest)
    # Check if directory was setup correctly
    if dirsetup_status:
        # Extract files to destination path
        if extract_file(filename,destpath):
            # Extract complete
            pass
        else:
            # Failed to extract file
            log_error("Failed to extract files")
            sys_exit(GUC_EXTRACT_ERROR)
    else:
        # Failed to setup directory
        log_info("Failed to setup directory")
        sys_exit(GUC_SETUP_ERROR)
    return

if __name__=='__main__':
    log_info('-'*80)
    try:
        get_user_config()
    except Exception as e:
        log_exception("Exception when downloading vECU",e)
    log_info('-'*80)
    

# End of File -----------------------------------------------------------------
