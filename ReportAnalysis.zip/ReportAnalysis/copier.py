# -*- coding: utf-8 -*-
"""
Created on Mon Dec 13 10:45:03 2021
@author: STEPHIG
Desc: Copy files from source to destination
"""

# Imports ---------------------------------------------------------------------
import errno
import os
from re import S
import shutil
import argparse as ap

from Logger import LogHandler

# Logger ----------------------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

# Functions -------------------------------------------------------------------

# Command line handler
def cli_handler():
    # Create parser
    parser= \
        ap.ArgumentParser(description="Copy files from source to destination.")
    
    # Add argument for source path(s)
    parser.add_argument('-s', "--src",
        metavar="SOURCE",
        type=str,
        nargs='+',
        help="Enter source path(s) to be copied.",
        required=True)
    
    # Argument for destination path
    parser.add_argument('-d', "--dest",
        metavar="DESTINATION",
        type=str,
        help="Enter destination path where files are to be moved.",
        required=True)
    
    args = parser.parse_args()
    
    return args.src,args.dest

# Copy file from source to destination
def copier(src,dest):
    logger.debug("Start copier: %s to %s" % (src,dest))
    
    # Update source and destination paths to long path format
    if os.path.isabs(src):
        longsrc=r'\\?\ '.strip()+src
        src=longsrc
    else:
        longsrc=os.path.join(os.path.abspath("."),src)
        longsrc=r'\\?\ '.strip()+longsrc
        src=longsrc
    
    if os.path.isabs(dest):
        longdest=r'\\?\ '.strip()+dest
        dest=longdest
    else:
        longdest=os.path.join(os.path.abspath("."),dest)
        longdest=r'\\?\ '.strip()+longdest
        dest=longdest
    
    logger.debug("Copier long paths: %s to %s" % (src,dest))
    
    # Check if source is a path or directory
    if os.path.isdir(src):
        # Copy folder tree
        try:
            for src_dir, dirs, files in os.walk(src):
                dst_dir = src_dir.replace(src, dest, 1)
                if not os.path.exists(dst_dir):
                    os.makedirs(dst_dir)
                for file_ in files:
                    src_file = os.path.join(src_dir, file_)
                    dst_file = os.path.join(dst_dir, file_)
                    if os.path.exists(dst_file):
                        # in case of the src and dst are the same file
                        if os.path.samefile(src_file, dst_file):
                            continue
                        os.remove(dst_file)
                    shutil.copy(src_file, dst_dir)
        except Exception as e:
            logger.exception("Exception during copy: %s"%e)
    else:
        # Create destination if not available
        if not os.path.exists(dest):
            os.makedirs(dest)
        
        # Copy File
        if os.path.exists(src):
            shutil.copy(src,dest)

    return

def main():
    source_list,destination=cli_handler()
    try:
        for source in source_list:
            copier(source,destination)
    except Exception as e:
        logger.exception("Exception while copying: %s"%e)
    return

if __name__ == '__main__':
    main()
    pass


# End of File -----------------------------------------------------------------
