# coding: utf-8
"""
Created on 05-Jul-2022
@author: STEPHIG
Desc: Compare multiple report files
"""

# Imports ---------------------------------------------------------------------
import argparse as ap
from ReportAnalysis.common import VALID_TEST_TYPES
from ReportAnalysis.common import TEST_TYPE_STRING

from ReportAnalysis.SW_VERSION import VERSION as sw_version

# Check __init__.py in ReportAnalysis module
from ReportAnalysis import compare_reports
from ReportAnalysis.CLI import get_inputs_for_compare

from Logger import LogHandler

# Variables -------------------------------------------------------------------
if __name__=='__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

# Functions -------------------------------------------------------------------

# Command line handler
def cli_handler():
    # Create parser
    parser=ap.ArgumentParser(description="Compare XML report files.")
    comparer_args=parser.add_argument_group("Required arguments")
    
    # List of input files
    comparer_args.add_argument("-i","--input",
        type=str,
        nargs='+',
        help="List of report files to be compared(in order)",
        required=True )
    
    # Add argument for file type
    comparer_args.add_argument('-t', "--type",
        type=str,
        choices=VALID_TEST_TYPES,
        help="Type of report file: %s"%TEST_TYPE_STRING,
        required=True)

    args = parser.parse_args()
    
    return args.input,args.type

# Report comparison:
#     Compare multiple report files
#     Create an excel sheet with the summary
# Arguments: list containing the following
#     list_of_files: List of XML report files to be compared
#     filetype: Test type of the reports (NTS | TLS | HEST | DIVA |GWD)
def compare(inputs):
    list_of_files,filetype=get_inputs_for_compare(inputs)
    # check for valid filetype and at least 2 files to be compared
    if (filetype is not None):
        if (len(list_of_files) > 1):
            # Compare reports
            compare_reports(filelist=list_of_files, filetype=filetype)
        else:
            logger.error("Specify at least 2 files for comparison")
    else:
        logger.error("Please specify a valid filetype")
    return

# Main analysis function if this file is executed as a standalone
def main():
    # Get inputs from command line
    filename,test_type = cli_handler()
    # Arrange inputs as required
    inputs=[filename,test_type]
    # Compare reports
    logger.info("Report Analysis Tool: %s"%(sw_version.version))
    compare(inputs)
    return

# Run -------------------------------------------------------------------------

if __name__ =='__main__':
    logger.debug("-"*80)
    main()
    logger.debug("-"*80)
    pass

# End of File ----------------------------------------------------------------
