# -*- coding: utf-8 -*-
"""
Created on 07-Jun-2022
@author: STEPHIG
Desc: API to handle command line interface for report analysis.
"""

# imports ---------------------------------------------------------------------

import argparse as ap

from Logger import LogHandler
from .common import VALID_TEST_TYPES
from .common import TEST_TYPE_STRING

# Constants -------------------------------------------------------------------

# Command line Action: Analyze
CLAT_ANALYZE="analyze"
CLAT_ANALYZE_HELP="Get test overview and analyze failure cases \
    from test report."

# Command line Action: Comaprison
CLAT_COMPARE="compare"
CLAT_COMPARE_HELP="Comapre test overview and ECU performance in \
    tests from list of test reports."

# Number of arguments for operation
NOA_ANALYZE=3  # (filename, file type, upload)
NOA_COMPARE=2  # (list of files, file type)

# Command Line Interface ------------------------------------------------------
# Create Logger
logger=LogHandler(__name__)

# Command line interface options for analyzer
def cli_analyzer(subparsers):
    # Add subparser for analyzer
    analyzer=subparsers.add_parser(CLAT_ANALYZE, help=CLAT_ANALYZE_HELP)
    analyzer_args=analyzer.add_argument_group("Required inputs for Analyzer")
    
    # Add argument for file path
    analyzer_args.add_argument("-i","--input",
        metavar="FILE_PATH",
        type=str,
        help="Report file to be analyzed",
        required=True)

    # Add argument for file type
    analyzer_args.add_argument('-t', "--type",
        metavar="FILE_TYPE",
        type=str,
        choices=VALID_TEST_TYPES,
        help="Type of report file: %s"%TEST_TYPE_STRING,
        required=True)
    
    # Add optional argument to enable upload to database
    analyzer.add_argument("-u", "--upload",
        action="store_true",
        help="Upload data from report to online database")
    
    return

# Command line interface options for analyzer
def cli_comparison(subparsers):
    # Add subparser for comparison
    comparer=subparsers.add_parser(CLAT_COMPARE, help=CLAT_COMPARE_HELP)
    comparer_args=comparer.add_argument_group("Arguments for Comparison")
    
    # List of input files
    comparer_args.add_argument("-i","--input",
        metavar="FILES",
        type=str,
        nargs='+',
        help="List of report files to be compared(in order)",
        required=True )
    
    # Add argument for file type
    comparer_args.add_argument('-t', "--type",
        metavar="FILE_TYPE",
        type=str,
        choices=VALID_TEST_TYPES,
        help="Type of report file: %s"%TEST_TYPE_STRING,
        required=True)

    return

# API for command line interface
def command_line_handler():
    # Create parser
    parser=ap.ArgumentParser(description="ECU Test Report Analysis")
    
    # Add subparsers to handle different actions
    subparsers = parser.add_subparsers(title="Actions",
        help="List of valid actions",
        dest='action',
        required=True)
    
    # Add commands for Analysis
    cli_analyzer(subparsers)
    
    # Add commands for comparison
    cli_comparison(subparsers)
    
    # Parse arguments
    args=parser.parse_args()
    arguments = list()
    
    if (CLAT_ANALYZE == args.action):
        arguments.append(args.input)  # Filename
        arguments.append(args.type)  # Test type
        arguments.append(args.upload)  # Enable/Disable upload to database
    elif (CLAT_COMPARE == args.action):
        arguments.append(args.input)
        arguments.append(args.type)
    else:
        # Invalid action type
        pass
    
    return args.action,arguments

# Get parameters for analyser from arguments
def get_inputs_for_analyzer(inputs):
    # Set default values
    filename=None
    filetype=None
    upload=False

    # Check number of inputs
    if NOA_ANALYZE == len(inputs):
        # get parameters from inputs
        filename=inputs[0]
        filetype=inputs[1]
        upload=bool(inputs[2])
    else:
        logger.error("Invalid number of inputs for analysis.")
    
    return filename,filetype,upload

def get_inputs_for_compare(inputs):
    # Set default values
    list_of_files=[]
    filetype=None

    # Check number of inputs
    if NOA_COMPARE == len(inputs):
        # Get parameters from list of inputs
        list_of_files = inputs[0]
        filetype = inputs[1]
    else:
        logger.error("Invalid number of inputs for comparison.")
    
    return list_of_files,filetype


if __name__=="__main__":
    pass

# End of file -----------------------------------------------------------------
