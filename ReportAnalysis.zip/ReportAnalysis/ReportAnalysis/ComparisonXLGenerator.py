# -*- coding: utf-8 -*-
"""
@author: MJOSEP
Desc: 
    - Generate Excel file with comparison data.
"""

from Logger import LogHandler

from .compare import get_compare_data
from .compare import CNDK_IDENTICAL
from .compare import CNDK_OPPOSITE
from .compare import CMPDK_TITLES
from .compare import CMPDK_OVERVIEW
from .compare import CMPDK_DATA
from .compare import CMPDK_CONTRAST

from .ExcelHandler import ExcelHandler

from .RHconstants import GFK_Red_Colour
from .RHconstants import GFK_Green_Colour
from .RHconstants import GFK_Grey_Colour
from .RHconstants import GFK_NoFill_Colour
from .RHconstants import GFK_TEST_GROUP_TITLE
from .RHconstants import GFK_TEST_CASE_LEVEL
from .RHconstants import GFK_TEST_CASE_TITLES
from .RHconstants import GFK_TEST_CASE_RESULT
from .RHconstants import GFK_INTERNAL_VALUE
from .RHconstants import GFK_INTERNAL_BOLD
from .RHconstants import GFK_INTERNAL_FILLCOLOUR
from .RHconstants import BIK_OVERVIEW_SL_NO
from .RHconstants import OVEK_TEST_COUNT
from .RHconstants import OVEK_EXE_COUNT
from .RHconstants import OVEK_PASS_COUNT
from .RHconstants import OVEK_FAIL_COUNT
from .RHconstants import GFK_OVERVIEW_SW_VERSION
from .RHconstants import GFK_TITLE_TEST_NAME
from .RHconstants import GFK_TITLE_TEST_NUM 
from .RHconstants import GFK_SHEET_NAME_COMPARISON
from .RHconstants import CMP_TEST_NOT_FOUND
from .RHconstants import GFK_NO_DATA
from .RHconstants import GFK_PASS
from .RHconstants import GFK_FAIL
from .RHconstants import GFK_NA
from .RHconstants import BIK_TOOL_VERSION
from .RHconstants import BIK_DATE
from .RHconstants import BIK_SW_VERSION


# Create logger
logger=LogHandler(__name__)

# For test data Decide excel properties based on data keyword
# Return: Dictionary with data and excel properties based on type of data
def arrangeData(dataKeyword, data):
    dataOut = {}
    if dataKeyword == GFK_TEST_GROUP_TITLE:
        dataOut[GFK_INTERNAL_BOLD] = False
        dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_Grey_Colour
        for subdata in data:
            if subdata[GFK_TEST_GROUP_TITLE] != CMP_TEST_NOT_FOUND:
                dataOut[GFK_INTERNAL_VALUE] = subdata[GFK_TEST_GROUP_TITLE]
            else:
                dataOut[GFK_INTERNAL_VALUE] = GFK_NO_DATA
        
    elif dataKeyword == GFK_TEST_CASE_LEVEL:
        for subdata in data:
            if subdata[GFK_TEST_CASE_LEVEL] != CMP_TEST_NOT_FOUND:
                dataOut[GFK_INTERNAL_VALUE] = subdata[GFK_TEST_CASE_LEVEL]
                break
            else:
                dataOut[GFK_INTERNAL_VALUE] = GFK_NO_DATA
        dataOut[GFK_INTERNAL_BOLD] = False
        dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour
    
    elif dataKeyword == GFK_TEST_CASE_TITLES:
        for subdata in data:
            if subdata[GFK_TEST_CASE_TITLES] != CMP_TEST_NOT_FOUND:
                dataOut[GFK_INTERNAL_VALUE] = subdata[GFK_TEST_CASE_TITLES]
                break
            else:
                dataOut[GFK_INTERNAL_VALUE] = GFK_NO_DATA
        dataOut[GFK_INTERNAL_BOLD] = False
        dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour
    
    elif dataKeyword == GFK_TEST_CASE_RESULT:
        dataOut[GFK_INTERNAL_BOLD] = False
        if data[GFK_TEST_CASE_RESULT] == GFK_PASS:
            dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_Green_Colour
            dataOut[GFK_INTERNAL_VALUE] = data[GFK_TEST_CASE_RESULT]
        elif data[GFK_TEST_CASE_RESULT] == GFK_FAIL:
            dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_Red_Colour
            dataOut[GFK_INTERNAL_VALUE] = data[GFK_TEST_CASE_RESULT]
        else:
            dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour
            dataOut[GFK_INTERNAL_VALUE] = GFK_NA
    
    return dataOut

# For overview Decide excel properties based on data keyword
# Return: Dictionary with data and excel properties based on type of data
def arrangeOverviewData(dataKeyword, data):
    dataOut=None
    try:
        dataOut = {}
        if dataKeyword == BIK_OVERVIEW_SL_NO:
            dataOut[GFK_INTERNAL_VALUE] = 1
            dataOut[GFK_INTERNAL_BOLD] = False
            dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour
        # elif dataKeyword == GFK_OVERVIEW_SW_VERSION:
        #     dataOut[GFK_INTERNAL_VALUE] = data[GFK_OVERVIEW_SW_VERSION]
        #     dataOut[GFK_INTERNAL_BOLD] = False
        #     dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour       
        elif dataKeyword == BIK_DATE:
            dataOut[GFK_INTERNAL_VALUE] = data[BIK_DATE]
            dataOut[GFK_INTERNAL_BOLD] = False
            dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour
        elif dataKeyword == OVEK_TEST_COUNT:
            dataOut[GFK_INTERNAL_VALUE] = data[OVEK_TEST_COUNT]
            dataOut[GFK_INTERNAL_BOLD] = False
            dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour
        elif dataKeyword == OVEK_EXE_COUNT:
            dataOut[GFK_INTERNAL_VALUE] = data[OVEK_EXE_COUNT]
            dataOut[GFK_INTERNAL_BOLD] = False
            dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour
        elif dataKeyword == OVEK_PASS_COUNT:
            dataOut[GFK_INTERNAL_VALUE] = data[OVEK_PASS_COUNT]
            dataOut[GFK_INTERNAL_BOLD] = False
            dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour
        elif dataKeyword == OVEK_FAIL_COUNT:
            dataOut[GFK_INTERNAL_VALUE] = data[OVEK_FAIL_COUNT]
            dataOut[GFK_INTERNAL_BOLD] = False
            dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour    
    except Exception as reason:
        logger.exception("Exception in arrangeOverviewData(): %s"%(reason))
    return dataOut

# For contrast decide excel properties
# Return: Dictionary with data and excel properties based on type of data
def arrangeContrastData(data):
    dataOut=None
    try:
        dataOut = {}
        dataOut[GFK_INTERNAL_VALUE] = data
        dataOut[GFK_INTERNAL_BOLD] = False
        dataOut[GFK_INTERNAL_FILLCOLOUR] = GFK_NoFill_Colour    
    except Exception as reason:
        logger.exception("Exception in arrangeContrastData: %s"%(reason))
    return dataOut

# To put the cases in ascending order in excel         
def compareversion(version1, version2):
    versions1 = [int(v) for v in version1.split(".")]
    versions2 = [int(v) for v in version2.split(".")]
    for i in range(max(len(versions1),len(versions2))):
        v1 = versions1[i] if i < len(versions1) else 0
        v2 = versions2[i] if i < len(versions2) else 0
        if v1 > v2:
            return 1
        else:
            return -1
    return 0     

# sorting the testcases in ascending order
def sort_data (levelList,titleList):
    for i in range(len(levelList)):
        for j in range(i + 1, len(levelList)):
            out_version= compareversion(levelList[i],levelList[j])
            if (out_version == 1 ) :
                levelList[i], levelList[j] = levelList[j], levelList[i]
                titleList[i],titleList[j] = titleList[j], titleList[i]

    return levelList, titleList 

# Get list of test titles without duplicates
def getUniqueTestTitles(data):
    result=[]
    try:
        titleList = []
        levelList = []
        for eachVersionData in data:
            for eachRowData in eachVersionData:
                if(eachRowData[GFK_TEST_GROUP_TITLE] != CMP_TEST_NOT_FOUND):
                    titleList.append(eachRowData[GFK_TEST_GROUP_TITLE])
                    levelList.append(eachRowData[GFK_TEST_CASE_LEVEL])
                    break
        
        levelsetList,titlesetList=sort_data(levelList,titleList)
        # create new list of titles without duplicate entries
        [result.append(x) for x in titlesetList if x not in result]
    except Exception as reason:
        logger.exception("Exception in getUniqueTestTitles(): %s"%(reason))
    return result

# Check if data belongs to specified group
def ishavingSameGroupTitle(testGroupTitle, eachRowData):
    foundFlag = False
    try:
        for versionData in eachRowData:
            if versionData[GFK_TEST_GROUP_TITLE] == testGroupTitle:
                foundFlag = True
                break
    except Exception as reason:
            logger.exception("Exception in ishavingSameGroupTitle(): %s" \
                %(reason))
    return foundFlag

# API to Comapre reports
# Arguments:
#     filelist: List of reports to be compared
#     filetype: Type of report (NEST|NTS|DiVA|TLS|...)
def compare_reports(filelist,filetype):
    titleList = [GFK_TITLE_TEST_NUM, GFK_TITLE_TEST_NAME]
    overviewTitle = [BIK_DATE, OVEK_TEST_COUNT, OVEK_EXE_COUNT, \
        OVEK_PASS_COUNT, OVEK_FAIL_COUNT]
    contrastTitle = [CNDK_IDENTICAL,CNDK_OPPOSITE]
    overviewDataList = []
    # all comparison data
    compared_data = get_compare_data( \
        comparison_list=filelist, \
        file_type=filetype )
    
    comparedTestData = compared_data[CMPDK_DATA]
    logger.debug("Comparison data Extracted")

    overviewData = compared_data[CMPDK_OVERVIEW]
    logger.debug("Overview data Extracted")
    
    contrastData = compared_data[CMPDK_CONTRAST]

    # Names of report files compared
    report_titles=compared_data["ReportTitle"]
    
    if len(comparedTestData[0]) == len(overviewData):
        logger.debug("Data length matching")
    
    else:
        logger.debug("Data length not matching")

    # Create excel file object
    xl_File = ExcelHandler()
    xl_File.generateXL()
    xl_File.set_active_sheet(GFK_SHEET_NAME_COMPARISON)
    uniqueTestGroupTitles = getUniqueTestTitles(comparedTestData)
    
    newDataList = []
    entryCount = 0
    for testGroupTitle in uniqueTestGroupTitles:
        subDataList = []
        subDataList. append(testGroupTitle)
        for eachRowData in comparedTestData:
            if ishavingSameGroupTitle(testGroupTitle, eachRowData):
                entryCount = entryCount+1
                noOfVersions = len(eachRowData)
                tempList = []
                preparedData_1 = arrangeData(GFK_TEST_CASE_LEVEL, eachRowData)
                
                if bool(preparedData_1):
                    tempList.append(preparedData_1)
                    preparedData_2 = arrangeData(GFK_TEST_CASE_TITLES, \
                        eachRowData)
                if bool(preparedData_2):
                    tempList.append(preparedData_2)
                for eachVersionData in eachRowData:
                    preparedData_3 = arrangeData(GFK_TEST_CASE_RESULT, \
                        eachVersionData)
                    if bool(preparedData_3):
                        tempList.append(preparedData_3)
                subDataList.append(tempList)
        newDataList.append(subDataList)
        
    # Add title to columns
    for index in range(len(report_titles)):
        try:
            versionTitle = BIK_DATE + ': ' + str(overviewData[index][BIK_DATE])
        except:
            # Parameter not found
            versionTitle=BIK_DATE + ': NA'
        
        try:
            report_name = CMPDK_TITLES + ': ' + report_titles[index]
        except:
            # Parameter not found
            report_name=CMPDK_TITLES + ": NA"
        titleList.append(report_name+"\n"+versionTitle)
    
    xl_File.add_comparisonTable(2,1, titleList, newDataList)
    numOfRows = len(uniqueTestGroupTitles) + entryCount + 2
    numberOfColum = len(titleList) 
    xl_File.draw_boder(2, numOfRows, 1, numberOfColum)
    logger.info("Comparison data table added")    
    
    # Table containing overview data
    for eachVersionData in overviewData:
        tempList = []
        preparedData_1 = arrangeOverviewData(BIK_OVERVIEW_SL_NO, \
            eachVersionData)
            
        preparedData_2 = arrangeOverviewData(BIK_DATE, eachVersionData)
        if bool(preparedData_2):
            tempList.append(preparedData_2)
            
        preparedData_3 = arrangeOverviewData(OVEK_TEST_COUNT, eachVersionData)
        if bool(preparedData_3):
            tempList.append(preparedData_3)
            
        preparedData_4 = arrangeOverviewData(OVEK_EXE_COUNT, eachVersionData)
        if bool(preparedData_4):
            tempList.append(preparedData_4)
            
        preparedData_5 = arrangeOverviewData(OVEK_PASS_COUNT, eachVersionData)
        if bool(preparedData_5):
            tempList.append(preparedData_5)
            
        preparedData_6 = arrangeOverviewData(OVEK_FAIL_COUNT, eachVersionData)
        if bool(preparedData_6):
            tempList.append(preparedData_6)
        overviewDataList.append(tempList)
            
    xl_File.set_active_sheet(CMPDK_OVERVIEW) 
    xl_File.add_overviewTable(10,2, overviewTitle, overviewDataList)   
    logger.info("Overview table added")
    
    # Handle contrast data
    if contrastData is not None:
        # add contrast data with cell formatting to a list
        contrastList=[]
        for data in contrastData.keys():
            contrastList.append(arrangeContrastData(contrastData[data]))
        # Add a table with contrast data
        xl_File.add_contrastTable(3,2,list(contrastData.keys()), contrastList)

    # Create filename and save to file
    outfile="Comparison_%s.xlsx"%(filetype)
    xl_File.save(filename=outfile)
    
    return


if __name__=="__main__":
    pass

# End of File -----------------------------------------------------------------
