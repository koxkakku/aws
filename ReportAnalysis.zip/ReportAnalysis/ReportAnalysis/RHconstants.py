# -*- coding: utf-8 -*-
'''
Created by: STEPHIG
Date: 21-Apr-2022
Desc: Report Handler contants, keys.
'''

# Report Handler constants

# Common dictionary keys (CDK_*)
CDK_TITLE="Title"
CDK_RESULT="Result"
CDK_LEVEL="Level"
CDK_OVERVIEW="Overview"

# Extracted Test Data Keys (ETDK_*)
ETDK_TITLE = "Title"
ETDK_OVERVIEW = "Overview"
ETDK_ECU_INFO = "ECU_info"
ETDK_TEST_DATA = "Test_Data"

#Test Data Keys for comparison file
CMP_TEST_GROUP = 'testgroup'
CMP_TEST_CYCLE = 'testcycle'
CMP_TESTCASE_TITLE = 'TestCase_Title:'
CMP_TESTCASE_LEVEL = 'TestCase_Level:'
CMP_TESTCASE_RESULT = 'TestCase_Result:'
CMP_TESTGROUP_TITLE = 'TestGroup_Title:'
CMP_TESTGROUP_LEVEL = 'TestGroup_Level:'
CMP_TEST_NOT_FOUND='TESTCASE NOT FOUND'
CMP_TESTCASE_RESULT_STR = 'TestCase_Result'

# Overview extract keys (OVEK_*)
OVEK_VERDICT = "Verdict"
OVEK_TEST_COUNT = "Total_Tests"
OVEK_PASS_COUNT = "Passed"
OVEK_FAIL_COUNT = "Failed"
OVEK_NA_COUNT = "NA"
OVEK_NE_COUNT = "Not_Executed"
OVEK_EXE_COUNT = "Executed"
OVEK_WARNING_COUNT = "Warning"
OVEK_INCONCLUSIVE_COUNT = "Inconclusive"

# Basic information Keys (BIK_*)
BIK_ECU_NAME="ECU_Name"
BIK_ECU_ID="ECU_ID"
BIK_RELEASE_VERSION="ECU_RELEASE" # BITS version
BIK_TOOL_VERSION="TOOL_VERSION"  # Test tool version
BIK_ECU_VARIANT="ECU Variant"
BIK_SPEC_VERSION="Specification Version"
BIK_ECU_EXTRACT="EXTRACT_VERSION"  # ARXML extract version
BIK_SW_VERSION="SW_VERSION"  # Software version
BIK_DATE="Date"  # Modification Date
BIK_OVERVIEW_SL_NO='S.No'#serial number
BIK_TEST_CONFIGURATION="TATS Version"

# Extract Data Test Step Keys (EDTSK_*)
EDTSK_ACTION="Action"
EDTSK_DESC="Desc"
EDTSK_RESULT=CDK_RESULT
EDTSK_LEVEL=CDK_LEVEL

# Extract Data Test Case Keys (EDTCK_*)
EDTCK_RESULT=CDK_RESULT
EDTCK_TITLE=CDK_TITLE
EDTCK_LEVEL=CDK_LEVEL
EDTCK_IDENT="Ident"
EDTCK_PRECONDITION="Data_Precondition"
EDTCK_STEPS="Steps"

# Test Group Keys (TGK_*)
EDTGK_TITLE=CDK_TITLE
EDTGK_LEVEL=CDK_LEVEL
EDTGK_OVERVIEW="Overview"
EDTGK_DATA="Data"

TEST_TAG_TYPE_KEY="ParaType"

# Data Extractor test group keys (DXTGK_*)
DXTGK_TITLE=CDK_TITLE
DXTGK_LEVEL=CDK_LEVEL
DXTGK_RESULT=CDK_RESULT
DXTGK_OVERVIEW=CDK_OVERVIEW
DXTGK_DATA="Data"

# Data Extractor test case keys (DXTCK_*)
DXTCK_TITLE=CDK_TITLE
DXTCK_LEVEL=CDK_LEVEL
DXTCK_RESULT=CDK_RESULT
DXTCK_REASON="Analysis"


# CompareXL Generator FILE KEYS(GFK_*)
GFK_JSON_FILE = "compare_output.json"
GFK_DEFAULT_FILE_NAME = "output.xlsx"
GFK_Blue_Color= '0000CCFF'
GFK_Default_width = 25
GFK_Short_width = 15
GFK_Max_Width=70
GFK_Red_Colour = '00ff0000'
GFK_Green_Colour = '0000ff00'
GFK_Grey_Colour = '00C0C0C0'
GFK_NoFill_Colour = '00ffffff'
GFK_TEST_GROUP_TITLE = "TestGroup_Title"
GFK_TEST_GROUP_LEVEL = "TestGroup_Level"
GFK_TEST_CASE_LEVEL = "TestCase_Level"
GFK_TEST_CASE_TITLES = "TestCase_Title"
GFK_TEST_CASE_RESULT = "TestCase_Result"
GFK_INTERNAL_VALUE = "VALUE"
GFK_INTERNAL_BOLD = "BOLD"
GFK_INTERNAL_FILLCOLOUR = "FILLCOLOUR"
GFK_OVERVIEW_SW_VERSION = "SW_Version"
GFK_TITLE_TEST_GROUP = 'Test Group'
GFK_TITLE_TEST_NAME = 'Test Name'
GFK_TITLE_TEST_NUM = 'Test No.'
GFK_SHEET_NAME_COMPARISON = 'Comparison'
GFK_NO_DATA='-'
GFK_PASS='pass'
GFK_FAIL='fail'
GFK_NA='N.A'


# End of file -----------------------------------------------------------------
