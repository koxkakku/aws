# -*- coding: utf-8 -*-
"""
Created on Thu June 23 11:57:09 2022

@author: ASEMPON

Desc:
    - Collect requested data from database using REST_API 
    - Push data into database using REST_API
"""

#importing request module for the REST API
import requests
import urllib3
import json
import datetime

from enum import IntEnum

# Overview dict keys
from .RHconstants import OVEK_PASS_COUNT
from .RHconstants import OVEK_WARNING_COUNT
from .RHconstants import OVEK_FAIL_COUNT
from .RHconstants import OVEK_NE_COUNT
from .RHconstants import OVEK_EXE_COUNT
from .RHconstants import BIK_SW_VERSION

# Basic information Key
from .RHconstants import BIK_ECU_NAME
from .RHconstants import BIK_RELEASE_VERSION

from ReportAnalysis.RESTconstants import ACCESS_TOKEN 
from ReportAnalysis.RESTconstants import BROP_RELEASE 
from ReportAnalysis.RESTconstants import TOOL_NAME 
from ReportAnalysis.RESTconstants import SPRINT 
from ReportAnalysis.RESTconstants import ECU_NAME 
from ReportAnalysis.RESTconstants import STATUS_CODE
from ReportAnalysis.RESTconstants import TEXT_INFO 
from ReportAnalysis.RESTconstants import WARNING
from ReportAnalysis.RESTconstants import SKIPPED
from ReportAnalysis.RESTconstants import VERSION
from ReportAnalysis.RESTconstants import TOTAL_FAIL
from ReportAnalysis.RESTconstants import TOTAL_TESTS
from ReportAnalysis.RESTconstants import TOTAL_PASS
from ReportAnalysis.RESTconstants import OVERVIEW 
from ReportAnalysis.RESTconstants import ECU_INFO 
from ReportAnalysis.RESTconstants import EXECUTION_TIMESTAMP
from ReportAnalysis.RESTconstants import URL 
from ReportAnalysis.RESTconstants import ERROR_MSG
from ReportAnalysis.RESTconstants import RESPONSE_URL

from .ReportAnalysis import AnalyseReport

from Logger import LogHandler

overview = {'PassCases':0,'FailCases':0}

# expected data format using the post and get methods
'''
Data format expected from the API
{
    "toolName": "NTS",
    "warning": 0,
    "skipped": 0,
    "ecuName": "idc",
    "version": "B3-11-12-2022",
    "sprint": "sprint-12",
    "bropRelease": "B3",
    "ExecutionTimestamp": "19-05-2022 01:36:59",
    "totalFail": 12,
    "totalTests": 36,
    "totalPass": 24
}
'''

class resultdata(IntEnum):
    ECU_NAME = 0
    TOTAL_CASE = 1
    PASS_CASE = 2
    FAIL_CASE = 3
    VERSION = 8
     
class DatabaseGetdata():
    def __init__(self):
        self.dblogger = LogHandler()
        pass
    
    # A function which returns token for the authorisation purpose which is used 
    # in get and post methods    
    def generate_token(self):  

        token = None 
        response = None
        head = {'Cache-Control' : 'no-cache',
                'Content-Type' : 'application/x-www-form-urlencoded',
                'Authorization' : 'Basic REFJVkJBRE1fTUlDVE1fRU1FQV9QUk9EXzAwNTEyOjE1LVBSVnBJNl83Llp1aTNocktDOWIweH5YUzJxUTg0'}
        data = {'client_id': 'DAIVBADM_MICTM_EMEA_PROD_00512' ,
                'grant_type' : 'client_credentials',
                'scope': 'openid groups audience'}

        try: 
            response = requests.post('https://ssoalpha.dvb.corpinter.net/v1/token' , headers = head, data=data) 
            data = json.loads(response.text)
            token = data[ACCESS_TOKEN]
        except requests.exceptions.ConnectionError as errc:
            self.dblogger.error("Error Connecting:  %s"%errc)
        except requests.exceptions.HTTPError as errh:
            self.dblogger.error("Http Error:  %s"%errh)
        except requests.exceptions.RequestException as err:
            self.dblogger.error("OOps: Something Else  %s"%err) 
        except Exception as e:
            self.dblogger.error("Exception while generating token %s"%e)
        return token    
        
    # get method which returns all the data that is present in the database 
    # with respect to ecuName, brop release etc.
    def get_method_view_all(self):
        temp = {}
        response = None
        ACCESS_TOKEN = self.generate_token()
        head = {'Authorization': 'Bearer {}'.format(ACCESS_TOKEN) }

        try:
            response = requests.get(URL ,  headers = head)
            temp[STATUS_CODE] = response.status_code
            temp[TEXT_INFO] = response.text
        except requests.exceptions.ConnectionError as errc:
            self.dblogger.error("Error Connecting:  %s"%errc)
        except requests.exceptions.HTTPError as errh:
            self.dblogger.error("Http Error:  %s"%errh)
        except requests.exceptions.RequestException as err:
            self.dblogger.error("OOps: Something Else  %s"%err)  
        except Exception as e:
            self.dblogger.error("Exception while getting data from database %s"%e)
            
        return temp

    # get method which returns data from data base with respect to the brop release
    def get_method_brop_release(self,input_data):
        temp = {}
        response = None
        ACCESS_TOKEN = self.generate_token()
        head = {'Authorization': 'Bearer {}'.format(ACCESS_TOKEN) }
        # brop_release = input('enter the brop_release: ')
        data ={BROP_RELEASE: input_data}
        url = URL+f'broprelease?{data}'

        try:
            response = requests.get(url , params=data, headers = head)
            temp[STATUS_CODE] = response.status_code
            if len(response.text)>2:
                temp[TEXT_INFO] = response.text
            else:
                temp[TEXT_INFO] = ERROR_MSG
        except requests.exceptions.ConnectionError as errc:
            self.dblogger.error("Error Connecting: %s"%errc)
        except requests.exceptions.HTTPError as errh:
            self.dblogger.error("Http Error: %s"%errh)
        except requests.exceptions.RequestException as err:
            self.dblogger.error("OOps: Something Else %s"%err)  
        except Exception as e:
            self.dblogger.error("Exception while getting brop release from database %s"%e)
            
        return temp

    # get method which returns data from data base with respect to the tool Name
    def get_method_tool_name(self,input_data):
        temp = {}
        response = None
        ACCESS_TOKEN = self.generate_token()
        head = {'Authorization': 'Bearer {}'.format(ACCESS_TOKEN) }
        # toolname = input('Enter the tool name: ')
        data = {TOOL_NAME: input_data}
        url = URL+f'toolname?{data}'

        try:
            response = requests.get(url , params=data, headers = head)
        except requests.exceptions.ConnectionError as errc:
            self.dblogger.error("Error Connecting: %s"%errc)
        except requests.exceptions.HTTPError as errh:
            self.dblogger.error("Http Error: %s"%errh)
        except requests.exceptions.RequestException as err:
            self.dblogger.error("OOps: Something Else %s"%err)
        except Exception as e:
            self.dblogger.error("Exception while getting tool name from database %s"%e)  

        temp[STATUS_CODE] = response.status_code
        if len(response.text)>2:
            temp[TEXT_INFO] = response.text
        else:
            temp[TEXT_INFO] = ERROR_MSG

        return temp

    # get method which returns data from data base with respect to the sprint
    def get_method_sprint(self,input_data):
        temp = {}
        response = None
        ACCESS_TOKEN = self.generate_token()
        head = {'Authorization': 'Bearer {}'.format(ACCESS_TOKEN) }
        # sprint = input('Enter the sprint value: ')
        data = {SPRINT: input_data}
        url = URL+f'sprint?{data}'

        try:
            response = requests.get(url , params=data, headers = head)
            temp[STATUS_CODE] = response.status_code
            if len(response.text)>2:
                temp[TEXT_INFO] = response.text
            else:
                temp[TEXT_INFO] = ERROR_MSG
        except requests.exceptions.ConnectionError as errc:
            self.dblogger.error("Error Connecting: %s"%errc)
        except requests.exceptions.HTTPError as errh:
            self.dblogger.error("Http Error: %s"%errh)
        except requests.exceptions.RequestException as err:
            self.dblogger.error("OOps: Something Else %s"%err)  
        except Exception as e:
            self.dblogger.error("Exception while getting sprint data from database %s"%e)  
            
        return temp

    # get method which returns data from data base with respect to the ecu name
    def get_method_ecu_name(self,input_data):
        temp = {}
        response = None
        ACCESS_TOKEN = self.generate_token()
        head = {'Authorization': 'Bearer {}'.format(ACCESS_TOKEN) }
        # ecuName = input('Enter the ecuName: ')
        data = {ECU_NAME: input_data}
        url = URL+f'ecuname?{data}'

        try:
            response = requests.get(url , params=data, headers = head)
            temp[STATUS_CODE] = response.status_code
            if len(response.text)>2:
                temp[TEXT_INFO] = json.loads(response.text)
            else:
                temp[TEXT_INFO] = ERROR_MSG
        except requests.exceptions.ConnectionError as errc:
            self.dblogger.error("Error Connecting: %s"%errc)
        except requests.exceptions.HTTPError as errh:
            self.dblogger.error("Http Error: %s"%errh)
        except requests.exceptions.RequestException as err:
            self.dblogger.error("OOps: Something Else %s"%err)  
        except Exception as e:
            self.dblogger.error("Exception while getting ecu data from database %s"%e) 
            
        return temp

    # get method which returns data from data base with respect to the all entries
    def get_method_by_all(self):
        temp = {}
        response = None
        ACCESS_TOKEN = self.generate_token()
        head = {'Authorization': 'Bearer {}'.format(ACCESS_TOKEN) }
        ecuName = input('Enter the ecuName: ')
        brop_release = input('enter the brop_release: ')
        sprint = input('Enter the sprint value: ')
        toolname = input('Enter the tool name: ') 
        data = {ECU_NAME:str(ecuName),BROP_RELEASE:str(brop_release),\
                SPRINT: str(sprint),TOOL_NAME:str(toolname)}
        url = URL+f'ecuname/release/sprint/toolname?{data}'

        try:
            response = requests.get(url , params=data, headers = head)
            temp[STATUS_CODE] = response.status_code
            if len(response.text)>2:
                temp[TEXT_INFO] = response.text
            else:
                temp[TEXT_INFO] = ERROR_MSG
        except requests.exceptions.ConnectionError as errc:
            self.dblogger.error("Error Connecting: %s"%errc)
        except requests.exceptions.HTTPError as errh:
            self.dblogger.error("Http Error: %s"%errh)
        except requests.exceptions.RequestException as err:
            self.dblogger.error("OOps: Something Else: %s"%err) 
        except Exception as e:
            self.dblogger.error("Exception while getting data from database %s"%e)  
            
        return temp
        
class DatabasePostData(DatabaseGetdata):
    def __init__(self):
        super().__init__()
        self.dblogger = LogHandler()
    
    # post method to post data to the data base accordingly
    def post_method_to_upload_data(self, argcls, filetype):
        temp_list = {}
        data = self.data_extraction_from_reports(argcls, filetype)
        response = None
        temp = {}
        
        ACCESS_TOKEN = self.generate_token()
        head = {'Authorization': 'Bearer {}'.format(ACCESS_TOKEN),
                'Content-Type':'application/json'}

        try:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            response = requests.post(URL, headers=head, data=json.dumps(data), verify=False)
            # response = requests.post(URL, headers=head, data=json.dumps(data))
        except requests.exceptions.ConnectionError as errc:
            self.dblogger.error("Error Connecting: %s"%errc)
        except requests.exceptions.HTTPError as errh:
            self.dblogger.error("Http Error: %s"%errh)
        except requests.exceptions.RequestException as err:
            self.dblogger.error("OOps: Something Else %s"%err)  
        except Exception as e:
            self.dblogger.error("Exception while posting data to database %s"%e)  

        temp[STATUS_CODE] = response.status_code
        temp[TEXT_INFO] = response.text 
        # Final URL location of Response.
        temp[RESPONSE_URL] = response.url
 
        return temp
    
    # Extracts data from the ReportConsolidator and arranges the data accordingly 
    def data_extraction_from_reports(self, argcls, filetype):
        temp = {}
        ext_info = {}
        ext_info = argcls.get_extract_info()
        local_time = datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")
        versionlist=str(ext_info[resultdata.VERSION]).split("\\n")
        version=" ".join(versionlist)
        
        # Arrange data to upload into Grafana
        temp[TOOL_NAME] = filetype
        temp[WARNING] = 0  # TODO: Get this from report
        temp[SKIPPED] = 0  # TODO: Get this from report
        temp[ECU_NAME] = ext_info[resultdata.ECU_NAME]
        temp[VERSION] = version + ' - ' + local_time 
        temp[SPRINT] = 'S#'
        temp[BROP_RELEASE] = ext_info[resultdata.VERSION]
        temp[EXECUTION_TIMESTAMP] = local_time 
        temp[TOTAL_FAIL] = ext_info[resultdata.FAIL_CASE] 
        temp[TOTAL_TESTS] = ext_info[resultdata.TOTAL_CASE] 
        temp[TOTAL_PASS] = ext_info[resultdata.PASS_CASE]

        return temp

class DatabaseDerivedClass(DatabasePostData):    
    
    def __init__(self): 
        self.overview_data=list()
        self.dblogger = LogHandler()
        super().__init__()

    def post_result_data(self, argcls, testtype):
        '''
        Post the data into grafana and print the ret status
        code and uploaded information
        '''
        ret_data = self.post_method_to_upload_data(argcls, testtype)
        
        if ret_data[STATUS_CODE] == 200:
            self.dblogger.info("Upload action successful: %s" %(ret_data[RESPONSE_URL])) 
        elif ret_data[STATUS_CODE] == 404:
            self.dblogger.info("The equested resource was not found: %s" %(ret_data[RESPONSE_URL]))
        elif ret_data[STATUS_CODE] == 500:
            self.dblogger.info("The server threw an error when processing the request: %s" %(ret_data[RESPONSE_URL]))
        else:
            self.dblogger.info("Not an valid status code: %s" %(ret_data[RESPONSE_URL]))
            
        return 

    # Get overview parameter from extracted database
    def __get_overview_data(self,database,key):
        retval="NA"
        try:
            retval=database[key]
        except Exception as e:
            # If not found set string as NA
            retval = "NA"
        return retval

    
    def get_extract_info(self):
        ''' Function to return extracted information'''
        retval = self.overview_data
        return retval

    # Extract required information from report handler
    def extract_info(self, argcls, report_file, testtype):

        # Gather data (must be in the same order as titles)
        self.overview_data = list()

        if argcls.get_analyser_status() is False:
            self.report_analyser = AnalyseReport(report_file=report_file, \
            file_type=testtype)

            if self.report_analyser.analyse() is True:
                # Set titles
                titles=["ECU","Test cases executed", \
                    "Test cases passed","Test cases failed","Test cases skipped", \
                    "Test cases warning"]
                overview = self.report_analyser.get_test_overview()
                ecu_info = self.report_analyser.get_ecu_info()
                
                self.ecu_name=self.__get_overview_data(ecu_info,BIK_ECU_NAME)
                self.overview_data.append(self.__get_overview_data(ecu_info,BIK_ECU_NAME))
                self.overview_data.append(self.__get_overview_data(overview,OVEK_EXE_COUNT))
                self.overview_data.append(self.__get_overview_data(overview,\
                    OVEK_PASS_COUNT))
                self.overview_data.append(self.__get_overview_data(overview,\
                    OVEK_FAIL_COUNT))
                self.overview_data.append(self.__get_overview_data(overview,OVEK_NE_COUNT))
                self.overview_data.append(self.__get_overview_data(overview, \
                    OVEK_WARNING_COUNT))
                self.overview_data.append(self.__get_overview_data(ecu_info,BIK_SW_VERSION))
                self.overview_data.append(self.__get_overview_data(ecu_info,BIK_RELEASE_VERSION))
            
        else:
            self.overview_data = argcls.get_result_data()

        return


if __name__ == "__main__":
    pass
    