# -*- coding: utf-8 -*-
'''
Created by: ASEMPON
Date: 22-Jun-2022
Desc: Rest API constants and keys.
'''

# REST API Constants
ACCESS_TOKEN = 'access_token'
BROP_RELEASE = 'bropRelease'
TOOL_NAME = 'toolName'
SPRINT = 'sprint'
ECU_NAME = 'ecuName'
STATUS_CODE = 'status_code'
TEXT_INFO = 'info'
WARNING ='warning'
SKIPPED ='skipped'
VERSION ='version'
TOTAL_FAIL ='totalFail'
TOTAL_TESTS ='totalTests'
TOTAL_PASS ='totalPass'
OVERVIEW = 'Overview'
ECU_INFO = 'ECU_info'
ECU = 'ECU'
REPORT_NAME = 'report.xml'
EXECUTION_TIMESTAMP ='ExecutionTimestamp'
EXTRACTED_DATA_FAIL_CASES = 'FailCases'
EXTRACTED_DATA_PASS_CASES = 'PassCases'
EXTRACTED_DATA_TOTAL_CASES = 'TotalCases'
RESPONSE_URL = 'url'


# url requierd to use methods like post or get
URL = 'https://fits-dev.query.api.dvb.corpinter.net/reports/'
#-------------------------------------------------------------

# error message to handle errors present in the code
ERROR_MSG = 'The value entered is not found in the DataBase'