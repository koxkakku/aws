# -*- coding: utf-8 -*-
"""
Created on 13-May-2022
@author: STEPHIG
Desc: 
    API to analyze reason for failure of test cases from lookup table.
"""
# NOTE: Only failed cases and steps are being analysed right now.

# Imports ---------------------------------------------------------------------
import os
import re
import json
from .DataExtractor import DataExtractor
from Logger import LogHandler

from .common import DIR_LOGS
from .common import DIR_REFERENCE
from .common import ECU_TEST_TYPE_NTS
from .common import ECU_TEST_TYPE_NEST
from .common import ECU_TEST_TYPE_NEST_SE
from .common import ECU_TEST_TYPE_DIAG
from .common import ECU_TEST_TYPE_DIVA
from .common import ECU_TEST_TYPE_TLS

from .RHconstants import DXTCK_LEVEL
from .RHconstants import DXTCK_RESULT
from .RHconstants import DXTCK_REASON
from .RHconstants import DXTGK_LEVEL
from .RHconstants import DXTGK_OVERVIEW
from .RHconstants import DXTCK_TITLE
from .RHconstants import DXTGK_TITLE
from .RHconstants import DXTGK_DATA

from .XMLConstants import XML_VERDICT_FAIL
from .XMLConstants import XML_VERDICT_ERROR
from .XMLConstants import XML_VERDICT_WARN
from .XMLConstants import XML_VERDICT_INCONCLUSIVE

# Constants -------------------------------------------------------------------

# Flag to control logging extracted and analysed data
#   True: Enable logging
#   False: Disable logging
LOG_ANALYSED_DATA=True

# Analyze only failures or all tests
ANALYZE_FAILURES_ONLY=False

# Reference Table group keys
RTKG_TITLE="Title"
RTKG_DATA="Data"
# Reference Table Reason keys
RTKR_KEY_STRING="key_string"
RTKR_REGEX_LIST="regex"
RTKR_SUMMARY="Summary"
RTKR_ISSUE_TYPE="issue"

# Analysed data keys
ADK_TITLE="Title"
ADK_LEVEL="Level"
ADK_RESULT="Result"
ADK_OVERVIEW="Overview"
ADK_DATA="Data"
ADK_ISSUE_TYPE="Issue"
ADK_ANALYSIS="Analysis"

# Lookup table file reference
LOOKUP_TABLE_REFERENCE = {
    ECU_TEST_TYPE_NTS  : "lookup_nts.json",
    ECU_TEST_TYPE_NEST : "lookup_nest.json",
    ECU_TEST_TYPE_NEST_SE : "lookup_nest.json",
    ECU_TEST_TYPE_DIVA : "lookup_diva.json",
    ECU_TEST_TYPE_DIAG : "lookup_diag.json",
    ECU_TEST_TYPE_TLS  : "lookup_tls.json"
}


# AnalyseReport ---------------------------------------------------------------

class AnalyseReport:
    def __init__(self,report_file,file_type):
        self.logger=LogHandler(__class__.__name__)
        self.data_extractor = DataExtractor(test_type=file_type,\
            report_file=report_file)
        self.test_type=file_type
        self.lookup_data=None
        self.analysed_data=None
        return
    
    # Load lookup table to memory
    # Return:
    #     True: Lookup table loaded successfully
    #     False: Failed to load lookup table
    def load_lookup_table(self):
        status=False
        lookup_filename=None
        
        # Find lookup table for test type
        if self.test_type in LOOKUP_TABLE_REFERENCE.keys():
            lookup_filename="%s/%s" % (DIR_REFERENCE, \
                LOOKUP_TABLE_REFERENCE[self.test_type])
        else:
            lookup_filename=None
            self.logger.error("Undefined file type: %s"%self.test_type)
        
        if lookup_filename is not None:
            if os.path.exists(lookup_filename):
                # Load lookup table from file
                try:
                    with open(lookup_filename,'r') as f:
                        self.lookup_data=json.load(f)
                        status=True
                except Exception as e:
                    # Failed to load lookup table
                    self.lookup_data=None
                    self.logger.exception("Failed to load Lookup table: %s"%e)
            else:
                self.logger.error("File not found: %s"%(lookup_filename))
        else:
            # Lookup table file was not defined
            self.logger.error("Filename for lookup table was not found.")
        return status

    # Load lookup table and get data from report
    def load_report(self):
        retval=None
        # Get extracted data
        if self.data_extractor.isOkayToStart():
            if self.data_extractor.extract():
                if ANALYZE_FAILURES_ONLY:
                    # NOTE: Only loads a list of failed cases from the report.
                    # get list of failed cases and associated data
                    retval = self.data_extractor.get_fail_cases()
                else:
                    retval = self.data_extractor.get_all_cases()
        return retval

    # Dump data to file: Can be used for debug logs
    def __dump(self,file,data):
        with open(file,"w") as f:
            f.write(json.dumps(data,indent=4))
        return
    
    # Get correct analysis and related data from lookup table
    # For a test case we can have more than one analysis dictionary with 
    # different lists of keyword phrases.
    # Format of analysis group:
    # {
    #     RTKR_KEY_STRING:["keyphrase1","keyphrase2","keyphrase3",...],
    #     RTKR_REGEX_LIST:["Regex1","Regex2","Regex3",...]
    #     RTKR_SUMMARY:"Summary message"
    # }
    # The analysis group with the 100% match ratio will be the best match.
    #            (number of matching phrases in fail_text)
    # Ratio =  ---------------------------------------------
    #          (Total number of key phrases in analysis group)
    
    # BUG: Shoud we check for 100% match or partial? Partial match needs a 
    # good lookup table to ensure there will be no incorrect matches.
    def get_analysis_for_text(self,reference,fail_text):
        retval=None
        # Set default value
        best_match_index=-1

        # Check for valid reference data
        if reference is not None:
            # parse through all analysis groups till you find the best match
            for analysis_index,analysis_group in enumerate(reference):
                # Reset match count and ratio for each analysis group
                hit_ratio = 0
                hit_count = 0
                # get list of key strings in this group
                key_list = analysis_group[RTKR_KEY_STRING]
                if(len(key_list) > 0):
                    # count number of hits for each key string list
                    for refkey in key_list:
                        # Check for match
                        # TODO: If you use re.search() instead of direct 
                        # comparison you'll be able to get more accurate 
                        # matches in lookup table. Is it necessary, though?
                        if refkey.lower() in fail_text.lower():
                            hit_count += 1
                    # Calculate ratio of hits
                    hit_ratio=hit_count/len(key_list)
                else:
                    # List of key strings is empty. Do not update counts. 
                    retval = None

                # NOTE: What if there are 2 or more matches? You currently 
                # terminate the loop at the first 100% match.
                
                # Check for hit ratio of 1 (indicating all keywords matched)
                if (hit_ratio == 1):
                    best_match_index=analysis_index
                    # TODO: I don't think we should stop here. What if there 
                    # are 2 or more matches? Find a way to select the best 
                    # solution from multiple matches.
                    break
            
            # The list index with the highest ratio will be the best match
            if best_match_index >= 0:  # Index of -1 would be invalid
                retval=reference[best_match_index]
        else:
            # Invalid reference data. Do not do anything
            pass
        return retval
    
    # Get parameters from lookup dictionary
    def get_para_from_reference(self,reference):
        # Define default values
        regex_list=[]
        summary="Undefined Summary in lookup table."
        issue_type=' '

        # Get necessary data from reference
        
        # Get list of regex strings
        try:
            regex_list=reference[RTKR_REGEX_LIST]
        except:
            regex_list=[]
        
        # Get summary message
        try:
            summary=reference[RTKR_SUMMARY]
        except:
            summary="Undefined Summary in lookup table."
        
        # Update type of issue
        try:
            issue_type=reference[RTKR_ISSUE_TYPE]
        except:
            issue_type=' '

        return regex_list,summary,issue_type

    # Analyze test case
    # Arguments:
    #     testcase: test case to be analysed
    #     lookup_data: Reference data for parent group
    # Return: Dictionary of analysed case data.
    #         Includes title, level, type of issue and analysis of case.
    def analyze_case(self,testcase,lookup_data):
        # List of summarized reasons for failure
        analysed_summary = list()
        # List of type of issues
        issue_type_list=list()
        issue_type=' '

        # Analyze only failed, inconclusive cases
        if (testcase[DXTCK_RESULT] == XML_VERDICT_FAIL) \
            or (testcase[DXTCK_RESULT] == XML_VERDICT_ERROR) \
            or (testcase[DXTCK_RESULT] == XML_VERDICT_INCONCLUSIVE):
            # Analyse each failure statement from extracted data
            for reason in testcase[DXTCK_REASON]:
                # Get correct analysis from lookup table
                analysis = \
                    self.get_analysis_for_text(lookup_data,reason)
                if analysis is None:
                    # Match not found in lookup table
                    # Add reason to list without modification
                    if reason not in analysed_summary:
                        analysed_summary.append(reason)
                else:
                    # Reference Data group found
                    
                    # Get necessary parameters from reference group
                    regex_list,summary,issue_type= \
                        self.get_para_from_reference(analysis)
                    
                    # Add issue type to list of issues
                    if issue_type not in issue_type_list:
                        issue_type_list.append(issue_type)
                    
                    # Add summary to analysis message
                    msg=summary
                    # Get regex data from string and append to message
                    for regex in regex_list:
                        extract=re.findall(regex,reason)
                        msg=msg+' '+(', '.join(extract))
                    
                    # Add message to list if not already present
                    if msg not in analysed_summary:
                        analysed_summary.append(msg)
            
        # Add analysed data to new case dictionary
        case_analysis=dict()
        case_analysis[ADK_TITLE]=testcase[DXTCK_TITLE]
        case_analysis[ADK_LEVEL]=testcase[DXTCK_LEVEL]
        case_analysis[ADK_RESULT]=testcase[DXTCK_RESULT]
        case_analysis[ADK_ISSUE_TYPE]=", ".join(issue_type_list)
        case_analysis[ADK_ANALYSIS]=analysed_summary
        return case_analysis
    
    # Analyze group data
    # Arguments:
    #     group_extract: Group data to be analysed
    #     lookup_data: Reference data for this group
    # Return: Dictionary of analysed data.
    #         Includes title, level, and data of group and individual cases.
    def analyze_group(self, group_extract, lookup_data):
        group_data=dict()
        # List of individual analysed testcase data
        case_analysis_list=list()
        for testdata in group_extract[DXTGK_DATA]:
            # Check if group or class
            # Assumption: If data dict contains overview it is of type group
            if (DXTGK_OVERVIEW in testdata.keys()):
                # This is a test group
                # Only test groups contain overview
                groupdata = self.analyze_group(testdata,lookup_data)
                case_analysis_list.append(groupdata)

            elif (DXTCK_REASON in testdata.keys()):
                # Assumption: If data dict contains result it is of type case
                # If it contains a reason field then it is a testcase
                # This is a Test case
                case_analysis=self.analyze_case(testdata,lookup_data)
                case_analysis_list.append(case_analysis)
            else:
                # Unknown type
                pass
        
        # Add to group dictionary
        group_data[ADK_TITLE]=group_extract[DXTGK_TITLE]
        group_data[ADK_LEVEL]=group_extract[DXTGK_LEVEL]
        group_data[ADK_OVERVIEW]=group_extract[DXTGK_OVERVIEW]
        group_data[ADK_DATA]=case_analysis_list
        return group_data
    
    # Get title of extracted data
    def get_group_title(self,data):
        try:
            retval = data[DXTGK_TITLE]
        except:
            retval=None
        return retval

    # Get associated data from lookup table based on group title
    def get_lookup_for_group(self,title):
        retval = None
        if self.lookup_data is not None:
            # Updated JSON is not divided into test groups
            retval = self.lookup_data
            # If JSON is divided into test groups
            # for group in self.lookup_data:
            #     if group[RTKG_TITLE] in title:
            #         # match found; return the associated data
            #         retval = group[RTKG_DATA]
        return retval

    # analyse extracted data from report
    def analyse_extract(self,extracted_data):
        # List to store analysed data for each group
        analysed_data=list()
        # Process one group at a time
        for data in extracted_data:
            # Get group title
            group_title = self.get_group_title(data)
            group_lookup = self.get_lookup_for_group(group_title)
            # Check if it is group or case
            if (DXTGK_OVERVIEW in data.keys()):
                group_analysis=self.analyze_group(group_extract=data, \
                    lookup_data=group_lookup)
            else:
                group_analysis=self.analyze_case(data,group_lookup)
            # Append group to final list
            analysed_data.append(group_analysis)
        
        return analysed_data

    # Analyse report
    def analyse(self):
        status=False
        # Load lookup table
        self.load_lookup_table()
        # Get extracted data from report
        extracted_data = self.load_report()
        # Analyse valid data if available
        if (extracted_data is not None):
            # Log data for reference
            if LOG_ANALYSED_DATA:
                extract_log=\
                    "%s/extract_%s.json"%(DIR_LOGS,self.get_report_filename())
                self.__dump(extract_log,extracted_data)
            # Process data extracted from report
            analysed_data=self.analyse_extract(extracted_data)
            # Copy to class variable
            self.analysed_data=analysed_data.copy()
            # Update status
            status=True

            # Log data for reference
            if LOG_ANALYSED_DATA:
                analysed_log=\
                    "%s/analysed_%s.json"%(DIR_LOGS,self.get_report_filename())
                self.__dump(analysed_log,self.analysed_data)
        else:
            # Failed to extract data from report
            status=False
        return status

    # API to get analysed/summarised data
    def get_analysis(self):
        return self.analysed_data

    # Get test overview
    def get_test_overview(self):
        return self.data_extractor.get_test_overview()

    # Get test overview
    def get_test_title(self):
        return self.data_extractor.get_test_title()
    
    # Get ECU info
    def get_ecu_info(self):
        return self.data_extractor.get_ecu_info()

    def get_report_filename(self):
        return self.data_extractor.get_report_filename()

# End of AnalyseReport --------------------------------------------------------


if __name__=='__main__':
    pass

# End of File -----------------------------------------------------------------
