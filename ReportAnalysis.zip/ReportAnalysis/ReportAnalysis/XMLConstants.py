# -*- coding: utf-8 -*-
'''
Created by: STEPHIG
Date: 20-Apr-2022
Desc: XML property defintions.
'''

# XML Tags
XML_TAG_TITLE = "title"
XML_TAG_VERDICT = "verdict"
XML_TAG_RESULT = "result"
XML_TAG_IDENT = "ident"
XML_TAG_CAUSE = "cause"
XML_TAG_TESTCYCLE = "testcycle"
XML_TAG_TESTUNIT = "testunit"
XML_TAG_TESTCOMMAND = "command"
XML_TAG_TESTCASELIST = "testcaselist"
XML_TAG_TESTFIXTURE = "testfixture"
XML_TAG_TESTGROUP = "testgroup"
XML_TAG_TESTCASE = "testcase"
XML_TAG_TESTCASE_ID = "testcaseid"
XML_TAG_TEST_PATTERN = "testpattern"
XML_TAG_PRECONDITION = "precondition"
XML_TAG_TEST_STEP = "teststep"
XML_TAG_TEST_SKIPPED = "skipped"
XML_TAG_TESTSETUP = "testsetup"
XML_TAG_SUT = "sut"
XML_TAG_INFO = "info"
XML_TAG_XINFO = "xinfo"
XML_TAG_INFO_NAME = "name"
XML_TAG_INFO_DESC = "description"
XML_TAG_TEST_REPORT = "testreport"

# XML Attributes
XML_ATTR_RESULT = "result"
XML_ATTR_IDENT = "ident"

# Result/Verdict Keywords
XML_VERDICT_PASS = "pass"
XML_VERDICT_FAIL = "fail"
XML_VERDICT_ERROR = "error"
XML_VERDICT_WARN = "warn"
XML_VERDICT_NA = "na"
XML_VERDICT_NONE = "none"
XML_VERDICT_INCONCLUSIVE = "inconclusive"

# End of file -----------------------------------------------------------------
