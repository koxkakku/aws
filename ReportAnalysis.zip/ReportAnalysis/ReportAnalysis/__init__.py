# -*- coding: utf-8 -*-
"""
Created on Tue Jan 25 11:56:22 2022

@author: STEPHIG
"""

from .SW_VERSION import VERSION as sw_version
from .ComparisonXLGenerator import compare_reports

from .CLI import command_line_handler
from .CLI import get_inputs_for_analyzer
from .CLI import get_inputs_for_compare
from .Consolidator import Consolidator
from .Consolidator import Consolidator_Cloud
from .ReportAnalysis import AnalyseReport

# End of File ----------------------------------------------------------------
