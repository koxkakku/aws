# -*- coding: utf-8 -*-
"""
Created on Thu Jan 27 15:55:02 2022

@author: STEPHIG

Desc:
    - Extract necessary test data from XML reports.
    - Data extracted:
        - Overview data
        - ECU Information
        - Test execution data

"""

import json
import os

from Logger import LogHandler

# XML imports
from . import XMLHandler as xmlh
from .XMLConstants import XML_TAG_TITLE
from .XMLConstants import XML_TAG_VERDICT
from .XMLConstants import XML_TAG_IDENT
from .XMLConstants import XML_TAG_TESTGROUP
from .XMLConstants import XML_TAG_TESTCASE
from .XMLConstants import XML_TAG_TEST_PATTERN
from .XMLConstants import XML_TAG_TEST_STEP
from .XMLConstants import XML_TAG_TEST_SKIPPED
from .XMLConstants import XML_TAG_TESTSETUP
from .XMLConstants import XML_TAG_SUT
from .XMLConstants import XML_TAG_INFO_NAME
from .XMLConstants import XML_TAG_INFO_DESC
from .XMLConstants import XML_TAG_TESTCYCLE
from .XMLConstants import XML_TAG_TESTUNIT
from .XMLConstants import XML_TAG_TESTCOMMAND
from .XMLConstants import XML_TAG_TESTCASELIST
from .XMLConstants import XML_TAG_TESTFIXTURE
from .XMLConstants import XML_TAG_TESTCASE_ID
from .XMLConstants import XML_TAG_CAUSE

# Key defintions for extracted overview
from .RHconstants import ETDK_TITLE
from .RHconstants import ETDK_OVERVIEW
from .RHconstants import ETDK_ECU_INFO
from .RHconstants import ETDK_TEST_DATA

# Overview dict keys
from .RHconstants import OVEK_VERDICT
from .RHconstants import OVEK_TEST_COUNT
from .RHconstants import OVEK_PASS_COUNT
from .RHconstants import OVEK_FAIL_COUNT
from .RHconstants import OVEK_NE_COUNT
from .RHconstants import OVEK_NA_COUNT
from .RHconstants import OVEK_EXE_COUNT
from .RHconstants import OVEK_WARNING_COUNT 
from .RHconstants import OVEK_INCONCLUSIVE_COUNT

# Basic information Key
from .RHconstants import BIK_ECU_NAME
from .RHconstants import BIK_ECU_ID
from .RHconstants import BIK_TOOL_VERSION
from .RHconstants import BIK_SW_VERSION
from .RHconstants import BIK_DATE
from .RHconstants import BIK_RELEASE_VERSION
from .RHconstants import BIK_ECU_EXTRACT
from .RHconstants import BIK_ECU_VARIANT
from .RHconstants import BIK_SPEC_VERSION
from .RHconstants import BIK_TEST_CONFIGURATION

# XML Attributes
from .XMLConstants import XML_ATTR_RESULT
from .XMLConstants import XML_ATTR_IDENT

# Result types
from .XMLConstants import XML_VERDICT_PASS
from .XMLConstants import XML_VERDICT_FAIL
from .XMLConstants import XML_VERDICT_NA
from .XMLConstants import XML_VERDICT_WARN
from .XMLConstants import XML_VERDICT_ERROR
from .XMLConstants import XML_VERDICT_INCONCLUSIVE

# Keys for test step
from .RHconstants import EDTSK_ACTION
from .RHconstants import EDTSK_DESC
from .RHconstants import EDTSK_RESULT

# Keys for test case
from .RHconstants import EDTCK_RESULT
from .RHconstants import EDTCK_TITLE
from .RHconstants import EDTCK_LEVEL
from .RHconstants import EDTCK_IDENT
from .RHconstants import EDTCK_STEPS

# Keys for test group
from .RHconstants import EDTGK_TITLE
from .RHconstants import EDTGK_LEVEL
from .RHconstants import EDTGK_DATA
from .RHconstants import EDTGK_OVERVIEW

# Miscellaneous
from .RHconstants import TEST_TAG_TYPE_KEY
from .common import DIR_LOGS

# Text constants NTS
ECU_NAME_TEXT_NTS="ECU"
ECU_ID_TEXT_NTS="ECU Variant"
TOOL_VERSION_TEXT_NTS="AKKA - Networking Test Suite"
SW_VERSION_TEXT_NTS="SW Version Information"
ECU_EXTRACT_TEXT_NTS="Used ECU Extract Version for test"
RELEASE_VERSION_TEXT_NTS="Release"
MODIFICATION_DATE_TEXT_NTS="Last modification of Test Module File"

# Text constants NEST
TOOL_VERSION_TEXT_NEST="NEST Suite Version"
MODIFICATION_DATE_TEXT_NEST="Last modification of Test Module File"
MODIFICATION_DATE_TEXT_NEST_SE="Last modification of Test Unit"
ECU_NAME_TEXT_NEST="ECU name"
ECU_ID_TEXT_NEST="UniquECUID"

# Text constants DIVA
ECU_NAME_TEXT_DIVA="ECU Name"
MODIFICATION_DATE_TEXT_DIVA="Last modification of Test Module File"

# Text constants DiagGW
ECU_NAME_TEXT_DIAG="DUT"
TOOL_VERSION_TEXT_DIAG = "Version"
RELEASE_VERSION_TEXT_DIAG = "ECU DDS Package Release Version"
MODIFICATION_DATE_TEXT_DIAG="Last modification of Test Module File"


# Text constants TLS
TEST_CONFIGURATION_TEXT_TLS="TATS Version"
ECU_NAME_TEXT_TLS="ECU name"  # Dummy
ECU_ID_TEXT_TLS="UniquECUID"  # Dummy


'''
Extract data from XML report into dictionaries:

{
    "Title": "NEST- Security Tests",
    "Overview": 
    {
        "Verdict": "fail",
        "Total_Tests": 163,
        "Not_Executed": 3,
        "Executed": 160,
        "Passed": 127,
        "Failed": 17
    },
    "ECU_info": {
        "ECU_Name": "LRR",
        "ECU_ID": "LRR_GEN6",
        "NEST_VERSION": "7.1.3"
    },
    "Test_Data":
    {
        "1":
        {
            "Type":"testgroup",
            "Title":"Preparation",
            "Data":
        }
    }
}
'''

# Base class for Data Extraction ----------------------------------------------

class BaseReportDataExtraction:
    def __init__(self,filename):
        self.logger=LogHandler(__class__.__name__)
        self.root = None
        self.filename = filename
        # Name of file without path
        basename=os.path.basename(filename)
        self.base_filename=os.path.splitext(basename)[0]
        self.report_extract = dict()
        # Create log folder
        if not os.path.exists(DIR_LOGS):
            os.makedirs(DIR_LOGS)
        return
    
    # Load report file
    def load(self):
        status,self.root = xmlh.load(self.filename)
        return status

    # Get information of parameter from tags under parent node
    # Arguments:
    #     Parent: Node to be searched
    #     parameter: Parameter <name> to search for
    # Return:
    #     Description text if matching parameter is found 
    # NOTE: Will be implemented in child class
    def get_para_info_from_tag(self,parent,parameter):
        return None
    
    # Get information from test step
    # Assumption: No further test data to dig into
    # NOTE: Will be implemented in child class
    def get_tag_data_test_step(self,node,level=[]):
        return None

    # Get information from test pattern:
    # Assumption: Contains only one or more test steps as test related data
    # NOTE: Will be implemented in child class
    def get_tag_data_test_pattern(self,node,level=[]):
        return None

    # Get information from test case
    # Assumption: Could contain other test objects
    # NOTE: Will be implemented in child class
    def get_tag_data_test_case(self,node,level=[]):
        return None

    # Get information about test groups
    # Assumption: Could contain any test object types
    # NOTE: Will be implemented in child class
    def get_tag_data_test_group(self,node,level=[]):
        data = dict()
        return data

    # Check if tag type expects test related information
    # NOTE: Will be implemented in child class
    def check_valid_test_tag(self,node):
        return False

    # Extract test related data from tag by identifying tag type
    # NOTE: Will be implemented in child class
    def get_tag_data_test(self,node,level=[],sublevel=0):
        return None

    # Extract all necessary data and arrange in dictionary
    def extract_data(self):
        title = self.extract_test_title()
        test_overview = self.extract_test_overview()
        ecu_info = self.extract_ecu_info()
        test_data = self.extract_test_data()

        # Update main dictionary
        self.report_extract[ETDK_TITLE] = title
        self.report_extract[ETDK_OVERVIEW] = test_overview
        self.report_extract[ETDK_ECU_INFO] = ecu_info
        self.report_extract[ETDK_TEST_DATA] = test_data
        return
    
    # log extracted data
    def log_extract(self):
        # Write extracted data to file
        filename="%s/%s.json" % (DIR_LOGS, self.base_filename)
        with open(filename,"w") as f:
            f.write(json.dumps(self.report_extract,indent=4))
        return

    # Get title of test module
    def extract_test_title(self):
        title = xmlh.get_text_from_tag(self.root, XML_TAG_TITLE)
        return title
    
    # Get ECU and setup information
    # NOTE: Will be implemented in child class
    def extract_ecu_info(self):
        data = dict()
        return data
        
    # Gather basic test information
    # NOTE: Will be implemented in child class
    def extract_test_overview(self):
        test_overview = dict()
        return test_overview
    
    # Gather data of test cases
    def extract_test_data(self):
        extracted_test_data = list()
        children = xmlh.get_all_children(self.root)
        level_count = 0
        for child in children:
            if self.check_valid_test_tag(child):
                level_count += 1
                extracted_data = self.get_tag_data_test(child,level=[], \
                    sublevel=level_count)
                # Check if data is available
                if extracted_data is not None:
                    # add extract to list
                    extracted_test_data.append(extracted_data)
        return extracted_test_data
    
    # Load file and extract all necessary data from file
    def extract(self):
        status = False
        if self.load():
            self.extract_data()
            self.log_extract() #To Test
            status = True
        else:
            self.logger.error("Failed to load file: %s" % (self.filename))
        return status
    
    # Get all extracted data
    def get_extracted_data(self):
        return self.report_extract
    
    # Get name of source report file
    def get_report_filename(self):
        return self.base_filename
    
    # Retrieve test overview
    def get_test_overview(self):
        return self.report_extract[ETDK_OVERVIEW]
    
    # Retrieve test title
    def get_test_title(self):
        return self.report_extract[ETDK_TITLE]
    
    # Get ECU information
    def get_ecu_info(self):
        return self.report_extract[ETDK_ECU_INFO]

    # Get detailed test related information
    def get_test_data(self):
        return self.report_extract[ETDK_TEST_DATA]

# End of Base class for Data Extraction ---------------------------------------


# NTS ReportDataExtraction ----------------------------------------------------

class NTSReportDataExtraction(BaseReportDataExtraction):
    # Get information of parameter from tags under parent node
    # Arguments:
    #     Parent: Node to be searched
    #     parameter: Parameter <name> to search for
    # Return:
    #     Description text if matching parameter is found 
    def get_para_info_from_tag(self,parent,parameter):
        retinfo = None
        # Parse all tags in parent node
        children = xmlh.get_all_children(parent)
        if children is not None:
            for child in children:
                l_name = None
                l_desc = None
                # read tags
                name_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_NAME)
                desc_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_DESC)
                
                # get text from tags
                if name_tag is not None:
                    l_name = xmlh.get_text(name_tag)
                if desc_tag is not None:
                    l_desc = xmlh.get_text(desc_tag)

                # check for match
                if l_name == parameter:
                    retinfo = l_desc
                    break
        return retinfo
    
    # Get information from test step
    # Assumption: No further test data to dig into
    def get_tag_data_test_step(self,node,level=[]):
        data = None
        text = xmlh.get_text(node)
        result = xmlh.get_attribute(node,XML_ATTR_RESULT)
        step = xmlh.get_attribute(node,XML_ATTR_IDENT)
        
        # Do not consider step if result is na or empty text field
        if (text is None) or result == XML_VERDICT_NA:
            data = None
        else:
            data=dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TEST_STEP
            data[EDTSK_ACTION]=step
            data[EDTSK_DESC]=text
            data[EDTSK_RESULT]= result
        return data

    # Get information from test pattern:
    # Assumption: Contains only one or more test steps as test related data
    def get_tag_data_test_pattern(self,node,level=[]):
        steps = list()
        children=xmlh.get_children_with_tag(node,XML_TAG_TEST_STEP)
        # Parse all available steps
        for child in children:
            subdata = self.get_tag_data_test_step(child,level)
            if subdata is not None:
                steps.append(subdata)
        
        if len(steps) > 0:
            data=steps.copy()
        else:
            # No data to add
            data = None
        return data

    # Get information from test case
    # Assumption: Could contain other test objects
    def get_tag_data_test_case(self,node,level=[]):
        # get basic info
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        ident = xmlh.get_text_from_tag(node,XML_TAG_IDENT)
        result = xmlh.get_attribute_from_tag(node, \
            XML_TAG_VERDICT,XML_ATTR_RESULT)
        
        test_objects = xmlh.get_all_children(node)
        data_list = list()
        
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                # test pattern or precondition data
                sub_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if sub_data is not None:
                    data_list.append(sub_data)
        
        if len(data_list) > 0:
            data = dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCASE
            data[EDTCK_TITLE] = title
            data[EDTCK_IDENT] = ident
            data[EDTCK_RESULT] = result
            data[EDTCK_LEVEL] = '.'.join([str(i) for i in level])
            data[EDTCK_STEPS] = data_list
        else:
            # No valid data found
            data = None
        return data

    # Get information about test groups
    # Assumption: Could contain any test object types
    def get_tag_data_test_group(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTGROUP
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data

    # Check if tag type expects test related information
    def check_valid_test_tag(self,node):
        status = False
        if xmlh.get_tagname(node) in \
            [XML_TAG_TESTCASE, \
            XML_TAG_TESTGROUP,\
            XML_TAG_TEST_PATTERN,\
            XML_TAG_TEST_STEP]:
            status = True
        return status

    # Extract test related data from tag by identifying tag type
    def get_tag_data_test(self,node,level=[],sublevel=0):
        data = None
        # identify type of tag and call appropriate function
        if node is not None:
            # list of levels for processing this tag
            l_level=level.copy()
            l_level.append(sublevel)          
            if xmlh.get_tagname(node) == XML_TAG_TESTCASE:
                data = self.get_tag_data_test_case(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_PATTERN:
                data = self.get_tag_data_test_pattern(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_STEP:
                data = self.get_tag_data_test_step(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTGROUP:
                data = self.get_tag_data_test_group(node,l_level)
            else:
                # Unused tag type; DO NOT record
                data=None
        return data

    # Get ECU information
    def extract_ecu_info(self):
        test_setup = \
            xmlh.get_child_with_tag(self.root, XML_TAG_TESTSETUP)
        sw_under_test = \
            xmlh.get_child_with_tag(self.root, XML_TAG_SUT)
        
        data = dict()
        data[BIK_TOOL_VERSION] = \
            self.get_para_info_from_tag(test_setup,TOOL_VERSION_TEXT_NTS)
        data[BIK_DATE] = \
            str(self.get_para_info_from_tag(test_setup, \
                MODIFICATION_DATE_TEXT_NTS))
        data[BIK_ECU_NAME] = \
            self.get_para_info_from_tag(sw_under_test,ECU_NAME_TEXT_NTS)
        data[BIK_ECU_ID] = \
            self.get_para_info_from_tag(sw_under_test,ECU_ID_TEXT_NTS)
        data[BIK_RELEASE_VERSION] = \
            self.get_para_info_from_tag(sw_under_test, \
                RELEASE_VERSION_TEXT_NTS)
        data[BIK_SW_VERSION] = \
            self.get_para_info_from_tag(sw_under_test,SW_VERSION_TEXT_NTS)
        data[BIK_ECU_EXTRACT] = \
            self.get_para_info_from_tag(sw_under_test,ECU_EXTRACT_TEXT_NTS)
        return data

    # Gather basic test information
    def extract_test_overview(self):
        # get test result
        overview_result = xmlh.get_attribute_from_tag( \
            self.root, XML_TAG_VERDICT, XML_ATTR_RESULT)
        
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_VERDICT] = overview_result
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_NA_COUNT] = na_count
        
        return test_overview
    
    # Gather result overview of individual test cases in specified node
    # Args:
    #   node: Node for which the overview data has to be gathered
    def extract_test_overview_group(self,node):
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_NA_COUNT] = na_count
        return test_overview
    
# End of NTS ReportDataExtraction ---------------------------------------------


# NEST ReportDataExtraction ---------------------------------------------------

# Use for Desktop reports
class NestReportDataExtraction(BaseReportDataExtraction):
    # Get information of parameter from tags under parent node
    # Arguments:
    #     Parent: Node to be searched
    #     parameter: Parameter <name> to search for
    # Return:
    #     Description text if matching parameter is found 
    def get_para_info_from_tag(self,parent,parameter):
        retinfo = None
        # Parse all tags in parent node
        children = xmlh.get_all_children(parent)
        if children is not None:
            for child in children:
                l_name = None
                l_desc = None
                # read tags
                name_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_NAME)
                desc_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_DESC)
                
                # get text from tags
                if name_tag is not None:
                    l_name = xmlh.get_text(name_tag)
                if desc_tag is not None:
                    l_desc = xmlh.get_text(desc_tag)

                # check for match
                if l_name == parameter:
                    retinfo = l_desc
                    break
        return retinfo
    
    # Get information from test step
    # Assumption: No further test data to dig into
    def get_tag_data_test_step(self,node,level=[]):
        data = None
        text = xmlh.get_text(node)
        result = xmlh.get_attribute(node,XML_ATTR_RESULT)
        step = xmlh.get_attribute(node,XML_ATTR_IDENT)
        
        # Do not consider step if result is na or empty text field
        if (text is None) or result == XML_VERDICT_NA:
            data = None
        else:
            data=dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TEST_STEP
            data[EDTSK_ACTION]=step
            data[EDTSK_DESC]=text
            data[EDTSK_RESULT]= result
        return data

    # Get information from test pattern:
    # Assumption: Contains only one or more test steps as test related data
    def get_tag_data_test_pattern(self,node,level=[]):
        steps = list()
        children=xmlh.get_children_with_tag(node,XML_TAG_TEST_STEP)
        
        # Parse all available steps
        for child in children:
            subdata = self.get_tag_data_test_step(child,level)
            if subdata is not None:
                steps.append(subdata)
        
        if len(steps) > 0:
            data=steps.copy()
        else:
            # No data to add
            data = None
        return data

    # Get information from test case
    # Assumption: Contains only one test pattern as relevant data
    def get_tag_data_test_case(self,node,level=[]):
        # get basic info
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        ident = xmlh.get_text_from_tag(node,XML_TAG_IDENT)
        result = xmlh.get_attribute_from_tag(node, \
            XML_TAG_VERDICT,XML_ATTR_RESULT)
        
        step_node = \
            xmlh.get_child_with_tag(node,XML_TAG_TEST_PATTERN)
        step_list=self.get_tag_data_test_pattern(step_node,level)
        
        data = None
        if step_list is not None:
            if len(step_list) > 0:
                data = dict()
                data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCASE
                data[EDTCK_TITLE] = title
                data[EDTCK_IDENT] = ident
                data[EDTCK_RESULT] = result
                data[EDTCK_LEVEL] = '.'.join([str(i) for i in level])
                data[EDTCK_STEPS] = step_list
            else:
                # No valid data found
                pass
        return data
    
    # Get information about test groups
    # Assumption: Could contain any test object types
    def get_tag_data_test_group(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTGROUP
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data

        # Get information about test units
    
    # Assumption: Could contain any test object types
    def get_tag_data_test_cycle(self,node,level=[]):
        # title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        try:
            title = "Test Cycle: %s"%('.'.join([str(i) for i in level]))
        except:
            title = "Test Cycle"
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCYCLE
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_DATA] = data_list
        return data

    # Check if tag type expects test related information
    def check_valid_test_tag(self,node):
        status = False
        if xmlh.get_tagname(node) in \
            [XML_TAG_TESTCASE, \
            XML_TAG_TESTCYCLE,\
            XML_TAG_TESTGROUP,\
            XML_TAG_TEST_PATTERN,\
            XML_TAG_TEST_STEP]:
            status = True
        return status

    # Extract test related data from tag by identifying tag type
    def get_tag_data_test(self,node,level=[],sublevel=0):
        data = None
        # identify type of tag and call appropriate function
        if node is not None:
            # list of levels for processing this tag
            l_level=level.copy()
            l_level.append(sublevel)
            
            if xmlh.get_tagname(node) == XML_TAG_TESTCASE:
                data = self.get_tag_data_test_case(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTCYCLE:
                data = self.get_tag_data_test_cycle(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_PATTERN:
                data = self.get_tag_data_test_pattern(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_STEP:
                data = self.get_tag_data_test_step(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTGROUP:
                data = self.get_tag_data_test_group(node,l_level)
            else:
                # Unused tag type; DO NOT record
                data=None
        return data

    # External API -------------------------
    
    # Get ECU information
    def extract_ecu_info(self):
        test_setup = \
            xmlh.get_child_with_tag(self.root, XML_TAG_TESTSETUP)
        
        data = dict()
        data[BIK_ECU_NAME]=\
            self.get_para_info_from_tag(test_setup,ECU_NAME_TEXT_NEST)
        data[BIK_ECU_ID]=\
            self.get_para_info_from_tag(test_setup,ECU_ID_TEXT_NEST)
        data[BIK_TOOL_VERSION]=\
            self.get_para_info_from_tag(test_setup,TOOL_VERSION_TEXT_NEST)
        data[BIK_DATE]=\
            str(self.get_para_info_from_tag(test_setup, \
                MODIFICATION_DATE_TEXT_NEST))
        return data

    # Gather basic test information
    def extract_test_overview(self):
        # get test result
        overview_result = xmlh.get_attribute_from_tag( \
            self.root, XML_TAG_VERDICT, XML_ATTR_RESULT)
        
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_VERDICT] = overview_result
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_NA_COUNT] = na_count
        
        return test_overview
    
    # Gather result overview of individual test cases in specified node
    # Args:
    #   node: Node for which the overview data has to be gathered
    def extract_test_overview_group(self,node):
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_NA_COUNT] = na_count
        
        return test_overview

# use for CANoe4SW-SE reports
class NestSEReportDataExtraction(BaseReportDataExtraction):
    # Get information of parameter from tags under parent node
    # Arguments:
    #     Parent: Node to be searched
    #     parameter: Parameter <name> to search for
    # Return:
    #     Description text if matching parameter is found 
    def get_para_info_from_tag(self,parent,parameter):
        retinfo = None
        # Parse all tags in parent node
        children = xmlh.get_all_children(parent)
        if children is not None:
            for child in children:
                l_name = None
                l_desc = None
                # read tags
                name_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_NAME)
                desc_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_DESC)
                
                # get text from tags
                if name_tag is not None:
                    l_name = xmlh.get_text(name_tag)
                if desc_tag is not None:
                    l_desc = xmlh.get_text(desc_tag)

                # check for match
                if l_name == parameter:
                    retinfo = l_desc
                    break
        return retinfo
    
    # Get information from test step
    # Assumption: No further test data to dig into
    def get_tag_data_test_step(self,node,level=[]):
        data = None
        text = xmlh.get_text(node)
        result = xmlh.get_attribute(node,XML_ATTR_RESULT)
        step = xmlh.get_attribute(node,XML_ATTR_IDENT)
        
        # Do not consider step if result is na or empty text field
        if (text is None) or result == XML_VERDICT_NA:
            data = None
        else:
            data=dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TEST_STEP
            data[EDTSK_ACTION]=step
            data[EDTSK_DESC]=text
            data[EDTSK_RESULT]= result
        return data

    # Get information from test pattern:
    # Assumption: Contains only one or more test steps as test related data
    def get_tag_data_test_pattern(self,node,level=[]):
        steps = list()
        children=xmlh.get_children_with_tag(node,XML_TAG_TEST_STEP)
        
        # Parse all available steps
        for child in children:
            subdata = self.get_tag_data_test_step(child,level)
            if subdata is not None:
                steps.append(subdata)
        
        if len(steps) > 0:
            data=steps.copy()
        else:
            # No data to add
            data = None
        return data

    # Get information from test case
    # Assumption: Contains only one test pattern as relevant data
    def get_tag_data_test_case(self,node,level=[]):
        # get basic info
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        ident = xmlh.get_text_from_tag(node,XML_TAG_TESTCASE_ID)
        result = xmlh.get_attribute_from_tag(node, \
            XML_TAG_VERDICT,XML_ATTR_RESULT)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCASE
        data[EDTCK_TITLE] = title
        data[EDTCK_IDENT] = ident
        data[EDTCK_RESULT] = result
        data[EDTCK_LEVEL] = '.'.join([str(i) for i in level])
        
        verdict = xmlh.get_child_with_tag(node,XML_TAG_VERDICT)
        cause = xmlh.get_text_from_tag(verdict,XML_TAG_CAUSE)
        data[EDTCK_STEPS] = [
            {
                TEST_TAG_TYPE_KEY:XML_TAG_TEST_STEP,
                EDTSK_RESULT:result,
                EDTSK_DESC:cause
            }
        ]
        
        return data
    
    # Get information about test groups
    # Assumption: Could contain any test object types
    def get_tag_data_test_group(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTGROUP
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data
    
    # Get information about test units
    # Assumption: Could contain any test object types
    def get_tag_data_test_unit(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTUNIT
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data
    
    # Get information about test fixtures
    # Assumption: Could contain any test object types
    def get_tag_data_test_fixture(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTFIXTURE
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data   

    # Get information about test units
    # Assumption: Could contain any test object types
    def get_tag_data_test_cycle(self,node,level=[]):
        # title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        try:
            title = "Test Cycle: %s"%('.'.join([str(i) for i in level]))
        except:
            title = "Test Cycle"
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCYCLE
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_DATA] = data_list
        return data

    # Check if tag type expects test related information
    def check_valid_test_tag(self,node):
        status = False
        if xmlh.get_tagname(node) in \
            [XML_TAG_TESTCASE, \
            XML_TAG_TESTCYCLE,\
            XML_TAG_TESTGROUP,\
            XML_TAG_TEST_PATTERN,\
            XML_TAG_TESTUNIT,\
            XML_TAG_TESTFIXTURE,\
            XML_TAG_TEST_STEP]:
            status = True
        return status

    # Extract test related data from tag by identifying tag type
    def get_tag_data_test(self,node,level=[],sublevel=0):
        data = None
        # identify type of tag and call appropriate function
        if node is not None:
            # list of levels for processing this tag
            l_level=level.copy()
            l_level.append(sublevel)
            
            if xmlh.get_tagname(node) == XML_TAG_TESTCASE:
                data = self.get_tag_data_test_case(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTCYCLE:
                data = self.get_tag_data_test_cycle(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_PATTERN:
                data = self.get_tag_data_test_pattern(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_STEP:
                data = self.get_tag_data_test_step(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTGROUP:
                data = self.get_tag_data_test_group(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTFIXTURE:
                data = self.get_tag_data_test_fixture(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTUNIT:
                data = self.get_tag_data_test_unit(node,l_level)
            else:
                # Unused tag type; DO NOT record
                data=None
        return data

    # External API -------------------------
    
    # Get ECU information
    def extract_ecu_info(self):
        test_setup = \
            xmlh.get_child_with_tag(self.root, XML_TAG_TESTSETUP)
        
        data = dict()
        data[BIK_ECU_NAME]=\
            self.get_para_info_from_tag(test_setup,ECU_NAME_TEXT_NEST)
        data[BIK_ECU_ID]=\
            self.get_para_info_from_tag(test_setup,ECU_ID_TEXT_NEST)
        data[BIK_TOOL_VERSION]=\
            self.get_para_info_from_tag(test_setup,TOOL_VERSION_TEXT_NEST)
        data[BIK_DATE]=\
            str(self.get_para_info_from_tag(test_setup, \
                MODIFICATION_DATE_TEXT_NEST_SE))
        
        return data

    # Gather basic test information
    def extract_test_overview(self):
        # get test result
        overview_result = xmlh.get_attribute_from_tag( \
            self.root, XML_TAG_VERDICT, XML_ATTR_RESULT)
        
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_VERDICT] = overview_result
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_NA_COUNT] = na_count
        return test_overview
    
    # Gather result overview of individual test cases in specified node
    # Args:
    #   node: Node for which the overview data has to be gathered
    def extract_test_overview_group(self,node):
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_NA_COUNT] = na_count
        
        return test_overview

# End of NEST ReportDataExtraction --------------------------------------------


# DIVA ReportDataExtraction ---------------------------------------------------

class DivaReportDataExtraction(BaseReportDataExtraction):
    # Get information of parameter from tags under parent node
    # Arguments:
    #     Parent: Node to be searched
    #     parameter: Parameter <name> to search for
    # Return:
    #     Description text if matching parameter is found 
    def get_para_info_from_tag(self,parent,parameter):
        retinfo = None
        # Parse all tags in parent node
        children = xmlh.get_all_children(parent)
        if children is not None:
            for child in children:
                l_name = None
                l_desc = None
                # read tags
                name_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_NAME)
                desc_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_DESC)
                
                # get text from tags
                if name_tag is not None:
                    l_name = xmlh.get_text(name_tag)
                if desc_tag is not None:
                    l_desc = xmlh.get_text(desc_tag)

                # check for match
                if l_name == parameter:
                    retinfo = l_desc
                    break
        return retinfo
    
    # Get information from test step
    # Assumption: No further test data to dig into
    def get_tag_data_test_step(self,node,level=[]):
        data = None
        text = xmlh.get_text(node)
        result = xmlh.get_attribute(node,XML_ATTR_RESULT)
        step = xmlh.get_attribute(node,XML_ATTR_IDENT)
        
        # Do not consider step if result is na or empty text field
        if (text is None) or result == XML_VERDICT_NA:
            data = None
        else:
            data=dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TEST_STEP
            data[EDTSK_ACTION]=step
            data[EDTSK_DESC]=text
            data[EDTSK_RESULT]= result
        return data

    # Get information from test pattern:
    # Assumption: Contains only one or more test steps as test related data
    def get_tag_data_test_pattern(self,node,level=[]):
        steps = list()
        children=xmlh.get_children_with_tag(node,XML_TAG_TEST_STEP)
        
        # Parse all available steps
        for child in children:
            subdata = self.get_tag_data_test_step(child,level)
            if subdata is not None:
                steps.append(subdata)
        
        if len(steps) > 0:
            data=steps.copy()
        else:
            # No data to add
            data = None
        return data

    # Get information from test case
    # Assumption: Contains only one test pattern as relevant data
    def get_tag_data_test_case(self,node,level=[]):
        # get basic info
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        ident = xmlh.get_text_from_tag(node,XML_TAG_IDENT)
        result = xmlh.get_attribute_from_tag(node, \
            XML_TAG_VERDICT,XML_ATTR_RESULT)
        
        test_objects = xmlh.get_all_children(node)
        data_list = list()
        
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                # test pattern or precondition data
                sub_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if sub_data is not None:
                    data_list.append(sub_data)
        
        if len(data_list) > 0:
            data = dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCASE
            data[EDTCK_TITLE] = title
            data[EDTCK_IDENT] = ident
            data[EDTCK_RESULT] = result
            data[EDTCK_LEVEL] = '.'.join([str(i) for i in level])
            data[EDTCK_STEPS] = data_list
        else:
            # No valid data found
            data = None
        return data
    
    # Get information about test groups
    # Assumption: Could contain any test object types
    def get_tag_data_test_group(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTGROUP
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data

    # Check if tag type expects test related information
    def check_valid_test_tag(self,node):
        status = False
        if xmlh.get_tagname(node) in \
            [XML_TAG_TESTCASE, \
            XML_TAG_TESTGROUP,\
            XML_TAG_TEST_PATTERN,\
            XML_TAG_TEST_STEP]:
            status = True
        return status

    # Extract test related data from tag by identifying tag type
    def get_tag_data_test(self,node,level=[],sublevel=0):
        data = None
        # identify type of tag and call appropriate function
        if node is not None:
            # list of levels for processing this tag
            l_level=level.copy()
            l_level.append(sublevel)
            if xmlh.get_tagname(node) == XML_TAG_TESTCASE:
                data = self.get_tag_data_test_case(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_PATTERN:
                data = self.get_tag_data_test_pattern(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_STEP:
                data = self.get_tag_data_test_step(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTGROUP:
                data = self.get_tag_data_test_group(node,l_level)
            else:
                # Unused tag type; DO NOT record
                data=None
        return data

    # Get ECU information
    def extract_ecu_info(self):
        test_setup = \
            xmlh.get_child_with_tag(self.root, XML_TAG_TESTSETUP)
        
        data = dict()
        data[BIK_ECU_NAME]=\
            self.get_para_info_from_tag(test_setup,ECU_NAME_TEXT_DIVA)
        data[BIK_ECU_VARIANT]=\
            self.get_para_info_from_tag(test_setup,BIK_ECU_VARIANT)
        data[BIK_SPEC_VERSION]=\
            self.get_para_info_from_tag(test_setup,BIK_SPEC_VERSION)
        data[BIK_DATE] = \
            str(self.get_para_info_from_tag(test_setup, \
                MODIFICATION_DATE_TEXT_DIVA))
        return data

    # Gather basic test information
    def extract_test_overview(self):
        # get test result
        overview_result = xmlh.get_attribute_from_tag( \
            self.root, XML_TAG_VERDICT, XML_ATTR_RESULT)
        
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        warning_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            elif XML_VERDICT_WARN in result:
                warning_count += 1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TEST_SKIPPED)    

        for testcase in skipped_tests:
            ne_count += 1

        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_VERDICT] = overview_result
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_WARNING_COUNT] = warning_count
        test_overview[OVEK_NA_COUNT] = na_count
        
        return test_overview
    
    # Gather result overview of individual test cases in specified node
    # Args:
    #   node: Node for which the overview data has to be gathered
    def extract_test_overview_group(self,node):
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        warning_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            elif XML_VERDICT_WARN in result:
                warning_count += 1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TEST_SKIPPED)    

        for testcase in skipped_tests:
            ne_count += 1

        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_WARNING_COUNT] = warning_count
        test_overview[OVEK_NA_COUNT] = na_count
        return test_overview
    
# End of DiVA ReportDataExtraction --------------------------------------------


# DiagGW ReportDataExtraction -------------------------------------------------

class DiagReportDataExtraction(BaseReportDataExtraction):
    # Get information of parameter from tags under parent node
    # Arguments:
    #     Parent: Node to be searched
    #     parameter: Parameter <name> to search for
    # Return:
    #     Description text if matching parameter is found 
    def get_para_info_from_tag(self,parent,parameter):
        retinfo = None
        # Parse all tags in parent node
        children = xmlh.get_all_children(parent)
        if children is not None:
            for child in children:
                l_name = None
                l_desc = None
                # read tags
                name_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_NAME)
                desc_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_DESC)
                
                # get text from tags
                if name_tag is not None:
                    l_name = xmlh.get_text(name_tag)
                if desc_tag is not None:
                    l_desc = xmlh.get_text(desc_tag)

                # check for match
                if l_name == parameter:
                    retinfo = l_desc
                    break
        return retinfo
    
    # Get information from test step
    # Assumption: No further test data to dig into
    def get_tag_data_test_step(self,node,level=[]):
        data = None
        text = xmlh.get_text(node)
        result = xmlh.get_attribute(node,XML_ATTR_RESULT)
        step = xmlh.get_attribute(node,XML_ATTR_IDENT)
        
        # Do not consider step if result is na or empty text field
        if (text is None) or result == XML_VERDICT_NA:
            data = None
        else:
            data=dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TEST_STEP
            data[EDTSK_ACTION]=step
            data[EDTSK_DESC]=text
            data[EDTSK_RESULT]= result
        return data

    # Get information from test pattern:
    # Assumption: Contains only one or more test steps as test related data
    def get_tag_data_test_pattern(self,node,level=[]):
        steps = list()
        children=xmlh.get_children_with_tag(node,XML_TAG_TEST_STEP)
        # Parse all available steps
        for child in children:
            subdata = self.get_tag_data_test_step(child,level)
            if subdata is not None:
                steps.append(subdata)
        
        if len(steps) > 0:
            data=steps.copy()
        else:
            # No data to add
            data = None
        return data

    # Get information from test case
    # Assumption: Could contain other test objects
    def get_tag_data_test_case(self,node,level=[]):
        # get basic info
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        ident = xmlh.get_text_from_tag(node,XML_TAG_IDENT)
        result = xmlh.get_attribute_from_tag(node, \
            XML_TAG_VERDICT,XML_ATTR_RESULT)
        
        test_objects = xmlh.get_all_children(node)
        data_list = list()
        
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                # test pattern or precondition data
                sub_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if sub_data is not None:
                    data_list.append(sub_data)
        
        if len(data_list) > 0:
            data = dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCASE
            data[EDTCK_TITLE] = title
            data[EDTCK_IDENT] = ident
            data[EDTCK_RESULT] = result
            data[EDTCK_LEVEL] = '.'.join([str(i) for i in level])
            data[EDTCK_STEPS] = data_list
        else:
            # No valid data found
            data = None
        return data

    # Get information about test groups
    # Assumption: Could contain any test object types
    def get_tag_data_test_group(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTGROUP
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data

    # Check if tag type expects test related information
    def check_valid_test_tag(self,node):
        status = False
        if xmlh.get_tagname(node) in \
            [XML_TAG_TESTCASE, \
            XML_TAG_TESTGROUP,\
            XML_TAG_TEST_PATTERN,\
            XML_TAG_TEST_STEP]:
            status = True
        return status

    # Extract test related data from tag by identifying tag type
    def get_tag_data_test(self,node,level=[],sublevel=0):
        data = None
        # identify type of tag and call appropriate function
        if node is not None:
            # list of levels for processing this tag
            l_level=level.copy()
            l_level.append(sublevel)          
            if xmlh.get_tagname(node) == XML_TAG_TESTCASE:
                data = self.get_tag_data_test_case(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_PATTERN:
                data = self.get_tag_data_test_pattern(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_STEP:
                data = self.get_tag_data_test_step(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTGROUP:
                data = self.get_tag_data_test_group(node,l_level)
            else:
                # Unused tag type; DO NOT record
                data=None
        return data

    # Get ECU information
    def extract_ecu_info(self):
        test_setup = \
            xmlh.get_child_with_tag(self.root, XML_TAG_TESTSETUP)
        sw_under_test = \
            xmlh.get_child_with_tag(self.root, XML_TAG_SUT)
        
        data = dict()
        data[BIK_TOOL_VERSION] = \
            self.get_para_info_from_tag(test_setup,TOOL_VERSION_TEXT_DIAG)
        data[BIK_DATE] = \
            str(self.get_para_info_from_tag(test_setup, \
                MODIFICATION_DATE_TEXT_DIAG))
        data[BIK_ECU_NAME] = \
            self.get_para_info_from_tag(sw_under_test,ECU_NAME_TEXT_DIAG)
        data[BIK_RELEASE_VERSION] = \
            self.get_para_info_from_tag(sw_under_test, \
                RELEASE_VERSION_TEXT_DIAG)
        return data    

    # Gather basic test information
    def extract_test_overview(self):
        # get test result
        overview_result = xmlh.get_attribute_from_tag( \
            self.root, XML_TAG_VERDICT, XML_ATTR_RESULT)
        
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_VERDICT] = overview_result
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_NA_COUNT] = na_count
        
        return test_overview
    
    # Gather result overview of individual test cases in specified node
    # Args:
    #   node: Node for which the overview data has to be gathered
    def extract_test_overview_group(self,node):
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif XML_VERDICT_FAIL in result:
                fail_count +=1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_NA_COUNT] = na_count
        return test_overview
    
# End of DiagGW ReportDataExtraction ------------------------------------------


# TLS ReportDataExtraction ---------------------------------------------------

class TLSReportDataExtraction(BaseReportDataExtraction):
    # Get information of parameter from tags under parent node
    # Arguments:
    #     Parent: Node to be searched
    #     parameter: Parameter <name> to search for
    # Return:
    #     Description text if matching parameter is found 
    def get_para_info_from_tag(self,parent,parameter):
        retinfo = None
        # Parse all tags in parent node
        children = xmlh.get_all_children(parent)
        for child in children:
            l_name = None
            l_desc = None
            # read tags
            name_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_NAME)
            desc_tag = xmlh.get_child_with_tag(child,XML_TAG_INFO_DESC)
            
            # get text from tags
            if name_tag is not None:
                l_name = xmlh.get_text(name_tag)
            if desc_tag is not None:
                l_desc = xmlh.get_text(desc_tag)

            # check for match
            if l_name == parameter:
                retinfo = l_desc
                break
        return retinfo
    
    # Get information from test step
    # Assumption: No further test data to dig into
    def get_tag_data_test_step(self,node,level=[]):
        data = None
        text = xmlh.get_text(node)
        result = xmlh.get_attribute(node,XML_ATTR_RESULT)
        step = xmlh.get_attribute(node,XML_ATTR_IDENT)
        
        # Do not consider step if result is na or empty text field
        if (text is None) or result == XML_VERDICT_NA:
            data = None
        else:
            data=dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TEST_STEP
            data[EDTSK_ACTION]=step
            data[EDTSK_DESC]=text
            data[EDTSK_RESULT]= result
        return data

    # Get information from test pattern:
    # Assumption: Contains only one or more test steps as test related data
    def get_tag_data_test_pattern(self,node,level=[]):
        steps = list()
        children=xmlh.get_children_with_tag(node,XML_TAG_TEST_STEP)
        
        # Parse all available steps
        for child in children:
            subdata = self.get_tag_data_test_step(child,level)
            if subdata is not None:
                steps.append(subdata)
        
        if len(steps) > 0:
            data=steps.copy()
        else:
            # No data to add
            data = None
        return data

    # Get information from test case
    # Assumption: Contains only one test pattern as relevant data
    def get_tag_data_test_case(self,node,level=[]):
        # get basic info
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        ident = xmlh.get_text_from_tag(node,XML_TAG_IDENT)
        result = xmlh.get_attribute_from_tag(node, \
            XML_TAG_VERDICT,XML_ATTR_RESULT)
                
        test_objects = xmlh.get_all_children(node)
        data_list = list()

        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                # test pattern or precondition data
                sub_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if sub_data is not None:
                    data_list.append(sub_data)
        
        if len(data_list) > 0:
            data = dict()
            data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCASE
            data[EDTCK_TITLE] = title
            data[EDTCK_IDENT] = ident
            data[EDTCK_RESULT] = result
            data[EDTCK_LEVEL] = '.'.join([str(i) for i in level])
            data[EDTCK_STEPS] = data_list
        else:
            # No valid data found
            data = None

        return data
    
    # Get information about test groups
    # Assumption: Could contain any test object types
    def get_tag_data_test_group(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTGROUP
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data

    # Get information about test units
    # Assumption: Could contain any test object types
    def get_tag_data_test_cycle(self,node,level=[]):
        # title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        try:
            title = "Test Cycle: %s"%('.'.join([str(i) for i in level]))
        except:
            title = "Test Cycle"
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCYCLE
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data

    # Get information about test units
    # Assumption: Could contain any test object types
    def get_tag_data_test_unit(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTUNIT
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data

    # Get information about commands
    # Assumption: Could contain any test object types
    def get_tag_data_test_command(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCOMMAND
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_DATA] = data_list
        return data
    
    # Get information about test case lists
    # Assumption: Could contain any test object types
    def get_tag_data_test_caselist(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTCASELIST
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data

    # Get information about test fixtures
    # Assumption: Could contain any test object types
    def get_tag_data_test_fixture(self,node,level=[]):
        title = xmlh.get_text_from_tag(node,XML_TAG_TITLE)
        test_objects = xmlh.get_all_children(node)
        
        data_list = list()
        level_count = 0
        for test in test_objects:
            # check if the tag contains test data
            if self.check_valid_test_tag(test):
                level_count += 1
                case_data = self.get_tag_data_test(test,level=level, \
                    sublevel=level_count)
                if case_data is not None:
                    data_list.append(case_data)
        
        data = dict()
        data[TEST_TAG_TYPE_KEY]=XML_TAG_TESTFIXTURE
        data[EDTGK_TITLE] = title
        data[EDTGK_LEVEL] = '.'.join([str(i) for i in level])
        data[EDTGK_OVERVIEW] = self.extract_test_overview_group(node)
        data[EDTGK_DATA] = data_list
        return data   

    # Check if tag type expects test related information
    def check_valid_test_tag(self,node):
        status = False
        if xmlh.get_tagname(node) in \
            [XML_TAG_TESTCYCLE, \
            XML_TAG_TESTUNIT, \
            XML_TAG_TESTCOMMAND, \
            XML_TAG_TESTCASELIST, \
            XML_TAG_TESTFIXTURE, \
            XML_TAG_TESTCASE, \
            XML_TAG_TESTGROUP,\
            XML_TAG_TEST_PATTERN,\
            XML_TAG_TEST_STEP]:
            status = True
        return status

    # Extract test related data from tag by identifying tag type
    def get_tag_data_test(self,node,level=[],sublevel=0):
        
        data = None
        # identify type of tag and call appropriate function
        if node is not None:
            # list of levels for processing this tag
            l_level=level.copy()
            l_level.append(sublevel)
            
            if xmlh.get_tagname(node) == XML_TAG_TESTCASE:
                data = self.get_tag_data_test_case(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTCYCLE:
                data = self.get_tag_data_test_cycle(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTCOMMAND:
                data = self.get_tag_data_test_command(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTCASELIST:
                data = self.get_tag_data_test_caselist(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTFIXTURE:
                data = self.get_tag_data_test_fixture(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTUNIT:
                data = self.get_tag_data_test_unit(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_PATTERN:
                data = self.get_tag_data_test_pattern(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TEST_STEP:
                data = self.get_tag_data_test_step(node,l_level)
            elif xmlh.get_tagname(node) == XML_TAG_TESTGROUP:
                data = self.get_tag_data_test_group(node,l_level)
            else:
                # Unused tag type; DO NOT record
                data=None
        return data

    # External API -------------------------
    
    # Get ECU information
    # TODO: Get name of ECU from report. Not found yet.
    def extract_ecu_info(self):
        test_setup = \
            xmlh.get_child_with_tag(self.root, XML_TAG_TESTSETUP)
        
        data = dict()
        data[BIK_ECU_NAME]=\
            self.get_para_info_from_tag(test_setup,ECU_NAME_TEXT_TLS)
        data[BIK_ECU_ID]=\
            self.get_para_info_from_tag(test_setup,ECU_ID_TEXT_TLS)
        data[BIK_TEST_CONFIGURATION]=\
            self.get_para_info_from_tag(test_setup,TEST_CONFIGURATION_TEXT_TLS)
        
        return data

    # Gather basic test information
    def extract_test_overview(self):
        # get test result
        overview_result = xmlh.get_attribute_from_tag( \
            self.root, XML_TAG_VERDICT, XML_ATTR_RESULT)
        
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        inconclusive_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif (XML_VERDICT_FAIL in result) or (XML_VERDICT_ERROR in result):
                fail_count +=1
            elif XML_VERDICT_INCONCLUSIVE in result:
                inconclusive_count += 1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(self.root, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_VERDICT] = overview_result
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_INCONCLUSIVE_COUNT] = inconclusive_count
        test_overview[OVEK_NA_COUNT] = na_count

        return test_overview
    
    # Gather result overview of individual test cases in specified node
    # Args:
    #   node: Node for which the overview data has to be gathered
    def extract_test_overview_group(self,node):
        # get list of test cases
        executed_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TESTCASE)
        case_count = 0
        pass_count = 0
        fail_count = 0
        inconclusive_count = 0
        na_count = 0
        for testcase in executed_tests:
            case_count += 1
            # check status of test case
            result = xmlh.get_attribute_from_tag(testcase, 
                                                    XML_TAG_VERDICT, 
                                                    XML_ATTR_RESULT)
            if XML_VERDICT_PASS in result:
                pass_count +=1
            elif (XML_VERDICT_FAIL in result) or (XML_VERDICT_ERROR in result):
                fail_count +=1
            elif XML_VERDICT_INCONCLUSIVE in result:
                inconclusive_count += 1
            else:
                na_count +=1
        
        # Not executed
        ne_count = 0
        skipped_tests = xmlh.get_tags_from_tree(node, 
                                                XML_TAG_TEST_SKIPPED)

        for testcase in skipped_tests:
            ne_count += 1
        # Update total case count
        case_count += ne_count
        
        # Add data to organized dictionary
        test_overview = dict()
        test_overview[OVEK_TEST_COUNT] = case_count
        test_overview[OVEK_NE_COUNT] = ne_count
        test_overview[OVEK_EXE_COUNT] = case_count - ne_count
        test_overview[OVEK_PASS_COUNT] = pass_count
        test_overview[OVEK_FAIL_COUNT] = fail_count
        test_overview[OVEK_INCONCLUSIVE_COUNT] = inconclusive_count
        test_overview[OVEK_NA_COUNT] = na_count
        return test_overview
    
# End of TLS ReportDataExtraction --------------------------------------------


if __name__=='__main__':
    pass

# End of File ----------------------------------------------------------------
