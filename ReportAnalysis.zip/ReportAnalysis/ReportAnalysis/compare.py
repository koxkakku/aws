# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 09:46:33 2022
@author: RAJAYAM
Desc: 
    - Gather data from multiple test reports
    - Compare differences between test cases.
"""

import json
from .DataExtractor import DataExtractor
from .RHconstants import ETDK_TEST_DATA
from .RHconstants import GFK_TEST_CASE_LEVEL
from .RHconstants import ETDK_ECU_INFO
from .RHconstants import CDK_TITLE
from .RHconstants import CDK_RESULT
from .RHconstants import CDK_LEVEL
from .RHconstants import TEST_TAG_TYPE_KEY
from .RHconstants import DXTGK_DATA
from .RHconstants import ETDK_OVERVIEW
from .RHconstants import CMP_TEST_GROUP
from .RHconstants import CMP_TEST_CYCLE
from .RHconstants import CMP_TESTCASE_TITLE
from .RHconstants import CMP_TESTCASE_LEVEL
from .RHconstants import CMP_TESTCASE_RESULT
from .RHconstants import CMP_TESTGROUP_TITLE
from .RHconstants import CMP_TESTGROUP_LEVEL
from .RHconstants import CMP_TESTCASE_RESULT_STR

# Comparison data keys (CMPDK_*)
CMPDK_TITLES="ReportTitle"
CMPDK_CONTRAST="Contrast"
CMPDK_OVERVIEW=ETDK_OVERVIEW
CMPDK_DATA=DXTGK_DATA

# Contrast Data Key (CNDK_*)
CNDK_IDENTICAL="Identical"
CNDK_OPPOSITE="Opposite"

NOT_FOUND ='None'
NOT_FOUND_LST = ['%sTESTCASE NOT FOUND'%CMP_TESTGROUP_TITLE,
                 '%sTESTCASE NOT FOUND'%CMP_TESTGROUP_LEVEL, 
                 '%sTESTCASE NOT FOUND'%CMP_TESTCASE_TITLE,
                 '%sTESTCASE NOT FOUND'%CMP_TESTCASE_LEVEL,
                 '%sTESTCASE NOT FOUND'%CMP_TESTCASE_RESULT,
                ]

# Extraction of TESTGROUP,LEVEL,RESULT from TEST_DATA if any testcase is 
# part of multiple testgroups
def testgroup_level_title_extraction(details,final_lst,temp_group_title,\
    temp_group_level):
    for loop in details:
        if DXTGK_DATA in loop:
            if(loop[DXTGK_DATA] != []):
                temp_group_title = loop[CDK_TITLE]
                temp_group_level = loop[CDK_LEVEL]
                testgroup_level_title_extraction(loop[DXTGK_DATA],final_lst, \
                    temp_group_title,temp_group_level)
        else:
                   
                final_lst.append(CMP_TESTGROUP_TITLE + temp_group_title)
                final_lst.append(CMP_TESTGROUP_LEVEL + temp_group_level)
                final_lst.append(CMP_TESTCASE_TITLE + loop[CDK_TITLE])
                final_lst.append(CMP_TESTCASE_LEVEL + loop[CDK_LEVEL])
                final_lst.append(CMP_TESTCASE_RESULT + loop[CDK_RESULT])
    return

# Extract data from test cycle
def testcycle_level_title_extraction(details,final_lst,temp_group_title,\
    temp_group_level):
    testgroup_level_title_extraction(details,final_lst,temp_group_title,temp_group_level)
    return

#Extraction of TESTGROUP,LEVEL,RESULT from TEST_DATA   
def testdata_extraction(compare_lst_testdata,index):
    new_lst = []
    _testCycleDone = False
    for i in compare_lst_testdata[index]:
        global final_lst
        final_lst = []
        
        if(i[TEST_TAG_TYPE_KEY] == CMP_TEST_CYCLE):
            # NOTE: Consider only the first test cycle for now.
            if _testCycleDone is False:
                _testCycleDone = True
                testcycle_level_title_extraction(i[DXTGK_DATA],final_lst, \
                    i[CDK_TITLE],i[CDK_LEVEL])
            else:
                # One Test cycle has already been processed for this report.
                pass
        elif(i[TEST_TAG_TYPE_KEY] == CMP_TEST_GROUP):
            testgroup_level_title_extraction(i[DXTGK_DATA],final_lst, \
                i[CDK_TITLE],i[CDK_LEVEL])
        else :
            final_lst.append(CMP_TESTGROUP_TITLE+NOT_FOUND)
            final_lst.append(CMP_TESTGROUP_LEVEL+NOT_FOUND)
            final_lst.append(CMP_TESTCASE_TITLE+ i[CDK_TITLE])
            final_lst.append(CMP_TESTCASE_LEVEL+ i[CDK_LEVEL])
            final_lst.append(CMP_TESTCASE_RESULT + i[CDK_RESULT])
        new_lst.append(final_lst)
       
    return(new_lst)

# To compare the result of testcase in various files        
def comparison_result(all_files_wosteps_split,compare_text,main, \
    compare_result,test_title):      
    if(main == 0): 
         
        diff_list = False  # Same list
        first_lst = []
        final_lst = []
        first_lst.append(test_title)
        for loop in range(len(all_files_wosteps_split) - 1):
            text_found = False
            # comparing base file testcase titles, results with other 
            # files(other list elements)
            for search in  all_files_wosteps_split[loop+1]:    
                for search_subelem in search:
                    temp_lst = []
                    if(CMP_TESTCASE_TITLE in search_subelem ): 
                        #comparing the title                         
                        if(compare_text == search_subelem):
                            temp_lst = search
                            first_lst.append(temp_lst)
                            text_found = True
                            #if title matches, comparing the result 
                            for lst in temp_lst:                                                                                                      
                                if(CMP_TESTCASE_RESULT in lst ):                                  
                                    if(compare_result != lst) :
                                        diff_list = True  
            # if same testcase is not found, then appending 
            # NOT FOUND LIST to first list           
            if(text_found == False):
                diff_list = True
                second_lst = []
                second_lst = NOT_FOUND_LST
                first_lst.append(second_lst) 
        # if testcase is FOUND but result is different, then updating 
        # the list with testgroup, level, title ,result details
        if(diff_list == True) :
            final_lst.append(first_lst)
                    
        if(final_lst != []):
            return final_lst
               
    else:
                        
        diff_list = False
        text_found = False
        first_lst = []
        final_lst = []
        # checking if test case exists in base file
        for search in  all_files_wosteps_split[0]:
            for search_subelem in search:
                if(CMP_TESTCASE_TITLE in search_subelem ):
                    if(compare_text == search_subelem):
                        text_found = True 
                        return None
                        break
        # if testcase is not found in base file, append 
        # NOT FOUND LIST to first list                               
        if(text_found == False):
            second_lst = []     
            second_lst = NOT_FOUND_LST
            first_lst.append(second_lst) 
           # Loop to check if testcase exists in other files except Base file                             
            for loop in range(len(all_files_wosteps_split)):
                # if loop ==0 (base file) , no need to append anything
                if(loop == 0):                                       
                     continue
                # if loop is equal to main file, then appending testcase 
                # data to the first list
                elif(loop == main):
                    first_lst.append(test_title)
                else:
                    # checking testcase data in other files
                    text_found1 = False
                    for search in  all_files_wosteps_split[loop]: 
                        for search_subelem in search:
                            if(CMP_TESTCASE_TITLE in search_subelem ):
                                if(compare_text == search_subelem):
                                    text_found1 = True
                                    first_lst.append(search)
                                          
                    if(text_found1 == False):
                        second_lst = []     
                        second_lst = NOT_FOUND_LST
                        first_lst.append(second_lst)
        if(first_lst != []):
            final_lst .append(first_lst)    
            return final_lst

# To get all testcases ist    
def all_testcase_list(all_files_wosteps_split,compare_text,main, \
    compare_result,test_title): 
     
    if(main == 0):                  
        first_lst = []
        final_lst = []
        first_lst.append(test_title)
        for loop in range(len(all_files_wosteps_split) - 1):
            text_found = False
            
            # comparing base file testcase titles, results with other 
            # files(other list elements)
            for search in  all_files_wosteps_split[loop+1]:    
                for search_subelem in search:
                    temp_lst = []
                    if(CMP_TESTCASE_TITLE in search_subelem ):
                        
                        # comparing the title                         
                        if(compare_text == search_subelem):
                            
                            temp_lst = search                            
                            first_lst.append(temp_lst)                            
                            text_found = True
                            break
            # if same testcase is not found, then appending 
            # NOT FOUND LIST to first list
            if(text_found == False):
               # first_lst.append(test_title)
                first_lst.append(NOT_FOUND_LST)   
        final_lst.append(first_lst)        
        if(final_lst != []):
            return final_lst
               
    else:
        text_found = False
        first_lst = []
        final_lst = []
        # checking if test case exists in base file
        for search in  all_files_wosteps_split[0]:
            for search_subelem in search:
                if(CMP_TESTCASE_TITLE in search_subelem ):
                    if(compare_text == search_subelem):
                        text_found = True 
                        return None
                        break
        # if testcase if not found in base file, append 
        # NOT FOUND LIST to first list                               
        if(text_found == False):
            first_lst.append(NOT_FOUND_LST) 
            # Loop to check if testcase exists in other files except Base file                             
            for loop in range(len(all_files_wosteps_split)):
                # if loop ==0 (base file) , no need to append anything
                if(loop == 0):                                       
                      continue
                # if loop is equal to main file , then appending 
                # testcase data to the first list
                elif(loop == main):
                    first_lst.append(test_title)
                else:
                    # checking testcase data in other files
                    text_found1 = False
                    for search in  all_files_wosteps_split[loop]: 
                        for search_subelem in search:
                            if(CMP_TESTCASE_TITLE in search_subelem ):
                                if(compare_text == search_subelem):
                                    text_found1 = True
                                    first_lst.append(search)
                                    break
                                          
                    if(text_found1 == False):
                        second_lst = []     
                        second_lst = NOT_FOUND_LST
                        first_lst.append(second_lst)
        if(first_lst != []):
            final_lst .append(first_lst)    
            return final_lst

# Gather data from reports to be compared
# TODO: Multilevel nested loops. May need to rewrite.
def get_compare_data(comparison_list,file_type):
    compare_lst_finaldata = []
    compare_lst_testdata = []
    k = []
    file_wosteps = []
    element = 0
    overview_data = {}
    ecu_info = {}
    overview = []
    report_titles=list()
    # collecting extract data 
    for file in comparison_list:
        data = DataExtractor(test_type=file_type,report_file=file)
        data.extract()
        store = ((data.get_extracted_data()))
        compare_lst_finaldata.append(store)
        report_titles.append(data.get_report_filename())
    
    # extracting  test data, overview data , ECU info into seperate lists      
    for i in  compare_lst_finaldata :
        compare_lst_testdata.append(i[ETDK_TEST_DATA]) 
        overview_data = i[ETDK_OVERVIEW] 
        ecu_info = i[ETDK_ECU_INFO]
        py = {**overview_data,**ecu_info}
        overview.append(py)
    
    # collecting Test case data from all the input reports into a single list       
    for loop_element in range(len(compare_lst_testdata)):
        file_wosteps.append( \
            testdata_extraction(compare_lst_testdata,loop_element))
    
    # Splitting the list into seperate lists having Testgroup title, 
    # Testgroup Level , Testcase title, level and Result
    all_files_wosteps_split = []
    for element in range(len(file_wosteps)) : 
        file_wosteps_split = [] 
        for test_title in file_wosteps[element]:
            length_limit = 5
            if(len(test_title)>length_limit):              
                for x in range(0, len(test_title) ,length_limit):
                    file_wosteps_split.append(test_title[x:(length_limit+x)])              
            else:
                    file_wosteps_split.append(test_title)
    
        all_files_wosteps_split.append(file_wosteps_split)
    
    output1 = []
    element = 0
    # Comparing one report test result data with other reports     
    for main in range(len(all_files_wosteps_split)):
        out1 = []       
        for test_title in all_files_wosteps_split[main]:
            for sub_elem in test_title:        
                if(CMP_TESTCASE_TITLE in sub_elem):        
                    compare_text = sub_elem
                if(CMP_TESTCASE_RESULT in sub_elem):
                    compare_result = (sub_elem)
                    # passing each testcase title and its corresponding result
                    # as argument to compare it with other list elements
                    # out1.append(comparison_result(all_files_wosteps_split, \
                    #     compare_text,main,compare_result,test_title))
                    out1.append(all_testcase_list(all_files_wosteps_split, \
                        compare_text,main,compare_result,test_title))
                    
       # removal of None items in the collected list             
        while(None in out1) :
            out1.remove(None)
        output1.append(out1)
    

    all_files_output = []
    # converting nested lists into a dictionary
    for i in output1:
        temp2 = []         
        for j in i :          
            temp = []
            for k in j:
                for l in k:
                    #print(l)
                    d = dict(a.split(':',1) for a in l)       
                    temp.append(d)
            temp2.append(temp)
        all_files_output.append(temp2)      
    all_files_output = ([x for x in all_files_output if x])
        
    # TODO: Verify what is being done here and rewrite.
    # To remove same testcases present in multiple testgroups
    for i in all_files_output[0]:
       if(len(i)>len(comparison_list)):           
            for j in i:               
               first_level = (j[GFK_TEST_CASE_LEVEL])
               break
            num=0
            for k in i:
                if (k[GFK_TEST_CASE_LEVEL] != first_level):
                    i.pop(num)
                num=num+1
    
    # Combining multiple lists into a single list which has information in 
    # the form of dictionary 
    for i in range(len(all_files_output)):
        if(i > 0):
            all_files_output[0].extend(all_files_output[i])
   # Removing the repeated testcases if it is found multipe times 
    sorted_list = []
    for item in  all_files_output[0]:
        if item not in sorted_list:
            sorted_list.append(item)
    
    # NOTE: 
    # The code for counting identical and opposite test cases has been 
    # implemented such that it works with the existing output of the 
    # comparison code. If the format of the sorted list is updated this will 
    # also need to be updated.
    # STEPHIG

    # Initialize variables for counting identical and opposite results
    count_identical = 0
    count_opposite = 0

    # Parse the sorted list of lists to get the number of 
    # identical and opposite cases
    for caselist in sorted_list:
        # Check if all dictionaries in each list have similar results
        try:
            # Make a list of results in current list of cases
            result_list=[case[CMP_TESTCASE_RESULT_STR] for case in caselist]
            
            # Count similar results
            if (result_list.count(result_list[0]) == len(result_list)):
                count_identical += 1
            else:
                count_opposite += 1
        except Exception as e:
            print("Exception while counting identical: %s"%e)
    # Arrange contrast data in a dictionary
    contrast_data={
        CNDK_IDENTICAL:count_identical,
        CNDK_OPPOSITE:count_opposite
    }

    # combining both test result data and overview info data into a dictionary
    json_dict = {
        CMPDK_DATA:sorted_list,
        CMPDK_OVERVIEW:overview,
        CMPDK_CONTRAST:contrast_data,
        CMPDK_TITLES:report_titles
        }
    
    return json_dict

if __name__ =="__main__":  
    pass

# End of File -----------------------------------------------------------------
