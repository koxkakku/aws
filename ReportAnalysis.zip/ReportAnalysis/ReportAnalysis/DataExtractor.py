# -*- coding: utf-8 -*-
"""
Created by: STEPHIG
Date: 26-Apr-2022
Desc: API to extract data from report file using report handler for test

TODO: Create new type of verdict for All cases instead of using None
"""

# Imports ---------------------------------------------------------------------
# Report handler classes
from .ReportHandler import NestReportDataExtraction
from .ReportHandler import NestSEReportDataExtraction
from .ReportHandler import NTSReportDataExtraction
from .ReportHandler import DivaReportDataExtraction
from .ReportHandler import DiagReportDataExtraction
from .ReportHandler import TLSReportDataExtraction

# Test type Reference keys
from .common import TTRK_CLASS

# ECU Test types
from .common import ECU_TEST_TYPE_NEST
from .common import ECU_TEST_TYPE_NEST_SE
from .common import ECU_TEST_TYPE_NTS
from .common import ECU_TEST_TYPE_DIVA
from .common import ECU_TEST_TYPE_DIAG
from .common import ECU_TEST_TYPE_TLS

# Failed cases keywords
from .RHconstants import DXTGK_TITLE
from .RHconstants import DXTGK_LEVEL
from .RHconstants import DXTGK_RESULT
from .RHconstants import DXTGK_OVERVIEW
from .RHconstants import DXTGK_DATA
from .RHconstants import DXTCK_TITLE
from .RHconstants import DXTCK_LEVEL
from .RHconstants import DXTCK_RESULT
from .RHconstants import DXTCK_REASON

# Overview dict keys
from .RHconstants import OVEK_VERDICT
from .RHconstants import OVEK_TEST_COUNT
from .RHconstants import OVEK_PASS_COUNT
from .RHconstants import OVEK_FAIL_COUNT
from .RHconstants import OVEK_NE_COUNT
from .RHconstants import OVEK_NA_COUNT
from .RHconstants import OVEK_EXE_COUNT
from .RHconstants import OVEK_WARNING_COUNT 
from .RHconstants import OVEK_INCONCLUSIVE_COUNT

# Keys for test step
from .RHconstants import EDTSK_DESC
from .RHconstants import EDTSK_RESULT

# Keys for test case
from .RHconstants import EDTCK_RESULT
from .RHconstants import EDTCK_TITLE
from .RHconstants import EDTCK_LEVEL
from .RHconstants import EDTCK_STEPS

# Keys for test group
from .RHconstants import EDTGK_TITLE
from .RHconstants import EDTGK_LEVEL
from .RHconstants import EDTGK_OVERVIEW
from .RHconstants import EDTGK_DATA

# Result types
from .XMLConstants import XML_VERDICT_PASS
from .XMLConstants import XML_VERDICT_FAIL
from .XMLConstants import XML_VERDICT_WARN
from .XMLConstants import XML_VERDICT_ERROR
from .XMLConstants import XML_VERDICT_NA

# XML imports
from .XMLConstants import XML_TAG_TESTGROUP
from .XMLConstants import XML_TAG_TESTCASE
from .XMLConstants import XML_TAG_TESTCASELIST
from .XMLConstants import XML_TAG_TESTFIXTURE
from .XMLConstants import XML_TAG_TESTCYCLE
from .XMLConstants import XML_TAG_TESTUNIT
from .XMLConstants import XML_TAG_TESTCOMMAND
from .XMLConstants import XML_TAG_TEST_STEP

# Miscellaneous
from .RHconstants import TEST_TAG_TYPE_KEY

# Constants -------------------------------------------------------------------
# Test type based look up table
# Add more parameters, if needed
DATA_EXTRACT_REFERENCE = {
    ECU_TEST_TYPE_NEST:{
        TTRK_CLASS:NestReportDataExtraction
    },
    ECU_TEST_TYPE_NEST_SE:{
        TTRK_CLASS:NestSEReportDataExtraction
    },
    ECU_TEST_TYPE_NTS:{
        TTRK_CLASS:NTSReportDataExtraction
    },
    ECU_TEST_TYPE_DIVA:{
        TTRK_CLASS:DivaReportDataExtraction
    },
    ECU_TEST_TYPE_DIAG:{
        TTRK_CLASS:DiagReportDataExtraction
    },
    ECU_TEST_TYPE_TLS:{
        TTRK_CLASS:TLSReportDataExtraction
    }
}

# Data extractor --------------------------------------------------------------

class DataExtractor:
    def __init__(self,test_type,report_file):
        self.test_type = test_type
        # check if test type is available in look up table
        if test_type in DATA_EXTRACT_REFERENCE.keys():
            self.report_handler = \
                DATA_EXTRACT_REFERENCE[self.test_type][TTRK_CLASS](report_file)
        else:
            self.report_handler=None
        return
    
    # Get dictionary containing Name,level and list of steps in command
    # Arguments:
    #     temp_steps: Extracted command dictionary to extract data from
    # Return:
    #     Dictionary with necessary data    OR
    #     None: If no matching data found
    def __get_teststep_in_command(self,temp_steps):
        if len(temp_steps[DXTGK_DATA]) >0:
            for temp_step in temp_steps[DXTGK_DATA]:
                if(temp_step[TEST_TAG_TYPE_KEY] == XML_TAG_TESTCOMMAND):
                    dummy_step = self.__get_teststep_in_command(temp_step)
                    if dummy_step is not None :
                        return dummy_step
                elif(temp_step[TEST_TAG_TYPE_KEY] == XML_TAG_TEST_STEP):
                    # if (temp_step[EDTSK_RESULT] == "fail"):
                    #     return temp_step
                    return temp_step
        else:
            return None

    # Get dictionary containing Name,level and list of steps in cases based 
    # on case verdict
    # Arguments:
    #     case: Extracted Case dictionary to extract data from
    #     verdict: Type of steps to be included
    #                 None: Include all steps
    #                 KW_VERDICT_FAIL: Include fail steps
    #                 KW_VERDICT_PASS: Include pass steps
    #                 KW_VERDICT_ERROR: Include error steps
    # Return:
    #     Dictionary with necessary data    OR
    #     None: If no matching data found
    def __get_case_data_by_verdict(self, case, verdict=None):
        retval = None
        enable_verdict = True
        if verdict is None:
            enable_verdict = False
        
        steps_list = list()
        # Should we filter cases by verdict
        if (enable_verdict == True):
            # check if veridct of case is as expected
            if (verdict in case[EDTCK_RESULT]):
                steps = case[EDTCK_STEPS]
                # list of steps. [test_pattern_steps]
                for step in steps:
                    # Check each step
                    if(step[TEST_TAG_TYPE_KEY] == XML_TAG_TEST_STEP):
                        if (verdict in step[EDTSK_RESULT]):
                            # Avoid adding the same task again
                            if step[EDTSK_DESC] not in steps_list:
                                steps_list.append(step[EDTSK_DESC])
                    
                    elif(step[TEST_TAG_TYPE_KEY] == XML_TAG_TESTCOMMAND):
                        if len(step[DXTGK_DATA]) > 0:
                            x_step = self.__get_teststep_in_command(step)
                            if x_step is not None:
                                if x_step[EDTSK_DESC] not in steps_list:
                                    steps_list.append(x_step[EDTSK_DESC])
                    
                    else:
                        # Do not use this info
                        pass

        else:
            # Do not consider verdict of case
            steps = case[EDTCK_STEPS]
            # list of steps. [test_pattern_steps]
            for step in steps:
                # Check each step
                if(step[TEST_TAG_TYPE_KEY] == XML_TAG_TEST_STEP):
                    # Avoid adding the same task again
                    if step[EDTSK_DESC] not in steps_list:
                        steps_list.append(step[EDTSK_DESC])
                
                elif(step[TEST_TAG_TYPE_KEY] == XML_TAG_TESTCOMMAND):
                    if (len(step[DXTGK_DATA]) > 0):
                        x_step = self.__get_teststep_in_command(step)
                        if x_step is not None:
                            # Add step to list if not already present
                            if x_step[EDTSK_DESC] not in steps_list:
                                steps_list.append(x_step[EDTSK_DESC])
                else:
                    # Do not use this info
                    pass
        
        if len(steps_list) > 0:
            retval=dict()
            retval[DXTCK_TITLE] = case[EDTCK_TITLE]
            retval[DXTCK_LEVEL] = case[EDTCK_LEVEL]
            retval[DXTCK_RESULT] = case[EDTCK_RESULT]
            retval[DXTCK_REASON] = steps_list
        
        return retval
    
    # Return list containing data from cases or subgroups based on verdict
    # Arguments:
    #     group: Extracted group dictionary to get data from
    #     verdict: Type of steps to be included
    #                 None: Include all steps
    #                 KW_VERDICT_FAIL: Include fail steps
    #                 KW_VERDICT_PASS: Include pass steps
    # Return:
    #     List with necessary data    OR
    #     None: If no matching data found
    def __get_group_data_by_verdict(self, group, verdict=None):
        retval = list()
        group_tagnames = [ XML_TAG_TESTGROUP,
                          XML_TAG_TESTUNIT,
                          XML_TAG_TESTCASELIST,
                          XML_TAG_TESTFIXTURE]
        
        for data in group[EDTGK_DATA]:
            # check if it is a test case
            if data[TEST_TAG_TYPE_KEY] == XML_TAG_TESTCASE:
                # Add data from test case to list
                case_data_dict = self.__get_case_data_by_verdict(data,verdict)
                if case_data_dict is not None:
                    retval.append(case_data_dict)
            
            elif any([data[TEST_TAG_TYPE_KEY]==tagname for tagname in group_tagnames]):
                # Add data from nested groups to this group's list
                group_data_list = \
                    self.__get_group_data_by_verdict(data,verdict)
                for case_data in group_data_list:
                    retval.append(case_data)
        
        return retval
    
    # Return list containing data from cases or subgroups based on verdict
    # Arguments:
    #     group: Extracted group dictionary to get data from
    #     verdict: Type of steps to be included
    #                 None: Include all steps
    #                 KW_VERDICT_FAIL: Include fail steps
    #                 KW_VERDICT_PASS: Include pass steps
    # Return:
    #     List with necessary data    OR
    #     None: If no matching data found
    # Assumption: No nested test cycles in the report
    def __get_cycle_data_by_verdict(self, group, verdict=None):
        retval = list()
        group_tagnames = [ XML_TAG_TESTGROUP,
                          XML_TAG_TESTUNIT,
                          XML_TAG_TESTCASELIST,
                          XML_TAG_TESTFIXTURE]
        
        for data in group[EDTGK_DATA]:
            group_data=dict()

            # check if it is a test case
            if (data[TEST_TAG_TYPE_KEY] == XML_TAG_TESTCASE):
                # Add data from test case to list
                case_data_dict = self.__get_case_data_by_verdict(data,verdict)
                if case_data_dict is not None:
                    group_data = case_data_dict
            
            elif any([(data[TEST_TAG_TYPE_KEY]==tagname) for tagname in group_tagnames]):
                # Add data from nested groups to this group's list
                group_data_list = \
                    self.__get_cycle_data_by_verdict(data,verdict)
                
                # Update dictionary if data is available
                if len(group_data_list) > 0:
                    group_data[EDTGK_TITLE] = data[EDTGK_TITLE]
                    group_data[EDTGK_LEVEL] = data[EDTGK_LEVEL]
                    group_data[EDTGK_OVERVIEW] = data[EDTGK_OVERVIEW]
                    group_data[EDTGK_DATA] = group_data_list
                
            # Append to return list if dict is not empty
            if group_data:
                retval.append(group_data)
        return retval
    
    # External API ---------------------------------------
    
    # get list of failed cases with failed steps
    def get_fail_cases(self):
        return self.get_cases_by_verdict(XML_VERDICT_FAIL)

    # get list of error cases with error steps
    def get_error_cases(self):
        return self.get_cases_by_verdict(XML_VERDICT_ERROR)

    # get list of pass cases with failed steps
    def get_pass_cases(self):
        return self.get_cases_by_verdict(XML_VERDICT_PASS)
    
    # get list of all cases with all steps
    def get_all_cases(self):
        return self.get_cases_by_verdict(None)
    
    # get list of cases with all steps based on verdict
    # Arguments:
    #     verdict: Type of steps to be included
    #                 None: Include all steps
    #                 XML_VERDICT_FAIL: Include fail steps
    #                 XML_VERDICT_PASS: Include pass steps
    #                 XML_VERDICT_ERROR: Include error steps
    def get_cases_by_verdict(self,verdict=None):
        retval = list()
        # Include all steps if the verdict requested is invalid
        if verdict not in [XML_VERDICT_FAIL,XML_VERDICT_ERROR,XML_VERDICT_PASS]:
            verdict = None
        check_verdict = verdict
        
        datalist = self.get_test_data()
        group_tagnames = [ XML_TAG_TESTCYCLE,
                          XML_TAG_TESTGROUP,
                          XML_TAG_TESTUNIT,
                          XML_TAG_TESTCASELIST,
                          XML_TAG_TESTFIXTURE ]
        # Get data from group/case and append to return list
        for data in datalist:
            if (data[TEST_TAG_TYPE_KEY] == XML_TAG_TESTCASE):
                steps = self.__get_case_data_by_verdict(data, \
                    verdict=check_verdict)
                if steps is not None:
                    # Add level, name of case here
                    temp = dict()
                    temp[DXTGK_TITLE] = data[EDTCK_TITLE]
                    temp[DXTGK_LEVEL] = data[EDTCK_LEVEL]
                    test_res = data[EDTCK_RESULT]

                    # Add overview here because test case has to be sent 
                    # as a case nested inside a group with the same title
                    test_overview = dict()
                    test_overview[OVEK_TEST_COUNT] = 1
                    test_overview[OVEK_NE_COUNT] = 0
                    test_overview[OVEK_EXE_COUNT] = 1
                    test_overview[OVEK_PASS_COUNT] = 0
                    test_overview[OVEK_FAIL_COUNT] = 0
                    test_overview[OVEK_WARNING_COUNT] = 0
                    test_overview[OVEK_NA_COUNT] = 0

                    if test_res in XML_VERDICT_PASS:
                        test_overview[OVEK_PASS_COUNT] = 1
                    elif test_res in XML_VERDICT_FAIL:
                        test_overview[OVEK_FAIL_COUNT] = 1
                    elif test_res in XML_VERDICT_WARN:
                        test_overview[OVEK_WARNING_COUNT] = 1
                    else:
                        test_overview[OVEK_NA_COUNT] = 1

                    temp[DXTGK_OVERVIEW] = test_overview
                    temp[DXTGK_DATA] = [steps]  # Data must be a list 
                                                  # of dictionaries of one or 
                                                  # more test cases
                    retval.append(temp)

            elif any([data[TEST_TAG_TYPE_KEY]==tagname for tagname in group_tagnames]):
                steps = self.__get_cycle_data_by_verdict(data, \
                    verdict=check_verdict)
                if len(steps) > 0:
                    # Add level, name of case here
                    temp = dict()
                    temp[DXTGK_TITLE] = data[EDTGK_TITLE]
                    temp[DXTGK_LEVEL] = data[EDTGK_LEVEL]
                    temp[DXTGK_OVERVIEW] = data[EDTGK_OVERVIEW]
                    temp[DXTGK_DATA] = steps
                    retval.append(temp)
        
        return retval
    
    # Extract data
    def extract(self):
        retval = None
        if self.report_handler is not None:
            retval = self.report_handler.extract()
        return retval

    # Get test overview from report handler
    def get_test_overview(self):
        retval = None
        if self.report_handler is not None:
            retval = self.report_handler.get_test_overview()
        return retval
    
    # Get test overview from report handler
    def get_test_title(self):
        retval = None
        if self.report_handler is not None:
            retval = self.report_handler.get_test_title()
        return retval

    # Get ECU info from report handler
    def get_ecu_info(self):
        retval = None
        if self.report_handler is not None:
            retval = self.report_handler.get_ecu_info()
        return retval
    
    # Get test data
    def get_test_data(self):
        retval = None
        if self.report_handler is not None:
            retval = self.report_handler.get_test_data()
        return retval

    # Get all extracted data
    def get_extracted_data(self):
        retval = None
        if self.report_handler is not None:
            retval = self.report_handler.get_extracted_data()
        return retval

    # Check if okay to start
    def isOkayToStart(self):
        status = False
        if self.report_handler is not None:
            status = True
        return status

    # Get name of report file
    def get_report_filename(self):
        retval=''
        if self.report_handler is not None:
            retval = self.report_handler.get_report_filename()
        return retval
        
# End of Data extractor -------------------------------------------------------


if __name__=='__main__':
    pass

# End of File -----------------------------------------------------------------
