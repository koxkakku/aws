# -*- coding: utf-8 -*-

'''
Created by: STEPHIG
Date: 20-Apr-2022
Desc: Class handling Excel file for reports
'''

import os
from openpyxl import Workbook
from openpyxl.styles import Alignment
from openpyxl.styles import PatternFill,Border,Side,Font, Color
from openpyxl.worksheet.dimensions import ColumnDimension, DimensionHolder 
from openpyxl.utils import get_column_letter

from Logger import LogHandler

from ReportAnalysis.RHconstants import GFK_Blue_Color
from ReportAnalysis.RHconstants import GFK_Default_width
from ReportAnalysis.RHconstants import GFK_Short_width
from ReportAnalysis.RHconstants import GFK_Max_Width
from ReportAnalysis.RHconstants import GFK_INTERNAL_VALUE
from ReportAnalysis.RHconstants import GFK_INTERNAL_FILLCOLOUR
from ReportAnalysis.RHconstants import GFK_TITLE_TEST_GROUP
from ReportAnalysis.RHconstants import GFK_TITLE_TEST_NAME
from ReportAnalysis.RHconstants import GFK_TITLE_TEST_NUM 
from ReportAnalysis.RHconstants import ETDK_OVERVIEW
from ReportAnalysis.RHconstants import GFK_SHEET_NAME_COMPARISON
from .common import DIR_OUTPUT

DEFAULT_SUMMARY_FILE="ReportSummary.xlsx"
Gray_Color = '00C0C0C0'
# Blue_Color= '0000CCFF'
Blue_Color= '000066CC'
Sr_No_Column_number =1
Failed_Case_Column_number=2
Analysis_Column_number=4
Issue_type_Column_number = 3
Default_width =20
Max_Width=70
Threshold_length_text=30

# ExcelHandler ----------------------------------------------------------------

class ExcelHandler:
    def __init__(self):
        self.logger=LogHandler(__class__.__name__)
        self.output_directory = DIR_OUTPUT
        # Create output directory
        try:
            if not os.path.exists(self.output_directory):
                os.makedirs(self.output_directory)
        except Exception as e:
            # Failed to create directory
            self.output_directory = None
            
        # create a new workbook
        self.workbook = Workbook()
        # current sheet
        self.active_sheet = self.workbook.active
        return
    
    # Change title of sheet
    def change_sheet_title(self,title):
        self.active_sheet.title = title
        return
    
    # Create a new sheet with given title
    def add_sheet(self,title):
        self.workbook.create_sheet(title)
        # self.active_sheet = self.workbook.active
        self.set_active_sheet(title)
        return

    # set given sheet as active sheet
    def set_active_sheet(self,title):
        status = False
        idx = self.get_sheet_index(title)
        if idx is not None:
            # Found sheet
            self.workbook.active = idx
            self.active_sheet = self.workbook.active
            status = True
        return status

    # get index of sheet
    def get_sheet_index(self,title):
        retval = None
        for i,name in enumerate(self.workbook.sheetnames):
            if title == name:
                retval = i
        return retval

    # Write data to cell
    # BUG: Limit length of string added to cell. 
    # If value is too long then it is not shown in Excel file
    def write_cell(self,row,col,value):
        # create cell object
        cell = self.active_sheet.cell(row,col)
        cell.alignment = Alignment(horizontal='left',vertical='top', \
            wrap_text=True)
        cell.value=value 
        top = Side(border_style='thin',color="00000000")
        cell.border = Border(top=top,bottom=top,left=top,right=top)
        return
    
    def set_fillcolor(self,row,col, color): 
        try:
            cell = self.active_sheet.cell(row,col)
            cell.fill = PatternFill(patternType='solid',fgColor=color)
        except Exception as reason:
            self.logger.exception("Exception in set_fillcolor(): %s"%(reason)) 
        return
    
    def set_alignment(self, row, col, VerticalOption='center', \
        HorizontalOption='center'):
        try:
            cell = self.active_sheet.cell(row,col)
            cell.alignment=Alignment( vertical = VerticalOption, \
                horizontal = HorizontalOption, \
                wrap_text=True)
        except Exception as reason:
            self.logger.exception("Exception in set_alignment(): %s"%(reason))            
        return
    
    def set_fontcolor(self,row,col, colorValue="00000000", boldValue=True):
        try:
            cell = self.active_sheet.cell(row,col)
            cell.font  = Font(color=colorValue, bold=boldValue)
        except Exception as reason:
            self.logger.exception("Exception in set_fontcolor(): %s"%(reason))            
        return
    
    def set_color(self,row,col):       
        cell = self.active_sheet.cell(row,col)
        cell.fill = PatternFill(patternType='solid',fgColor=Blue_Color)
        cell.font  = Font(color="00000000", bold=True)
        cell.alignment=Alignment( vertical='center', horizontal= 'center', \
            wrap_text=True)
        return  
 
    def add_table(self,row,col,titles,data):
        # Add title
        for col_offset,title in enumerate(titles):
            self.write_cell(row=row,col=col+col_offset,value=title)
            self.set_color(row=row,col=col+col_offset)
       
        # Start adding data one row at a time
        for row_offset,row_entry in enumerate(data):
            # Write row one cell at a time
            for col_offset,cell in enumerate(row_entry):
                # write cell
                self.write_cell(row=row+1+row_offset,col=col+col_offset, \
                    value=cell)           
            self.table_mod(row=row,col=col+col_offset)        
        return
    
    def draw_boder(self, startRow, rowNo, startColoum, coloumNo):
        try:
            for rowOffset in range(rowNo):
                for coloumOffset in range(coloumNo):
                    row = startRow + rowOffset
                    col = startColoum + coloumOffset
                    cell = self.active_sheet.cell(row,col)
                    top = Side(border_style='thin',color="00000000")
                    cell.border = Border(top=top,bottom=top,left=top,right=top)
        except Exception as reason:
            self.logger.exception("Exception in draw_boder(): %s"%(reason))    
        return

    def table_mod(self,row,col):
        ws= self.active_sheet
        row_number = 0
        mr=ws.max_row
        mc=ws.max_column 
        # To merge cells for TEST GROUP rows
        for row in range(1,mr+1):
            row_number= row_number+1
            for col in range(1, mc+1): 
                if(col == Analysis_Column_number):
                   if((ws.cell(row,col).value == None) and \
                       (ws.cell(row,Failed_Case_Column_number).value != None)):             
                        ws.merge_cells(start_row=row, \
                            start_column=Failed_Case_Column_number, \
                                end_row=row, end_column=mc)
                        for rows in ws.iter_rows(min_row=row_number,\
                            max_row=row_number, 
                            min_col=Sr_No_Column_number, 
                            max_col=Failed_Case_Column_number):
                            for cell in rows:             
                                cell.fill= PatternFill( \
                                    start_color=Gray_Color, 
                                    end_color=Gray_Color,
                                    fill_type = "solid") 
                                cell.font  = Font(color="00000000", bold=True) 
                                
        # To set column_width in worksheets
        for col in range(1, mc+1): 
                text_length=0
                row_number=0
                for rows in ws.iter_rows(min_row=1, max_row=mr, \
                    min_col=col, max_col=col):
                    row_number= row_number+1
                    if(len(str(ws.cell(row_number,col).value)) > text_length):
                      text_length = len(str(ws.cell(row,col).value))            
                if(text_length>Threshold_length_text):
                    self.active_sheet.column_dimensions[ \
                        get_column_letter(col)].width = Max_Width
                else:
                    self.active_sheet.column_dimensions[ \
                        get_column_letter(col)].width = Default_width
        return
    
    def add_comparisonTable(self,row,col,titles,data):
        try:
            # Add title
           
            for col_offset,title in enumerate(titles):
                self.write_cell(row=row,col=col+col_offset,value=title)
                self.set_fillcolor(row=row,col=col+col_offset, \
                    color=GFK_Blue_Color)
                self.set_fontcolor(row=row,col=col+col_offset)
                self.set_coloumWidth(col+col_offset, title)
                if title == GFK_TITLE_TEST_NUM or title == GFK_TITLE_TEST_NAME:
                    self.set_alignment(row=row,col=col+col_offset)
                else:
                    self.set_alignment(row=row, col=col+col_offset, \
                        VerticalOption='top', HorizontalOption='left')
            
            # put test group data in the next row to the title
            #row = row+1
            row1=row
            # Start adding data one row at a time
            for row_offset,row_entry in enumerate(data): 
                # write the test description
                # self.write_cell(row=row+(row_offset*2),col=col, \
                #     value=row_entry[0])
                # for tempOffset in range(len(row_entry[1]) + 1):
                #     self.set_fillcolor(row=row+(row_offset*2),
                #     col=col+tempOffset, color=GFK_Grey_Colour)                          
                
                # put test case data in the next row to the 
                # test group data and next coloum
                row=row1
                row = row+1
                # Write row one cell at a time
                for row_sub_offset,eachVersionData in enumerate(row_entry[1:]):
                    for col_sub_offset,cellValue in enumerate(eachVersionData):
                        # # write the test case details 
                        self.write_cell(row=row+row_sub_offset,\
                            col=col+col_sub_offset, \
                            value=cellValue[GFK_INTERNAL_VALUE]) 
                        self.set_fillcolor(row=row+row_sub_offset, \
                            col=col+col_sub_offset,
                            color=cellValue[GFK_INTERNAL_FILLCOLOUR]) 
                row1=row+row_sub_offset
            return
        except Exception as reason:
            self.logger.exception("Exception in \
                add_comparisonTable(): %s"%(reason))
    
    def add_overviewTable(self,row,col,titles,data):
        try:
            # Add title
            for col_offset,title in enumerate(titles):
                self.write_cell(row=row,col=col+col_offset,value=title)
                self.set_fillcolor(row=row,col=col+col_offset, \
                    color=GFK_Blue_Color)
                self.set_alignment(row=row,col=col+col_offset)
                self.set_fontcolor(row=row,col=col+col_offset)
                self.set_coloumWidth(col+col_offset, title)
            # Start adding data one row at a time
            for row_offset,row_entry in enumerate(data):
                # Write row one cell at a time
                for col_offset,cellValue in enumerate(row_entry):
                    # write cell
                    self.write_cell(row=row+1+row_offset,col=col+col_offset, \
                        value=cellValue[GFK_INTERNAL_VALUE]) 
                    self.set_fillcolor( row=row+1+row_offset, \
                        col=col+col_offset, \
                        color=cellValue[GFK_INTERNAL_FILLCOLOUR] )
        except Exception as reason:
            self.logger.exception("Exception in \
                add_overviewTable(): %s"%(reason))
        
        return
    
    # Assumption: Only one row in contrast data
    def add_contrastTable(self,row,col,titles,data):
        try:
            # Add title
            for col_offset,title in enumerate(titles):
                self.write_cell(row=row,col=col+col_offset,value=title)
                self.set_fillcolor(row=row,col=col+col_offset, \
                    color=GFK_Blue_Color)
                self.set_alignment(row=row,col=col+col_offset)
                self.set_fontcolor(row=row,col=col+col_offset)
                self.set_coloumWidth(col+col_offset, title)
            
            # Write row one cell at a time
            for col_offset,cellValue in enumerate(data):
                # write cell
                self.write_cell(row=row+1,col=col+col_offset, \
                    value=cellValue[GFK_INTERNAL_VALUE]) 
                self.set_fillcolor( row=row+1, \
                    col=col+col_offset, \
                    color=cellValue[GFK_INTERNAL_FILLCOLOUR] )
        except Exception as reason:
            self.logger.exception("Exception while adding table%s"%(reason))
        
        return
    
    def set_coloumWidth(self, col, titleText):
        try:
            if titleText == GFK_TITLE_TEST_NAME:
                self.active_sheet.column_dimensions[ \
                        get_column_letter(col)].width = GFK_Max_Width
                
            elif titleText == GFK_TITLE_TEST_GROUP:
                self.active_sheet.column_dimensions[ \
                        get_column_letter(col)].width = GFK_Max_Width
                
            elif titleText == GFK_TITLE_TEST_NUM:
                self.active_sheet.column_dimensions[ \
                        get_column_letter(col)].width = GFK_Short_width
            else:
                self.active_sheet.column_dimensions[ \
                        get_column_letter(col)].width = GFK_Default_width
        except Exception as reason:
            self.logger.exception("Exception in \
                set_coloumWidth(): %s"%(reason)) 
            
    def generateXL(self):
        try:
            overviewSheet = ETDK_OVERVIEW
            comparisonSheet = GFK_SHEET_NAME_COMPARISON  # B1 vs B2 vs B3
            
            self.change_sheet_title(overviewSheet)
            self.add_sheet(comparisonSheet)
        
        except Exception as reason:
            self.logger.exception("Exception in generateXL(): %s"%(reason))            
            
            
    # Save to file
    def save(self, filename=DEFAULT_SUMMARY_FILE):
        if self.output_directory is not None:
            outfile = "%s/%s"%(self.output_directory,filename)
        else:
            outfile = filename
        # save workbook to file
        try:
            self.workbook.save(outfile)
            self.logger.info("Saved Workbook: %s"%(outfile))
        except Exception as e:
            # failed to save file
            self.logger.exception("Failed to save %s: %s" % (outfile,e))
        return

# End of ExcelHandler ---------------------------------------------------------


if __name__=='__main__':
    pass

# End of File ----------------------------------------------------------------
