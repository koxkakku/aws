# -*- coding: utf-8 -*-

'''
Created by: STEPHIG
Date: 02-Jun-2022
Desc: Get failure analysed data from report and add to excel file.
'''

import os
import json

from Logger import LogHandler

from .ExcelHandler import ExcelHandler
from .ReportAnalysis import AnalyseReport

# Overview dict keys
from .RHconstants import OVEK_PASS_COUNT
from .RHconstants import OVEK_NA_COUNT
from .RHconstants import OVEK_WARNING_COUNT
from .RHconstants import OVEK_FAIL_COUNT
from .RHconstants import OVEK_NE_COUNT
from .RHconstants import OVEK_EXE_COUNT
from .RHconstants import OVEK_INCONCLUSIVE_COUNT

# Basic information Key
from .RHconstants import BIK_ECU_NAME
from .RHconstants import BIK_RELEASE_VERSION
from .RHconstants import BIK_SW_VERSION
# Analysis keys
from .ReportAnalysis import ADK_TITLE
from .ReportAnalysis import ADK_LEVEL
from .ReportAnalysis import ADK_DATA
from .ReportAnalysis import ADK_ANALYSIS
from .ReportAnalysis import ADK_ISSUE_TYPE

from .common import DIR_OUTPUT


OUTPUT_REPORT_FILE = "Report_Analysis.xlsx"

# Overview data
OVERVIEW_SHEET_TITLE="Test Overview"
OVERVIEW_HEADING="Overview"
OVERVIEW_TITLE_ROW=1
OVERVIEW_TITLE_COL=2
OVERVIEW_TABLE_ROW=2
OVERVIEW_TABLE_COL=2

# Failure data
FAILURE_SHEET_TITLE="Failure Analysis"
FAILURE_HEADING_ROW=1
FAILURE_HEADING_COL=1
FAILURE_TABLE_ROW=2
FAILURE_TABLE_COL=1

# Constants for Consolidated Cloud data
CLOUD_DATA_TITLE = "Title"
CLOUD_DATA_OVERVIEW = "Overview"
CLOUD_DATA_SETUP = "Setup"
CLOUD_DATA_TESTDATA = "Data"

# TODO: Decide on a common overview format for all test types.

# Data consolidator -----------------------------------------------------------

class Consolidator:
    def __init__(self, report_file, testtype):
        self.logger=LogHandler(__class__.__name__)
        self.report_analyser = AnalyseReport(report_file=report_file, \
            file_type=testtype)
        self.test_type=testtype
        self.report_gen = ExcelHandler()
        self.ecu_name = None
        return
    
    # get failed cases from report
    # Info needed:
    # - Level
    # - Failed case
    # - Type of issue
    # - Reason for failure (Analysis)
    # Arrange into rows to be added to database
    def get_failed_cases(self):
        titles = ["S.No.", "Failed TestCase", "Issue Type", \
            "Analysis",  "Remarks"]
        failures = list()
        # get fail case analysis data
        fail_data = self.report_analyser.get_analysis()
        
        # arrange all data into a single list
        for test in fail_data:
            try:
                # Get level, title of group before failure data in group
                failures.append( [test[ADK_LEVEL], \
                    test[ADK_TITLE],''] )
                
                for case in test[ADK_DATA]:
                    # get data from case
                    level = case[ADK_LEVEL]
                    title = case[ADK_TITLE]
                    issue_type=case[ADK_ISSUE_TYPE]
                    reasons = '\n'.join(case[ADK_ANALYSIS])
                    remarks=' '
                    # Add to failure list
                    failures.append([level,title,issue_type,reasons,remarks])
            except Exception as e:
                self.logger.exception("Exception while retrieving \
                    failed cases: %s"%e)
        return titles,failures
    
    # Add data from failed cases to excel sheet
    def add_fail_case_data(self):
        sheetname = FAILURE_SHEET_TITLE
        # get failed cases info
        fail_titles,fail_data = self.get_failed_cases()
        # add to excel sheet
        self.report_gen.add_sheet(sheetname)
        
        # Add heading before table
        # Get name of ECU
        ecu_info = self.report_analyser.get_ecu_info()
        ecu_name=self.__get_overview_data(ecu_info,BIK_ECU_NAME)
        # Create string for heading
        heading="Analysis of failed testcases: %s"%(ecu_name)
        # Write heading to cell
        self.report_gen.write_cell(FAILURE_HEADING_ROW,\
            FAILURE_HEADING_COL,heading)
        
        # Add table with data
        self.report_gen.add_table(row=FAILURE_TABLE_ROW,\
            col=FAILURE_TABLE_COL, \
            titles=fail_titles, data=fail_data)
        return

    # Get overview parameter from extracted database
    def __get_overview_data(self,database,key):
        retval="NA"
        try:
            retval=database[key]
        except Exception as e:
            # If not found set string as NA
            retval = "NA"
        return retval

    def add_test_overview(self):
        # Set titles
        self.upload_data = list()

        titles=["ECU","Test cases executed", \
            "Test cases passed","Test cases failed","Test cases skipped", \
            "Test cases warning","Test cases inconclusive","Test cases Unknown/NA"]
        overview = self.report_analyser.get_test_overview()
        ecu_info = self.report_analyser.get_ecu_info()
        
        # Gather data (must be in the same order as titles)
        overview_data = list()
        self.ecu_name=self.__get_overview_data(ecu_info,BIK_ECU_NAME)
        overview_data.append(self.__get_overview_data(ecu_info,BIK_ECU_NAME))
        # overview_data.append(self.__get_overview_data(ecu_info,\
        #     BIK_RELEASE_VERSION))
        overview_data.append(self.__get_overview_data(overview,OVEK_EXE_COUNT))
        overview_data.append(self.__get_overview_data(overview,\
            OVEK_PASS_COUNT))
        overview_data.append(self.__get_overview_data(overview,\
            OVEK_FAIL_COUNT))
        overview_data.append(self.__get_overview_data(overview,OVEK_NE_COUNT))
        overview_data.append(self.__get_overview_data(overview, \
            OVEK_WARNING_COUNT))
        overview_data.append(self.__get_overview_data(overview, \
            OVEK_INCONCLUSIVE_COUNT))
        overview_data.append(self.__get_overview_data(overview, \
            OVEK_NA_COUNT))
        
        # Add to file
        self.report_gen.change_sheet_title(OVERVIEW_SHEET_TITLE)
        # Create string for overview heading
        heading="%s %s"%(self.test_type,OVERVIEW_HEADING)
        # Add heading
        self.report_gen.write_cell(OVERVIEW_TITLE_ROW,\
            OVERVIEW_TITLE_COL,heading)
        # Add overview table
        self.report_gen.add_table(row=OVERVIEW_TABLE_ROW, \
            col=OVERVIEW_TABLE_COL, titles=titles, \
                data=[overview_data])

                
        self.upload_data = overview_data
        self.upload_data.append(self.__get_overview_data(ecu_info,BIK_SW_VERSION))
        self.upload_data.append(self.__get_overview_data(ecu_info,BIK_RELEASE_VERSION))
        
        return

    # send overview data to upload into database
    def get_result_data(self):
        return self.upload_data

    def save(self):
        # set default filename
        filename=OUTPUT_REPORT_FILE
        base_filename=self.report_analyser.get_report_filename()
        if (base_filename is None) or (base_filename == ''):
            if self.ecu_name is not None:
                # create filename with ECU name and test type
                filename="%s_%s_Result_Analysis.xlsx"%(self.test_type, \
                    self.ecu_name)
            else:
                # create filename with test type
                filename="%s_Result_Analysis.xlsx"%(self.test_type)
        else:
            # Keep filename same as the name of report file
            filename="%s_Result_Analysis.xlsx"%(base_filename)

        # Save to file
        self.report_gen.save(filename)
        return

    def get_analyser_status(self):
        return self.status
    
    def consolidate(self):
        self.status = self.report_analyser.analyse()
        # Extract data
        if self.status:
            # add overview info
            self.add_test_overview()
            # add failed cases info
            self.add_fail_case_data()
            # Save to database
            self.save()
        else:
            # Failed to extract and analyse data. Should this be logged?
            pass
        return


# Consolidator for Grafana Cloud

class Consolidator_Cloud:
    def __init__(self, report_file, testtype):
        self.logger=LogHandler(__class__.__name__)
        self.report_analyser = AnalyseReport(report_file=report_file, \
            file_type=testtype)
        self.test_type=testtype
        self.report_gen = ExcelHandler()
        self.ecu_name = None
        self.output_directory = DIR_OUTPUT
        return
    
    # get failed cases from report
    # Info needed:
    # - Level
    # - Failed case
    # - Type of issue
    # - Reason for failure (Analysis)
    # Arrange into rows to be added to database
    def get_failed_cases(self):
        titles = ["S.No.", "Failed TestCase", "Issue Type", \
            "Analysis",  "Remarks"]
        failures = list()
        # get fail case analysis data
        fail_data = self.report_analyser.get_analysis()
        
        # arrange all data into a single list
        for test in fail_data:
            try:
                # Get level, title of group before failure data in group
                failures.append( [test[ADK_LEVEL], \
                    test[ADK_TITLE],''] )
                
                for case in test[ADK_DATA]:
                    # get data from case
                    level = case[ADK_LEVEL]
                    title = case[ADK_TITLE]
                    issue_type=case[ADK_ISSUE_TYPE]
                    reasons = '\n'.join(case[ADK_ANALYSIS])
                    remarks=' '
                    # Add to failure list
                    failures.append([level,title,issue_type,reasons,remarks])
            except Exception as e:
                self.logger.exception("Exception while retrieving \
                    failed cases: %s"%e)
        return titles,failures
    
    # Add data from failed cases to excel sheet
    def add_fail_case_data(self):
        # get failed cases info
        analyzed_data = self.report_analyser.get_analysis()

        return analyzed_data

    # Get overview parameter from extracted database
    def __get_overview_data(self,database,key):
        retval="NA"
        try:
            retval=database[key]
        except Exception as e:
            # If not found set string as NA
            retval = "NA"
        return retval

    def add_test_overview(self):
        # Set titles
        self.upload_data = list()
        overview = self.report_analyser.get_test_overview()
        ecu_info = self.report_analyser.get_ecu_info()
        
        # Gather data (must be in the same order as titles)
        overview_data = list()
        self.ecu_name=self.__get_overview_data(ecu_info,BIK_ECU_NAME)
        overview_data.append(self.__get_overview_data(ecu_info,BIK_ECU_NAME))
        # overview_data.append(self.__get_overview_data(ecu_info,\
        #     BIK_RELEASE_VERSION))
        overview_data.append(self.__get_overview_data(overview,OVEK_EXE_COUNT))
        overview_data.append(self.__get_overview_data(overview,\
            OVEK_PASS_COUNT))
        overview_data.append(self.__get_overview_data(overview,\
            OVEK_FAIL_COUNT))
        overview_data.append(self.__get_overview_data(overview,OVEK_NE_COUNT))
        overview_data.append(self.__get_overview_data(overview, \
            OVEK_WARNING_COUNT))
        overview_data.append(self.__get_overview_data(overview, \
            OVEK_INCONCLUSIVE_COUNT))
        overview_data.append(self.__get_overview_data(overview, \
            OVEK_NA_COUNT))
        
        self.upload_data = overview_data
        self.upload_data.append(self.__get_overview_data(ecu_info,BIK_SW_VERSION))
        self.upload_data.append(self.__get_overview_data(ecu_info,BIK_RELEASE_VERSION))
        return self.upload_data

    # send overview data to upload into database
    def get_result_data(self):
        return self.upload_data

    def save(self,data):
        status = False
        # set default filename
        filename=OUTPUT_REPORT_FILE
        base_filename=self.report_analyser.get_report_filename()
        if (base_filename is None) or (base_filename == ''):
            if self.ecu_name is not None:
                # create filename with ECU name and test type
                filename="%s_%s_Result_Analysis.json"%(self.test_type, \
                    self.ecu_name)
            else:
                # create filename with test type
                filename="%s_Result_Analysis.json"%(self.test_type)
        else:
            # Keep filename same as the name of report file
            filename="%s_Result_Analysis.json"%(base_filename)

        # Create output directory
        try:
            if not os.path.exists(self.output_directory):
                os.makedirs(self.output_directory)
        except Exception as e:
            # Failed to create directory
            self.logger.error("Could not create directory: %s"%(self.output_directory))
            self.output_directory = None
        
        # Add filepath if needed
        if self.output_directory is not None:
            outfile = "%s/%s"%(self.output_directory,filename)
        else:
            outfile = filename
        
        # Save to file
        try:
            self.logger.info("Writing to file: %s"%(outfile))
            with open(outfile,"w") as f:
                f.write(json.dumps(data,indent=4))
                status = True
        except Exception as e:
            self.logger.exception("Exception occurred while writing to file: %s "%(outfile),e)
        return status

    def get_analyser_status(self):
        return self.status
    
    def consolidate(self):
        self.status = self.report_analyser.analyse()
        consolidated = dict()
        # Extract data
        if self.status:
            # add overview info
            # TODO: Identify test type based on title
            title = self.report_analyser.get_test_title()
            overview = self.report_analyser.get_test_overview()
            ecu_info = self.report_analyser.get_ecu_info()
            # add failed cases info
            testdata = self.add_fail_case_data()
            
            # Add to dictionary
            consolidated[CLOUD_DATA_TITLE] = title
            consolidated[CLOUD_DATA_OVERVIEW] = overview
            consolidated[CLOUD_DATA_SETUP] = ecu_info
            consolidated[CLOUD_DATA_TESTDATA] = testdata
            # Save to database
            self.save(consolidated)
        else:
            # Failed to extract and analyse data. Should this be logged?
            pass
        return


# End of data consolidator ----------------------------------------------------


if __name__=='__main__':
    pass

# End of File -----------------------------------------------------------------
