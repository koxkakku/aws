# -*- coding: utf-8 -*-

'''
Created by: STEPHIG
Date: 24-Feb-2022
Desc: API for basic data extraction from XML file.
'''

import os
from Logger import LogHandler
from xml.etree import ElementTree as ET

# Create logger
logger=LogHandler(__name__)

def load(filename):
    retval = False
    root=None
    # check if file exists
    if os.path.exists(filename):
        logger.info("Parsing file: %s"%filename)
        try:
            root = ET.parse(filename).getroot()
            retval = True
        except:
            root = None
            retval = False
    else:
        logger.error("File not found: %s"%filename)
    return retval,root

# Get list of all immediate child tags
def get_all_children(node):
    retval = None
    if node is not None:
        retval = list(node)
    return retval

# Get first next generation node with tag
def get_child_with_tag(node,tag):
    retval = None
    try:
        if node is not None:
            retval = node.find(tag)
    except Exception as e:
        logger.exception("get_child: %s"%e)
    return retval

# Get list of all next generation nodes with tag
def get_children_with_tag(node,tag):
    retval = list()
    try:
        if node is not None:
            retval = node.findall(tag)
    except Exception as e:
        logger.exception("get_children: %s"%e)
    return retval

# Get list of all generation nodes with tag
def get_tags_from_tree(node,tag):
    retval = list()
    try:
        if node is not None:
            retval = node.iter(tag)
    except Exception as e:
        logger.exception("get_tags_from_tree: %s"%e)
    return retval

# return value of attribute
def get_attribute(node,attribute):
    retval = None
    try:
        if node is not None:
            retval = node.get(attribute)
    except Exception as e:
        logger.exception("get_attribute: %s"%e)
    return retval

# get value of text from node
def get_text(node):
    retval = ''
    try:
        if node is not None:
            retval = node.text
    except Exception as e:
        logger.exception("get_text: %s"%e)
    return retval

# get name of tag
def get_tagname(node):
    retval=''
    try:
        if node is not None:
            retval = node.tag
    except Exception as e:
        logger.exception("get_tagname: %s"%e)
    return retval

# get text from node
def get_text_from_tag(node,tag):
    retval = ''
    try:
        if node is not None:
            retval = get_text(get_child_with_tag(node, tag))
    except Exception as e:
        logger.exception("get_text_from_tag: %s"%e)
    return retval

# get attribute from node
def get_attribute_from_tag(node,tag,attribute):
    retval = ''
    try:
        if node is not None:
            retval = get_attribute(get_child_with_tag(node, tag), 
                                            attribute)
    except Exception as e:
        logger.exception("get_attribute_from_tag: %s"%e)
    return retval


if __name__=='__main__':
    pass

# End of File ----------------------------------------------------------------
