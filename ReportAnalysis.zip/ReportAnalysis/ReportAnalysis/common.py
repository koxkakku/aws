# -*- coding: utf-8 -*-

'''
Created by: STEPHIG
Date: 20-Apr-2022
Desc: Common defintions shared by multiple files.
'''

# Directories
DIR_LOGS="Logs"
DIR_OUTPUT="Output"
DIR_REFERENCE="Reference"

# Test type Reference parameters
TTRK_CLASS="Class"

# ECU Test types
ECU_TEST_TYPE_NEST="NEST"
ECU_TEST_TYPE_NEST_SE="NEST_SE"
ECU_TEST_TYPE_NTS="NTS"
ECU_TEST_TYPE_DIVA="DIVA"
ECU_TEST_TYPE_DIAG="GWD"
ECU_TEST_TYPE_TLS="TLS"

# List of test types
VALID_TEST_TYPES = [ \
    ECU_TEST_TYPE_NTS,
    ECU_TEST_TYPE_DIAG,
    ECU_TEST_TYPE_DIVA,
    ECU_TEST_TYPE_NEST,
    ECU_TEST_TYPE_NEST_SE,
    ECU_TEST_TYPE_TLS
    ]

# String of options
TEST_TYPE_STRING=" | ".join(VALID_TEST_TYPES)

# End of file -----------------------------------------------------------------
