# Version information for Report Analysis Tool

class VERSION:
    major=1
    minor=1
    revision=0
    patch=3
    version='.'.join(str(data) for data in [major,minor,revision,patch])

# End of file -----------------------------------------------------------------
