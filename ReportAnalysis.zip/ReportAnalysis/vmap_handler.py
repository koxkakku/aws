# coding: utf-8
"""
Created on 16-Nov-2022
@author: STEPHIG
Desc:
    - Decide if a symbol mapping file is needed based on the number of DLL 
      files in search directory.
    - Choose appropriate vmap file from the following sources:
        - Default file
        - Uploaded by user in UI
        - Delivered in the package
    - Save the vmap file to destination folder.
Usage:
    python vmap_handler.py -j JOB_ID -s search_directory -d destination
Example:
    python vmap_handler.py  -j 18_08_2022_05_12_15 -s NEST\Database -d NEST\Database
"""

# Imports ---------------------------------------------------------------------
# Log handler
from Logger import LogHandler

import os
import argparse
from shutil import move

# Common Cloud functions
from web_ui import URL_BASE
from web_ui import generate_token
from web_ui import load_user_inputs

# common functions
from common import download_file


# Exit codes
from exit_handler import VHE_PROCESS_ERROR
from exit_handler import VHE_DOWNLOAD_FAILED
from exit_handler import VHE_INVALID_INPUT
from exit_handler import VHE_UNDEFINED_INPUT
from exit_handler import VHE_NO_DLL
from exit_handler import VHE_FILE_NOT_FOUND
from exit_handler import VHE_INVALID_DLL
from exit_handler import VHE_UNKNOWN_ERROR
from exit_handler import sys_exit

# Constants -------------------------------------------------------------------

# Standard name of vmap file
STD_FILENAME_VMAP="test_sym_map.vmap"

# Default VMAP file location
DEFAULT_VMAP_FILE="Reference\\Default_SymMap.vmap"

# Alternate names for ECUs.
# Some ECUs are delivered with different DLL names which cannot be used 
# directly in the vmap file. 
# This table lists alternate names for such DLLs.
VMAP_ALT_ECU_NAMES={
    "AAL_A_540_902_11_00_SW224300":"CLT_XX",
    "EVE_12_LIBB_BAT14":"BAT14"
}

# User input json keys
UIK_DOWNLOAD_INFO="DownloadInfo"

# User input: No data
UI_NO_DATA="none"

# Keys for common test data
UI_VMAP_KEY="vmap"

# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

# VMAP Handler exit error code
vhe_exit_error=VHE_UNKNOWN_ERROR

# Functions -------------------------------------------------------------------

# Update ECU, vHSM names in default VMAP file and save to destination directory
def update_default_vmap(vecu,vhsm,dest):
    status=False
    logger.info("Updating default VMAP file.")
    
    # Get file paths
    filepath=os.path.join(os.getcwd(),DEFAULT_VMAP_FILE)
    newfile=os.path.join(dest,STD_FILENAME_VMAP)
    logger.debug("Default VMAP file: %s"%(filepath))
    logger.debug("VMAP file to be updated: %s"%(newfile))
    logger.debug("Substitutions: vECU: %s;\t vHSM: %s"%(vecu,vhsm))
    
    # Check if file exists
    if os.path.isfile(filepath):
        try:
            data=None
            # Read default file
            with open(filepath, 'r') as file:
                data = file.read()
                # Replace the texts
                data = data.replace("v_ECU", vecu)
                data = data.replace("v_HSM", vhsm)
            
            # Create VMAP file
            with open(newfile, 'w+') as file:
                file.write(data)
            
            logger.debug("Updated VMAP file.")
            status=True
        except Exception as e:
            status=False
            logger.exception("Failed to update default VMAP: %s"%(e))
    else:
        logger.error("Could not find default VMAP file.")
    return status

# Update default VMAP file and copy to directory.
# Uses DLL names to update default VMAP file.
# NOTE: Uses a lookup table for certain ECU that use alternate DLL names.
# Assumption: There will be no more than 2 DLL files.
def handle_vmap_default(dir_src,dest):
    status=False
    logger.info("Use default symbol mapping file.")
    
    # Get names of ECU and vHSM from DLL file names
    target_ecu=None
    target_vHSM=None

    global vhe_exit_error
    # Get list of DLL files
    dll_files=get_dll_files(dir_src)
    if len(dll_files)>0:
        # Get ECU and vHSM substitutions from file names
        for name in dll_files:
            if "vhsm" in name.lower():
                # Filename with extension
                bname=os.path.basename(name)
                # Get filename without extension
                target_vHSM=os.path.splitext(bname)[0]
                break
        
        for name in dll_files:
            if target_vHSM != name:
                # Filename with extension
                bname=os.path.basename(name)
                # Get filename without extension
                ecuname=os.path.splitext(bname)[0]
                # Use alternate name if needed
                if ecuname in VMAP_ALT_ECU_NAMES.keys():
                    ecuname=VMAP_ALT_ECU_NAMES[ecuname]
                target_ecu=ecuname
                break
        
        # Proceed to update file
        if (target_vHSM is not None) \
            and (target_ecu is not None):
            if update_default_vmap(target_ecu,target_vHSM,dest):
                status=True
            else:
                # Update error code
                vhe_exit_error=VHE_PROCESS_ERROR
                logger.info("Failed to update default VMAP file")
        else:
            status=False
            # Update error code
            vhe_exit_error=VHE_INVALID_DLL
            logger.error("Invalid DLL filenames: %s"%(str(dll_files)))
    else:
        # No DLL files found
        # Update error code
        vhe_exit_error=VHE_NO_DLL
    return status

# Download vmap file uploaded by user from cloud 
def handle_vmap_cloud(jobid,filename,dest):
    status=False
    logger.info("Download VMAP file from cloud.")
    global vhe_exit_error
    
    # generate new token
    token=generate_token()
    if token is not None:
        # URL to download file
        url="%s/%s/%s" % (URL_BASE,jobid,filename)
        file=os.path.join(dest,filename)
        
        # Download the file
        if download_file(token,url,file):
            # Rename to standard name
            status = update_vmap(srcdir=dest,destdir=dest,filename=filename)
        else:
            # Failed to download file
            # Update error code
            vhe_exit_error=VHE_DOWNLOAD_FAILED
            
            status=False
            logger.error("Failed to download symbol mapping \
                file from cloud.")
    else:
        vhe_exit_error=VHE_PROCESS_ERROR
        logger.error("Could not generate token")
    return status

# Search local directory for VMAP file that was delivered as part 
# of the delivered package.
# Arg:
#   dir_search: Directory to search for vmap files
#   dest: Directory to copy standard vmap file
def handle_vmap_search(dir_search,dest):
    status=False
    logger.info("Searching VMAP file in %s" % dir_search)
    ext_files=list()
    if os.path.exists(dir_search):
        # Get list of files with extension
        for path, subdirs, files in os.walk(dir_search):
            for file in files:
                if file.endswith(".vmap"):
                    ext_files.append(os.path.join(path, file))
        # Log list of files
        logger.debug("List of vmap files: %s"%str(ext_files))

        # Copy to destination folder
        if len(ext_files)>0:
            file_basename=os.path.basename(ext_files[0])
            status=update_vmap(srcdir=dir_search, \
                destdir=dest,filename=file_basename)
        else:
            global vhe_exit_error
            vhe_exit_error=VHE_FILE_NOT_FOUND
            logger.error("Could not find vmap file.")
    else:
        logger.error("Did not find search directory: %s" % dir_search)

    return status

# Download symbol mapping file
def download_vmap_file(jobid,dest,user_input,dir_search):
    status=False
    logger.debug("Get symbol mapping file.")
    # Get list of files to download
    if UI_VMAP_KEY in user_input[UIK_DOWNLOAD_INFO].keys():
        vmap_data=user_input[UIK_DOWNLOAD_INFO][UI_VMAP_KEY]
        if vmap_data["default"].lower() == "true":
            # Use default symbol mapping file.
            status=handle_vmap_default(dir_search,dest)
        else:
            # Get name of symbol mapping file mentioned in user input file
            item=vmap_data["filename"]
            if item.lower() != UI_NO_DATA:
                # Download user uploaded file
                status=handle_vmap_cloud(jobid,item,dest)
            else:
                # Search VMAP file in local directory
                logger.info("VMAP file marked as None in user input.")
                status=handle_vmap_search(dir_search,dest)
    else:
        # VMAP data key not found
        # Update error code
        global vhe_exit_error
        vhe_exit_error=VHE_UNDEFINED_INPUT
        
        status=False
        logger.info("No symbol mapping section in user input file.")
    return status

# Update vmap file to standard name and move to destination directory
# Args:
#   srcdir: Current Location of VMAP file
#   destdir: Destination directory where VMAP file is to be placed
#   filename: Base Name of VMAP file to be updated.
def update_vmap(srcdir,destdir,filename):
    status=False
    try:
        # Get full filenames with path
        srcfile=os.path.join(srcdir,filename)
        stdfile=os.path.join(destdir,STD_FILENAME_VMAP)
        
        # Update the filename
        # os.rename(srcfile,stdfile)
        move(srcfile,stdfile)
        logger.info("VMAP file renamed: (%s) to (%s)" % (srcfile,stdfile))
        status=True
    except Exception as e:
        # Failed to rename file
        global vhe_exit_error
        vhe_exit_error=VHE_PROCESS_ERROR
        logger.error("Exception while renaming file:%s"%e)
    return status

# Get list of DLL files from directory
# Args: Directory to search for files
# Return: List of DLL files
def get_dll_files(dir_src):
    dll_files=list()
    # Check if directory is valid
    if os.path.exists(dir_src):
        # Get list of files with extension DLL
        logger.info("Searching dll files")
        for path, subdirs, files in os.walk(dir_src):
            for file in files:
                if file.endswith(".dll"):
                    dll_files.append(os.path.join(path, file))
        # Log list of dll files
        logger.debug("DLL files: %s"%str(dll_files))
    else:
        # Invalid directory
        logger.error("Path not found: %s"%(dir_src))
    return dll_files

# Is there a need for symbol mapping file
# Search directory for vHSM, vECU DLL files to decide.
# Arguments: 
#   dir_src: Directory to search for DLL files
# Return:
#   Boolean:
#       True: VMAP file is needed
#       False: VMAP file is not needed
def check_need_for_vmap(dir_src):
    status=False
    logger.info("Check need for VMAP file")
    # Get DLL files in directory
    dll_files=get_dll_files(dir_src)
    # Check if directory is valid
    if len(dll_files) > 0:
        # Get list of files with extension DLL
        
        # Search list of filenames for vHSM, vECU files
        count_vhsm = 0
        for name in dll_files:
            if "vhsm" in name.lower():
                count_vhsm +=1
        
        if (len(dll_files)>=2) \
            and (count_vhsm>0):
            status=True
            logger.info("VMAP file is required.")
    else:
        # Update error code
        global vhe_exit_error
        vhe_exit_error=VHE_NO_DLL
        logger.error("No DLL files found in Source directory: %s"%dir_src)
        logger.info("Failed to validate the need for VMAP file.")
    return status

# Handle Symbol mapping file
# Decide if vmap file is needed
# Select default or user shared vmap file 
def vmap_handler(jobid,dir_search,dest="."):
    status=False
    logger.info("Symbol mapping file handler")
    
    global vhe_exit_error
    # Check if vmap file is required
    if check_need_for_vmap(dir_search):
        # Create destination directory if it does not exist
        if not os.path.exists(dest):
            logger.info("Creating directory: %s" % dest)
            os.makedirs(dest)

        # Load user input JSON file
        user_input=load_user_inputs(jobid,dest)
        if user_input is not None:
            # Download VMAP file
            status=download_vmap_file(jobid, \
                dest,user_input,dir_search)
        else:
            vhe_exit_error=VHE_INVALID_INPUT
            logger.error("Failed to load JSON file")
    else:
        status=True
        logger.debug("VMAP file is not needed.")
    return status

# Command line interface handler
def cli_handler():
    parser = argparse.ArgumentParser()
    rargs=parser.add_argument_group("Required arguments")
    # Job ID: To download user input file
    rargs.add_argument("-j","--job",
        metavar="jobID",
        help="Job ID for test",
        type=str,
        required=True,
        default=None)
    
    # Search directory to look for DLL files to decide the need for vmap file
    rargs.add_argument("-s","--search", \
        help="Directory to search DLL files.",
        required=True,
        default=".")

    # Destination directory to store symbol mapping file
    rargs.add_argument("-d","--dest", \
        help="Directory to save file.",
        required=True,
        default=".")
    
    # Parse arguments
    args = parser.parse_args()
    return args.job, args.search, args.dest

# Get input JSON file; Download files uploaded by user for test type
def main():
    jobid,dir_search,dir_dest=cli_handler()
    # Check type of action
    if vmap_handler(jobid,dir_search,dir_dest):
        logger.info("VMAP Handling complete!!!")
    else:
        logger.error("Failed to setup vmap file!!!")
        sys_exit(vhe_exit_error)
    return

# Handle if executed as main script
if __name__ == "__main__":
    logger.info("-"*80)
    main()
    logger.info("-"*80)

# End of File -----------------------------------------------------------------
