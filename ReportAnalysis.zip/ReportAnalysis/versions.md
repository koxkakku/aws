1.0.0: Initial version
    - Data extraction for NEST, NTS report
    - Data consolidation for NEST, NTS: Create excel file with failed cases 
      and test overview.

1.0.1: Data Extractor API
    - DataExtractor API which will be common for all report types.

1.0.2: Report comparison API
    - API to compare multiple test report.

1.0.3: 
    - Command line interface to execute comparison or analysis.
    - Report analysis using lookup table to summarize failure statements (NTS only).

1.0.4: 
    - Added data extraction for TLS report.

1.0.5:
    - Added option to upload results to online database.
    - New features to support operation of jenkins pipeline.

1.0.6:
    - Removed network type as an argument for report analysis.
    - Created a single lookup table for each test type irrespective of the type of network.

1.0.7:
    - Removed main.py. analysis and comparison can be handled directly through analyse.py and compare.py.
    - Updated user manual.
    - Added script to download files from JFrog artifactory.

1.1.0.0: Cloud specific update
    - Removed generation of Excel sheet
    - Updated code to generate only JSON file with all test cases (pass,fail,warning)
    - Added an overview to each test group giving a status count of test cases within that group
    - JSON updated to include nested groups
    - Updated version format "major.minor.revision.patch"

1.1.0.1:
    - Restructured reference JSON files to have a list of error messages irrespective of test groups.
