import os
import sys
import json
import logging
import argparse

from pathlib import Path
from requests import get

logger = logging.getLogger(__name__)

class PipelineWriter:

    @staticmethod
    def parent_job_template():
        parent_job_template = """
stages:
  - GenerateSimulations
.basic:
  allow_failure: false
"""
        return parent_job_template

    @staticmethod
    def child_pipeline_job_template(ecu, test_type):
        child_pipeline_job_template = f"""

generate-simulation-for-{ecu['diagnostic_name']}-{test_type}-trigger-job: 
  stage: GenerateSimulations
  variables: 
    NCD_RELEASE: {ecu['ncd_release']}
    VEHICLE_LINE: {ecu['vehicle_line']}
    VECU_LEVEL: {ecu['vecu_level']}
    ECU_NAME: {ecu['diagnostic_name']}
  trigger:
    include: {test_type}/{test_type}.gitlab-ci.yml
    strategy: depend
    forward:
      pipeline_variables: true
"""
        return child_pipeline_job_template

class PipelineGenerator:

    def __init__(self):
        
        self.ECUS = []
        self.TEST_TYPES = []
        self.TESTRUN_ID = os.getenv('TESTRUN_ID')
        self.SIMULATION_RUNTIME_BACKEND_KEY = os.getenv('SIMULATION_RUNTIME_BACKEND_KEY')
        self.SIMULATION_RUNTIME_BACKEND_URL = os.getenv('SIMULATION_RUNTIME_BACKEND_URL')
        self.child_pipeline_name = "child-pipeline-gitlab-ci.yml"
    
    def parsing_user_json(self):
        api_call = f"{self.SIMULATION_RUNTIME_BACKEND_URL}/simulation/{self.TESTRUN_ID}"
        response = get(api_call, headers={"Authorization": self.SIMULATION_RUNTIME_BACKEND_KEY})
        logger.debug(f"{response}: {response.content}")

        user_json = json.loads(response.content)["data"]
        logger.debug(f"Json input loaded: {json.dumps(user_json, indent=4)}")

        common_data = user_json['common_data']

        if "brop" in user_json:
            logger.debug("Brop entry present, parsing ecus to  self.ECUS")
            for ecu in common_data['ecu']:  
                logger.debug(f"Adding ECU {ecu['diagnostic_name']} to Brop list")
                self.ECUS.append(ecu)
                
            brop_data = user_json['brop']
            test_data = brop_data['test_data'] 

            for key in test_data.keys():
                if test_data[key] is None:
                    continue
                    
                self.TEST_TYPES.append(key)
                logger.debug(f"Appending {key} to TEST_TYPES")
        

    def generate_child_pipelines(self):
        try:
            logger.debug("Generating child pipelines for testrun %s", self.TESTRUN_ID)
            with open(self.child_pipeline_name, 'w+') as f:
                f.write(PipelineWriter.parent_job_template())
                for ecu in self.ECUS:
                    for test_type in self.TEST_TYPES:
                        f.write(PipelineWriter.child_pipeline_job_template(ecu, test_type))

            logger.debug("Created child pipelines: %s",Path(self.child_pipeline_name).read_text())
        
        except Exception as e:
            print(f"Something went wrong in generateChildPipelines! Error: {e}")
            sys.exit(f"Something went wrong in generateChildPipelines! Error: {e}")


def parse_args():
    parser=argparse.ArgumentParser(description="Pipeline Generator from User Json")
    
    # global arguments
    parser.add_argument('-v', '--verbose', type=str, help='verbose level INFO|DEBUG|ERROR',default= "INFO")

    args=parser.parse_args()
    
    return args      

def main():
    args = parse_args()

    if args.verbose == "DEBUG":
        loglevel = logging.DEBUG
    elif args.verbose == "ERROR":
        loglevel = logging.ERROR
    else:
        loglevel = logging.INFO

    logging.basicConfig(level=loglevel, format='%(levelname)s: %(message)s')

    try:
        logger.debug("the args are:")
        for arg in vars(args):
            logger.debug(f"{arg} is {getattr(args, arg)}")

        generator = PipelineGenerator()
        generator.parsing_user_json()
        generator.generate_child_pipelines()

        logger.debug("Generation Done")

    except Exception as e:
        print(f"Something went wrong in main! Error: {e}")
        sys.exit(f"Something went wrong in main! Error: {e}")


if __name__ == "__main__":
    main()
