"""
Created by: SYARAGA
Date: 25-04-2023
Desc: Strings defined for the dynamic_yaml generation file
 
"""

# Output file
OUTPUT_FILE = 'venvironment.yaml'

# Constant for ethernet yaml file
MAIN = 'MAIN'

#Extensions for files
EXT_ARXML = '.arxml'
EXT_VSYSVAR = '.vsysvar'
EXT_VMODULE = '.vmodule'
EXT_SIL = '.sil'
EXT_DLL = '.dll'
EXT_YAML = '.yaml'
EXT_VMAP = '.vmap'

# Folder database
FOLDER_DATABASE = 'Database'

#Sil kit node
SIL_KIT = 'silkit'

#Main nodes of YAML file
NODE_VERSION = 'version'
NODE_VERSION_DATA = '2.2.0'
NODE_DATABASES = 'databases'
NODE_SYSTEM_VARIABLES = 'system-variables'
NODE_CANFD_NETWORKS = 'canfd-networks'
NODE_ETHERNET_NETWORKS = 'ethernet-networks'
NODE_SIMULATION_NODE = 'simulation-nodes'
NODE_SYMBOL_MAPPING = 'symbol-mappings'
NODE_SECURITY = 'security'

#Symbol Mapping node properties
NODE_SYMBOL_MAP_FILE_PATH = 'file-path'

#Database node property name
DB_NODE_PROP_NAME = 'name'
DB_NODE_PROP_FILE_PATH = 'file-path'
DB_NODE_PROP_NETWORK_NAME = 'network-name'

#System variables property
SYS_VAR_NODE_PROP_FILE_PATH = 'file-path'

# Simulation nodes Constants
SIM_NODE_PROP_NAME = 'name'
SIM_NODE_PROP_FILE_PATH = 'file-path'
SIM_NODE_PROP_NETWORK = 'network'
SIM_NODE_PROP_MODELLING_LIBRARIES = 'modeling-libraries'
SIM_NODE_PROP_NETWORK_ASSIGNMENTS = 'network-assignments'
SIM_NODE_PROP_TCP_IP_STACK = 'tcp-ip-stack'
SIM_NODE_PROP_SELECTED_STACK = 'selected-stack'
SIM_NODE_PROP_NODE = 'node'
SIM_NODE_PROP_DATABASE_NODE = 'database-node'
SIM_NODE_PROP_DATABASE = 'database'
SIM_NODE_PROP_INDIVIDUAL = 'individual'
SIM_NODE_VECTOR_SIMULATION_NODE = 'VectorSimulationNode'
SIM_NODE_VIRTUAL_TARGET = 'VirtualTarget'
SIM_NODE_ETH_SIMULATION_NODE = 'VectorSimulationNode'
SIM_NODE_VMODULE_CANFD_SECMGR = 'SecMgrCANoeClient.vmodule'
SIM_NODE_VMODULE_CANFD_ASRPDUIL = 'AsrPDUIL.vmodule'
SIM_NODE_VMODULE_CANFD_ASRPDUIL2 = 'AsrPDUIL2.vmodule'

# Network node properties
NW_NODE_PROP_MODE = 'mode'
NW_NODE_PROP_NAME = 'name'
NW_NODE_PROP_DATABASE ='database'
NW_NODE_PROP_APP_CHANNEL = 'application-channel'
NW_NODE_PROP_ARBITRATION_BAUDRATE = 'arbitration-baudrate'
NW_NODE_PROP_DATA_BAUDRATE = 'data-baudrate'
NW_NODE_PROP_MAPPING = 'mapping'
NW_NODE_PROP_ISO = 'iso'
NW_NODE_PROP_MAPPING_INTERNAL = 'internal-simulator'

# Global setting nodes
NODE_GLOBAL_SETTINGS = 'global-settings'
GS_TIME_SOURCE = 'time-source'
GS_TIME_SCALING_FACTOR = 'time-scaling-factor'
GS_EXTERNAL_SOFTWARE = 'external-software'
GS_AS_FAST_AS_POSSIBLE = 'as-fast-as-possible'

# Sil Kit nodes
NODE_SL_KIT = 'sil-kit'
SK_PARTICIPANT_NAME = 'participant-name'
SK_CONFIG_FILE_PATH = 'config-file-path'
SK_SIMULATION_STEP_IN_MICRO_SEC = 'simulation-step-in-micro-sec'
SK_SIMULATION_STEP_100_MICRO_SEC = 100

# Logging node properties
LOG_NODE_LOGGING = 'logging'
LOG_NODE_FILE_NAME = 'file-name'
LOG_NODE_TEST_LOGGING_BLF = 'log.blf'

# User input parametres
VTT = 'VTT'
SILVER = 'SILVER'
CAN = 'CAN'
ETHERNET = 'ETH'
VECU_TYPE = 'vECU_type'

# Folder strings
DATABASE = 'Database'
SUT = 'Database'
SYSVAR = 'Sys_Var'
LIN = 'LIN'

# Parser data elements
PD_NAME = 'name'
PD_PARENT_NW ='parent_nw'
PD_ECU_ARXML = 'ecu_arxml'
PD_VECU_TYPE = 'vECU_type'
PD_TEST_TYPE = 'test_type'
PD_BAUD = 'baud'
PD_FDBAUD = 'fdbaud'
PD_VSYSVAR_FILES = 'vsysvar_files'
PD_VMODULE_FILES = 'vmodule_files'

# INI constants
# Sections
INI_SECTION_DB = "DATABASE"
INI_SECTION_CONFIG = "CONFIGURATION"
INI_SECTION_DLL = "ECU_VTT_FILES"
INI_SECTION_ADAPTIVE = "ADAPTIVE_PARAMETERS"
# DB Keys
INI_KEY_DB_ARXML='ECU_EXTRACT'
INI_KEY_DB_ODX='ODX_FILE'
# Config Keys
INI_KEY_CONFIG_ECU_KIND = "ECU_KIND"
INI_KEY_CONFIG_ECU_TYPE='ECU_TYPE'
INI_KEY_CONFIG_NW='NW_UNDER_TEST'
INI_KEY_CONFIG_DIAG='DIAG_CHANNEL'
INI_KEY_CONFIG_ROE='ROE_PDU'
INI_KEY_CONFIG_VARIANT='VARIANT'
INI_KEY_CONFIG_TICK_CYCLE='TICKCOUNT_CYCLE_TIME'
INI_KEY_CONFIG_FIREWALL='DIAG_FIREWALL'
INI_KEY_CONFIG_DIAG_RQ_ID='DIAG_RQ_ID'
INI_KEY_CONFIG_DIAG_RS_ID='DIAG_RS_ID'
# VTT keys
INI_KEY_VTT_ECU='ECU_FILE'
INI_KEY_VTT_HSM='HSM_FILE'
INI_KEY_VTT_SYSVAR = "SYSVAR"
# Adaptive parameter Keys
INI_KEY_ADAPTIVE_ECU_TYPE = "AP_FLAG"
INI_KEY_ADAPTIVE_USE_CALLOUT = "SCRIPT_FLAG"

# INI filename
NEST_INI_FILE = "NEST_input.ini"
# NEST file Directories
# DIR_ECU_NEST = "SUT"
DIR_ECU_NEST = "Database"
DIR_SYSVAR_NEST = "Sys_Var"

#json parser constants
JSP_COMMON_DATA = "common_data"
JSP_ECU = "ecu"
JSP_NAME = "name"
JSP_BROP = "brop"
JSP_TEST_DATA = "test_data"
JSP_SECURITY_COMPOUND = "security_compound"
JSP_NETWORKS = "networks"
JSP_TYPE = "type"
JSP_ECU_EXTRACT = "ecu_extract"
JSP_NEST = "nest"
JSP_TO_TEST = "to_test"
JSP_NCD = "ncd"
JSP_TO_ODXD = "odxd"
JSP_VARIANT = "variant"

#security node constants
SEC_NETWORK_PROFILE_ASSIGNMENTS = 'network-profile-assignments'
SEC_NETWORK = 'network'
SEC_PROFILE_ID = 'profile-id'
SECUIRTY_VALUE = 1876966221
