To generate the YAML files, run generate_tls_yaml.py file, the usage is as below

usage: generate_tls_yaml.py [-h] -u UI_JSON

Generate the yaml file

options:
  -h, --help            show this help message and exit
  -u UI_JSON, --ui_json UI_JSON
                        path to the sample brop_ui_json file

To generate the vtestunit YAML files, run generate_vtestunit_yaml.py file, the usage is as below

usage: generate_vtestunit_yaml.py [-h] -i NEST_INI

Generate the *.vtestunit.yaml file

options:
  -h, --help            show this help message and exit
  -i NEST_INI, --nest_ini NEST_INI
                        path to the sample nest_input.ini file

******************************************************************************
Folder Structure:
database : arxml, odx, cdd
SUT : dll(vecu,vhsm), sil, vmodule(vecu,vhsm)
CAPL : cin, can 
sysvar: vsysvar Files, vmap files
silkit registry : yaml file
******************************************************************************

NOTE :
1. sample_ui.json file is used here for reference and not finalised one.
2. venvironment.yaml file is the generated yaml file from the scripts, just kept as an example. 
3. NEST.vtestunit.yaml file is the generated vtestunit yaml file from the scripts, just kept as an example. 

INFO:
1. constants.py: has constants defined for all the strings
2. generate_tls_yaml.py : makes use of the API's from the YAML_Handler.py and adds the properties and generates aml file(takes sample_ui.json file as input)
3. get_node_api.py : Gets API for all the properties being added to the final yaml, either from json parser or INI parser
4. INI_parser.py : API to extract data from INI file
5. Json_parser.py : API to extract data from the json file
6. YAML_Handler.py : API to add nodes to the yaml file
7. generate_vtestunit_yaml.py : API to generate the vtestunit yaml file using nest_ini as an input