"""
Created by: SYARAGA
Date: 06-09-2023
Desc: API to decide whether to take inputs from sample_ui.json or from nest_sample.ini file

Input : sample_ui.json file
Output : Api from respective parser (Ini_parser and json_parser)

"""

# Import section

# json parser
from json_parser import UI_Json_Parser

# ini parser
from INI_parser import INI_Parser

# INI file path constant
from constants import NEST_INI_FILE

from constants import JSP_NEST

"""
Class Config_Input
input: ui_json
output: methods to get info from respective parser files
"""
class Config_Input:

    obj = None

    def __init__(self,ui_json):
        self.ui_json = ui_json
        return

    # decide the type of test from ui_json
    def decide_test_type(self):
        if self.obj is None:
            obj_for_test_type = UI_Json_Parser(self.ui_json)
            test_type = obj_for_test_type.get_test_type()
            if test_type.lower() == JSP_NEST:
                obj = INI_Parser(filename=NEST_INI_FILE)
            else:
                obj = UI_Json_Parser(self.ui_json)
            self.obj = obj
        return self.obj
    
    def get_test_type(self):
        test_type = None
        obj_test_type = UI_Json_Parser(self.ui_json)
        test_type = obj_test_type.get_test_type()
        return test_type
    
    def get_ecu_arxml(self):
        obj = self.decide_test_type()
        return obj.get_ecu_arxml()
    
    def get_ecu_type(self):
        obj = self.decide_test_type()
        return obj.get_ecu_type()
    
    def get_nw_name(self):
        obj = self.decide_test_type()
        return obj.get_nw_name()
    
    def get_vmodule(self):
        obj = self.decide_test_type()
        return obj.get_vmodule_file()
    
    def get_sysvar(self):
        obj = self.decide_test_type()
        return obj.get_vsysvar_file()
    
if __name__ == "__main__":
    print("-"*80)
    obj = Config_Input('sample_ui.json')
    print(obj.get_ecu_arxml())
    print("-"*80)
