'''
Author: STEPHIG
Desc: Extract necessary data from ARXML files
- Get baudrates for all networks from ECU extract
- Read Identifiers of Diagnostic frames (CAN, LIN)
- Extract NM PDU ID
- Extract ECU STAT ID

'''

# Imports ---------------------------------------------------------------------
import json
import os
from pathlib import Path

from . import ARXMLHandler as xmlh
from Logger import LogHandler

# Variables -------------------------------------------------------------------
# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

# Constants -------------------------------------------------------------------
# Flag to comtrol writing data to file
# False: Do not write to JSON file
# True: Write to JSON file
ENABLE_FILE_DUMP = True

# Namespace definition
NAMESPACE_KEY="AUTOSAR"
NAMESPACE={NAMESPACE_KEY:"http://autosar.org/schema/r4.0"}

# Common XML Tag names
XMLTN_AR_PKGS="AR-PACKAGES"
XMLTN_AR_PKG="AR-PACKAGE"
XMLTN_SHORT_NAME="SHORT-NAME"
XMLTN_IDENTIFIER="IDENTIFIER"
XMLTN_ECU_INSTANCE="ECU-INSTANCE"
XMLTN_ELEMENTS="ELEMENTS"
XMLTN_PHY_CHANNELS="PHYSICAL-CHANNELS"
XMLTN_FRAME_TRIGGERING="FRAME-TRIGGERINGS"
XMLTN_BAUD="BAUDRATE"
XMLTN_CAN_FD_BAUD="CAN-FD-BAUDRATE"
XMLTN_NW_ENDPOINTS="NETWORK-ENDPOINTS"
XMLTN_NW_ENDPOINT="NETWORK-ENDPOINT"
XMLTN_NW_EP_ADDRESS="NETWORK-ENDPOINT-ADDRESSES"
XMLTN_IP_CONFIG="IPV-4-CONFIGURATION"
XMLTN_IPV4_ADDRESS="IPV-4-ADDRESS"
XMLTN_ISIGNAL_IPDU_GROUPS="I-SIGNAL-I-PDU-GROUP"
XMLTN_SIGNAL_PDUS="I-SIGNAL-I-PDUS"
XMLTN_SIGNAL_PDU_REF_COND="I-SIGNAL-I-PDU-REF-CONDITIONAL"
XMLTN_SIGNAL_PDU_REF="I-SIGNAL-I-PDU-REF"
XMLTN_COMM_DIR="COMMUNICATION-DIRECTION"

# Network clusters
XMLTN_CLUSTER_CAN="CAN-CLUSTER"
XMLTN_CLUSTER_LIN="LIN-CLUSTER"
XMLTN_CLUSTER_ETH="ETHERNET-CLUSTER"

# CAN information tags
CAN_TAG_CLUSTER_VAR="CAN-CLUSTER-VARIANTS"
CAN_TAG_CLUSTER_COND="CAN-CLUSTER-CONDITIONAL"
CAN_TAG_PHY_CHANNEL="CAN-PHYSICAL-CHANNEL"
CAN_TAG_FRAME_TRIGGERING="CAN-FRAME-TRIGGERING"

# LIN information tags
LIN_TAG_CLUSTER_VAR="LIN-CLUSTER-VARIANTS"
LIN_TAG_CLUSTER_COND="LIN-CLUSTER-CONDITIONAL"
LIN_TAG_PHY_CHANNEL="LIN-PHYSICAL-CHANNEL"
LIN_TAG_FRAME_TRIGGERING="LIN-FRAME-TRIGGERING"

# Ethernet information tags
ETH_TAG_CLUSTER_VAR="ETHERNET-CLUSTER-VARIANTS"
ETH_TAG_CLUSTER_COND="ETHERNET-CLUSTER-CONDITIONAL"
ETH_TAG_PHY_CHANNEL="ETH-PHYSICAL-CHANNEL"
ETH_TAG_FRAME_TRIGGERING="ETH-FRAME-TRIGGERING"
ETHERNET_TAG_PHY_CHANNEL="ETHERNET-PHYSICAL-CHANNEL"

ETH_NW_NAME_DIAG_ONBOARD="MAIN_2"
ETH_NW_NAME_DIAG_OFFBOARD="MAIN_1"

# Pakckage Attribute
ATTR_PKG_UUID="UUID"

# Network extract tags
NWE_TAG_ECU_INSTANCE="EcuInstances"

# ECU extract tags
ECUE_TAG_COMM_CLUSTER="CommunicationClusters"
ECUE_TAG_ECU_INSTANCES="EcuInstances"
ECUE_TAG_TP_CONFIG="TpConfigs"
ECUE_TAG_ISIGNALIPDU="ISignalIPduGroups"

# ECU Extracted data keys
ECUEDK_NW_CAN="CAN"
ECUEDK_NW_LIN="LIN"
ECUEDK_NW_ETH="ETH"
# NW details
ECUEDK_NWD_NAME="name"
ECUEDK_NWD_BAUD="baud"
ECUEDK_NWD_FDBAUD="fdbaud"
ECUEDK_NWD_IPDATA="ipdata"
# ECU details
ECUEDK_ECU_NAME="Name"

# ECU types/roles
ECU_TYPES_STANDARD="STANDARD"
ECU_TYPES_GATEWAY="GATEWAY"
ECU_TYPES_VSM="VSM"
ECU_TYPES_INVALID="NA"

# PDU directions
PDU_COMM_DIR_IN="IN"
PDU_COMM_DIR_OUT="OUT"

# List of VSM ECUs
VSM_ECU_NAMES=[]  # TODO: Update this list
# PDU to be searched
PDU_SECTICK_KEYWORD="VSS_TP_SecTickCount"

# Helper Functions ------------------------------------------------------------

# Write file to directory. It will generate output filename using basepath of 
# filename passed as argument
# Arguments:
#     filename: name of arxml file being processed
#     data: Data to be saved in file
#     filepath: Directory where file is to be saved
def write_to_json(filename,data,filepath="Logs"):
    try:
        # Write to file if needed
        if ENABLE_FILE_DUMP:
            if not os.path.exists(filepath):
                os.makedirs(filepath)
            # Save file to path
            fname = os.path.join(filepath,Path(filename).stem+".json")
            with open(fname,"w") as f:
                json.dump(data,f,indent=4)
                logger.debug("Updated data in %s"%(fname))
    except Exception as e:
        logger.exception("Failed to write to JSON file",e)
    return

# Classes ---------------------------------------------------------------------

'''
Base class for handling ARXML files
'''
class Base_ARXML_Handler:
    def __init__(self,filename):
        self.root = None
        self.filename = filename
        return
    
    def load(self):
        status,self.root = xmlh.load(self.filename)
        return status
    
    def frame_tagname(self,tag):
        return "%s:%s"%(NAMESPACE_KEY,tag)

    # Get list of all AUTOSAR packages
    def get_ar_packages(self,node):
        retlist=[]
        # Create tags with namespace
        _tag_ar_pkgs=self.frame_tagname(XMLTN_AR_PKGS)
        _tag_ar_pkg=self.frame_tagname(XMLTN_AR_PKG)
        # Parse
        ar_pkgs=xmlh.get_child_with_tag(node,_tag_ar_pkgs,NAMESPACE)
        retlist=xmlh.get_children_with_tag(ar_pkgs,_tag_ar_pkg,NAMESPACE)
        return retlist
    
    def get_ar_pkg_with_name(self,node,name):
        retval=None
        pkglist = []
        # Get list of all AR packages
        pkglist=self.get_ar_packages(node)
        
        # Find package with expected name
        for pkg in pkglist:
            # Get name of this package
            pkg_name = self.get_short_name(pkg)
            # Check name
            if name == pkg_name:
                retval = pkg
                logger.debug("Identifed Package: %s" % (pkg_name))
                break
        return retval

    # Get short name from node. Search subnodes for tag short name and 
    # get value of name.
    def get_short_name(self,node):
        retval=None
        _tag_name=self.frame_tagname(XMLTN_SHORT_NAME)
        retval = xmlh.get_text( \
            xmlh.get_child_with_tag(node,_tag_name,NAMESPACE))
        return retval
    
    # Get elements node from package
    def get_elements(self,package):
        # Frame tag names with namespace
        _tag_elements=self.frame_tagname(XMLTN_ELEMENTS)
        # Extract list
        elements = xmlh.get_child_with_tag(package,_tag_elements,NAMESPACE)
        return elements
    
    # Get list of elements from Package
    def get_elements_by_tag(self,package,tagname):
        retlist=[]
        # Frame tag names with namespace
        _tag_elements=self.frame_tagname(XMLTN_ELEMENTS)
        _tag_instance=self.frame_tagname(tagname)
        # Extract list
        elements = xmlh.get_child_with_tag(package,_tag_elements,NAMESPACE)
        retlist = xmlh.get_children_with_tag(elements,_tag_instance,NAMESPACE)
        return retlist
    
    # Get first element from package with given xml tagname
    def get_element_by_tag(self,package,tagname):
        retdata=None
        # Frame tag names with namespace
        _tag_elements=self.frame_tagname(XMLTN_ELEMENTS)
        _tag_instance=self.frame_tagname(tagname)
        # Extract list
        elements = xmlh.get_child_with_tag(package,_tag_elements,NAMESPACE)
        retdata = xmlh.get_child_with_tag(elements,_tag_instance,NAMESPACE)
        return retdata

    # Get first module with tag
    def get_child_with_tag(self,package,tagname):
        # Frame tag names with namespace
        _tag_instance=self.frame_tagname(tagname)
        child = xmlh.get_child_with_tag(package,_tag_instance,NAMESPACE)
        return child

    # Get children with tag
    def get_children_with_tag(self,package,tagname):
        # Frame tag names with namespace
        _tag_instance=self.frame_tagname(tagname)
        children = xmlh.get_children_with_tag(package,_tag_instance,NAMESPACE)
        return children

    # Get parameter from node. Search subnodes for tagname and 
    # get value of associated text.
    def get_tag_text_from_children(self,node,tagname):
        retval=None
        _tag_name=self.frame_tagname(tagname)
        retval = xmlh.get_text( \
            xmlh.get_child_with_tag(node,_tag_name,NAMESPACE))
        return retval


'''
Class to extract data from Network extract.
'''
class NW_ARXML_Handler(Base_ARXML_Handler):
    def __init__(self,filename):
        logger.debug("Network extract: %s" % (filename))
        super().__init__(filename)
        return
    
    # Extract ECU data from network extract
    def get_connected_ecus(self):
        retlist=[]
        # Find the AR Package for ECU instances
        ecupkg = self.get_ar_pkg_with_name(self.root,NWE_TAG_ECU_INSTANCE)
        # Get list of ECU elements from ECU package
        elements = self.get_elements_by_tag(ecupkg,XMLTN_ECU_INSTANCE)
        # Get ECU name from each instance
        for instance in elements:
            name=self.get_short_name(instance)
            retlist.append(name)
        return retlist


'''
Class to extract data from ECU extract.
'''
class ECU_ARXML_Handler(Base_ARXML_Handler):
    def __init__(self,filename):
        logger.debug("ECU extract: %s" % (filename))
        super().__init__(filename)
        self.nw_data = None
        self.ecu_data = None
        self.frame_data = None
        return

    def load(self):
        status = False
        if super().load():
            self.nw_data = self.get_network_details()
            self.ecu_data = self.get_ecu_details()
            self.frame_data = self.get_frame_data()
            status = True
        return status

    # Get details of ECU from file
    def get_ecu_details(self):
        if self.ecu_data is None:
            data={}
            # Find the AR Package for ECU instances
            ecu_ar_pkg = self.get_ar_pkg_with_name(self.root,ECUE_TAG_ECU_INSTANCES)
            
            # Get list of Packages in communication cluster
            ecu_instances = self.get_ar_packages(ecu_ar_pkg)
            if(len(ecu_instances) > 0):
                # Use the first element in the list
                instance = ecu_instances[0]
            else:
                # Some ARXML files directly define the ECU data without AR packages
                instance = ecu_ar_pkg
            # Get list of ECU elements from ECU package
            ecu = self.get_element_by_tag(instance,XMLTN_ECU_INSTANCE)
            # get name of ECU
            name = self.get_short_name(ecu)
            data[ECUEDK_ECU_NAME] = name
            
            self.ecu_data = data
        else:
            # Do nothing. Data already loaded to memory
            pass
        return self.ecu_data

    # Get list of network names connected to ECU
    def get_network_names(self):
        retlist=[]
        # Find the AR Package for ECU instances
        comm_pkg = self.get_ar_pkg_with_name(self.root,ECUE_TAG_COMM_CLUSTER)
        # Get list of Packages in communication cluster
        nw_pkgs = self.get_ar_packages(comm_pkg)
        # Create list of all network names
        for pkg in nw_pkgs:
            retlist.append(self.get_short_name(pkg))
        return retlist

    # Get data of each network connected to ECU in a structured format
    '''
    data = [
        {
            "name":"BODY4",
            "protocol":"CAN",
            "Baudrate":500000,
            "canfdBaudrate":2000000
        }
    ]
    '''
    def get_network_details(self):
        if self.nw_data is None:
            retdata={}

            # Find the AR Package for ECU instances
            comm_pkg = self.get_ar_pkg_with_name(self.root,ECUE_TAG_COMM_CLUSTER)
            # Get list of all Packages in communication cluster
            comm_clusters = self.get_ar_packages(comm_pkg)
            
            # Create a list of necessary data for all clusters
            for cluster_pkg in comm_clusters:
                # Get AR packages
                ldata = self.get_ar_packages(cluster_pkg)
                if(len(ldata) > 0):
                    # NOTE: Get only the first package from the list
                    comm_pkg = ldata[0]
                else:
                    comm_pkg = cluster_pkg
                
                # Get elements for CAN cluster
                comm_elements = self.get_elements_by_tag(comm_pkg,XMLTN_CLUSTER_CAN)
                nwlist = self.get_nw_data_can(comm_elements)
                if (len(nwlist) > 0):
                    if ECUEDK_NW_CAN in retdata.keys():
                        retdata[ECUEDK_NW_CAN] += nwlist
                    else:
                        retdata[ECUEDK_NW_CAN] = nwlist
                
                # Get elements for LIN cluster
                comm_elements = self.get_elements_by_tag(comm_pkg,XMLTN_CLUSTER_LIN)
                nwlist = self.get_nw_data_lin(comm_elements)
                if (len(nwlist) > 0):
                    if ECUEDK_NW_LIN in retdata.keys():
                        retdata[ECUEDK_NW_LIN] += nwlist
                    else:
                        retdata[ECUEDK_NW_LIN] = nwlist
                
                # Get elements for Ethernet cluster
                comm_elements = self.get_elements_by_tag(comm_pkg,XMLTN_CLUSTER_ETH)
                nwlist = self.get_nw_data_ethernet(comm_elements)
                if (len(nwlist) > 0):
                    if ECUEDK_NW_ETH in retdata.keys():
                        retdata[ECUEDK_NW_ETH] += nwlist
                    else:
                        retdata[ECUEDK_NW_ETH] = nwlist
            self.nw_data = retdata
        else:
            # Do nothing. Data was already loaded to memory
            pass
        return self.nw_data
    
    # Get CAN cluster information
    # Argument: List of elements of networks of type CAN
    # Return: List of dictionaries with necessary information about individual
    # networks [{nw1 data},{nw2 data}]
    def get_nw_data_can(self,clusterdata):
        retdata = []
        for element in clusterdata:
            element_data = {}
            # Get name of network
            sname=self.get_short_name(element)
            
            can_variant = self.get_child_with_tag(element,CAN_TAG_CLUSTER_VAR)
            can_cond = self.get_child_with_tag(can_variant,CAN_TAG_CLUSTER_COND)
            # Get baudrates
            baud = self.get_tag_text_from_children(can_cond,XMLTN_BAUD)
            # Check if it support CAN-FD
            fdbaud = self.get_tag_text_from_children(can_cond,XMLTN_CAN_FD_BAUD)

            # Update data to dictionary
            element_data[ECUEDK_NWD_NAME] = sname
            element_data[ECUEDK_NWD_BAUD] = baud
            element_data[ECUEDK_NWD_FDBAUD] = fdbaud
            retdata.append(element_data)
        return retdata
    
    # Get LIN cluster information
    # Argument: List of elements of networks of type LIN
    # Return: List of dictionaries with necessary information about individual
    # networks [{nw1 data},{nw2 data}]
    def get_nw_data_lin(self,clusterdata):
        retdata = []
        for element in clusterdata:
            element_data = {}
            # Get name of network
            sname=self.get_short_name(element)
            
            can_variant = self.get_child_with_tag(element,LIN_TAG_CLUSTER_VAR)
            can_cond = self.get_child_with_tag(can_variant,LIN_TAG_CLUSTER_COND)
            # Get baudrates
            baud = self.get_tag_text_from_children(can_cond,XMLTN_BAUD)

            # Update data to dictionary
            element_data[ECUEDK_NWD_NAME] = sname
            element_data[ECUEDK_NWD_BAUD] = baud
            retdata.append(element_data)
        return retdata
    
    # Get Ethernet cluster information
    # Argument: List of elements of networks of type Ethernet
    # Return: List of dictionaries with necessary information about individual
    # networks [{nw1 data},{nw2 data}]
    def get_nw_data_ethernet(self,clusterdata):
        retdata = []
        for element in clusterdata:
            element_data = {}
            # Get name of network
            sname=self.get_short_name(element)
            
            nw_variant = self.get_child_with_tag(element,ETH_TAG_CLUSTER_VAR)
            nw_cond = self.get_child_with_tag(nw_variant,ETH_TAG_CLUSTER_COND)
            # Get baudrates
            baud = self.get_tag_text_from_children(nw_cond,XMLTN_BAUD)

            # Get IPv4 data----------------------------------------------------
            ipdata = self._get_eth_ip_data(nw_cond)
            
            # Update data to dictionary
            element_data[ECUEDK_NWD_NAME] = sname
            element_data[ECUEDK_NWD_BAUD] = baud
            element_data[ECUEDK_NWD_IPDATA] = ipdata
            retdata.append(element_data)
        return retdata

    # Get IPv4 address information for ethernet
    # Argument: Ethernet NW Conditional data
    def _get_eth_ip_data(self,nw_cond):
        ipdata = {}
        # Get physical channels
        phy_channel = self.get_child_with_tag(nw_cond,XMLTN_PHY_CHANNELS)
        # Parse through channels for diagnostic data
        channels = self.get_children_with_tag(phy_channel, \
                                                ETHERNET_TAG_PHY_CHANNEL)
        # Parse each channel and get ID, if available
        for channel in channels:
            name_chnl = \
                self.get_tag_text_from_children(channel,XMLTN_SHORT_NAME)
            # Collection of all IPs in endpoint
            ipdata[name_chnl] = {}
            # NW Enpoints
            nw_eps = self.get_child_with_tag(channel,XMLTN_NW_ENDPOINTS)
            # get list of end points
            nw_endpoints = self.get_children_with_tag(nw_eps,XMLTN_NW_ENDPOINT)
            for endpoint in nw_endpoints:
                nw_ep_name = self.get_tag_text_from_children(endpoint,XMLTN_SHORT_NAME)
                # Get NW Endpoint address/ipv4 configs/ip address
                nw_ep_address = self.get_child_with_tag(endpoint,XMLTN_NW_EP_ADDRESS)
                for config in self.get_children_with_tag(nw_ep_address,XMLTN_IP_CONFIG):
                    ip = self.get_tag_text_from_children(config,XMLTN_IPV4_ADDRESS)
                    if ip is not None:
                        ipdata[name_chnl][nw_ep_name] = ip
        return ipdata

    # Extract details of all frames
    def get_frame_data(self):
        if self.frame_data is None:
            data={}
            logger.debug("Extracting frame data from file")
            # Find the AR Package for ECU instances
            comm_pkg = self.get_ar_pkg_with_name(self.root,ECUE_TAG_COMM_CLUSTER)
            # Get list of all Packages in communication cluster
            comm_clusters = self.get_ar_packages(comm_pkg)
            
            # Create a list of necessary data for all clusters
            for cluster_pkg in comm_clusters:
                # Get AR packages
                ldata = self.get_ar_packages(cluster_pkg)
                if(len(ldata)>0):
                    # NOTE: Get only the first package from the list
                    comm_pkg = ldata[0]
                else:
                    comm_pkg = cluster_pkg
                
                # Get elements for CAN cluster
                comm_element = self.get_element_by_tag(comm_pkg,XMLTN_CLUSTER_CAN)
                # Check if you got some valid data
                if comm_element is not None:
                    frame_data = self.get_frame_data_can(comm_element)
                    if ECUEDK_NW_CAN in data.keys():
                        data[ECUEDK_NW_CAN].update(frame_data)
                    else:
                        data[ECUEDK_NW_CAN] = frame_data
                
                # Get elements for LIN cluster
                comm_element = self.get_element_by_tag(comm_pkg,XMLTN_CLUSTER_LIN)
                # Check if you got some valid data
                if comm_element is not None:
                    frame_data = self.get_frame_data_lin(comm_element)
                    if ECUEDK_NW_LIN in data.keys():
                        data[ECUEDK_NW_LIN].update(frame_data)
                    else:
                        data[ECUEDK_NW_LIN] = frame_data

                # # Get elements for ETH cluster
                # comm_element = self.get_element_by_tag(comm_pkg,XMLTN_CLUSTER_ETH)
                # # Check if you got some valid data
                # if comm_element is not None:
                #     frame_data = self.get_frame_data_eth(comm_element)
                #     if ECUEDK_NW_ETH in data.keys():
                #         data[ECUEDK_NW_ETH].update(frame_data)
                #     else:
                #         data[ECUEDK_NW_ETH] = frame_data
            
            self.frame_data = data
        else:
            # Do nothing. Data already loaded to memory
            pass    
        return self.frame_data
    
    # Extract details of CAN frames
    # Return: List of dictionaries with frame details
    # {nwname:{frame1:id1,frame2:id2}}
    def get_frame_data_can(self,framedata):
        data = {}
        # Get name of network
        sname=self.get_short_name(framedata)
        # Dive-in to reach the node with frame data
        variant = self.get_child_with_tag(framedata,CAN_TAG_CLUSTER_VAR)
        nw_cond = self.get_child_with_tag(variant,CAN_TAG_CLUSTER_COND)
        channel = self.get_child_with_tag(nw_cond,XMLTN_PHY_CHANNELS)
        nw_channel = self.get_child_with_tag(channel,CAN_TAG_PHY_CHANNEL)
        frame_trigger = \
            self.get_child_with_tag(nw_channel,XMLTN_FRAME_TRIGGERING)
        nw_frame_triggers = \
            self.get_children_with_tag(frame_trigger,CAN_TAG_FRAME_TRIGGERING)
        
        # Extract necessary data from individual frames
        frame_info = {}  # Will contain extracted data for all frames
        for trigger in nw_frame_triggers:
            identifier = \
                self.get_tag_text_from_children(trigger,XMLTN_IDENTIFIER)
            # Add data to dictionary
            frame_info[self.get_short_name(trigger)] = int(identifier)

        # Add frame data to main data
        data[sname] = frame_info
        return data

    # Extract details of LIN frames
    # Return: List of dictionaries with frame details
    # {nwname:{frame1:id1,frame2:id2}}
    def get_frame_data_lin(self,framedata):
        data = {}
        # Get name of network
        sname=self.get_short_name(framedata)
        # Dive-in to reach the node with frame data
        variant = self.get_child_with_tag(framedata,LIN_TAG_CLUSTER_VAR)
        nw_cond = self.get_child_with_tag(variant,LIN_TAG_CLUSTER_COND)
        channel = self.get_child_with_tag(nw_cond,XMLTN_PHY_CHANNELS)
        nw_channel = self.get_child_with_tag(channel,LIN_TAG_PHY_CHANNEL)
        frame_trigger = \
            self.get_child_with_tag(nw_channel,XMLTN_FRAME_TRIGGERING)
        nw_frame_triggers = \
            self.get_children_with_tag(frame_trigger,LIN_TAG_FRAME_TRIGGERING)
        
        # Extract necessary data from each frame type
        frame_info = {}
        for trigger in nw_frame_triggers:
            identifier = \
                self.get_tag_text_from_children(trigger,XMLTN_IDENTIFIER)
            # Add data to dictionary
            frame_info[self.get_short_name(trigger)] = int(identifier)

        # Add frame data to main data
        data[sname] = frame_info
        return data

    # Extract details of LIN frames
    # Return: List of dictionaries with frame details
    # {nwname:{frame1:id1,frame2:id2}}
    # TODO: Fix this
    def get_frame_data_eth(self,framedata):
        data = {}
        # Get name of network
        sname=self.get_short_name(framedata)
        # Dive-in to reach the node with frame data
        variant = self.get_child_with_tag(framedata,ETH_TAG_CLUSTER_VAR)
        nw_cond = self.get_child_with_tag(variant,ETH_TAG_CLUSTER_COND)
        channel = self.get_child_with_tag(nw_cond,XMLTN_PHY_CHANNELS)
        nw_channel = self.get_child_with_tag(channel,ETH_TAG_PHY_CHANNEL)
        frame_trigger = \
            self.get_child_with_tag(nw_channel,XMLTN_FRAME_TRIGGERING)
        nw_frame_triggers = \
            self.get_children_with_tag(frame_trigger,ETH_TAG_FRAME_TRIGGERING)
        
        # Extract necessary data from each frame type
        frame_info = {}
        for trigger in nw_frame_triggers:
            identifier = \
                self.get_tag_text_from_children(trigger,XMLTN_IDENTIFIER)
            # Add data to dictionary
            frame_info[self.get_short_name(trigger)] = int(identifier)

        # Add frame data to main data
        data[sname] = frame_info
        return data

    # Extract identifier of frame with given name from data
    def get_frame_id_with_name(self,data,framename,nwtype,nwname):
        identifier = None
        logger.debug("Searching ID for frame: %s"%(framename))
        if nwtype in data.keys():
            if nwname in data[nwtype].keys():
                for frame in data[nwtype][nwname].keys():
                    # look for matching name
                    if framename in frame:
                        identifier = data[nwtype][nwname][frame]
                        break
            else:
                logger.error("Could not find NW with name %s in ARXML"%(nwname))
        else:
            logger.error("Could not find NW of type %s in ARXML"%(nwtype))
        return identifier

    # Read name of ECU
    def get_ecu_name(self):
        ecu_name = None
        try:
            # Get name of ECU
            ecu_data = self.get_ecu_details()
            ecu_name = ecu_data[ECUEDK_ECU_NAME]
        except Exception as e:
            logger.exception("Failed to get name of ECU",e)
        return ecu_name

    # get id for ECU_Stat
    def get_ecu_stat_id(self,nwname):
        ecu_id = None
        logger.debug("Extract ECU stat ID for NW: %s"%(nwname))
        # Get Network type (CAN, Eth, Flexray)
        nwtype = self.__get_nwtype(nwname)
        if nwtype is not None:
            try:
                # Get name of ECU
                ecu_data = self.get_ecu_details()
                ecu_name = ecu_data[ECUEDK_ECU_NAME].upper()
                
                # If ECU has _XX in the name use only first part of ECU name
                # Example: CLT_XX->CLT
                if(ecu_name.find("_XX") != -1):
                    ecu_name = ecu_name.split("_XX")[0]
                
                logger.debug("ECU: %s"%ecu_name)
                # FIXME: Does not work for BAT14. The ousrce data should be from CommunicationClusters/WN Name/PDU-Triggerings
                # Get data of frames for specified network
                framedata = self.get_frame_data()[nwtype][nwname]
                for framename in framedata:
                    # Search for PDU names
                    if ((framename.startswith("ECU_Stat_") or ("_ECU_Stat_" in framename)) \
                        and ("ST3" in framename.upper()) \
                        and (ecu_name in framename.upper()) \
                            ):
                        # This is the ECU_Stat PDU
                        ecu_id = framedata[framename]
                        break
                
                if ecu_id is None:
                    logger.error("Failed to get ECU Stat ID")
            except Exception as e:
                logger.exception("Failed to get ECU Stat ID",e)
        else:
            logger.error("Could not identify network: %s"%(nwname))
        return ecu_id

    # get ROE PDU from ARXML file
    def get_roe_pdu(self):
        ROE_PDU_NAME = "ROE_"
        ecu_instance_name = self.ecu_data[ECUEDK_ECU_NAME]
        if(ecu_instance_name.find("_XX") != -1):
           ROE_PDU_NAME =  ROE_PDU_NAME + ecu_instance_name[:ecu_instance_name.find("_XX")]
        elif(ecu_instance_name.find("_xx") != -1):
            ROE_PDU_NAME = ROE_PDU_NAME + ecu_instance_name[:ecu_instance_name.find("_xx")]
        else:
            ROE_PDU_NAME = ROE_PDU_NAME + ecu_instance_name
        if(ecu_instance_name == "MPC"):
            ROE_PDU_NAME = "ROE_SMPC"
        return ROE_PDU_NAME

    # Get type of network from name of network
    def __get_nwtype(self,nwname):
        retval = None
        framedata = self.get_frame_data()
        
        for bus in framedata:
            if nwname in framedata[bus].keys():
                retval = bus
                break
        return retval
    
    # Read identifier for NM_STAT, Dummy
    # Arguments: Name of network to extract NM PDU information from
    # Return: Tuple (NM_PDU_ID, NM_DUMMY_ID)
    def get_nm_pdu_id(self,nwname):
        nm_stat_id = None
        nm_dummy_id = None
        # Get name of ECU
        ecu_data = self.get_ecu_details()
        ecu_name = ecu_data[ECUEDK_ECU_NAME].upper()
        
        # If ECU has _XX in the name use only first part of ECU name
        # Example: CLT_XX->CLT
        if(ecu_name.find("_XX") != -1):
            ecu_name = ecu_name.split("_XX")[0]
        
        # Get Network type (CAN, Eth, Flexray)
        nwtype = self.__get_nwtype(nwname)
        if nwtype is not None:
            # Get data of frames for specified network
            framedata = self.get_frame_data()[nwtype][nwname]
            # Search for keywords to identify NM frames
            for framename in framedata:
                # Search for NM PDU names
                if (framename.startswith("NM_") 
                    and ("ST3" in framename.upper())):
                    # This is an NM PDU. Proceed ahead
                    if "_DUMMY_" in framename.upper():
                        nm_dummy_id = framedata[framename]
                        logger.debug("nm_dummy_id: %d"%(nm_dummy_id))
                    elif ecu_name in framename.upper():
                        nm_stat_id = framedata[framename]
                        logger.debug("nm_stat_id: %d"%(nm_stat_id))
                    else:
                        pass
        else:
            logger.error("Could not find newtwork %s in ARXML"%(nwname))
        
        return (nm_stat_id,nm_dummy_id)

    # Get list of signal PDU group nodes
    def _get_signal_pdu_groups(self,node):
        retval = None
        _tag_pdu_groups = self.frame_tagname(XMLTN_ISIGNAL_IPDU_GROUPS)
        
        elements = self.get_elements(node)
        # get children of type isignal-ipdu-groups
        retval = xmlh.get_children_with_tag(elements,_tag_pdu_groups,NAMESPACE)
        return retval

    # Read communication direction of signal PDU group
    def get_pdu_comm_direction(self,node):
        retval = None
        _tag_dir = self.frame_tagname(XMLTN_COMM_DIR)
        retval = xmlh.get_text_from_tag(node,_tag_dir,NAMESPACE)
        return retval

    # Check if a PDU is present in the given signal group
    # Arguments:
    #   group: isignal-pdu group to be checked for PDU
    #   name: String to be matched in PDU name
    # Return:
    #   True: Available
    #   False: Not Available
    def _is_pdu_in_signal_group(self,group,name):
        retval = False
        # Frame tagnames with namespace
        _tag_pdus = self.frame_tagname(XMLTN_SIGNAL_PDUS)
        _tag_pdu_ref_cond = self.frame_tagname(XMLTN_SIGNAL_PDU_REF_COND)
        _tag_pdu_ref = self.frame_tagname(XMLTN_SIGNAL_PDU_REF)
        
        # Get list of signal PDUs inside this group
        pdus = xmlh.get_child_with_tag(group,_tag_pdus,NAMESPACE)
        pdu_conds = xmlh.get_children_with_tag(pdus,_tag_pdu_ref_cond,NAMESPACE)
        for pdu_cond in pdu_conds:
            pdu_ref_text = xmlh.get_text_from_tag(pdu_cond,_tag_pdu_ref,NAMESPACE)
            if (name in pdu_ref_text):
                retval = True
                break
        return retval

    # Get ECU type from list of signal pdu groups
    def _get_ecu_type_from_signal_groups(self,signal_pdu_groups):
        status = False
        retval = ECU_TYPES_INVALID
        # Find direction of group containing the SecTickCount PDU
        for group in signal_pdu_groups:
            # Check if group contains the PDU
            if self._is_pdu_in_signal_group(group,PDU_SECTICK_KEYWORD):
                direction = self.get_pdu_comm_direction(group)
                # Decide ECU type based on direction
                if self.get_ecu_name() in VSM_ECU_NAMES:
                    retval = ECU_TYPES_VSM
                elif direction == PDU_COMM_DIR_IN:
                    retval = ECU_TYPES_STANDARD
                elif direction == PDU_COMM_DIR_OUT:
                    retval = ECU_TYPES_GATEWAY
                logger.debug("Identified ECU type: %s"%(retval))
                status = True
                break
        
        return status,retval
    
    # Identify ECU role for given network
    # Argument: Name of network for which ECU type is to be identified
    # Return: Type of ECU
    #   (ECU_TYPES_GATEWAY|ECU_TYPES_VSM|ECU_TYPES_STANDARD|ECU_TYPES_INVALID)
    # NOTE: May have to hardcode some network names for specific ECUs since the
    # network name is not consistent in all ARXML files.
    # Example: CLT uses CAL_XX in some places and CAL_DL at others.
    def get_ecu_type(self,nwname):
        retval = ECU_TYPES_INVALID
        
        # FIXME: Some special cases required hard coding
        if nwname == "CAL_XX":
            nwname = "CAL_DL"

        # Get name of ECU
        ecu_name = self.get_ecu_name()
        logger.debug("Checking ECU type for %s"%(ecu_name))

        # Find the AR Package for ECU instances
        pdu_pkg = self.get_ar_pkg_with_name(self.root,ECUE_TAG_ISIGNALIPDU)
        # Get package of specified network
        nw_data = self.get_ar_pkg_with_name(pdu_pkg,nwname)
        
        # Check if nw package is available
        if nw_data is None:
            logger.error("No NW packages with the name %s"%(nwname))
            return retval
        
        # Get NW package
        nw_pkgs = self.get_ar_packages(nw_data)
        
        # Start analyzing each package
        for nw_pkg in nw_pkgs:
            _stop_loop = False
            # Check for sub packages
            cop_ar_pkgs = self.get_ar_packages(nw_pkg)
            if len(cop_ar_pkgs) > 0:
                logger.debug("Found at least one sub pkg")
                for pkg in cop_ar_pkgs:
                    # Get list of signal PDU groups from package
                    signal_pdu_groups = self._get_signal_pdu_groups(pkg)
                    # Find direction of group containing the SecTickCount PDU
                    status,ecu_type = self._get_ecu_type_from_signal_groups(signal_pdu_groups)
                    if status:
                        retval = ecu_type
                        _stop_loop = True
                        break
            else:
                # Get list of signal PDU groups from package
                signal_pdu_groups = self._get_signal_pdu_groups(nw_pkg)
                # Find direction of group containing the SecTickCount PDU
                status,ecu_type = self._get_ecu_type_from_signal_groups(signal_pdu_groups)
                if status:
                    retval = ecu_type
                    _stop_loop = True
                    break
            if _stop_loop:
                logger.debug("Breaking nw pkg loop")
                break
        return retval

# Test Functions --------------------------------------------------------------
TESTFILE_BAT14 = "Test/ECU/BAT14_STAR_3_Ecu_Extract_2022_42a0/BAT14_STAR_35_Ecu_Extract_2022_42a0_AR44.arxml"

TESTFILE_CEIC_C = "Test/ECU/CEIC_C_STAR_35_Ecu_Extract_2022_42b/CEIC_C_STAR_35_2022_42b0_d_Ecu_Details_Extract_2022_42b0_AR44.arxml"
TESTFILE_CEIC_M = "Test/ECU/CEIC_M_STAR_35_2022_42b/CEIC_M_STAR_35_2022_42b0_d_Ecu_Details_Extract_2022_42b0_AR2011.arxml"

TESTFILE_CLT = "Test/ECU/CLT/CLT_FL_STAR_3_Ecu_Extract_2022_29a0_AR43.arxml"

TESTFILE_BC = "Test/ECU/BC_STAR_35_Ecu_Extract_2022_42a0/BC_STAR_35_d_Ecu_Details_Extract_2022_42a0_AR44.arxml"
TESTFILE_CDCC = "Test/ECU/CDCC_STAR_35_Ecu_Extract_2022_42b0/CDCC_STAR_35_Ecu_Extract_2022_42b0_AR2011.arxml"
TESTFILE_CIVIC = "Test/ECU/CIVIC_STAR_35_Ecu_Extract_2022_42b0/CIVIC_STAR_35_d_Ecu_Details_Extract_2022_42b0_AR44.arxml"


def test_nw():
    # file="Test/NW/BODY2_STAR_3_2022_42b0/STAR_35_BODY2_CAN_2022_42b_AR44.arxml"
    # file="Test/NW/BODY2_STAR_3_2022_42b0/STAR_35_BODY2_CAN_2022_42b_AR2011.arxml"
    
    file="Test/NW/STAR_3_MAIN_Ethernet_2022_42b0/STAR_3_MAIN_Ethernet_2022_42b_AR43.arxml"
    # file="Test/NW/STAR_3_MAIN_Ethernet_2022_42b0/STAR_3_MAIN_Ethernet_2022_42b_FUNC_VEH_AR43.arxml"
    
    # file="Test/NW/BODY4_CAN_STAR_3_2022_42a/STAR_35_BODY4_CAN_2022_42a_AR44.arxml"
    # file="Test/NW/BODY4_CAN_STAR_3_2022_42a/STAR_35_BODY4_CAN_2022_42a_AR2011.arxml"
    
    fh=NW_ARXML_Handler(file)
    if fh.load():
        names=fh.get_connected_ecus()
        for name in names:
            logger.info("ECU: %s"%(name))
    return

def test_ecu(file=TESTFILE_BC):
    
    fh=ECU_ARXML_Handler(file)
    if fh.load():
        names=fh.get_network_names()
        for name in names:
            logger.info("NW: %s"%(name))

        nwdata = fh.get_network_details()
        print(json.dumps(nwdata,indent=2))
        
        # Get details of ECU
        ecu_data = fh.get_ecu_details()
        ecu_name = ecu_data[ECUEDK_ECU_NAME]
        print("ecu_name",ecu_name)

        # framedata = fh.get_frame_data()
        # print(json.dumps(framedata,indent=2))
        # Get identifier of specific frame
        # data = fh.get_nm_pdu_id("BODY4")
        # print(data)

        # Request frame
        # fname = "DIAG_BC_15_ExtEth_RQ_FD_ST3_"
        # id = fh.get_frame_id_with_name(framedata,fname,ECUEDK_NW_CAN,"BODY4")
        # print("Request Identifier:",id)
        
        # # # Response frame
        # # DIAG_ecuname_ExtEth_RS
        # fname = "DIAG_BC_15_ExtEth_RS_FD_ST3_"
        # id = fh.get_frame_id_with_name(framedata,fname,ECUEDK_NW_CAN,"BODY4")
        # print("Response Identifier:",id)
        
    return

def get_nw_data(file=TESTFILE_BC):
    nwdata = None
    fh=ECU_ARXML_Handler(file)
    if fh.load():
        nwdata = fh.get_network_details()
        # nwdata = fh.get_tp_data()
        # Write to file
        # write_to_json(file,nwdata)
        print(json.dumps(nwdata,indent=2))
    return nwdata

def test_nm_id(file,nwname):
    fh=ECU_ARXML_Handler(file)
    if fh.load():
        logger.info("ECU: \t%s"%fh.get_ecu_name())
        # Get details of ECU
        ecu_id = fh.get_ecu_stat_id(nwname)
        logger.info("ECU Stat Identifier: \t%s"%(str(ecu_id)))
        
        # Get details of NM PDU
        nm_ecu_id,nm_dummy_id = fh.get_nm_pdu_id(nwname)
        logger.info("NM PDU Identifier: \t%d"%nm_ecu_id)
        logger.info("NM Dummy Identifier: \t%d"%nm_dummy_id)
    return

def test_ecu_type(file,nwname):
    fh = ECU_ARXML_Handler(file)
    if fh.load():
        ecu_type = fh.get_ecu_type(nwname)
        print("ECU:",fh.get_ecu_name())
        print("\tECU Type for network %s\t->\t%s"%(nwname,ecu_type))
    return

def test_ecu_type_all_nw(file):
    fh = ECU_ARXML_Handler(file)
    if fh.load():
        print("ECU:",fh.get_ecu_name())
        nw_names = fh.get_network_names()
        for nw in nw_names:
            ecu_type = fh.get_ecu_type(nw)
            print("\tECU Type for network %s\t->\t%s"%(nw,ecu_type))
    return

if __name__=="__main__":
    logger.info("-"*80)
    test_ecu_type(TESTFILE_CLT,"CAL_DL")
    test_ecu_type(TESTFILE_CEIC_C,"MAIN")
    # test_ecu_type(TESTFILE_CEIC_M,"BODY4")
    # test_ecu_type(TESTFILE_CEIC_M,"BODY2")

    # test_ecu_type_all_nw(TESTFILE_BAT14)
    # test_ecu_type_all_nw(TESTFILE_CEIC_M)
    # test_ecu_type_all_nw(TESTFILE_CEIC_C)
    # test_ecu_type_all_nw(TESTFILE_BC)
    # test_ecu_type_all_nw(TESTFILE_CDCC)
    # test_ecu_type_all_nw(TESTFILE_CIVIC)
    logger.info("-"*80)


# End of file -----------------------------------------------------------------
