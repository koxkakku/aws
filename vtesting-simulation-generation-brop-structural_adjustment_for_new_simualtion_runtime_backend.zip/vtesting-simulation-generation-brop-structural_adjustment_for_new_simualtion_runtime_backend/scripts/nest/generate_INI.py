'''
Script to generate INI file for NEST configuration generation.
Author: Naresh
Modified By: STEPHIG
'''

import configparser
import os
import argparse as ap

from Logger import LogHandler
from json_parser import UI_Json_Parser
from arxml_handler.extract import ECU_ARXML_Handler

# INI section titles
from constants import INI_SECTION_DB
from constants import INI_SECTION_CONFIG
from constants import INI_SECTION_DLL
from constants import INI_SECTION_ADAPTIVE

# INI DB keys
from constants import INI_KEY_DB_ARXML
from constants import INI_KEY_DB_ODX

# INI Config keys
from constants import INI_KEY_CONFIG_DIAG
from constants import INI_KEY_CONFIG_ECU_TYPE
from constants import INI_KEY_CONFIG_ECU_KIND
from constants import INI_KEY_CONFIG_NW
from constants import INI_KEY_CONFIG_ROE
from constants import INI_KEY_CONFIG_VARIANT
from constants import INI_KEY_CONFIG_TICK_CYCLE
from constants import INI_KEY_CONFIG_FIREWALL
from constants import INI_KEY_CONFIG_DIAG_RQ_ID
from constants import INI_KEY_CONFIG_DIAG_RS_ID

# INI VTT keys
from constants import INI_KEY_VTT_ECU
from constants import INI_KEY_VTT_HSM
from constants import INI_KEY_VTT_SYSVAR

#INI Adaptive Keys
from constants import INI_KEY_ADAPTIVE_ECU_TYPE
from constants import INI_KEY_ADAPTIVE_USE_CALLOUT

from constants import NEST_INI_FILE
from constants import DIR_ECU_NEST
from constants import DIR_SYSVAR_NEST

# Logging functions -----------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# INI Generation class ---------------------------------------------------------

class INI_Generator:
    def __init__(self,file: str) -> None:
        self.filename = file
        self.input_handler = None
        self.arxml_handler = None
        self.config = configparser.ConfigParser()
        self.config.optionxform = str
        return

    # Read the input file
    def load(self) -> bool:
        status = False
        try:
            self.input_handler = UI_Json_Parser(self.filename)
            # Load data to memory
            if self.input_handler.load_json() is not None:
                status = True
        except Exception as e:
            log_exception("Failed to read input file",e)
        return status

    # Get name of ARXML from JSON and parse the file
    def load_arxml(self) -> bool:
        status = False
        if self.arxml_handler is None:
            file = self.get_arxml_path()
            self.arxml_handler = ECU_ARXML_Handler(file)
            if self.arxml_handler.load():
                status = True
            else:
                status = False
                self.arxml_handler = None
                log_error("Failed to read ARXML file: %s"%(file))
        else:
            status = True
        return status

    # Write confgiuration data to INI file
    def create(self,filename: str=NEST_INI_FILE) -> bool:
        status = False
        try:
            with open(filename, 'w') as f:
                self.config.write(f)
            status = True
        except Exception as e:
            log_exception("Exception while writing file:",e)
        return status
    
    #  arxml file extraction from JSON
    def get_arxml_path(self):
        file = self.input_handler.get_ecu_arxml()
        arxml_path = os.path.abspath(file)
        return arxml_path

    #  ODXD file extraction from JSON
    def get_odxd_path(self):
        file = self.input_handler.get_ecu_odxd()
        odxd_path = os.path.abspath(file)
        return odxd_path

    # network name extraction from JSON
    def read_network_name(self) -> str:
        nw_name = self.input_handler.get_nw_name()
        return nw_name

    # variant extraction from JSON
    def read_variant(self):
        return self.input_handler.get_ecu_variant()

    # ROE PDU extraction from JSON
    def read_roe_pdu(self):
        ecu_roe_pdu = None
        # Get ROE from ARXML file
        if self.load_arxml():
            ecu_roe_pdu = self.arxml_handler.get_roe_pdu()
        else:
            log_error("Failed to update ROE PDU in INI")
        return ecu_roe_pdu

    # Get the type of ECU (Silver or VTT)
    def get_ecu_pkg_type(self):
        vecutype = "VTT"  # Default value
        for root,dirs,files in os.walk(DIR_ECU_NEST):
            for file in files:
                if file.endswith('.sil'):
                    vecutype="SIL"
                    break
            # Break outer loop
            if vecutype == "SIL":
                break
        return vecutype

    # Get ECU type
    def get_ecu_type(self):
        retval = None
        # Get network under test
        nwname = self.read_network_name()
        if self.load_arxml():
            retval = self.arxml_handler.get_ecu_type(nwname)
        else:
            log_error("Failed to update ECU Type in INI")
        return retval

    # Get path to vECU DLL file
    def get_vtt_ecu_dll(self):
        retval = None
        for root,dirs,files in os.walk(DIR_ECU_NEST):  
            for file in files:
                _fname = file.lower()  # Change filename to lower case
                if (_fname.find("hsm") == -1) and _fname.endswith('.vmodule'):
                    retval = os.path.abspath(os.path.join(DIR_ECU_NEST, file))
                    break
            # Break outer loop
            if retval is not None:
                break
        return retval

    # Get path to vHSM DLL file
    def get_vtt_hsm_dll(self):
        retval = None
        for root,dirs,files in os.walk(DIR_ECU_NEST):
            for file in files:
                _fname = file.lower()  # Change filename to lower case
                if (_fname.find("hsm") != -1) and _fname.endswith('.vmodule'):
                    retval = os.path.abspath(os.path.join(DIR_ECU_NEST, file))
                    break
            # Break outer loop
            if retval is not None:
                break
        return retval

    # Get list of system variable files
    def get_sysvar(self) -> list:
        sysvar = []
        for root,dirs,files in os.walk(DIR_SYSVAR_NEST):
            for file in files:
                if file.endswith('.vsysvar') :
                    sysvar_path = os.path.join(DIR_SYSVAR_NEST, file)
                    sysvar.append (sysvar_path)
        return sysvar
    
    # Update configuration file
    def config_set_value(self,section,key,value) -> None:
        self.config.set(section,key,value)
        return
    
    # Create a new section in the configuration.
    # Note that this will delete any old data within the section if it exists.
    def config_create_section(self,section) -> None:
        self.config[section] = {}
        return

    # Check if ECU uses Adaptive or Classic autosar
    # NOTE: Hardcoded for now since we only test classic ECUs.
    def is_ecu_adaptive(self):
        return 0
    
    # Check if callout script JSON needs to be used for Adaptive
    # NOTE: Hardcoded for now since we only test classic ECUs.
    def need_callout_script(self):
        return 0

    # Get diagnostic request ID
    # NOTE: hardcoded for now
    def get_diag_rq_id(self):
        return str(12345678)
    
    # Get diagnostic response ID
    # NOTE: hardcoded for now
    def get_diag_rs_id(self):
        return str(12345678)

    # The tick count for simulation cycle is hardcoded
    def get_cycle_tick_count(self):
        return str(100)

    # Check if status of diagnostic firewall is enabled for ECU
    def get_diag_firewall_status(self):
        return str(0)

    # Generate INI file
    def generate(self) -> bool:
        status = False
        # Start structuring the final file

        # Section DB
        self.config_create_section(INI_SECTION_DB)
        self.config_set_value(INI_SECTION_DB, INI_KEY_DB_ARXML, 
                              self.get_arxml_path())
        self.config_set_value(INI_SECTION_DB, INI_KEY_DB_ODX,
                              self.get_odxd_path())

        # Section configuration
        self.config_create_section(INI_SECTION_CONFIG)
        ecu_pkg_type  = self.get_ecu_pkg_type()
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_ECU_KIND, 
                              ecu_pkg_type)
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_ECU_TYPE,
                              self.get_ecu_type())
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_NW,
                              self.read_network_name())
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_DIAG,
                              self.read_network_name())
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_DIAG_RQ_ID,
                              self.get_diag_rq_id())
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_DIAG_RS_ID,
                              self.get_diag_rs_id())
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_ROE,
                              str(self.read_roe_pdu()))
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_VARIANT,
                              self.read_variant())
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_TICK_CYCLE,
                              self.get_cycle_tick_count())
        self.config_set_value(INI_SECTION_CONFIG, INI_KEY_CONFIG_FIREWALL,
                              self.get_diag_firewall_status())

        # Section ECU type specific
        if ecu_pkg_type == 'VTT':
            # Add paths to DLL files
            self.config_create_section(INI_SECTION_DLL)
            self.config_set_value(INI_SECTION_DLL, INI_KEY_VTT_ECU,
                                  self.get_vtt_ecu_dll())
            self.config_set_value(INI_SECTION_DLL, INI_KEY_VTT_HSM,
                                  self.get_vtt_hsm_dll())
            # self.config_set_value(INI_SECTION_DLL, INI_KEY_VTT_SYSVAR,
            #                       str(self.get_sysvar()))
        else:
            # NOTE: SIL files are currently not supported
            pass
        
        # Section Adaptive parameters
        self.config_create_section(INI_SECTION_ADAPTIVE)
        self.config_set_value(INI_SECTION_ADAPTIVE,INI_KEY_ADAPTIVE_ECU_TYPE,
                              str(self.is_ecu_adaptive()))
        self.config_set_value(INI_SECTION_ADAPTIVE,INI_KEY_ADAPTIVE_USE_CALLOUT,
                              str(self.need_callout_script()))

        if self.create(NEST_INI_FILE):
            log_info("INI file generated!!!")
            status = True
        else:
            log_error("Failed to generate INI file.")
        return status

# End class --------------------------------------------------------------------

def cli_handler():
    # Create parser
    parser = ap.ArgumentParser(description="Generate the yaml file")

    # Add argument to the sample ui_json file
    parser.add_argument("-u", "--ui_json",
                        type=str,
                        help="path to the sample brop_ui_json file",
                        required=True)

    args = parser.parse_args()
    return args.ui_json

def main():
    inputjson = cli_handler()
    config = INI_Generator(inputjson)
    if config.load():
        if config.generate():
            # INI generated successfully
            pass
        else:
            log_error("Error during generation of INI file.")
    else:
        log_error("Failed to load JSON file.")
    return


if __name__ =='__main__':
    logger.info("-"*80)
    main()
    logger.info("-"*80)
					 
# End of File -----------------------------------------------------------------
