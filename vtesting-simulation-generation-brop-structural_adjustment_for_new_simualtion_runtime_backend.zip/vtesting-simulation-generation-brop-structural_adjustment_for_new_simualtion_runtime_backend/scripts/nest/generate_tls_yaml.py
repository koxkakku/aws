"""
Created by: SYARAGA
Date: 09-10-2023
Desc: API's to generate TLS yaml file

"""

# Import section ------------------------------------------------------------

import os
import sys
import yaml
import json
import argparse as ap

from Logger import LogHandler

from get_node_api import Config_Input

from arxml_handler.extract import ECU_ARXML_Handler

from YAML_Handler import Version
from YAML_Handler import SymbolMapping
from YAML_Handler import Database
from YAML_Handler import EthernetNetworks
from YAML_Handler import SimulationNodeEthernet
from YAML_Handler import SecurityProfile
from YAML_Handler import Logging
from YAML_Handler import CreateConfig

# Constants defination--------------------------------------------------------

#output file
from constants import OUTPUT_FILE

# Extension constants
from constants import EXT_VMAP

# Folder name 
from constants import SYSVAR

# Protocols name 
from constants import CAN
from constants import ETHERNET
from constants import LIN

# Parsed data constants
from constants import PD_NAME
from constants import PD_BAUD
from constants import PD_FDBAUD
from constants import PD_PARENT_NW
from constants import PD_ECU_ARXML
from constants import PD_VECU_TYPE
from constants import PD_VSYSVAR_FILES
from constants import PD_TEST_TYPE
from constants import PD_VMODULE_FILES

# Sim node properties
from constants import SIM_NODE_VECTOR_SIMULATION_NODE
from constants import SIM_NODE_VIRTUAL_TARGET

# ECU Type
from constants import VTT
from constants import SILVER

# Logging functions -----------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return
    
def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

class GenerateTLSYAML:

    yaml_dict = dict() # dict to be dumped in yaml file
    yaml_lst = list()  # List of generated node objects
    network_data = None

    def __init__(self,ui_json_file):
        self.ui_json_file = ui_json_file
        return
    
    ''' Input - ui_json file
        Output - dict = {
            "name": "BODY4",
            "baud": "500000",
            "fdbaud": "2000000",
            "parent_nw": "CAN",
            "ecu_arxml": "BAT14_STAR_35_Ecu_Extract_2023_05a0_AR2011.arxml",
            "ecu_type" : VTT/silver,
            "Sys_var file" : example.vsysvar,
            "vmodule file" : ex.vmodule
            }'''
    def parsed_data(self):
       if self.network_data is None: 
            final_nw_data = {}
            nw_parsed_data = Config_Input(self.ui_json_file)
            nw_type = nw_parsed_data.get_nw_name()
            # info = ECU_ARXML_Handler(filename='database\BC_STAR_35_d_Ecu_Details_Extract_2022_42a0_AR2011.arxml')
            info = ECU_ARXML_Handler(filename= nw_parsed_data.get_ecu_arxml())
            if info.load():
                nw_data = info.get_network_details()
                # with open("NW.json","w") as f:
                #     json.dump(nw_data,f,indent=4)
                for key,value in nw_data.items():
                    if key == CAN and isinstance(value, list):
                        can_info = {}
                        for data in value:
                            if data[PD_NAME] == nw_type:
                                can_info[PD_NAME] = data[PD_NAME]
                                can_info[PD_BAUD] = data[PD_BAUD]
                                can_info[PD_FDBAUD] = data[PD_FDBAUD]
                                can_info.update({PD_PARENT_NW:CAN})
                                final_nw_data.update(can_info)
                            else:
                                log_debug("Could not find the network name from the arxml file: %s"%nw_type)
                    elif key == LIN and isinstance(value, list):
                        lin_info ={}
                        for data in value:
                            if data[PD_NAME] == nw_type:
                                lin_info[PD_NAME] = data[PD_NAME]
                                lin_info[PD_BAUD] = data[PD_BAUD]
                                lin_info.update({PD_PARENT_NW:LIN})
                                final_nw_data.update(lin_info)
                            else:                
                                log_debug("Could not find the network name from the arxm file: %s"%nw_type)
                    elif key == ETHERNET and isinstance(value, list):
                        eth_info = {}
                        for data in value:
                            if data[PD_NAME] == nw_type:
                                eth_info[PD_NAME] = data[PD_NAME]
                                eth_info[PD_BAUD] = data[PD_BAUD]
                                eth_info.update({PD_PARENT_NW:ETHERNET})
                                final_nw_data.update(eth_info)
                            else:                
                                log_debug("Could not find the network name from the arxm file: %s"%nw_type)
                    else:
                        log_error('Could not find the network details')
            final_nw_data[PD_ECU_ARXML] = nw_parsed_data.get_ecu_arxml()
            final_nw_data[PD_VECU_TYPE] = nw_parsed_data.get_ecu_type()
            final_nw_data[PD_VSYSVAR_FILES] = nw_parsed_data.get_sysvar()
            final_nw_data[PD_VMODULE_FILES] = nw_parsed_data.get_vmodule()
            final_nw_data[PD_TEST_TYPE] = nw_parsed_data.get_test_type()
            self.network_data = final_nw_data
       return self.network_data
    
    # Logic to find files like arxml, vsysvar etc
    '''input - file_extension, folder_name
       output - filepath with particular extension
    '''
    def file_finding(self,extension,folder_name):
        file_list = []
        res_dict = {}
        for root,dirs,files in os.walk(folder_name):
            for file in files:
                if file.endswith(extension):
                    filepath = os.path.join(root,file)
                    filepath = self.raw_string(filepath) 
                    file_list.append(filepath)
        if len(file_list)>0:
            res_dict[extension] = file_list
        else:
            res_dict[extension] = None
        log_debug("Local Directory: %s"%res_dict)
        return res_dict
    
    # Function to return paths with double backslash 
    # (YAML requiers either single front slash or double back slash for it's working)
    def raw_string(self,path):
        rw_string_filepath = path.encode('unicode_escape').decode()
        return rw_string_filepath
    
    # Version details of a particular YAML file
    def add_version(self):
        version = Version()
        self.yaml_lst.append(version)
        return True
    
    # Add the smbol mapping file if it exists in the Sys_Var foler
    def add_symbol_mapping(self):
        log_debug('Adding Symbol mapping node')
        vmap_file = self.file_finding(extension=EXT_VMAP,folder_name=SYSVAR)
        vmap_filepath = []
        try:
            if vmap_file[EXT_VMAP] is not None:
                vmap_filepath = vmap_file[EXT_VMAP][0]
            else:
                log_debug('Did not find any vmpap files')
        except Exception as e:
            log_exception('Failed to add symbol mapping node node: ',e)
        
        if len(vmap_filepath) > 0:
            symbol_mapping = SymbolMapping(file = vmap_filepath)
            self.yaml_lst.append(symbol_mapping)
        else:
            log_debug("Symbol mapping node not added")
        return True
    
    # method to add database to the yaml file
    def add_database(self):
        log_debug('Adding database node')
        status = False
        # Get data from UI Json and ARXML file
        nw_data = self.parsed_data()
        required_keys = [PD_ECU_ARXML,PD_NAME]
        if all(key in nw_data for key in required_keys):
            # Get extracted data
            ecu_arxml = nw_data[PD_ECU_ARXML]
            node_name = nw_data[PD_NAME]

            # get ARXML Filepath
            arxml = self.raw_string(ecu_arxml)

            database = Database()
            database.add_node(name=node_name,filepath=arxml)
            
            # update main YAML data
            self.yaml_lst.append(database)
            status = True
        else:
            status = False
            log_error("Could not get nw_data from JSON/YAML")
        return status
    
    # method to add the ethernet network node to the yaml file
    def add_ethernet_nw(self):
        log_debug('Adding ethernet networks node')
        status = False
        # Get data from UI Json and ARXML file
        nw_data = self.parsed_data()
        if PD_NAME in nw_data:
            status = True
            name = nw_data[PD_NAME]

            ethernet_nw = EthernetNetworks()
            ethernet_nw.add_node(nodename=name)
            
            self.yaml_lst.append(ethernet_nw)
        else:
            status = False
            log_debug('Could not get network data from json/yaml')
        return status
    
    # method to add the simulation node
    def add_simulation_node(self):
        log_debug('Adding simulation node')
        status = False
        # Get data from UI Json and ARXML file
        nw_data = self.parsed_data()
        required_keys = [PD_NAME,PD_VECU_TYPE,PD_VMODULE_FILES]
        if all(key in nw_data for key in required_keys):
            
            # Get extracted data 
            name = nw_data[PD_NAME]
            # get vECU_type
            vECU_type = nw_data[PD_VECU_TYPE]
            # modeling libraries
            modeling_lib = nw_data[PD_VMODULE_FILES]

            sim_node = SimulationNodeEthernet()

            # Nodes common for all types of vECUs
            sim_node.add_node(nodename= SIM_NODE_VECTOR_SIMULATION_NODE,nwname=name,canfile=r'CAPL\\SendNM.can')

            if vECU_type.upper() == VTT:
                sim_node.add_node(nodename=SIM_NODE_VIRTUAL_TARGET, nwname=name,modeling_libraries=modeling_lib)
            elif vECU_type.upper() == SILVER:
                pass
            
            self.yaml_lst.append(sim_node)
            status = True
        else:
            status = False
            log_error("Could not get any nw_data from JSON/ARXML")
        return status
    
    def add_security_profile(self):
        log_debug("Adding security profile")
        status = False

        # Get data from UI Json and ARXML file
        nw_data = self.parsed_data()

        if PD_NAME in nw_data:
            status = True
            nw_name = nw_data[PD_NAME]

            security_profile = SecurityProfile()
            security_profile.add_node(nwname=nw_name)

            self.yaml_lst.append(security_profile)
        else:
            status = False
            log_error("Could not get any nw_data from JSON/ARXML")
        return status
    
    # method to add the log information
    def add_logging(self):
        log_debug("Adding the log.blf file")
        log_details = Logging()
        self.yaml_lst.append(log_details)
        return True

    # Creating yaml file to dump all the final output
    def create_yaml(self):
        log_debug('Created yaml file: venvironment.yaml')
        yaml_info = CreateConfig(filename=OUTPUT_FILE,data=self.yaml_lst)
        status = yaml_info.create()
        return status
    
# Command line handler
def cli_handler():
    # Create parser
    parser=ap.ArgumentParser(description="Generate the yaml file")
   
    # Add argument to the sample ui_json file
    parser.add_argument("-u", "--ui_json",
        type=str,
        help="path to the sample brop_ui_json file",
        required=True)

    args = parser.parse_args()  
    return args.ui_json

def generate():
    ui_json_file = cli_handler()
    # main class that adds all the nodes
    obj = GenerateTLSYAML(ui_json_file=ui_json_file)
    func_list = [obj.add_version,
                 obj.add_symbol_mapping,
                 obj.add_database,
                 obj.add_ethernet_nw,
                 obj.add_simulation_node,
                 obj.add_security_profile,
                 obj.add_logging]
    count = 0
    for functions in func_list:
        if functions():
            count+=1
        else:
            break
    if count == len(func_list):
        if obj.create_yaml():
            logger.info("All functions executed successfully, YAML file generated")
        else:
            logger.error("Failed to create TLS configuration.")
    else:
        logger.error("Failed to execute 1 or more functions")
        sys.exit(1)
    return 
    
if __name__ == "__main__":
    print("-"*80)
    generate()    
    print("-"*80)
