"""
Created by: SYARAGA
Date: 29-06-2023
Desc: API's for getting data from user_json file
"""

# Import section 
from Logger import LogHandler
import json 
import os

# String constanst 
from constants import JSP_COMMON_DATA
from constants import JSP_ECU
from constants import JSP_NAME
from constants import JSP_BROP
from constants import JSP_TEST_DATA
from constants import JSP_ECU_EXTRACT
from constants import JSP_TO_TEST
from constants import JSP_TO_ODXD
from constants import JSP_VARIANT

from constants import DATABASE

from constants import SUT
from constants import EXT_SIL
from constants import VTT
from constants import SILVER

from constants import EXT_VMODULE

from constants import SYSVAR
from constants import EXT_VSYSVAR

# Logging functions -----------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

'''
Base class that extracts data from the ui_json file
'''
class UI_Json_Parser():

    json_data = None

    def __init__(self,input_json_path):
        self.input_json_path = input_json_path
        
    # input file : ui_json file
    # output : loaded json_data
    def load_json(self):
       if self.json_data is None:
            try: 
                with open(self.input_json_path) as infile:
                    try:
                        # load file and copy key, values into json_data
                        json_data = json.load(infile)
                        # print("Json loaded succesfully")
                    except Exception as e:
                        print("Exception raise while load json", e)
                    finally:
                        # close files
                        infile.close()      
            except FileNotFoundError:
                    log_exception('Could not find the specified file: %s'%self.input_json_path)
            except IOError:
                    log_error("An error occurred while reading the file!")
            except Exception as e:
                    log_exception("An unexpected error occurred:", str(e))
            self.json_data = json_data         
       return self.json_data

    # Function to return paths with double backslash 
    # (YAML requiers either single front slash or double back slash for it's working)
    def raw_string(self,path):
        rw_string_filepath = None
        if path is not None:
             rw_string_filepath = path.encode('unicode_escape').decode()
        return rw_string_filepath

    # Logic to find files like arxml, vsysvar etc
    '''input - file_extension, folder_name
       output - filepath with particular extension
    '''
    def file_finding(self,extension,folder_name):
        file_list = []
        ecu_type = {}
        for root,dirs,files in os.walk(folder_name):
            for file in files:
                if file.endswith(extension):
                    filepath = os.path.join(root,file)
                    filepath = self.raw_string(filepath) 
                    file_list.append(filepath)
        if len(file_list)>0:
            ecu_type[extension] = file_list
        else:
            ecu_type[extension] = None
        log_debug("Local Directory: %s"%ecu_type)
        return ecu_type

    # Extracts the ecu_name from the ui_json file
    def read_ecu_name(self):
        json_data = self.load_json()
        ecu_name = None
        try:
            ecu_name = json_data[JSP_COMMON_DATA][JSP_ECU][0][JSP_NAME]
        except Exception as e:
            log_exception("An unexpected error occurred:", str(e)) 
        return ecu_name

    # Extracts the network_name from the ui_json file
    def get_nw_name(self):
        json_data = self.load_json()
        nw_name = None
        try:
            test_info = json_data[JSP_BROP][JSP_TEST_DATA]
            for key,value in test_info.items():
                test_data = value[JSP_TO_TEST]
                # Get the first key in the dictionary
                nw_name = list(test_data.keys())[0]
                # Stop after getting name of first network if there are 
                # multiple networks mentioned.
                break
        except Exception as e:
            log_exception("An unexpected error occurred:", str(e))
        return nw_name
    
    # Extracts the ecu_arxml_file from the ui_json file
    def get_ecu_arxml(self):
        json_data = self.load_json()
        ecu_arxml = None
        try:
            # ecu_arxml = json_data[JSP_BROP][JSP_ECU_EXTRACT]
            ecu_arxml = os.path.join(DATABASE,json_data[JSP_BROP][JSP_ECU_EXTRACT])
        except Exception as e:
            log_exception("An unexpected error occurred:", str(e))
        return ecu_arxml
    
    # Logic to find the vECU_type using .sil file
    def get_ecu_type(self):
        ecu_type = None
        for root,dirs,files in os.walk(SUT):
            for file in files:
                if file.endswith(EXT_SIL):
                    ecu_type = SILVER
                else:
                    ecu_type = VTT
        return ecu_type
    
    # get vmodule files directly from the folder SUT
    def get_vmodule_file(self):
        vmodule_file_virtual_target = self.file_finding(extension=EXT_VMODULE,folder_name=SUT)
        vmodule_virtual_target_vECU = []
        try:
            if vmodule_file_virtual_target[EXT_VMODULE] is not None:
                vmodule_virtual_target_vECU = vmodule_file_virtual_target[EXT_VMODULE]
            else:
                log_error('Did not find any vmodule files')
        except Exception as e:
            log_exception('Failed to add virtual target node: ',e)
        return vmodule_virtual_target_vECU

    # Get test_type from the ui_json file
    def get_test_type(self):
        json_data = self.load_json()
        test_type = None
        try:
            test_data = json_data[JSP_BROP][JSP_TEST_DATA]
            # Get the first key in dictionary
            test_type = list(test_data.keys())[0]
        except Exception as e:
            log_exception("An unexpected error occurred:", str(e))
        return test_type
    
    # Get vsysvar file from the folder directly
    def get_vsysvar_file(self):
        file = self.file_finding(extension=EXT_VSYSVAR,folder_name=SYSVAR)
        filepath = []
        try:
            if file[EXT_VSYSVAR] is not None:
                filepath = file[EXT_VSYSVAR]
            else:
                log_debug('Did not find any vsysvar files')
        except Exception as e:
            log_exception('Failed to add system variable node: ',e)
        return filepath
    
    # Get path to ODXD file
    def get_ecu_odxd(self):
        json_data = self.load_json()
        ecu_odx = None
        try:
            testtype = self.get_test_type()
            if testtype is not None:
                odxfile = json_data[JSP_BROP][JSP_TEST_DATA][testtype][JSP_TO_ODXD]
                ecu_odx = os.path.join(DATABASE,odxfile)
        except Exception as e:
            log_exception("An unexpected error occurred:", str(e))
        return ecu_odx
    
    # Get ECU variant name
    def get_ecu_variant(self):
        json_data = self.load_json()
        ecu_variant = None
        try:
            testtype = self.get_test_type()
            if testtype is not None:
                ecu_variant = json_data[JSP_BROP][JSP_TEST_DATA][testtype][JSP_VARIANT]
        except Exception as e:
            log_exception("An unexpected error occurred:", str(e))
        return ecu_variant
    

if __name__ == "__main__":
    a = UI_Json_Parser('sample_ui.json')
    print(a.get_vmodule_file())

