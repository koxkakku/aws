# Script to generate a compiled configuration and vTestunit to be used for 
# testing virtual ECU in CANoe4SW-SE.
# Argument: UserInput JSON file
# Generated artifacts: 
#   default.venvironment
#   *.vtestunit
# Usage:
# .\generate.ps1 path_to_user.json 
# .\generate.ps1 user_input.json 

# Tested on Powershell with CANoe4SW SE v17 sp3

# Tool defintions
$DIR_TOOL_INI='C:/NEST;'

# Update directory of CANoe4SW tools to Path
$env:Path=$DIR_TOOL_INI + $env:Path

$DIR_TOOL_NEST='C:/NEST/Executable;'

# Update directory of CANoe4SW tools to Path
$env:Path=$DIR_TOOL_NEST + $env:Path

$TOOL_INI_MAKE="generate_INI.exe"
$TOOL_NEST="nest.exe"


# Get user JSON as input
if ( !$args )
{
    Write-Output "Please provide a user INI file as input"
    exit 1
}
else
{
    $UI_INI_FILE=$args[0]
}

Write-Output "INI: $UI_INI_FILE"


# Separator text
$SEPARATOR="-"*80



# Smoke ------------------------------------------------------------------------

Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
Write-Output "Generating yaml file..."
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""

# Change working directory to Appropriate test suite

# Generate configuration YAML


# Generate configuration YAML
Write-Output "Generate Configuration NEST YAML file ./$UI_INI_FILE"
$process = Start-Process -NoNewWindow -Wait -PassThru -FilePath nest.exe -ArgumentList "-o5 -ini ./$UI_INI_FILE"
$retval=$process.ExitCode
if ($retval -ne 0){
    Write-Output "$SEPARATOR"
    Write-Output "Error during generation of  YAML"
    Write-Output "$SEPARATOR"
    exit 1
}

