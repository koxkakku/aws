import io
import os
import sys
import json
import zipfile
import logging
import argparse
from requests import post, get, status_codes

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')    



def parse_args():
    parser=argparse.ArgumentParser(description="Send Status to Simulation Runtime Backend")
    
    subparser = parser.add_subparsers(dest='command')
    
    send_state = subparser.add_parser("send_state")
    send_state.add_argument('-m', '--message', type=str, help='TBD', required = True)
    send_state.add_argument('-n', '--job_name', type=str, help='TBD', required = True)
    send_state.add_argument('-p', '--job_project_name', type=str, help='TBD', required = True)
    send_state.add_argument('--stage', type=str, help='TBD',default= "dev")
    send_state.add_argument('-s', '--status', type=str, help='TBD',default= "success")
    send_state.add_argument('-f', '--is_failed', type=bool, help='TBD',default= False)

    download_vecu = subparser.add_parser("download_vecu")
    download_vecu.add_argument('-d', '--diagnostic_name', type=str, help="TBD", required=True)
    download_vecu.add_argument('-o', '--output', type=str, help="TBD", required=True)

    upload_csd = subparser.add_parser("upload_csd")
    upload_csd.add_argument('-j', '--json', type=str, help="TBD", required=True)
    upload_csd.add_argument('-i', '--input', type=str, help="TBD", required=True)

    args=parser.parse_args()
    
    return args  

TESTRUN_ID = os.getenv('TESTRUN_ID')
SIMULATION_RUNTIME_BACKEND_KEY = os.getenv('SIMULATION_RUNTIME_BACKEND_KEY')
SIMULATION_RUNTIME_BACKEND_URL = os.getenv('SIMULATION_RUNTIME_BACKEND_URL')


def send_state(message, job_name, job_project_name, status = "success", is_failed = False, stage = "dev"):
    logger.info("Start sending state")
    result = post(
        url=f"{SIMULATION_RUNTIME_BACKEND_URL}/simulation/{TESTRUN_ID}/state",
        json={
            "message": message,
            "stage": stage,
            "status": status,
            "is_failed": is_failed,
            "job_name": job_name,
            "job_project_name": job_project_name
        },
        headers={"Authorization": SIMULATION_RUNTIME_BACKEND_KEY})

    if result.status_code == status_codes.codes['ok']:
        logger.info(f"{result.status_code}: {result.content}")
    else:
        logger.error(f"{result.status_code}: {result.content}")


def download_vecu(args):
    logger.info("Start downloading vecu")
    
    logger.info("Get vecu presigned s3 download url.")
    logger.info(f"URL: {SIMULATION_RUNTIME_BACKEND_URL}/simulation/{TESTRUN_ID}/vecu-version/{args.diagnostic_name}")
    result = get(
        url=f"{SIMULATION_RUNTIME_BACKEND_URL}/simulation/{TESTRUN_ID}/vecu-version/{args.diagnostic_name}",
        headers={"Authorization": SIMULATION_RUNTIME_BACKEND_KEY})
    
    result_json = json.loads(result.content)
    if result.status_code != status_codes.codes['ok']:
        logger.error(f"{result.status_code}: {result.content}")
        send_state(result_json["message"], "download_vecu",  "", status=result_json["status"], is_failed=True)
    else:
        logger.info(f"{result.status_code}: {result.content}")
        send_state(result_json["message"], "download_vecu",  "")
        
        logger.info("Download vecu from presigned s3 download link.")
        result = get(
            url=result_json["data"]["url"],
            stream=True
        )
        
        if result.status_code == status_codes.codes['ok']:
            logger.info(f"{result.status_code}")
            send_state("Downloading completed", "download_vecu",  "")
        else:
            logger.error(f"{result.status_code}")
            send_state("Failed downlading vecu", "download_vecu",  "", status=str(result.status_code), is_failed=True)
        
        logger.info(f"Downloaded files saved here: {args.output}")
        os.makedirs(args.output, exist_ok=True)
        zip_file = zipfile.ZipFile(io.BytesIO(result.content))
        zip_file.extractall(args.output)

        logger.info("Downloading vecu finished")


def upload_comiled_simulation_data(args):
    logger.info("Start uploading compiled simulation data")

    json_data = json.loads(args.json)
        
    logger.info("Get compiled simulation data presigned s3 upload url.")
    result = post(
        url=f"{SIMULATION_RUNTIME_BACKEND_URL}/simulation/{TESTRUN_ID}/compiled-simulation-data",
        json=json_data,
        headers={"Authorization": SIMULATION_RUNTIME_BACKEND_KEY})
    
    result_json = json.loads(result.content)
    if result.status_code != status_codes.codes['ok']:
        logger.error(f"{result.status_code}: {result.content}")
        send_state(result_json["message"], "upload_comiled_simulation_data",  "", status=result_json["status"], is_failed=True)
    else:
        logger.info(f"{result.status_code}: {result.content}")
        send_state(result_json["message"], "upload_comiled_simulation_data",  "")
            
        logger.info("Upload compiled simulation data to presigned s3 upload link.")

        files = {"file": open(args.input,"rb")}
        result = post(
            url=result_json["data"]["url"],
            data=result_json["data"]["fields"],
            files=files
        )
        
        if result.status_code == status_codes.codes['ok']:
            logger.info(f"{result.status_code}: {result.content}")
            send_state("Upload completed", "upload_comiled_simulation_data",  "")
        else:
            logger.error(f"{result.status_code}: {result.content}")
            send_state("Failed uploading data", "upload_comiled_simulation_data",  "", status=str(result.status_code), is_failed=True)

def main():
    args = parse_args()

    try:
        if args.command == "send_state":
            send_state(args.message, args.job_name, args.job_project_name, args.status, args.is_failed, args.stage)
        elif args.command == "download_vecu":
            download_vecu(args)
        elif args.command == "upload_csd":
            upload_comiled_simulation_data(args)
    except Exception as e:
        logger.error(f"Something went wrong in main! Error: {e}")
        sys.exit(f"Something went wrong in main! Error: {e}")


if __name__ == "__main__":
    main()
