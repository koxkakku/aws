To generate the VEXECPLAN files, run generate_vexecplan.py file, the usage is as below

usage: generate_vexecplan.py [-h] -u UI_JSON

Generate the vexecplan file

options:
  -h, --help            show this help message and exit
  -u UI_JSON, --ui_json UI_JSON
                        path to the sample brop_ui_json file


NOTE:
ui.json file is used for testing purpose and not finalised one!
TestModule.xml and smoke_test.vexecplan files are used for reference here for the smoke test use case
