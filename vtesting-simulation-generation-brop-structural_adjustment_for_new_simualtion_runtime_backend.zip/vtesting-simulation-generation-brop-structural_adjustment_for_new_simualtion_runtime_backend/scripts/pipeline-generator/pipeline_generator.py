import os
import sys
import json
import logging
import argparse

from pathlib import Path
from requests import get

logger = logging.getLogger(__name__)


class PipelineWriter:
    @staticmethod
    def parent_job_template():
        parent_job_template = """
stages:
  - integrate-simulations
.basic:
  allow_failure: false
  
 # default script for all jobs before executing 
before_script:
  # configure poetry to use the artifactory repository
  - poetry config http-basic.oakwowt-publish $JFROG_USER $JFROG_TOKEN
  - poetry config http-basic.oakwowt $JFROG_USER $JFROG_TOKEN
  # install
  - poetry install --no-root
  - source `poetry env info --path`/bin/activate
  # execute report script to backend
  - echo "job $CI_JOB_NAME started in stage $CI_JOB_STAGE"
  - python ./scripts/backend-client/backend-client.py -v "$LOG_LEVEL" -e "$DEPLOY_ENV" send-state --message "$CI_JOB_NAME Job started"

# default after script with reporting job done
after_script: 
     # configure poetry to use the artifactory repository
    - poetry config http-basic.oakwowt-publish $JFROG_USER $JFROG_TOKEN
    - poetry config http-basic.oakwowt $JFROG_USER $JFROG_TOKEN
    # install
    - poetry install --no-root
    - source `poetry env info --path`/bin/activate
    - echo "job $CI_JOB_NAME finished in stage $CI_JOB_STAGE with status $CI_JOB_STATUS"
    - >
      if [ $CI_JOB_STATUS == 'success' ]; then
         python ./scripts/backend-client/backend-client.py -v "$LOG_LEVEL" -e "$DEPLOY_ENV" send-state --status "successful" --message "$CI_JOB_NAME Job successful executed"
      else 
         python ./scripts/backend-client/backend-client.py -v "$LOG_LEVEL" -e "$DEPLOY_ENV" send-state --status "failed" --is_failed True --message "$CI_JOB_NAME Job failed TODO Find Reason"
      fi
 
  

"""
        return parent_job_template

    @staticmethod
    def child_pipeline_job_template(instance_type, test_type, branch2integrate):
        child_pipeline_job_template = f"""

trigger-{test_type.lower()}-integration-pipeline: 
  stage: integrate-simulations 
  trigger:
    include:
        - project: 'oak/vtesting/vtesting-simulation-generation-{instance_type.lower()}'
          file: {test_type.lower()}/{test_type.lower()}.gitlab-ci.yml
          ref: '{branch2integrate}'
    strategy: depend
    forward:
      pipeline_variables: true
"""
        return child_pipeline_job_template


class PipelineGenerator:
    def __init__(self):
        self.child_pipeline_name = "trigger-integration-pipelines.gitlab-ci.yml"

    def generate_child_pipelines(self, instance_type, test_environment_types, branch2integrate):
        try:
            logger.debug("Generating child pipelines")
            with open(self.child_pipeline_name, "w+") as f:
                f.write(PipelineWriter.parent_job_template())
                for test_environment_type in test_environment_types:
                    logger.debug("Processing %s",test_environment_type )
                    f.write(
                        PipelineWriter.child_pipeline_job_template(
                            instance_type, test_environment_type, branch2integrate
                        )
                    )

            logger.debug(
                "Created child pipelines at %s: %s",
                os.path.abspath(self.child_pipeline_name),
                Path(self.child_pipeline_name).read_text(),
            )

        except Exception as e:
            print(f"Something went wrong in generateChildPipelines! Error: {e}")
            sys.exit(f"Something went wrong in generateChildPipelines! Error: {e}")


def parse_args():
    parser = argparse.ArgumentParser(description="Pipeline Generator from User Json")

    # global arguments
    parser.add_argument("-v", "--verbose", type=str, help="verbose level INFO|DEBUG|ERROR", default="INFO")

    parser.add_argument("-i", "--instance", type=str, help="instance to add", default="INFO")

    parser.add_argument("-t", "--type", nargs="+", help="type to add", required=True)
    args = parser.parse_args()

    return args


def main():
    args = parse_args()

    if args.verbose == "DEBUG":
        loglevel = logging.DEBUG
    elif args.verbose == "ERROR":
        loglevel = logging.ERROR
    else:
        loglevel = logging.INFO

    logging.basicConfig(level=loglevel, format="%(levelname)s: %(message)s")

    try:
        logger.debug("the args are:")
        for arg in vars(args):
            logger.debug(f"{arg} is {getattr(args, arg)}")

        generator = PipelineGenerator()
        generator.generate_child_pipelines(args.instance, args.type)

        logger.debug("Generation Done")

    except Exception as e:
        print(f"Something went wrong in main! Error: {e}")
        sys.exit(f"Something went wrong in main! Error: {e}")


if __name__ == "__main__":
    main()
