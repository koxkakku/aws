# Script to generate a compiled configuration and vTestunit to be used for 
# testing virtual ECU in CANoe4SW-SE.
# Argument: UserInput JSON file
# Generated artifacts: 
#   default.venvironment
#   *.vtestunit
# Usage:
# .\generate.ps1 path_to_user.json 
# .\generate.ps1 user_input.json 

# Tested on Powershell with CANoe4SW SE v17 sp3

# Tool defintions
$DIR_TOOL_C4SW='C:/Program Files/Vector CANoe4SW Server Edition 17/Exec64;'
# Update directory of CANoe4SW tools to Path
$env:Path=$DIR_TOOL_C4SW + $env:Path

$TOOL_ENV_MAKE="environment-make.exe"
$TOOL_TESTUNIT_MAKE="test-unit-make.exe"
$TOOL_C4SW="canoe4sw-se.exe"

# Get user JSON as input
if ( !$args )
{
    Write-Output "Please provide a user JSON file as input"
    exit 1
}
else
{
    $UI_JSON_FILE=$args[0]
}

Write-Output "JSON: $UI_JSON_FILE"

# Local directories
$DIR_RESULTS="Results"
$DIR_SUITE="SmokeTests"
$DIR_VEXECPLAN="vExecutionPlan"

# Local Files
$FILE_CONFIG="$DIR_SUITE/output.yaml"
$FILE_VTU_YML="$DIR_SUITE/SmokeTest.vtestunit.yaml"
$FILE_VEXECPLAN="$DIR_VEXECPLAN/output.vexecplan"

# Compiled data
$COMPILED_VENV="Default.venvironment"
$COMPILED_VTU="SmokeTest.vtestunit"

# Separator text
$SEPARATOR="-"*80


# Pre-Run ----------------------------------------------------------------------
# Delete old compiled files
if (Test-Path $COMPILED_VENV)
{
    Write-Output "Deleting $COMPILED_VENV"
    Remove-Item -Recurse -Force $COMPILED_VENV
}
if (Test-Path $COMPILED_VTU)
{
    Write-Output "Deleting $COMPILED_VTU"
    Remove-Item -Recurse -Force $COMPILED_VTU
}


# Smoke ------------------------------------------------------------------------

Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
Write-Output "Generating $FILE_CONFIG..."
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""

# Change working directory to Appropriate test suite
Set-Location $DIR_SUITE

# Generate configuration YAML
Write-Output "Generate Configuration YAML file ../$UI_JSON_FILE"
$process = Start-Process -NoNewWindow -Wait -PassThru -FilePath ".\generate_yaml.exe" -ArgumentList "-u ../$UI_JSON_FILE"
$retval=$process.ExitCode
if ($retval -ne 0){
    Write-Output "$SEPARATOR"
    Write-Output "Error during generation of configuration YAML"
    Write-Output "$SEPARATOR"
    exit 1
}
# Go back to root directory
Set-Location ..

# # SKIP THIS since *.vtestunit.yaml is constant for a given version of the tool
# Write-Output ""
# Write-Output "$SEPARATOR"
# Write-Output ""
# Write-Output "Generating $FILE_VTU_YML..."
# Write-Output ""
# Write-Output "$SEPARATOR"
# Write-Output ""
# # Generate vtestunit yaml file
# Write-Output "Vtestunit file: $FILE_VTU_YML"

Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
Write-Output "Compiling $FILE_CONFIG..."
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
# Compile configuration YAML to create Default.venvironment
$process = Start-Process -NoNewWindow -Wait -PassThru -FilePath $TOOL_ENV_MAKE -ArgumentList $FILE_CONFIG
$retval=$process.ExitCode
if ($retval -ne 0) 
{
    Write-Output "$SEPARATOR"
    Write-Output "Error during generation of default vEnvironment"
    Write-Output "$SEPARATOR"
    exit 1
}

Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
Write-Output "Compiling $FILE_VTU_YML..."
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
# Compile *.vtestunit.yaml to create vtestunit
$process = Start-Process -NoNewWindow -Wait -PassThru -FilePath $TOOL_TESTUNIT_MAKE -ArgumentList "$FILE_VTU_YML -e $COMPILED_VENV"
$retval=$process.ExitCode
if ($retval -ne 0) 
{
    Write-Output "$SEPARATOR"
    Write-Output "Error during generation of vTestunit"
    Write-Output "$SEPARATOR"
    exit 1
}

# Generation of vexecplan
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
Write-Output "Generating VEXECPLAN..."
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
# Change working directory
Set-Location $DIR_VEXECPLAN

# Generate configuration YAML
Write-Output "Generate vExecution plan"
$process = Start-Process -NoNewWindow -Wait -PassThru -FilePath ".\test_execution_plan.exe" -ArgumentList "-u ../$UI_JSON_FILE"
$retval=$LASTEXITCODE
if ($retval -ne 0) 
{
    Write-Output "$SEPARATOR"
    Write-Output "Error during generation of vexecplan"
    Write-Output "$SEPARATOR"
    exit 1
}
# Go back to root directory
Set-Location ..

# Execution
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
Write-Output "Executing tests..."
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
$process = Start-Process -NoNewWindow -Wait -PassThru -FilePath $TOOL_C4SW -ArgumentList "$COMPILED_VENV --test-unit $COMPILED_VTU -d $DIR_RESULTS --test-execution-plan $FILE_VEXECPLAN"
# $retval=$process.ExitCode
# if($retval -ne 0) 
# {
#     Write-Output "$SEPARATOR"
#     Write-Output "Error during execution of test in CANoe4SW: $retval"
#     Write-Output "$SEPARATOR"
#     exit 1
# }
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""


# End of File ------------------------------------------------------------------
