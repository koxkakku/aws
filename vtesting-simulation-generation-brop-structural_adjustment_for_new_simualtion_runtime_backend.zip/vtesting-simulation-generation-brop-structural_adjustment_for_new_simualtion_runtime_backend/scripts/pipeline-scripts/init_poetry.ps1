# Function to install Poetry
function Install-Poetry {
    try {
        py -V:3.9 -m pip install poetry
        Write-Output "Poetry installed successfully."
    } catch {
        Write-Error "Failed to install Poetry: $_"
        exit 1
    }
}

# Function to configure Poetry with credentials
function Configure-Poetry {
    param (
        [string]$user,
        [string]$token
    )

    try {
        poetry config http-basic.oakwowt-publish $user $token
        poetry config http-basic.oakwowt $user $token
        Write-Output "Poetry configured successfully."
    } catch {
        Write-Error "Failed to configure Poetry: $_"
        exit 1
    }
}

# Function to install dependencies using Poetry
function Install-Dependencies {
    try {
        poetry install --no-root -vvv
        Write-Output "Dependencies installed successfully."
    } catch {
        Write-Error "Failed to install dependencies: $_"
        exit 1
    }
}

# Main script
try {
    # Ensure Python 3.9 is used
    $pythonVersion = py -V:3.9 --version
    Write-Output "Python version: $pythonVersion"

    # Install Poetry
    Install-Poetry

    # Display poetry environment information
    poetry env info

    # Check if JFrog environment variables are set
    if (-not $env:JFROG_USER -or -not $env:JFROG_TOKEN) {
        Write-Error "JFROG_USER and/or JFROG_TOKEN environment variables are not set."
        exit 1
    }

    # Configure Poetry with JFrog credentials
    Configure-Poetry -user $env:JFROG_USER -token $env:JFROG_TOKEN

    # Install dependencies
    Install-Dependencies

} catch {
    Write-Error "An error occurred: $_"
    exit 1
}
