# Function to perform nslookup and check if it's successful
function Test-Nslookup {
    param (
        [string]$Domain
    )
    try {
        $result = nslookup $Domain 2>&1
        $success = $result -contains "UnKnown can't find"
		
        return $success
    } catch {
        return $false
    }
}

# Domain to lookup
$domain = "mercedes-benz.com"
$dnsServerToSet = "172.16.0.2"

# Check if nslookup is successful
if (-not (Test-Nslookup -Domain $domain)) {
    # If nslookup failed, execute the following commands
	Write-Host "Could not resolve $domain adding $dnsServerToSet as DNS server"
    $adapter = Get-NetAdapter | Where-Object {$_.Status -eq "Up"}
	
    $secondaryDNS = (Get-NetRoute | Where-Object { $_.DestinationPrefix -eq '0.0.0.0/0' }).NextHop
    $dnsServers = "172.16.0.2", $secondaryDNS
    Set-DnsClientServerAddress -ServerAddresses $dnsServers -InterfaceIndex $adapter.InterfaceIndex
    Get-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex | Format-Table -Property InterfaceAlias, ServerAddresses
	Write-Host "New DNS set"
	ipconfig /all
	
} else {
    Write-Host "nslookup for $domain was successful."
}
