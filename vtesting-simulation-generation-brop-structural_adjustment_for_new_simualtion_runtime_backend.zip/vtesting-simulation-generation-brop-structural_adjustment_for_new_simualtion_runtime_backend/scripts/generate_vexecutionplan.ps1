# Script to generate a compiled configuration and vTestunit to be used for 
# testing virtual ECU in CANoe4SW-SE.
# Argument: UserInput JSON file
# Generated artifacts: 
#   default.venvironment
#   *.vtestunit
# Usage:
# .\generate.ps1 path_to_user.json 
# .\generate.ps1 user_input.json 

# Tested on Powershell with CANoe4SW SE v17 sp3

# Tool defintions
$DIR_TOOL_C4SW='C:/Program Files/Vector CANoe4SW Server Edition 17/Exec64;'
# Update directory of CANoe4SW tools to Path
$env:Path=$DIR_TOOL_C4SW + $env:Path

$TOOL_ENV_MAKE="environment-make.exe"
$TOOL_TESTUNIT_MAKE="test-unit-make.exe"
$TOOL_C4SW="canoe4sw-se.exe"

# Get user JSON as input
if ( !$args )
{
    Write-Output "Please provide a user JSON file as input"
    exit 1
}
else
{
    $UI_JSON_FILE=$args[0]
}

Write-Output "JSON: $UI_JSON_FILE"

# Local directories
$DIR_RESULTS="Results"
$DIR_SUITE="SmokeTests"
$DIR_VEXECPLAN="vExecutionPlan"

# Local Files
$FILE_CONFIG="$DIR_SUITE/output.yaml"
$FILE_VTU_YML="$DIR_SUITE/SmokeTest.vtestunit.yaml"
$FILE_VEXECPLAN="$DIR_VEXECPLAN/output.vexecplan"

# Compiled data
$COMPILED_VENV="Default.venvironment"
$COMPILED_VTU="SmokeTest.vtestunit"

# Separator text
$SEPARATOR="-"*80


# Pre-Run ----------------------------------------------------------------------

# Change working directory
Set-Location $DIR_VEXECPLAN

# Generate configuration YAML
Write-Output "Generate vExecution plan"
python.exe test_execution_plan.py -u "../$UI_JSON_FILE"
$retval=$LASTEXITCODE
if ($retval -ne 0) 
{
    Write-Output "$SEPARATOR"
    Write-Output "Error during generation of vexecplan"
    Write-Output "$SEPARATOR"
    exit 1
}