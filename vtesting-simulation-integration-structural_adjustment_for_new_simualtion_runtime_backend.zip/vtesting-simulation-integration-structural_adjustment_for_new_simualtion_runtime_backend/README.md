# vTesting Integration Pipeline (draft) - [Confluence](https://wiki.swf.i.mercedes-benz.com/x/k2gAJg)

1. [Introduction](#introduction)
2. [Pipeline execution](#pipeline-execution-of-the-integration-pipeline)
    1. [Integration pipeline](#integration)
    2. [Deployment pipeline](#deployment)
    4. [Reporting/Clean up](#reportingclean-up)
3. [Pipeline variables](#pipeline-variables)
4. [Branches](#branches)
    1. [Main](#branch-main)
    2. [Dev-Main](#branch-dev-main)
    3. [Feature-Branch](#branch-feature-branch)
5. [Folder structure](#folder-structure)
6. [Concept](#concept)
7. [Stages](#stages)

## Introduction

This repository is the starting point of the vTesting project. It triggers the Simulation integration and deployment pipelines.

![Overall Workflow](./docs/images/overview_workflow.png)

1. Configuration
    - Configuring vECUs, Packages, Testing Capabilities, Pipeline in the MB.OS Portal. The result is a json string with a configuration to create the testing environment and execute defined Tests

2. Trigger
    - After the the creation of the the json configuration, the MB.OS Portal triggers the integration pipeline in  this repository. the Pipeline trigger by new/updated ECU version, manual trigger, new/updated Package version, Change in Simulation Configuration
    Goal: Interface to trigger the pipeline when something is changing

3. Integration
    - Creating Compiled Simulation Data, used to deploy.
Goal: Simulation data that can be deployed and Tests that can be executed 

4. Deployment
    - Deployment to the Cloud
Create a Deployment configuration, Cluster Creation, node creation, Load Balancing, starting the simulation
Goal: A running simulation with an interface to execute tests

5. Testing
    - Execution of the Tests
Goal: Test Results

6. Reporting
    - Reporting
Goal: Reporting Test Results  

7. Cleanup
    - Clean Up
Goal: Clean up all not needed resources.

## Pipeline Execution of the integration pipeline

<img src="./docs/diagramms/overall_architecture.drawio.svg">

### Integration

The main integration pipeline starts with splitting the to intigrateing simulations into smaller child pieplines.
From the user json it creates and triggers for each vECU and testing type (ECU1->BROP->NEST, BROP->nts, FROP->xxx, etc) a child pipeline:
-    [vtesting-simulation-generation-brop](https://git.swf.daimler.com/oak/vtesting/vtesting-simulation-generation-brop)  
-    [vtesting-simulation-generation-frop](https://git.swf.daimler.com/oak/vtesting/vtesting-simulation-generation-frop)

TODO: SYSTEM LEVEL. multiple vecu in one system.

### Deployment

After the child pipelines are triggered the pipeline waits till the simulations are generated and triggers the deployment pipeline in the repository:
-    [vtesting-deployment](https://git.swf.daimler.com/oak/vtesting/vtesting-simulation-generation-brop).

### Reporting/Clean up

TODO: Report Concept

## Pipeline variables

|Variable                           |Description                                            |Default value  |
|---                                |---                                                    |---            |
| GENERATION_BRANCH_TO_EXECUTE      | In development which branch of the  [vtesting-simulation-generation-brop](https://git.swf.daimler.com/oak/vtesting/vtesting-simulation-generation-brop) should be executed    | "main"        |
| LOG_LEVEL                         | Logging level of the scripts "DEBUG\|INFO\|ERROR"     | INFO          |

## Branches

<img src="./docs/diagramms/gitlab_branch_workflow.drawio.svg">

### Branch "main"

Main Branch for production. Pipeline triggers the pipeline in the main branch in its child pipelines. Persistent Branch.
  
### Branch "dev-main"

main dev branch with all features merged. ready for testing befor merge to main branch.Pipeline Triggers by default the dev-main or a specific branch in child pipelines if provided by variable. Persistent Branch.
 
### Branch "feature-branch"

Feature Branch with new features of vtesting-simualtion-integration. Triggers the pipeline in the dev-main branch in its child pipelines. Deleted after future is merged.

## Folder structure

|Folder     |Description                                                    |
|---        |---                                                            |
|scripts    | Global scripts used by main pipeline or by all child pipeline |
|docs       | Folder with documentation for this repository                 |

## Concept

TBD

### Stages

- ParseJobParameter
- SimulationIntegration
- IntegrationCheck
- Report
- Deployment
