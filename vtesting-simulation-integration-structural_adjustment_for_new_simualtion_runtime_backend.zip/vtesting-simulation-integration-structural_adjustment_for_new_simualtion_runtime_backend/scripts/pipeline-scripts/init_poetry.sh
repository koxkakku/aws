#!/bin/bash

# Check if environment variables are set
if [ -z "$JFROG_USER" ]; then
    echo "JFROG_USER is not set. Exiting."
    exit 1
fi

if [ -z "$JFROG_TOKEN" ]; then
    echo "JFROG_TOKEN is not set. Exiting."
    exit 1
fi

# Configure poetry to use the artifactory repository
poetry config http-basic.oakwowt-publish $JFROG_USER $JFROG_TOKEN
if [ $? -ne 0 ]; then
    echo "Failed to configure poetry for oakwowt-publish. Exiting."
    exit 1
fi

poetry config http-basic.oakwowt $JFROG_USER $JFROG_TOKEN
if [ $? -ne 0 ]; then
    echo "Failed to configure poetry for oakwowt. Exiting."
    exit 1
fi

# Install dependencies try 5 tiems . if error end
for i in {1..5}; do
    poetry install  --no-root && break || sleep 10
done

if [ $? -ne 0 ]; then
    echo "Failed to install dependencies with poetry. Exiting."
    exit 1
fi

# Print job information
echo "Poetry virtual environment activated"
