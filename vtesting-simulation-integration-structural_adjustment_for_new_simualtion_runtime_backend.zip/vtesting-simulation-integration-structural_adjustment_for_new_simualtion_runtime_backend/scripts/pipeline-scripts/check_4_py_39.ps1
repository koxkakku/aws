# Check if Python is installed
$pythonInstalled = $false
try {
    $pythonVersion = python --version 2>&1
    $pythonInstalled = $true
} catch {
    Write-Output "Python is not installed."
}

# Check the Python version
if ($pythonInstalled) {
    if ($pythonVersion -like "*Python 3.9*") {
        Write-Output "Python 3.9 is already installed."
    } else {
        Write-Output "Python is installed, but it's not version 3.9."
        # Install Python 3.9 (see next step)
    }
} else {
    # Python is not installed, install Python 3.9 (see next step)
}

# Function to download and install Python 3.9
function Install-Python39 {
    $installerPath = ".\python-3.9.0.exe" # specify the path for the installer
    $installerUrl = "https://www.python.org/ftp/python/3.9.13/python-3.9.13-amd64.exe"  # Python 3.9 installer URL
	$PythonInstallPath='C:\Program Files\Python39'

    try {
        # Download the installer
        Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath
        Write-Output "Python 3.9 installer downloaded successfully."

        # Run the installer
        Start-Process -FilePath $installerPath -Args "/quiet InstallAllUsers=1 PrependPath=1" -Wait
        Write-Output "Python 3.9 has been installed."
		
		Remove-Item $installerPath
		$env:Path += ";$PythonInstallPath;$PythonInstallPath\Scripts\"
		Write-Host "Path variables set to:"
		$env:Path -split ';'
	
    } catch {
        Write-Error "Failed to download or install Python 3.9. Error: $_"
    }
}

# Call the function to install Python 3.9 if necessary
if (!$pythonInstalled -or !($pythonVersion -like "*Python 3.9*")) {
    Install-Python39
}
