import os
import sys
from uuid import UUID
import logging
current_dir = os.path.dirname(os.path.abspath(__file__))
# Get the parent directory by going one level up
sys.path.append(current_dir)

import lib

from lib import global_parse_args,aws_token_manager,log_config

from pprint import pprint, pformat
import token_master_auth
from importlib.metadata import version

import vtprun_client_py

from vtprun_client_py import (
    ApiException,
    SimulationStateSetResponseAllOfData,
)

# Get the filename without the extension and use it for the logger's name. else if we take __name__ main will be shown
logger_name = os.path.splitext(os.path.basename(__file__))[0]
logger = log_config.setup_logging(logger_name)

def get_states():
    try:
        # import global args
        parser = global_parse_args.create_global_parser()

        parsed_inputs = parser.parse_args()

        # logging options
        if parsed_inputs.verbose == "DEBUG":
            loglevel = logging.DEBUG
        elif parsed_inputs.verbose == "ERROR":
            loglevel = logging.ERROR
        else:
            loglevel = logging.INFO

        logger.setLevel(loglevel)
        
        # output all inputs for debug
        logger.debug("the inputs are:")
        for arg in vars(parsed_inputs):
            logger.debug("{} is {}".format(arg, getattr(parsed_inputs, arg)))

        # get proxy address if there is one
        proxy = os.getenv("HTTP_PROXY", None)

        # set address of the Backend
        configuration = vtprun_client_py.Configuration(
            host=parsed_inputs.backend_url,
            access_token=aws_token_manager.get_access_token(
                parsed_inputs.test_run_id, parsed_inputs.project, parsed_inputs.environment
            ),
        )

        logger.debug("token is %s", configuration.access_token)

        if proxy:
            configuration.proxy = proxy
            with vtprun_client_py.ApiClient(configuration) as api_client:
                api_instance = vtprun_client_py.IntegrationApi(api_client)
            logger.debug("Calling get_states_from_backend")
            response: SimulationStateSetResponseAllOfData = api_instance.integrations_integration_id_states_get(
                parsed_inputs.test_run_id
            )
            logger.info("Response: %s", pformat(response))
    except ApiException as e:
        print("Exception when calling UploadArtifactsApi->artifacts_artifact_type_download_post: %s\n" % e)


if __name__ == "__main__":
    try:
        get_states()

    except Exception as e:
        sys.exit(f"Something went wrong in __name__! Error: {e}")
