import os
import sys
import logging

# add local lib
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

from lib import global_parse_args,aws_token_manager,log_config

from pprint import pprint, pformat
from importlib.metadata import version

import vtprun_client_py
from vtprun_client_py import SimulationState, SimulationStateResponse


# Get the filename without the extension and use it for the logger's name. else if we take __name__ main will be shown
logger_name = os.path.splitext(os.path.basename(__file__))[0]
logger = log_config.setup_logging(logger_name)

def send_state():
    # import global args
    parser = global_parse_args.create_global_parser()

    # add args for send state
    parser.add_argument("--message", type=str, help="Message with a discription what failed", required=True)
    parser.add_argument(
        "--is_failed", type=bool, help="Status of the job failed=True or success=False", required=False, default=False
    )
    parser.add_argument(
        "--stage",
        type=str,
        help="The stage the simulation integration is passing",
        required=False,
        default=os.getenv("CI_JOB_STAGE"),
    )
    parser.add_argument(
        "--job_name",
        type=str,
        help="The job the simulation integration is passing",
        required=False,
        default=os.getenv("CI_JOB_NAME"),
    )
    parser.add_argument(
        "--job_project_name",
        type=str,
        help="The project name the job of the simulation integration is passing",
        required=False,
        default=os.getenv("CI_PROJECT_NAME"),
    )
    parser.add_argument(
        "--status", type=str, help="Current status of the integration", required=False, default="successful"
    )
    parsed_inputs = parser.parse_args()

    # logging options
    if parsed_inputs.verbose == "DEBUG":
        loglevel = logging.DEBUG
    elif parsed_inputs.verbose == "ERROR":
        loglevel = logging.ERROR
    else:
        loglevel = logging.INFO
        
    logger.setLevel(loglevel)

    # output all inputs for debug
    logger.debug("the inputs are:")
    for arg in vars(parsed_inputs):
        logger.debug("{} is {}".format(arg, getattr(parsed_inputs, arg)))

    # get proxy address if there is one
    proxy = os.getenv("HTTP_PROXY", None)

    # set address of the Backend
    configuration = vtprun_client_py.Configuration(
        host=parsed_inputs.backend_url,
        access_token=aws_token_manager.get_access_token(
            parsed_inputs.test_run_id, parsed_inputs.project, parsed_inputs.environment
        ),
    )

    logger.debug("token is %s", configuration.access_token)

    if proxy:
        configuration.proxy = proxy

    # main functions
    try:
        with vtprun_client_py.ApiClient(configuration) as api_client:
            api_instance = vtprun_client_py.IntegrationApi(api_client)

        # sent command
        logger.debug("Calling sent_status_to_backend")
        current_state: SimulationState = SimulationState(
            stage=parsed_inputs.stage,
            status=parsed_inputs.status,
            is_failed=parsed_inputs.is_failed,
            job_name=parsed_inputs.job_name,
            job_project_name=parsed_inputs.job_project_name,
            message=parsed_inputs.message,
        )

        logger.info("Sending states for testrun ID %s: State: %s", parsed_inputs.test_run_id, current_state)

        response: SimulationStateResponse = api_instance.integrations_integration_id_states_post(
            integration_id=parsed_inputs.test_run_id, simulation_state=current_state
        )

        if response.status != "successful":
            logger.error("Response for sent status was not succesfull, got response: {response}")
            sys.exit(1)

        logger.info("Current state successful sent")

        # the pipeline is successful remove token
        if parsed_inputs.stage == "finished-integration":
            logger.info("State is finished-integration -> Integration finished. removing token from aws")
            aws_token_manager.remove_access_token(
                parsed_inputs.test_run_id, getattr(parsed_inputs, "project"), getattr(parsed_inputs, "environment")
            )

    except Exception as e:
        logger.error("Could not sent status, error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    try:
        send_state()

    except Exception as e:
        logger.error("Not handled exception, got: {e}")
        sys.exit(1)