import boto3
from botocore.exceptions import ClientError
import os
import time


from token_master_auth import  AuthTokenManager
import logging

from .log_config import setup_logging

from jose import ExpiredSignatureError
import json

logger = setup_logging(__name__)

# set boto logger to info
boto3_logger = logging.getLogger("botocore")
boto3_logger.setLevel(logging.INFO)

#
# Function to check if the secret is available
def is_secret_available(client, secret_name):
    logger.debug("Calling is_secret_available")
    try:
        client.get_secret_value(SecretId=secret_name)
        return True
    except ClientError as e:
        return False


# Function to wait for the secret with a timeout
def wait_for_secret(client, secret_name, timeout=10):
    logger.debug("Calling wait_for_secret")
    start_time = time.time()
    while not is_secret_available(client, secret_name):
        if time.time() - start_time > timeout:
            raise TimeoutError(f"Timed out waiting for secret '{secret_name}' to become available.")
        print(f"Waiting for secret '{secret_name}' to be available...")
        time.sleep(5)  # Wait for 5 seconds before retrying
    print(f"Secret '{secret_name}' is now available.")


# Function to check if the secret is deleted
def is_secret_deleted(client, secret_name):
    logger.debug("Calling is_secret_deleted")
    try:
        client.get_secret_value(SecretId=secret_name)
        return False  # Secret still exists
    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceNotFoundException":
            return True  # Secret is deleted
        return False  # Secret still exists


# Function to wait for the secret to be deleted with a timeout
def wait_for_secret_deletion(client, secret_name, timeout=10):
    logger.debug("Calling wait_for_secret_deletion")
    start_time = time.time()
    while True:
        if is_secret_deleted(client, secret_name):
            print(f"Secret '{secret_name}' has been deleted.")
            break
        elif time.time() - start_time > timeout:
            raise TimeoutError(f"Timed out waiting for secret '{secret_name}' to be deleted.")
        print(f"Waiting for secret '{secret_name}' to be deleted...")
        time.sleep(5)  # Wait for 5 seconds before retrying


def remove_access_token(id, project, environment):
    try:
        logger.debug("Calling remove_access_token")

        # Create a Secrets Manager client
        session = boto3.session.Session()
        client = session.client(service_name="secretsmanager", region_name=None)

        projects_secretes_base_path = environment + "-" + project
        tokens_secret_name = projects_secretes_base_path + "/tokens/" + id

        response = client.get_secret_value(SecretId=tokens_secret_name)
        client.delete_secret(SecretId=response["ARN"], ForceDeleteWithoutRecovery=True)
        logger.debug("Token %s removed from aws", tokens_secret_name)

    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceNotFoundException":
            logger.info("notoken present, nothing to do")
            return

def get_access_token_from_auth(project, environment):
    logger.debug("Calling get_token_from_auth")
    projects_secretes_base_path = environment + "-" + project
    backend_secrets_base_path = environment + "-" + "vtesting-runtime-simulation-backend"
        
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=None)

    logger.debug("Get secretes from aws")
    owm_id = client.get_secret_value(SecretId=projects_secretes_base_path + "/secret-client-id")["SecretString"]
    owm_secret = client.get_secret_value(SecretId=projects_secretes_base_path + "/secret-client-secret")["SecretString"]
    backend_id = client.get_secret_value(SecretId=backend_secrets_base_path + "/secret-client-id")["SecretString"]
    
    try:
        token = AuthTokenManager(owm_id, owm_secret, backend_id).get_token()
        return token
    except ClientError as e:
            # Other AWS error
            logger.error(f"Failed to retrieve or create secret: {e}")
            exit(1)
   
   
   
def get_access_token(id, project, environment):
    logger.debug("Calling get_token_from_auth")
    projects_secretes_base_path = environment + "-" + project
    backend_secrets_base_path = environment + "-" + "vtesting-runtime-simulation-backend"
    
    stored_secret = projects_secretes_base_path + "/tokens/" + id
    
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=None)

    logger.debug("Get secretes from aws")
    owm_id = client.get_secret_value(SecretId=projects_secretes_base_path + "/secret-client-id")["SecretString"]
    owm_secret = client.get_secret_value(SecretId=projects_secretes_base_path + "/secret-client-secret")["SecretString"]
    backend_id = client.get_secret_value(SecretId=backend_secrets_base_path + "/secret-client-id")["SecretString"]
    
    try:
        # Try to retrieve the secret
        get_secret_value_response = client.get_secret_value(SecretId=stored_secret)
        logger.info(f"Retrieved secret {stored_secret}")
        return get_secret_value_response['SecretString']
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            # Secret not found, create it
            
            logger.info(f"Secret {stored_secret} not found. Creating new secret.")
            token = AuthTokenManager(owm_id, owm_secret, backend_id).get_token()
            client.create_secret(Name=stored_secret, SecretString=token)
            return token
        else:
            # Other AWS error
            logger.error(f"Failed to retrieve or create secret: {e}")
            exit(1)
   
   
