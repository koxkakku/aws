import argparse
import os


def create_global_parser():
    """Parse function for the backend client.

    Returns:
        type: parsed values.

    """
    # create parser
    parser = argparse.ArgumentParser(description="backend client parser")
    # global arguments
    parser.add_argument(
        "-v", "--verbose", type=str, help="verbose level INFO|DEBUG|ERROR", required=False, default="INFO"
    )
    parser.add_argument(
        "-t",
        "--test_run_id",
        type=str,
        help="The TESTRUN_ID of the simulation bundle release",
        required=False,
        default=os.getenv("TESTRUN_ID"),
    )

    parser.add_argument(
        "-e",
        "--environment",
        type=str,
        help="The environment currently running (dev|nonprod|prod) ",
        required=False,
        default="dev",
    )

    parser.add_argument(
        "-p",
        "--project",
        type=str,
        help="The project currently running",
        required=False,
        default="vtesting-simulation-integration",
    )

    parser.add_argument(
        "--backend_url",
        type=str,
        help="The url to the vtesting-runtime-simulation-backend api",
        required=False,
        default="https://vtprun.vtp-dev.corpinter.net/api",
    )
    parser.add_argument(
        "-b",
        "--branch",
        help="Branch to execute the integration",
        type=str,
        default=os.getenv("GENERATION_BRANCH_TO_EXECUTE"),
    )

    return parser
