import os
import sys
import logging
from uuid import UUID
from backend_client_cmd_parser import create_parser
from aws_token_manager import get_access_token, remove_access_token
from pprint import pprint, pformat
import token_master_auth
from importlib.metadata import version

import json
from typing import Dict, List, Optional
import requests
import zipfile
from py7zr import SevenZipFile

import vtprun_client_py

from vtprun_client_py import (
    ApiException,
    SimulationState,
    SimulationStateResponse,
    SimulationStateSetResponseAllOfData,
    SimulationIntegration,
    SimulationIntegrationResponse,
)

logger = logging.getLogger("backend-client")


def sent_status_to_backend(api_instance, id, args):
    """Sends status to backend"""

    try:
        logger.debug("Calling sent_status_to_backend")
        current_state: SimulationState = SimulationState(
            stage=args.stage,
            status=args.status,
            is_failed=args.is_failed,
            job_name=args.job_name,
            job_project_name=args.job_project_name,
            message=args.message,
        )

        logger.info("Sending states for testrun ID %s: State: %s", id, current_state)

        response: SimulationStateResponse = api_instance.integrations_integration_id_states_post(
            integration_id=id, simulation_state=current_state
        )

        if response.status != "successful":
            sys.exit(f"Could not send status, error: {pformat(response)}")

        logger.info("Current state successful sent")

        # the pipeline is successful remove token
        if args.stage == "finished-integration":
            logger.info("State is finished-integration -> Integration finished. removing token from aws")

            remove_access_token(id, getattr(args, "project"), getattr(args, "environment"))

    except ApiException as e:
        sys.exit(f"Something went wrong in sent_status_to_backend! Error: {e}")


def get_states_from_backend(api_instance, id):
    """Sends status to backend"""
    try:
        logger.debug("Calling get_states_from_backend")
        response: SimulationStateSetResponseAllOfData = api_instance.integrations_integration_id_states_get(id)
        logger.info("Response: %s", pformat(response))
    except ApiException as e:
        print("Exception when calling UploadArtifactsApi->artifacts_artifact_type_download_post: %s\n" % e)


def get_sim_integration_package(api_instance, id):
    """get the simulation integration package from the backend for a specific integration"""
    try:
        logger.debug("Calling get_sim_integration_package")
        response: SimulationIntegrationResponse = api_instance.integrations_integration_id_get(id)
        logger.debug("Response: %s", pformat(response))

        if response.status != "successful":
            sys.exit(f"Get package not successful, error: {response}")
        try:
            integration_package: SimulationIntegration = response.data

            logger.debug((pformat(integration_package)))
            return integration_package

        except KeyError:
            logger.info("PIPELINE_ID not found")

    except ApiException as e:
        print("Exception when calling UploadArtifactsApi->artifacts_artifact_type_download_post: %s\n" % e)


def send_integration_request(api_instance, filepath, branch2integrate):
    """Sends a request for a simulation integration to the backend for testing purpose"""

    try:
        logger.debug("Calling send_integration_release_request")
        if not branch2integrate:
            sys.exit(f"Branch not set for integration request")

        with open(filepath, "r") as file:
            file_contents = file.read()

        data = json.loads(file_contents)
        release_package: SimulationIntegration = SimulationIntegration(
            simulation_bundle_release=data,
            created_at=data["created_at"],
            created_by=data["created_by"],
            id=data["id"],
            pipeline_id=1234,
            pk="fsdfsd",
            sk="sfdfgdf",
        )

        logger.info("release_package: %s", release_package.to_str)
        response: SimulationIntegrationResponse = api_instance.integrations_post(
            body=release_package, branch=branch2integrate
        )

        if response.status != "successful":
            sys.exit(f"Could not send status, error: {response}")
        try:
            logger.info("PIPELINE_ID not found")
            # to_integrate_package: SimulationIntegration = response.data

            # logger.info("Started Testrun with ID: %s", to_integrate_package.id)
            # logger.info("PIPELINE_ID is: %s", to_integrate_package.pipeline_id)
            # logger.debug((pformat(to_integrate_package)))

        except KeyError:
            logger.info("PIPELINE_ID not found")

        logger.info("Package send")

    except ApiException as e:
        sys.exit(f"Something went wrong in sent_status_to_backend! Error: {e}")
    except FileNotFoundError as e:
        sys.exit(f"Could not find file integration package file: {e}")


def prepare_integration_pipeline(integration_package, branch2integrate):
    try:
        logger.debug("Calling create_integration_pipelines")
        integration_package_forParsing = integration_package.to_dict()

        instance_type = json.loads(integration_package_forParsing.get("simulation_bundle_release"))["test_environment"][
            "instance"
        ]
        test_environment_type = json.loads(integration_package_forParsing.get("simulation_bundle_release"))[
            "test_environment"
        ]["type"]

        logger.info("Instance to integrate: %s", instance_type)

        logger.info("type to integrate: %s", test_environment_type)

        # for test_environment in integration_package.test_environment.test_environment:
        #    # add Instance type
        #   if not instance_type:
        #        logger.info("Instance type to integrate: %s", test_environment.instance)
        #        instance_type = test_environment.instance
        #    elif test_environment.instance != instance_type:
        #        logger.error(
        #            f"Error in SimulationBundleRelease only one kind of instance should be present. last instance type was %s, this is %s",
        #            instance_type,
        #            test_environment.instance,
        #        )
        #        sys.exit(f"Something went wrong in create_integration_pipelines! Error: {e}")#
        #
        #    # add test_environment_type
        #    logger.info("Appending %s to integrate", test_environment.type)
        #    test_environment_type.append(test_environment.type)

        # write variables for integration into dot file to forward them to trigger job
        with open("integration_vars.env", "w+") as f:
            # integration type
            f.write("INTEGRATION_TYPE=" + instance_type + "\n")
            f.write("SIMULATIONS_TO_INTEGRATE=" + test_environment_type + "\n")
            f.write("TESTRUN_ID=" + integration_package.id + "\n")
            f.write("DEPLOY_ENV=" + os.environ["DEPLOY_ENV"] + "\n")

            # for triggering the correct repo
            if instance_type == "BROP":
                f.write("INTEGRATION_PIPELINE_ID=" + os.environ["BROP_SIM_INTEGRATION_PROJECT_ID"] + "\n")
                f.write(
                    "INTEGRATION_PIPELINE_API_READ_TOKEN="
                    + os.environ["BROP_INTEGRATION_PIPELINE_API_READ_TOKEN"]
                    + "\n"
                )
            else:
                f.write("INTEGRATION_PIPELINE_ID=" + os.environ["FROP_SIM_INTEGRATION_PROJECT_ID"] + "\n")
                f.write(
                    "INTEGRATION_PIPELINE_API_READ_TOKEN="
                    + os.environ["FROP_INTEGRATION_PIPELINE_API_READ_TOKEN"]
                    + "\n"
                )

    except Exception as e:
        sys.exit(f"Something went wrong in create_integration_pipelines! Error: {e}")


def download_package(api_instance, test_run_id, packages, dst, extract):
    try:
        logger.debug("Calling download_package")
        integration_package: SimulationIntegration = get_sim_integration_package(api_instance, test_run_id)
        for package in packages:
            logger.debug("Processing %s", package)
            download_url = find_id_in_simulation_integration(package, integration_package)["id"]
            if download_url is not None:
                download_file(download_url, dst, extract)
            else:
                sys.exit(f"could not find download id for package {package}")

    except Exception as e:
        sys.exit(f"Something went wrong in create_integration_pipelines! Error: {e}")


def find_id_in_simulation_integration(key_to_find, nested_dict):
    """
    Recursively searches for a key in a nested dictionary.

    Args:
    - key_to_find: The key to search for.
    - nested_dict: The nested dictionary to search.

    Returns:
    - The value associated with the key, or None if the key is not found.
    """
    logger.debug("Calling find_id_in_simulation_integration")
    logger.debug("searching for %s", key_to_find)
    if key_to_find in nested_dict:
        return nested_dict[key_to_find]

    for key, value in nested_dict.items():
        if isinstance(value, dict):
            result = find_id_in_simulation_integration(key_to_find, value)
            if result is not None:
                return result

    return None


def download_file(url, extract_to, extract):
    """
    Downloads a file from the given URL and extracts it.
    Supports ZIP and 7z formats.

    Args:
    - url (str): The URL of the file to download.
    - extract_to (str): Directory where the extracted files will be stored.

    Returns:
    - None
    """

    try:
        # Download the file

        logger.info("Downloading: %s to %s", url, extract_to)
        response = requests.get(url)
        response.raise_for_status()  # Raise an HTTPError if the HTTP request returned an unsuccessful status code

        # Define file name and path
        file_name = url.split("/")[-1]
        file_path = os.path.join(extract_to, file_name)

        # Write the downloaded file to a new file
        with open(file_path, "wb") as file:
            file.write(response.content)
        # extract
        if extract:
            logger.info("Downloading: %s to %s", url, extract_to)
            # Extract the file based on its extension
            if file_name.endswith(".zip"):
                with zipfile.ZipFile(file_path, "r") as zip_ref:
                    zip_ref.extractall(extract_to)
            elif file_name.endswith(".7z"):
                with SevenZipFile(file_path, "r") as zip_ref:
                    zip_ref.extractall(extract_to)
            else:
                raise ValueError("Unsupported file format")

            # Remove the downloaded archive file
            os.remove(file_path)

    except requests.RequestException as e:
        print(f"Error downloading the file: {e}")
    except (zipfile.BadZipFile, ValueError) as e:
        print(f"Error extracting the file: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


def main(parsed_inputs):
    # logging options
    if parsed_inputs.verbose == "DEBUG":
        loglevel = logging.DEBUG
    elif parsed_inputs.verbose == "ERROR":
        loglevel = logging.ERROR
    else:
        loglevel = logging.INFO

    logging.basicConfig(level=loglevel, format="[%(asctime)s - %(levelname)s (%(name)s)]: %(message)s")

    logger.debug("##### Environment Data for debug:")
    # logger.debug("# aws_token_manager version: %s", version(token_master_auth))
    # logger.debug("# vtprun_client_py version: %s", version(vtprun_client_py))
    logger.debug("##### End Data for debug")

    # get proxy address if there is one
    proxy = os.getenv("HTTP_PROXY", None)

    # set address of the Backend
    configuration = vtprun_client_py.Configuration(
        host=parsed_inputs.backend_url,
        access_token=get_access_token(parsed_inputs.test_run_id, parsed_inputs.project, parsed_inputs.environment),
    )

    logger.debug("token is %s", configuration.access_token)

    if proxy:
        configuration.proxy = proxy

    # main functions
    try:
        with vtprun_client_py.ApiClient(configuration) as api_client:
            api_instance = vtprun_client_py.IntegrationApi(api_client)
        # output all inputs for debug
        logger.debug("the inputs are:")
        for arg in vars(parsed_inputs):
            logger.debug("{} is {}".format(arg, getattr(parsed_inputs, arg)))

        # sent command
        if parsed_inputs.command == "send-state":
            sent_status_to_backend(api_instance, parsed_inputs.test_run_id, parsed_inputs)

        # get status command
        elif parsed_inputs.command == "get-states":
            get_states_from_backend(api_instance, parsed_inputs.test_run_id)

        # get package
        elif parsed_inputs.command == "get-package":
            get_sim_integration_package(api_instance, parsed_inputs.test_run_id)

        # send integration request
        elif parsed_inputs.command == "send-integration-request":
            send_integration_request(api_instance, parsed_inputs.package_file, parsed_inputs.branch)

        # create integration pipeline to trigger
        elif parsed_inputs.command == "prepare-integration":
            prepare_integration_pipeline(
                get_sim_integration_package(api_instance, parsed_inputs.test_run_id), parsed_inputs.branch
            )

        # create integration pipeline to trigger
        elif parsed_inputs.command == "get-artefact":
            download_package(
                api_instance, parsed_inputs.test_run_id, parsed_inputs.package, parsed_inputs.dst, parsed_inputs.extract
            )

        else:
            sys.exit("Unknown command! Try python backend-client.py --help")

    except Exception as e:
        sys.exit(f"Something went wrong in main! Error: {e}")


if __name__ == "__main__":
    try:
        # import args
        parser = create_parser()
        parsed_inputs = parser.parse_args()

        main(parsed_inputs)

    except Exception as e:
        sys.exit(f"Something went wrong in __name__! Error: {e}")
