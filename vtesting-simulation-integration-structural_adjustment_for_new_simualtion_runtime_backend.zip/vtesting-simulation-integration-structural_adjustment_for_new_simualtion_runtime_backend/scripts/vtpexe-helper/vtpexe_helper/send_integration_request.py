import os
import sys
import logging
from uuid import UUID

# add local lib
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

from lib import global_parse_args,aws_token_manager,log_config

from pprint import pprint, pformat
import token_master_auth
from importlib.metadata import version

import json
from typing import Dict, List, Optional
import requests
import zipfile
from py7zr import SevenZipFile

import vtprun_client_py

from vtprun_client_py import (
    ApiException,
    SimulationIntegrationResponse,
)

from vtpcap_model_py import  (SimulationBundleReleaseGetResolved)

# Get the filename without the extension and use it for the logger's name. else if we take __name__ main will be shown
logger_name = os.path.splitext(os.path.basename(__file__))[0]
logger = log_config.setup_logging(logger_name)

def send_request(api_instance, filepath, branch2integrate):
    """Sends a request for a simulation integration to the backend for testing purpose"""

    try:
        logger.debug("Calling send_integration_release_request")
        if not branch2integrate:
            sys.exit(f"Branch not set for integration request")

        with open(filepath, "r") as file:
            file_contents = file.read()
        
        release_package: SimulationBundleReleaseGetResolved = SimulationBundleReleaseGetResolved.from_json(file_contents)
        
        logger.info("release_package: %s", release_package.to_str)
        response: SimulationIntegrationResponse = api_instance.integrations_post( 
            body=release_package.to_dict(), branch=branch2integrate
        )
        
        logger.info("integrations_post not found")
        if response.status != "successful":
            sys.exit(f"Could not send status, error: {response}")
        try:
            logger.info("PIPELINE_ID not found")

            logger.info("Started Testrun with ID: %s", response.data.id)
            logger.info("PIPELINE_ID is: %s", response.data.pipeline_id)
            logger.debug((pformat(response.data)))

        except KeyError:
            logger.info("PIPELINE_ID not found")

        logger.info("Package send")

    except ApiException as e:
        sys.exit(f"Something went wrong in sent_status_to_backend! Error: {e}")
    except FileNotFoundError as e:
        sys.exit(f"Could not find file integration package file: {e}")


def send_integration_request():
    # import global args
    parser = global_parse_args.create_global_parser()

    parser.add_argument("-f", "--package_file", help="Path to simulation Package release file", type=str)

    parsed_inputs = parser.parse_args()

    # logging options
    if parsed_inputs.verbose == "DEBUG":
        loglevel = logging.DEBUG
    elif parsed_inputs.verbose == "ERROR":
        loglevel = logging.ERROR
    else:
        loglevel = logging.INFO

    logger.setLevel(loglevel)

    # output all inputs for debug
    logger.debug("the inputs are:")
    for arg in vars(parsed_inputs):
        logger.debug("{} is {}".format(arg, getattr(parsed_inputs, arg)))
    # get proxy address if there is one
    
    proxy = os.getenv("HTTP_PROXY", None)

     # set address of the Backend
    configuration = vtprun_client_py.Configuration(
        host=parsed_inputs.backend_url,
        access_token=aws_token_manager.get_access_token_from_auth(
            parsed_inputs.project, parsed_inputs.environment
        )
    )
    
    logger.debug("token is %s", configuration.access_token)

    if proxy:
        configuration.proxy = proxy

    # main functions
    try:
        with vtprun_client_py.ApiClient(configuration) as api_client:
            api_instance = vtprun_client_py.IntegrationApi(api_client)

        send_request(api_instance, parsed_inputs.package_file, parsed_inputs.branch)

    except Exception as e:
        sys.exit(f"Something went wrong in main! Error: {e}")


if __name__ == "__main__":
    try:
        send_integration_request()

    except Exception as e:
        sys.exit(f"Something went wrong in __name__! Error: {e}")
