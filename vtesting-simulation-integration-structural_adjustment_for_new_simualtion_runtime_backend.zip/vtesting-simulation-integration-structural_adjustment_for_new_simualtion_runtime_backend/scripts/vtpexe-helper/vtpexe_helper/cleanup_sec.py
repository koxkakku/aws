import boto3
from botocore.exceptions import ClientError
import sys
import time
import os

import lib
from lib import global_parse_args,aws_token_manager,log_config

import vtprun_client_py

from vtprun_client_py import (
    SimulationState,
    SimulationStateResponse,
)


from token_master_auth import Auth, AuthTokenManager

from jose import ExpiredSignatureError
import json

# Get the filename without the extension and use it for the logger's name. else if we take __name__ main will be shown
logger_name = os.path.splitext(os.path.basename(__file__))[0]
logger = log_config.setup_logging(logger_name)



def main():
    
    # Create a Secrets Manager client
    environment = "dev"
    project = "vtesting-simulation-integration"
    projects_secretes_base_path = environment + "-" + project

    # get proxy address if there is one
    proxy = os.getenv("HTTP_PROXY", None)

    # set address of the Backend
    configuration = vtprun_client_py.Configuration(
        host="https://vtprun.vtp-dev.corpinter.net/api",
        access_token=aws_token_manager.get_access_token_from_auth(project, environment),
    )
    logger.info("Using token: %s ", configuration.access_token)
    if proxy:
        configuration.proxy = proxy
    # send to current state

    with vtprun_client_py.ApiClient(configuration) as api_client:
        api_instance = vtprun_client_py.IntegrationApi(api_client)

    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=None)
    try:
        logger.info("Calling remove_all_tokens")

        projects_secretes_base_path = environment + "-" + project
        tokens_prefix = projects_secretes_base_path + "/tokens/"

        secrets = client.list_secrets(
            MaxResults=100,
            Filters=[
                {"Key": "name", "Values": [tokens_prefix]},
            ],
        )["SecretList"]
        # Filter the secrets by the prefix

        logger.info("got secretes: %s",secrets)
        for secret in secrets:
            logger.info("removing Token %s from aws", secret["Name"])

            testrunid = get_string_after_last_slash(secret["Name"])

            logger.info("removing secret tokenfor testrunid  %s", testrunid)

            response = client.delete_secret(SecretId=secret["ARN"], ForceDeleteWithoutRecovery=True)

            logger.info("Response from removing  %s", response)

            current_state: SimulationState = SimulationState(
                stage="finished-integration",
                status="failed",
                is_failed=True,
                job_name="Delete job",
                job_project_name="delete",
                message="deleting old jobs",
            )

            logger.info("sending end to backend")
            response: SimulationStateResponse = api_instance.integrations_integration_id_states_post(
                integration_id=testrunid, simulation_state=current_state
            )

        logger.info("Current state successful sent")
        # wait_for_secret_deletion(client, secret['Name'])
        #

        exit()
    except ClientError as e:
        logger.error("An error occurred while remove_all_tokens:", e)
        sys.exit(f"An error occurred while remove_all_tokens! Error: {e}")


def get_string_after_last_slash(input_string):
    # Find the last occurrence of '/'
    last_slash_index = input_string.rfind("/")

    # Check if '/' is found
    if last_slash_index != -1:
        # Return the substring after the last '/'
        return input_string[last_slash_index + 1 :]
    else:
        # Return the original string if no '/' found
        return input_string


if __name__ == "__main__":
    try:
        # import args

        main()

    except Exception as e:
        sys.exit(f"Something went wrong in __name__! Error: {e}")
