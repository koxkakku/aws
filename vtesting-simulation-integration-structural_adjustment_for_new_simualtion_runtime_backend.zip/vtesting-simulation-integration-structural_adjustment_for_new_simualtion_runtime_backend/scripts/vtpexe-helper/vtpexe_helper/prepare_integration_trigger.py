import os
import sys
import logging

current_dir = os.path.dirname(os.path.abspath(__file__))
# Get the parent directory by going one level up
sys.path.append(current_dir)

from lib import  (
    global_parse_args,
    aws_token_manager,
    log_config
    )

from pprint import pprint, pformat
from importlib.metadata import version

import json
from typing import Dict, List, Optional

import vtprun_client_py

from vtprun_client_py import (
    ApiException,
    SimulationIntegrationResponse,
    SimulationIntegration
)

from vtpcap_model_py import  (SimulationBundleReleaseGetResolved,TestEnvironment,Instance)

# Get the filename without the extension and use it for the logger's name. else if we take __name__ main will be shown
logger_name = os.path.splitext(os.path.basename(__file__))[0]
logger = log_config.setup_logging(logger_name)

def get_sim_integration_package(api_instance, id):
    """get the simulation integration package from the backend for a specific integration"""
    try:
        logger.debug("Calling get_sim_integration_package")
        response: SimulationIntegrationResponse = api_instance.integrations_integration_id_get(id)
        logger.debug("Response from integration service: %s", pformat(response))

        if response.status != "successful":
            sys.exit(f"Get package not successful, error: {response}")
        try:
            integration_package: SimulationIntegration = response.data


            return SimulationBundleReleaseGetResolved.from_json(integration_package.simulation_bundle_release)

        except KeyError:
            logger.error("PIPELINE_ID not found")

    except ApiException as e:
            logger.error(f"Not handled exception in get_sim_integration_package! Error: {e}")
            exit(1)

def prepare_integration_pipeline(simulation_bundle_release, branch2integrate):
    try:
        logger.debug("Calling create_integration_pipelines")

        logger.debug("simulation_bundle_release: %s", simulation_bundle_release)
        
        # get testenvironment
        test_environment: TestEnvironment =  simulation_bundle_release.test_environment
        
        # write variables for integration into dot file to forward them to trigger job
        with open("integration_vars.env", "w+") as f:
            # integration type
            if not test_environment.test_type:
                logger.debug("TEST_TYPE: %s", "NEST")
                f.write("TEST_TYPE=" + "NEST" + "\n")
            else:
                logger.debug("TEST_TYPE: %s", test_environment.test_type)
                f.write("TEST_TYPE=" + test_environment.test_type + "\n")
                
            logger.debug("INSTANCE_TYPE: %s", test_environment.instance)
            f.write("INSTANCE_TYPE=" + test_environment.instance + "\n")
            
            logger.debug("TESTRUN_ID: %s",  os.environ["TESTRUN_ID"])
            f.write("TESTRUN_ID=" + os.environ["TESTRUN_ID"] + "\n")
            
            logger.debug("DEPLOY_ENV: %s", os.environ["DEPLOY_ENV"])
            f.write("DEPLOY_ENV=" + os.environ["DEPLOY_ENV"] + "\n")

            # for triggering the correct repo
            if test_environment.instance == Instance.BROP:
                f.write("INTEGRATION_PIPELINE_ID=" + os.environ["BROP_SIM_INTEGRATION_PROJECT_ID"] + "\n")
                f.write(
                    "INTEGRATION_PIPELINE_API_READ_TOKEN="
                    + os.environ["BROP_INTEGRATION_PIPELINE_API_READ_TOKEN"]
                    + "\n"
                ) # for triggering the correct repo
            elif test_environment.instance == Instance.FROP:
                f.write("INTEGRATION_PIPELINE_ID=" + os.environ["FROP_SIM_INTEGRATION_PROJECT_ID"] + "\n")
                f.write(
                    "INTEGRATION_PIPELINE_API_READ_TOKEN="
                    + os.environ["FROP_INTEGRATION_PIPELINE_API_READ_TOKEN"]
                    + "\n"
                )
            else:
                logger.debug("Instance %s not supported", test_environment.instance)

    except Exception as e:
        if e == 'DEPLOY_ENV' or 'INTEGRATION_TYPE' or 'TESTRUN_ID' :
                logger.error("Could not find: %s variable", e)
                exit(1)
        else:
            logger.error(f"Not handled exception in prepare_integration_pipeline! Error: {e}")
            exit(1)


def prepare_integration():
    # import global args
    parser = global_parse_args.create_global_parser()

    parsed_inputs = parser.parse_args()

    # logging options
    if parsed_inputs.verbose == "DEBUG":
        loglevel = logging.DEBUG
    elif parsed_inputs.verbose == "ERROR":
        loglevel = logging.ERROR
    else:
        loglevel = logging.INFO

    logger.setLevel(loglevel)

    # output all inputs for debug
    logger.debug("the inputs are:")
    for arg in vars(parsed_inputs):
        logger.debug("{} is {}".format(arg, getattr(parsed_inputs, arg)))
    # get proxy address if there is one
    proxy = os.getenv("HTTP_PROXY", None)

    # set address of the Backend
    configuration = vtprun_client_py.Configuration(
        host=parsed_inputs.backend_url,
        access_token=aws_token_manager.get_access_token(
            parsed_inputs.test_run_id, parsed_inputs.project, parsed_inputs.environment
        ),
    )

    logger.debug("token is %s", configuration.access_token)

    if proxy:
        configuration.proxy = proxy

    # main functions
    try:
        with vtprun_client_py.ApiClient(configuration) as api_client:
            api_instance = vtprun_client_py.IntegrationApi(api_client)

        prepare_integration_pipeline(
            get_sim_integration_package(api_instance, parsed_inputs.test_run_id), parsed_inputs.branch
        )
    except Exception as e:
        sys.exit(f"Something went wrong in main! Error: {e}")


if __name__ == "__main__":
    try:
        prepare_integration()

    except Exception as e:
        sys.exit(f"Something went wrong in __name__! Error: {e}")
