import os
import sys
import logging
import argparse
from requests import post, status_codes

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')    



def parse_args():
    parser=argparse.ArgumentParser(description="Send Status to Simulation Runtime Backend")
    
    # global arguments
    # message: str, job_name: str, job_project_name: str, "", stage: str = "dev", status: str = "success", is_failed = false
    parser.add_argument('-m', '--message', type=str, help='sets the branch of the child pipelines', required = True)
    parser.add_argument('-n', '--job_name', type=str, help='sets the branch of the child pipelines', required = True)
    parser.add_argument('-p', '--job_project_name', type=str, help='sets the branch of the child pipelines', required = True)
    parser.add_argument('--stage', type=str, help='sets the branch of the child pipelines',default= "dev")
    parser.add_argument('-s', '--status', type=str, help='sets the branch of the child pipelines',default= "success")
    parser.add_argument('-f', '--is_failed', type=bool, help='sets the branch of the child pipelines',default= False)

    args=parser.parse_args()
    
    return args  

TESTRUN_ID = os.getenv('TESTRUN_ID')
SIMULATION_RUNTIME_BACKEND_KEY = os.getenv('SIMULATION_RUNTIME_BACKEND_KEY')
SIMULATION_RUNTIME_BACKEND_URL = os.getenv('SIMULATION_RUNTIME_BACKEND_URL')


def send_status(args):
    result = post(
        url=f"{SIMULATION_RUNTIME_BACKEND_URL}/simulation/{TESTRUN_ID}/state",
        json={
            "message": args.message,
            "stage": args.stage,
            "status": args.status,
            "is_failed": args.is_failed,
            "job_name": args.job_name,
            "job_project_name": args.job_project_name
        },
        headers={"Authorization": SIMULATION_RUNTIME_BACKEND_KEY})

    if result.status_code == status_codes.codes['ok']:
        logger.info(f"{result.status_code}: {result.content}")
    else:
        logger.error(f"{result.status_code}: {result.content}")

def main():
    args = parse_args()

    try:
        send_status(args)
    except Exception as e:
        logger.error(f"Something went wrong in main! Error: {e}")
        sys.exit(f"Something went wrong in main! Error: {e}")


if __name__ == "__main__":
    main()