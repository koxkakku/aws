import os
import sys
import json
import logging
import argparse

from pathlib import Path
from requests import get

logger = logging.getLogger(__name__)


class PipelineWriter:

    @staticmethod
    def parent_job_template():
        parent_job_template = """
stages:
  - GenerateSimulations
.basic:
  allow_failure: false
"""
        return parent_job_template

    @staticmethod
    def child_pipeline_job_template(Simulation, ecu, testrun_id, branch):
        if(testrun_id is None):
          testrun_id = "TEST_RUN"
        child_pipeline_job_template = f"""

generate-simulation-for-{ecu}-{Simulation}-trigger-job: 
  stage: GenerateSimulations 
  variables: 
    ECU: {ecu}
    TESTRUN_ID: {testrun_id}
  trigger:
    project: oak/vtesting/vtesting-simulation-generation-{Simulation}
    branch: {branch}
    strategy: depend
"""
        return child_pipeline_job_template

class PipelineGenerator:

    def __init__(self):
        
        self.BROP = []
        self.FROP = []
        self.TESTRUN_ID = os.getenv('TESTRUN_ID')
        self.SIMULATION_RUNTIME_BACKEND_KEY = os.getenv('SIMULATION_RUNTIME_BACKEND_KEY')
        self.SIMULATION_RUNTIME_BACKEND_URL = os.getenv('SIMULATION_RUNTIME_BACKEND_URL')
        self.child_pipeline_name = "child-pipeline-gitlab-ci.yml"

    
    def parsing_user_json(self):
        api_call = f"{self.SIMULATION_RUNTIME_BACKEND_URL}/simulation/{self.TESTRUN_ID}"
        response = get(api_call, headers={"Authorization": self.SIMULATION_RUNTIME_BACKEND_KEY})
        logger.debug(f"{response}: {response.content}")

        user_json = json.loads(response.content)["data"]
        logger.debug(f"Json input loaded: {json.dumps(user_json, indent=4)}")

        common_data = user_json['common_data']

        if "brop" in user_json and user_json["brop"] is not None:
            logger.debug("Brop entry present, parsing ecus to Brop")
            for ecu in common_data['ecu']:  
                logger.debug(f"Adding ECU {ecu['diagnostic_name']} to Brop list")
                self.BROP.append(ecu['diagnostic_name'])

        if "frop" in user_json and user_json["frop"] is not None:
            logger.debug("Frop entry present, parsing ecus to frop")
            for ecu in common_data['ecu']:  
                logger.debug(f"Adding ECU {ecu['diagnostic_name']} to Frop list")
                self.FROP.append(ecu['diagnostic_name'])


    def generate_child_pipelines(self,branch):
        try:
            logger.debug("Generating child pipelines for testrun %s", self.TESTRUN_ID)
            with open(self.child_pipeline_name, 'w+') as f:
                f.write(PipelineWriter.parent_job_template())
                for ecu in self.BROP:
                    f.write(PipelineWriter.child_pipeline_job_template("BROP",ecu, self.TESTRUN_ID,branch))
                for ecu in self.FROP:
                    f.write(PipelineWriter.child_pipeline_job_template("FROP",ecu, self.TESTRUN_ID,branch))

            logger.debug("Created child pipelines: %s",Path(self.child_pipeline_name).read_text())
        
        except Exception as e:
            logger.info(f"Something went wrong in generateChildPipelines! Error: {e}")
            sys.exit(f"Something went wrong in generateChildPipelines! Error: {e}")


def parse_args():
    parser=argparse.ArgumentParser(description="Pipeline Generator from User Json")
    
    # global arguments
    parser.add_argument('-v', '--verbose', type=str, help='verbose level INFO|DEBUG|ERROR',default= "INFO")
    parser.add_argument('-b', '--branch', type=str, help='sets the branch of the child pipelines',default= "main")

    args=parser.parse_args()
    
    return args    

def main():
    args=parse_args()

    if args.verbose == "DEBUG":
        loglevel = logging.DEBUG
    elif args.verbose == "ERROR":
        loglevel = logging.ERROR
    else:
        loglevel = logging.INFO
    logging.basicConfig(level=loglevel, format='%(levelname)s: %(message)s')

    try:
        logger.debug("the args are:")
        for arg in vars(args):
            logger.debug(f"{arg} is {getattr(args, arg)}")

        generator = PipelineGenerator()
        generator.parsing_user_json()
        generator.generate_child_pipelines(args.branch)

        logger.debug("Generation Done")

    except Exception as e:
        logger.info(f"Something went wrong in main! Error: {e}")
        sys.exit(f"Something went wrong in main! Error: {e}")


if __name__ == "__main__":
    main()
            
