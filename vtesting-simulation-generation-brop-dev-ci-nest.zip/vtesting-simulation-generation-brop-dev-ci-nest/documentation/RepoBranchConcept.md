# vtesting-simualtion-generation repository branch concept

![Branch Concept](./Images/GitlabBranchWorkflow-sim-generation.drawio.png)

## Branches
### main branch

Main Pipeline for production. Pipeline is triggered by pipeline in main branch of vtesting-simulation-integration. If triggered manually parameter for correct starting should be provided  Persistent Branch
  
### dev-main branch

Main dev pipeline with all Testing types merged. Ready for testing before merge to main branch.If pipeline is triggered manually default values for the simulation generation must be provided. Persistent Branch.

### dev-testingType1 (dev-nest, dev-tls, ...)

Main Testing type branch for one Type (e.g. NEST,TLS,DiVa...). All features for a specific type are merged. Persistent Branch

### dev-testingType1-feature-1 (dev-nest-new-folder, ev-nest-TEDAG12345-xxxxx, ...)

Feature Branch with new features of a Testing type. Deleted after future is merged merged in dev-testingType1.
