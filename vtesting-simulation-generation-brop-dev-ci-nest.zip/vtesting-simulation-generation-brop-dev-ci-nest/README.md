# Simulation generation repository (work in progress)

1. [Introduction](#introduction)
2. [Folder structure](#folder_tructure)
3. [Pipelines](#pipelines)
    1. [main pipeline](#main_pipeline)
    2. [child pipelines](#child_pipelines)
    3. [Run pipeline with testing values](#testingValues)
4. [Branches](#branches)
    1. [Branch "main"](#Main)
    2. [Branch "dev-main"](#Dev-main)
    3. [Branch "dev-testingType1"](#Dev-testingType1)
    4. [Branch "dev-testingType1-feature-1"](#Dev-testingType1-feature-1)

## Introduction <a name="introduction"></a>

Repository for the generation of the BROP simulation NEST, DIVA, TLS, NTS, securityCompound and GWD

## Folder structure <a name="folder_tructure"></a>

|Folder |Description  |
|---------|---------|
|scripts     | Global scripts used by main pipeline or by all child pipeline |
|documentation     |   Folder with documentation for this repository      |
|template     | Template folder for the generation of the simulation. Contains a testing pipeline ([template.gitlab-ci.yml](template\template.gitlab-ci.yml)) and a skeleton pipeline ([skeleton.gitlab-ci.yml](template\skeleton.gitlab-ci.yml)). The template job has some example jobs for different scenarios |
|diva     |  Folder with child pipeline for the diva simulation generation  and specific tools/scripts   |
|gwd     |   Folder with the child pipeline for the gwd simulation generation and its specific tools/scripts  |
|nest     |   Folder with child pipeline for the nest simulation generation  and its specific tools/scripts |
|nts     |   Folder with child pipeline for the nts simulation generation    and its specific tools/scripts   |
|securityCompound     |  Folder with child pipeline for the securityCompound simulation generation and its specific tools/scripts  |
|tls     |  Folder with child pipeline for the tls simulation generation  and its specific tools/scripts   |

## Pipelines <a name="pipelines"></a>

### main pipeline (.gitlab-ci.yml) <a name="main_pipeline"></a>

The main pipeline triggers one of the child pipelines in the simulation generation folders depending on the TESTRUN ID of the job or if manually started by the variable INTEGRATION_JOB.

#### Main pipeline variables

|Variable |Description  | Default value |
|---------|---------|---------|
| TESTRUN_ID    | The TestRun ID to identify the test job parameter in the database   | $TESTRUN_ID from upstream job |
| ECU   | The ECU for which the simulation should be build  | $ECU from upstream job |
| UPLOAD_RESULTS   | Boolean value to for testing. If set to false Results should not be uploaded  | true |
| TESTING_JSON   | This parameter is for testing the downstream pipeline. This json is the user json  | "" |
| LOG_LEVEL   | The LogLevel all tools should provide  | DEBUG |

### child pipelines <a name="child_pipelines"></a>

Each simulation generation folder contains a pipeline script which will be triggered by the main pipeline if the user json requests a generation.

### Run pipeline with testing values] <a name="testingValues"></a>

For Testing without a deployment start the pipeline without the TESTRUN_ID variable and with a valid user json in the TESTING_JSON variable. This will add the user json to dynamodb the same way as the upstream job wwith the id BROP_TESTING_PIPELINE_TESTRUN#$CI_PIPELINE_ID". By passing this ID to the downstream job as TESTRUN_ID, all jobs can access the data the same way as using the regular ID.

## Branches <a name="branches"></a>

![Branch Concept](./documentation/Images/GitlabBranchWorkflow-sim-generation.drawio.png)

### Branch "main" <a name="Main"></a>

Main branch for production. Pipeline is triggered by pipeline in main branch of vtesting-simulation-integration. If triggered manually parameter for correct starting should be provided  Persistent protected Branch
  
### Branch "dev-main" <a name="Dev-main"></a>

Main dev branch with all Testing types merged. Ready for testing before merge to main branch.If pipeline is triggered manually default values for the simulation generation must be provided. Persistent protected Branch.

### Branch "dev-testingType1" (dev-nest, dev-tls, ...) <a name="Dev-testingType1"></a>

Main Testing type branch for one Type (e.g. NEST,TLS,DiVa...). All features for a specific type are merged. Persistent protected Branch

### Branch "dev-testingType1-feature-1" (dev-nest-new-folder, dev-nest-TEDAG12345, ... ) <a name="Dev-testingType1-feature-1"></a>

Feature Branch with new features of a Testing type. Deleted after future is merged merged in dev-testingType1.
