import argparse
import os
import sys
import json
import logging
from pprint import pprint
from zipfile import ZipFile
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from botocore.config import Config
from pathlib import Path


logger = logging.getLogger(__name__)

class Jobs:

    def __init__(self):
        
        self.BROP = []
        self.FROP = []
        self.TESTRUN_ID = os.getenv('TESTRUN_ID')
        self.child_pipeline_name = "child-pipeline-gitlab-ci.yml"

    def parsParameterFromJson(self, userJson):
        try:
            logger.debug("In parsParameterFromJson")
            json_dic = json.loads(userJson)
            logger.debug("Json input loaded: %s", json.dumps(json_dic, indent=4))

            common_data = json_dic['commonData']

            if "brop" in json_dic:
                logger.debug("Brop entry present, parsing ecus to Brop")
                for ecu in common_data['ecu']:  
                    logger.debug("Adding ECU %s to Brop list", ecu['name'])
                    self.BROP.append(ecu['name'])

            if "frop" in json_dic:
                logger.debug("frop entry present, parsing ecus to frop")
                for ecu in common_data['ecu']:  
                    logger.debug("Adding ECU %s to Frop list", ecu['name'])
                    self.FROP.append(ecu['name'])
        
            logger.debug("Parsed %s to FROP and %s to BROP",self.FROP, self.BROP)
            return "Parsed "+ str(self.FROP) + " to FROP and "+ str(self.BROP) + " to BROP"
        
        except Exception as e:
            print(f"Something went wrong in parsParameterFromJson! Error: {e}")
            sys.exit(f"Something went wrong in parsParameterFromJson! Error: {e}")
 
    def parsParameterFromDB(self, inputs, dyn_resource):
        logger.debug("In parsParameterFromDB")
        try:
            table = dyn_resource.Table(inputs.table)

            logger.debug("Getting user json from table %s, id: %s, sort: %s", inputs.table,inputs.key,inputs.sort )
            response = table.get_item(Key={'id':inputs.key, 'sort': inputs.sort})

            items = response['Item']
            common_data = items['commonData']
            logger.debug("commonData: %s", json.dumps(common_data, indent=4))

            if "brop" in items:
                logger.debug("Brop entry present, parsing ecus to Brop")
                for ecu in common_data['ecu']:  
                    logger.debug("Adding ECU %s to Brop list", ecu['name'])
                    self.BROP.append(ecu['name'])

            if "frop" in items:
                logger.debug("frop entry present, parsing ecus to frop")
                for ecu in common_data['ecu']:  
                    logger.debug("Adding ECU %s to Frop list", ecu['name'])
                    self.FROP.append(ecu['name'])
            if inputs.out:
                logger.debug("output file set to %s",Path(inputs.out))
                with open(Path(inputs.out), 'w') as fp:
                    for item in self.FROP:
                        # write each FROP item on a new line
                        fp.write("%s\n" % item)
                    for item in self.BROP:
                        # write each BROP item on a new line
                        fp.write("%s\n" % item)
                    logger.debug("done writing file")

            logger.debug("Parsed %s to FROP and %s to BROP",self.FROP, self.BROP)

            return "Parsed "+ str(self.FROP) + " to FROP and "+ str(self.BROP) + " to BROP"

        except ClientError as err:
            logger.error(
                "Couldn't get db entry %s with sort %s from table %s. Error: %s: %s",
                inputs.key, inputs.sort, self.table.name,
                err.response['Error']['Code'], err.response['Error']['Message'])
            raise
        else:
            return json.dumps(response['Item'], indent=4)



def parse_args():
    parser=argparse.ArgumentParser(description="Json Parser, to import the UserJason into the DynamoDB")
    # global arguments
    parser.add_argument('-v', '--verbose', type=str, help='verbose level INFO|DEBU|ERROR',default= "INFO")
    parser.add_argument('-o', '--out', help='The file name to save the parameter',type=str, default = '')

    subparser = parser.add_subparsers(dest='command')
    db_options = subparser.add_parser('fromDatabase')
    db_options.add_argument('-t', '--table', type=str, help='The table to access',default= 'simulation-run')
    db_options.add_argument('-k', '--key', help='The primary key of the database entry',type=str, default = os.getenv('TESTRUN_ID'))
    db_options.add_argument('-s', '--sort', help='The sort key of the database entry',type=str, default = 'SIMULATION#USER_JSON')
    db_options.add_argument('--AWSaccessKey', 
                        type=str, 
                        help=("""The AWS access Key of the user with DynamoDB access rights, 
                        if not provided the environment variable AWS_ACCESS_KEY_ID_DYNAMO_DB_USER will be used"""),
                        default= os.environ.get('AWS_ACCESS_KEY_ID_DYNAMO_DB_USER'))
    db_options.add_argument('--AWSsecretKey', 
                        type=str, 
                        help="""The AWS access Key of the user with DynamoDB access rights, 
                        if not provided the environment variable AWS_ACCESS_KEY_ID_DYNAMO_DB_USER will be used""",
                        default= os.environ.get('AWS_SECRET_ACCESS_KEY_DYNAMO_DB_USER'))
    
    json_options = subparser.add_parser('fromJson')
    json_options.add_argument('-f', '--file', help='User Json file with all ecus simulation to generate',type=str)

    args=parser.parse_args()
    
    return args    

def main(inputs,dyn_resource):
    
        if inputs.verbose == "DEBUG":
            loglevel = logging.DEBUG
        elif inputs.verbose == "ERROR":
            loglevel = logging.ERROR
        else:
            loglevel = logging.INFO
        logging.basicConfig(level=loglevel, format='%(levelname)s: %(message)s')
        try:
            logger.debug("the inputs are:")
            for arg in vars(inputs):
                logger.debug("{} is {}".format(arg, getattr(inputs, arg)))

            jobs = Jobs()

            if inputs.command == "fromJson":
                 if inputs.file:
                    print (jobs.parsParameterFromJson(Path(inputs.file).read_text()))

            if inputs.command == "fromDatabase":
                print (jobs.parsParameterFromDB(inputs,dyn_resource ))


            logger.debug("Generation Done")

        except Exception as e:
            print(f"Something went wrong in main! Error: {e}")
            sys.exit(f"Something went wrong in main! Error: {e}")


if __name__ == "__main__":
    try:
        inputs=parse_args()
        main(inputs, boto3.resource('dynamodb'))
             
    except Exception as e:
        print(f"Something went wrong in __name__! Here's what: {e}")
        sys.exit(f"Something went wrong in __name__! Error: {e}")
