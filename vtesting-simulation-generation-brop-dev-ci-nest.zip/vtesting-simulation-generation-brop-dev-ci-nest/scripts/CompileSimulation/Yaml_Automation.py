"""
Created by: GIKUMAR
Date: 03-03-2023
Desc: API's for TLS Yaml Automation
"""
import os
import json
import yaml

#input_dir = r"C:\My_Drive\Yaml_Automation"
input_dir = r"dependencies"

def load_json(input_json_path):
    #retval = None
    with open(input_json_path) as infile:
        try:
            global _json_data
            # load file and copy key, values into _json_data
            _json_data = json.load(infile)
            print("Json loaded succesfully")
            #retval = True

        except Exception as e:
            print("Exception raise while load json", e)
            #retval = False

        finally:
            # close files
            infile.close()

    #return retval

def read_ecu_name():
    try:
        ecu_name = ""
        for key, value in _json_data.items():
            if key == "CommonData":
                for i_key, i_value in value.items():
                    if i_key == "ECU":
                        print("Value = ", value)
                        for j_key, j_value in i_value.items():
                            if j_key == "Name":
                                ecu_name = j_value


    except Exception as e:
        pass

    return ecu_name

def search_and_replace_infile(search_text,replace_text,file_name):

	# Opening file in read only mode
	with open(file_name, 'r') as file:

		# Reading the content of the file and store it in a variable
		data = file.read()
		#print("data = ",data)

		# Searching and replacing the text
		data = data.replace(search_text, replace_text)
		#print("replaced data = ",data)

	# Opening file in write only mode
	with open(file_name, 'w') as file:

		# Writing the replace_text in file
		file.write(data)

def read_setup_files(db_dir) :
    vmodule_file_list = []
    Eth_IL = False
    SendNM = False
    vECU_file = "None"
    vHSM_file = "None"
    arxml_file = "None"
    sysvar_file = "None"
    yaml_file = "None"
    can_file = "None"
    isExist = os.path.exists(db_dir)
    print(isExist)
    print(os.path.exists("dependencies"))
    print(os.path.exists("./dependencies"))
    print(os.path.exists("dependencies/"))
    return_data_list = [vECU_file,vHSM_file,arxml_file,sysvar_file,yaml_file,can_file]
    for root, dirs, files in os.walk(db_dir):
        for file in files:
            if file.endswith(".vmodule"):
                if "Ethernet_IL" in file:
                    Eth_IL = True
                else:
                    vmodule_file_list.append(file)
                    #print(os.path.join(root, file))

            elif file.endswith(".arxml"):
                arxml_file = file
                #print(os.path.join(root, file))

            elif file.endswith(".vsysvar"):   
                sysvar_file =  file
                #print(os.path.join(root, file))

            elif file.endswith(".yaml"):
                yaml_file =  os.path.join(root, file)
                #print(os.path.join(root, file))

            elif file.endswith(".can"):
                if "SendNM" in file:
                    SendNM = True
                else:
                    can_file = file
                    #print(os.path.join(root, file))

                
    if Eth_IL:
        pass
    else:
        print("Error : Ethernet_IL.vmodule not found")

    if SendNM:
        pass
    else:
        print("Error : SendNM.can not found")

    #print("dll_file_list = ",dll_file_list)
    if (len(vmodule_file_list) > 2) or (len(vmodule_file_list) == 0):
        print("Error : More than two dlls found or No dlls found")
    else :
        vECU_file = vmodule_file_list[0]
        print("vECU_file = ",vECU_file)
        return_data_list[0] = vECU_file
        if (len(vmodule_file_list) == 2) :
            vHSM_file = vmodule_file_list[1]
            print("vHSM_file = ",vHSM_file)
            return_data_list[1] = vHSM_file
    print("arxml_file = ",arxml_file)
    return_data_list[2] = arxml_file	
    print("sysvar_file = ",sysvar_file)
    return_data_list[3] = sysvar_file
    print("yaml_file = ",yaml_file)
    return_data_list[4] = yaml_file
    print("can_file = ",can_file)
    return_data_list[5] = can_file
    return return_data_list

def load_yaml(input_yaml_path):
    #retval = None
    with open(input_yaml_path) as infile:
        try:
            global _yaml_data
            # load file and copy key, values into _yaml_data
            _yaml_data = yaml.safe_load(infile)
            print(_yaml_data)
            print("Yaml loaded succesfully")
            #retval = True

        except Exception as e:
            print("Exception raised while load yaml", e)
            #retval = False

        finally:
            # close files
            infile.close()

def write_yaml(input_yaml_path):
    #retval = None
    with open(input_yaml_path,'w') as infile:
        try:
            # load file and copy key, values into _yaml_data
            yaml.dump(_yaml_data,infile,sort_keys=False)
            print(_yaml_data)
            print("Yaml written succesfully")
            #retval = True

        except Exception as e:
            print("Exception raised while writing yaml", e)
            #retval = False

        finally:
            # close files
            infile.close()

def edit_yaml_data_sysvar(sysvar_file):
    try:
        for key, value in _yaml_data.items():
            #print("Key = ",key," & Value = ",value)
            if key == "system-variables":
                value[0]["file-path"] = arxml_file
                #print(_yaml_data)
    except Exception as e:
        print("Exception", e)

def edit_yaml_data_database(arxml_file):
    try:
        for key, value in _yaml_data.items():
            #print("Key = ",key," & Value = ",value)
            if key == "databases":
                value[0]["file-path"] = arxml_file
                #print(_yaml_data)
    except Exception as e:
        print("Exception", e)

def edit_yaml_data_vECU(vECU_file):
    try:
        for key, value in _yaml_data.items():
            #print("Key = ",key," & Value = ",value)
            if key == "simulation-nodes":
                #print("value[0][modeling-libraries]",value[0]["modeling-libraries"])
                value[0]["modeling-libraries"] = [vECU_file]
                #print(_yaml_data)
    except Exception as e:
        print("Exception", e)

def edit_yaml_data_vHSM(vECU_file,vHSM_file):
    try:
        for key, value in _yaml_data.items():
            #print("Key = ",key," & Value = ",value)
            if key == "simulation-nodes":
                #print("value[0][modeling-libraries]",value[0]["modeling-libraries"])
                value[0]["modeling-libraries"] = [vECU_file,vHSM_file]
                #print(_yaml_data)
    except Exception as e:
        print("Exception", e)

def edit_yaml_data_can(can_file):
    try:
        for key, value in _yaml_data.items():
            #print("Key = ",key," & Value = ",value)
            if key == "simulation-nodes":
                print("value[0][file-path]",value[0]["file-path"])
                value[0]["file-path"] = can_file
                #print(_yaml_data)
    except Exception as e:
        print("Exception", e)


if __name__ == '__main__':
    try:

        #load_json("BROP_UI_Sample.json")
        ecu_name_json = "CU"
        print("ecu_name_json = ",ecu_name_json)

        vECU_file,vHSM_file,arxml_file,sysvar_file,yaml_file,can_file = read_setup_files(input_dir)
        search_and_replace_infile("v_ECU",ecu_name_json,yaml_file)
        load_yaml(yaml_file)

        # edit_yaml_data_sysvar(sysvar_file)
        edit_yaml_data_database(arxml_file)

        if vHSM_file == "None":
            edit_yaml_data_vECU(vECU_file)
        else:
            edit_yaml_data_vHSM(vECU_file,vHSM_file)

        if can_file == "None":
            pass
        else:
            edit_yaml_data_can(can_file)

        write_yaml(yaml_file)

    except Exception as e:
        print("Exception", e)

