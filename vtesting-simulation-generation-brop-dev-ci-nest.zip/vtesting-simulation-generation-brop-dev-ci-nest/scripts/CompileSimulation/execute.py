# -*- coding: utf-8 -*-

'''
Created by: STEPHIG
Date: 24-02-2023
Desc: API to execute a compiled configuration. Supports RESTBus simulation as well as execution with test unit.

Arguments:
    env: Relative/absolute path to compiled environment.
    testunit: Relative/absolute path to compiled test unit (optional).
    timeout: Maximum duration (minutes) to run configuration
    dest: Directory to save log files (Optional)

Usage:
    python execute.py <env> <testunit> <dest> <timeout>
    
    python execute.py -e Compiled/Default.venvironment -d Output/ -t 60
    python execute.py -e Compiled/Default.venvironment -v Compiled/Test.vtestunit -d Output/

TODO:
- Add function to start execution as independent process and exit
- Add function to stop an execution that may be running
- Add a state machine that allows user to interact with the execution system
'''

# Imports ---------------------------------------------------------------------
import os
import argparse as ap
import subprocess as sp

from Logger import LogHandler

# Constants -------------------------------------------------------------------

# Simulation constants
SIMC_TOOL = "C:\\Program Files\\Vector CANoe4SW Server Edition 16\\Exec64\\canoe4sw-se.exe"
SIMC_SYS_ARCH = "Win32"
SIMC_TIMEOUT = 5*60  # minutes

# Error code messages
ERC_MESSAGES = {
    0:"Success",
    1:"Error when parsing CLI parameters.",
    2:"An error occurred during execution of the environment defined in the configuration file.",
    99:"Status of test execution is unknown. The final verdict was undefined.",
    101:"All tests were executed, but at least one test failed.",
    102:"All tests were executed, but no results were received.",
    103:"All tests were executed, but the result is inconclusive.",
    104:"An error in the test system occurred while executing the tests."
}

# Logging functions -----------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# Functions -------------------------------------------------------------------

# Run simulation of test unit and exit at the end. Function waits for 
# simulation to end or timeout.
# Arguments:
#    env: Path to compiled environment
#    vtu: Path to compiled vTestUnit
#    timeout: Maximum duration to run the simulation
#    dest: Directory to store compiled environment files
# Return:
#       True: Completed
#       False: Failed to run
def run_simulation(env,vtu=None,dest=".",timeout=SIMC_TIMEOUT):
    status = False
    err = True
    log_info("Initiating simulation...")
    # Create destination folder
    try:
        dest = os.path.abspath(dest)
        if not os.path.exists(dest):
            os.makedirs(dest)
            err = False
        else:
            # Path exists
            err = False
    except Exception as e:
        log_error("Failed to create output directory: %s"% e)

    # Start execution if everything went well so far
    if not err:
        # Generate command line argument

        # TODO: Should I use a class for this?
        # Basic command without test unit
        cmd = [SIMC_TOOL,env]
        # Show progress
        cmd.append("--show-progress=tree-element")
        # Set working directory
        cmd.append("--working-dir=%s"%dest)
        # Add vtest unit if valid
        if vtu is not None:
            if os.path.exists(vtu):
                log_info("Adding vTestunit: %s"%vtu)
                cmd.append("--test-unit=%s"%vtu)
            else:
                log_error("vTest Unit not found.")
        
        log_debug("Cmd: %s" % (cmd))
        
        # Initiate subprocess and wait for completion
        try:
            # Convert timeout to seconds
            timeout=timeout*60
            exec_out = sp.run(cmd, capture_output=True, check=True, 
                timeout=timeout)
            log_info("Simulation completed successfully!!!")
            log_debug("retcode: %d"%(exec_out.returncode))
            log_info("Output: \n%s"%(exec_out.stdout.decode("utf-8")))
            log_debug("Error: \n%s"%(exec_out.stderr.decode("utf-8")))
            status = True
        except sp.TimeoutExpired as e:
            log_error("Timeout occured during execution!")
            log_debug("Error: \n%s"%(e.stderr.decode("utf-8")))
            log_info("Output: \n%s"%(e.stdout.decode("utf-8")))
        except sp.CalledProcessError as e:
            log_error("Error during execution. Exit code: %d" % (e.returncode))
            try:
                log_error(ERC_MESSAGES[e.returncode])
            except:
                # Unknown error
                pass
            log_info("Error: \n%s"%(e.stderr.decode("windows-1252")))
            log_info("Output: \n%s"%(e.stdout.decode("windows-1252")))
        except Exception as e:
            log_error("Unhandled exception during execution: %s"%(e))
    return status

# CLI -------------------------------------------------------------------------

def cli_handler():
    parser = ap.ArgumentParser()
    sargs = parser.add_argument_group("Arguments for simulation")
    sargs.add_argument("-e","--env",
        metavar="Environment",
        help="Path to compiled environment",
        type=str,
        required=True,
        default=None
        )

    sargs.add_argument("-v","--vtu",
        metavar="vTestUnit",
        help="Path to compiled vTest Unit. Will run RestBus simulation if not provided.",
        type=str,
        required=False,
        default=None
        )
    
    # Simulation Timeout
    parser.add_argument("-t","--timeout",
        metavar="Time",
        help="Maximum duration to run simulation (minutes)",
        type=int,
        default=SIMC_TIMEOUT)
    
    # Output folder
    parser.add_argument("-o","--output",
        metavar="Output",
        help="Path to store logs, output files",
        type=str,
        default="Output")
    
    args = parser.parse_args()
    
    return args.env,args.vtu,args.output,args.timeout

# API -------------------------------------------------------------------------

def execute():
    penv,pvtu,out,timeout = cli_handler()
    # Start simulation
    run_simulation(env=penv,vtu=pvtu,dest=out,timeout=timeout)
    return

if __name__ == "__main__":
    log_info("-"*80)
    execute()
    log_info("-"*80)
    pass

# End of file -----------------------------------------------------------------
