"""
Created by: SYARAGA
Date: 10-05-2023
Desc: main script which generates the yaml file

"""

# Import section ---------------------------------------
import argparse as ap

from NEST_yaml import YAML_Config
from Logger import LogHandler

from constants import OUTPUT_FILE
from constants import VALID_VECU_TYPES
from constants import VECU_TYPE_STRING
from constants import NETWORK_TYPE_STRING
from constants import VALID_NETWORK_TYPES

# Create logger for file
if __name__ == '__main__':
    logger=LogHandler()
    logger.setup()
else:
    logger=LogHandler(__name__)

# Functions -------------------------------------------------------------------

# Command line handler
def cli_handler():
    # Create parser
    parser=ap.ArgumentParser(description="Generate the NEST yaml file")
   
    # Add argument for vECU_name
    parser.add_argument("-i","--vECU_name",
        type=str,
        help="Diagnostic name of the vECU to be analyzed",
        required=True)
    
    # Add argument for network_type
    parser.add_argument('-n', "--network_type",
        type=str,
        choices= VALID_NETWORK_TYPES,
        help="Network type: %s"%NETWORK_TYPE_STRING,
        required=True)
    
    # Add argument for vECU_type
    parser.add_argument("-t", "--vECU_type",
        type=str,
        choices= VALID_VECU_TYPES,
        help="vECU_type: %s"%VECU_TYPE_STRING,
        required=True)
    
    # Add argument to database
    parser.add_argument("-d", "--database",
        type=str,
        help="path to the database folder for all the files",
        required=True)
    
    args = parser.parse_args()
    
    return args.vECU_name,args.network_type,args.vECU_type,args.database

def generate():
    vECU_name,network_type,vECU_type,database = cli_handler()
    obj = YAML_Config(vECU_name=vECU_name,network_type=network_type,vECU_type=vECU_type,database_folder=database)
    func_list = [obj.add_version,obj.add_sysvar,obj.add_database,obj.add_network,obj.add_simulation_nodes,obj.add_logging]
    count = 0
    for functions in func_list:
        if functions():
            obj.create_yaml(OUTPUT_FILE)
            count+=1
    if count == len(func_list):
        logger.debug("All functions executed successfully")
    else:
        logger.info("Failed to execute 1 or more functions")
    return 

if __name__ =='__main__':
    logger.debug("-"*80)
    generate()
    logger.debug("-"*80)
    pass


