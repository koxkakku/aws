"""
Created by: SYARAGA
Date: 25-04-2023
Desc: ymlconfig is used to create nodes required to be added in simulation nodes and network nodes
 
"""
# Import section ---------------------------------------------------------------

from Logger import LogHandler

#Main nodes of YAML file
from constants import NODE_CANFD_NETWORKS
from constants import NODE_ETHERNET_NETWORKS

# Constant for ethernet yaml file
from constants import MAIN

# Simulation node constants
from constants import SIM_NODE_PROP_NAME
from constants import SIM_NODE_PROP_FILE_PATH
from constants import SIM_NODE_PROP_NETWORK
from constants import SIM_NODE_PROP_MODELLING_LIBRARIES
from constants import SIM_NODE_PROP_NETWORK_ASSIGNMENTS
from constants import SIM_NODE_PROP_TCP_IP_STACK
from constants import SIM_NODE_PROP_SELECTED_STACK
from constants import SIM_NODE_PROP_NODE
from constants import SIM_NODE_PROP_DATABASE_NODE
from constants import SIM_NODE_PROP_DATABASE
from constants import SIM_NODE_PROP_INDIVIDUAL

# Network node properties
from constants import NW_NODE_PROP_MODE
from constants import NW_NODE_PROP_NAME
from constants import NW_NODE_PROP_DATABASES
from constants import NW_NODE_PROP_APP_CHANNEL
from constants import NW_NODE_PROP_ARBITRATION_BAUDRATE
from constants import NW_NODE_PROP_DATA_BAUDRATE
from constants import NW_NODE_PROP_MAPPING
from constants import NW_NODE_PROP_ISO
from constants import NW_NODE_PROP_INT_SIM

# User input parametres
from constants import CANFD
from constants import ETHERNET

# Logging functions -----------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return



'''Class simulation_node to add nodes like VectorSimulation nodes, 
VirtualTarget nodes based on the network type'''

class simulation_node():

    def __init__(self,nwtype):
        self.nwtype = nwtype
        pass
    
    ''' Structure of the properties being added for canfd
    simulation-nodes:

    - name: VectorSimulationNode
      file-path: can file
      network-assignments:
      - network: CAL_XX
      modelling-libraries:
      - vmodule1
      - vmodule2
      - vmodule3

    - name: VirtualTarget
      file-path: can file
      network-assignments:
    - network: CAL_XX
    modelling-libraries:
    - vmodule files

    Structure of the properties added for ethernet
        simulation-nodes:

        - name: ECU_name
        file-path: can file
        tcp-ip-stack:
            selected-stack: individual
        network-assignments:
        - network: network
            database-node:
            database: network
            node: ECU_name
        modeling-libraries:
        - Database\\MyECU.vmodule
        
        - name: VirtualTarget
        tcp-ip-stack:
            selected-stack: individual
        network-assignments:
        - network: network
        modeling-libraries:
        - vmodule files
    

    '''

    # NOTE: Find a way to reduce number of arguments
    def add_node(self,node_name,vECU_name,modelling_libraries_node = False,filepath=None,modelling_libraries=list(),filepath_node = False,db_node=False):
        sim_node_data = {}
        if self.nwtype.lower() == CANFD:
              sim_node_data[SIM_NODE_PROP_NAME] = node_name
              if filepath_node:
                sim_node_data[SIM_NODE_PROP_FILE_PATH] = filepath
              sim_node_data[SIM_NODE_PROP_NETWORK_ASSIGNMENTS] = [{SIM_NODE_PROP_NETWORK:vECU_name}]
              if modelling_libraries_node:
                    sim_node_data[SIM_NODE_PROP_MODELLING_LIBRARIES] = modelling_libraries 
        elif self.nwtype.lower() == ETHERNET:
            sim_node_data[SIM_NODE_PROP_NAME] = node_name
            if filepath_node:
                sim_node_data[SIM_NODE_PROP_FILE_PATH] = filepath
            sim_node_data[SIM_NODE_PROP_TCP_IP_STACK] = {SIM_NODE_PROP_SELECTED_STACK:SIM_NODE_PROP_INDIVIDUAL}
            sim_node_data[SIM_NODE_PROP_NETWORK_ASSIGNMENTS] = [{SIM_NODE_PROP_NETWORK:MAIN}]
            if db_node:
                sim_node_data[SIM_NODE_PROP_NETWORK_ASSIGNMENTS][0][SIM_NODE_PROP_DATABASE_NODE] = {SIM_NODE_PROP_DATABASE:MAIN, SIM_NODE_PROP_NODE:vECU_name}
            sim_node_data[SIM_NODE_PROP_MODELLING_LIBRARIES] = modelling_libraries
        else:
            log_debug('Simulation nodes not generated, because network name not supported: %s'%(self.nwtype))
        return sim_node_data


class network_node():
    def __init__(self,nw_type):
        self.nw_type = nw_type
    
    def add_node(self,vECU_name):
        network_data = None
        # NOTE: Baud rate may change
        if self.nw_type.lower() == CANFD:
            network_data = {NODE_CANFD_NETWORKS : [{NW_NODE_PROP_NAME: vECU_name, 
                                             NW_NODE_PROP_DATABASES: [vECU_name],
                                               NW_NODE_PROP_APP_CHANNEL: 1, 
                                               NW_NODE_PROP_MODE: NW_NODE_PROP_ISO, 
                                               NW_NODE_PROP_ARBITRATION_BAUDRATE: 500000,
                                               NW_NODE_PROP_DATA_BAUDRATE: 1000000,
                                               NW_NODE_PROP_MAPPING:NW_NODE_PROP_INT_SIM}]}
        elif self.nw_type.lower() == ETHERNET:
            network_data = {NODE_ETHERNET_NETWORKS: [{NW_NODE_PROP_NAME:MAIN,
                                                  NW_NODE_PROP_DATABASES:[MAIN]}]}
        else:
            log_error('Failed to add network node. Unknown Network type: %s'%(self.nw_type))
        return network_data


def test():
    return

if __name__ == "__main__":
    test()
