"""
Created by: SYARAGA
Date: 25-04-2023
Desc: Strings being defined for the NEST_Yaml generation file
 
"""

# Output file
OUTPUT_FILE = 'venvironment.yaml'

# Constant for ethernet yaml file
MAIN = 'MAIN'

#Extensions for files
EXT_ARXML = '.arxml'
EXT_VSYSVAR = '.vsysvar'

# Folder database
FOLDER_DATABASE = 'dependencies'

#Main nodes of YAML file
NODE_VERSION = 'version'
NODE_VERSION_DATA = '1.1.0'
NODE_DATABASES = 'databases'
NODE_SYSTEM_VARIABLES = 'system-variables'
NODE_CANFD_NETWORKS = 'canfd-networks'
NODE_ETHERNET_NETWORKS = 'ethernet-networks'
NODE_SIMULATION_NODE = 'simulation-nodes'

#Database node property name
DB_NODE_PROP_NAME = 'name'
DB_NODE_PROP_FILE_PATH = 'file-path'
DB_NODE_PROP_NETWORK_NAME = 'network-name'

#System variables property
SYS_VAR_NODE_PROP_FILE_PATH = 'file-path'

# Simulation nodes Constants
SIM_NODE_PROP_NAME = 'name'
SIM_NODE_PROP_FILE_PATH = 'file-path'
SIM_NODE_PROP_NETWORK = 'network'
SIM_NODE_PROP_MODELLING_LIBRARIES = 'modeling-libraries'
SIM_NODE_PROP_NETWORK_ASSIGNMENTS = 'network-assignments'
SIM_NODE_PROP_TCP_IP_STACK = 'tcp-ip-stack'
SIM_NODE_PROP_SELECTED_STACK = 'selected-stack'
SIM_NODE_PROP_NODE = 'node'
SIM_NODE_PROP_DATABASE_NODE = 'database-node'
SIM_NODE_PROP_DATABASE = 'database'
SIM_NODE_PROP_INDIVIDUAL = 'individual'
SIM_NODE_VECTOR_SIMULATION_NODE = 'VectorSimulationNode'
SIM_NODE_VIRTUAL_TARGET = 'VirtualTarget'
SIM_NODE_ETH_SIMULATION_NODE = 'Simulation_Node'

# Network node properties
NW_NODE_PROP_MODE = 'mode'
NW_NODE_PROP_NAME = 'name'
NW_NODE_PROP_DATABASES ='databases'
NW_NODE_PROP_APP_CHANNEL = 'application-channel'
NW_NODE_PROP_ARBITRATION_BAUDRATE = 'arbitration-baudrate'
NW_NODE_PROP_DATA_BAUDRATE = 'data-baudrate'
NW_NODE_PROP_MAPPING = 'mapping'
NW_NODE_PROP_ISO = 'iso'
NW_NODE_PROP_INT_SIM = 'internal-simulator'

# Logging node properties
LOG_NODE_LOGGING = 'logging'
LOG_NODE_FILE_NAME = 'file-name'
LOG_NODE_TEST_LOGGING_BLF = 'Test_Logging.blf'

# User input parametres
VTT = 'vtt'
SILVER = 'silver'
CANFD = 'canfd'
ETHERNET = 'ethernet'

# Dictionary keyword
DICT_ARXML = 'arxml'
DICT_VSYSVASR = 'vsysvar'

# Valid choice types
VALID_VECU_TYPES = ['vtt','silver']
VALID_NETWORK_TYPES = ['canfd','ethernet']

# Strings of options
VECU_TYPE_STRING=" | ".join(VALID_VECU_TYPES)
NETWORK_TYPE_STRING=" | ".join(VALID_NETWORK_TYPES)