"""
Created by: SYARAGA
Date: 25-04-2023
Desc: Script to create YAML files for NEST for canfd and ethernet network

"""

# Import section ----------------------------------------------------------------
import yaml
import os

from Logger import LogHandler

from ymlconfig import simulation_node
from ymlconfig import network_node

# Output yaml file
from constants import OUTPUT_FILE

# Constant for ethernet yaml file
from constants import MAIN

# Folder Database
from constants import FOLDER_DATABASE

#Extensions for files
from constants import EXT_ARXML
from constants import EXT_VSYSVAR

#Main nodes of YAML file
from constants import NODE_DATABASES
from constants import NODE_VERSION
from constants import NODE_VERSION_DATA
from constants import NODE_SYSTEM_VARIABLES
from constants import NODE_SIMULATION_NODE

#Database node property name
from constants import DB_NODE_PROP_NAME 
from constants import DB_NODE_PROP_FILE_PATH 
from constants import DB_NODE_PROP_NETWORK_NAME

#System variables property
from constants import SYS_VAR_NODE_PROP_FILE_PATH

# Simulation node constants
from constants import SIM_NODE_VECTOR_SIMULATION_NODE
from constants import SIM_NODE_VIRTUAL_TARGET
from constants import SIM_NODE_ETH_SIMULATION_NODE

# Logging node constants
from constants import LOG_NODE_LOGGING
from constants import LOG_NODE_FILE_NAME
from constants import LOG_NODE_TEST_LOGGING_BLF

# User input parametres
from constants import VTT
from constants import SILVER
from constants import CANFD
from constants import ETHERNET

# Dictionary keyword
from constants import DICT_ARXML
from constants import DICT_VSYSVASR

# Constants defined for simulation node method canfd
can_file_canfd_vector_sim = r'Trigger_PDU_VSM.can'
vmodule_canfd_vector_sim_SecMgr = r'SecMgrCANoeClient.vmodule'
vmodule_canfd_vector_sim_AsrPDUIL =r'AsrPDUIL.vmodule'
vmodule_canfd_vector_sim_AsrPDUIL2 = r'AsrPDUIL2.vmodule'
can_file_canfd_virtual_target = r'VirtualTarget.can'
vmodule_canfd_virtual_target_LIBB2 = r'LiBB2_CamelPreh_0009022288_230731_VTT.vmodule'


# Constants defined for simulation node method ethernet
can_file_ethernet_virtual_target = r"PowerSupply.can"
vmodule_ethernet_virtual_target = r"MyECU.vmodule"
vmodule_ethernet_vector_simulation = r"Ethernet_IL.vmodule"

# Logging functions -----------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# Class YAML_Config to generate a final yaml file for NEST
class YAML_Config():
    """
    Main class
    """
    yaml_config_dict = {}
    local_filesys = None

    '''Users need to provide vECU_name, network_type, vECU_type, database folder
    ex: 
        - vECU_name = CAL_XX
        - network_type = canfd
        - vECU_type = vtt
        - database = DATABASE_FOLDER
    
    '''
    def __init__(self,vECU_name,network_type,vECU_type,database_folder):
        self.vECU_name = vECU_name
        self.network_type = network_type
        self.vECU_type = vECU_type
        self.database_folder = database_folder
        return

    # Logic to find files like arxml, vsysvar etc
    def file_finding(self):
        if self.local_filesys is None:
            res_dict = {}
            arxml_lst = []
            vsysvar_list = []
            log_debug("Started file finding")
            for root,dirs,files in os.walk(self.database_folder):
                for file in files:
                    if file.endswith(EXT_ARXML):
                        log_debug('found the arxml file')
                        # TODO: Recheck the need for converting to raw string
                        #filepath = os.path.join(root,file)
                        filepath = file
                        arxml_lst.append(filepath)
                    elif file.endswith(EXT_VSYSVAR):
                        log_debug('found the vsysvar file')
                        #filepath = os.path.join(root,file)
                        filepath = file
                        vsysvar_list.append(filepath)
            if len(arxml_lst)>0:
                res_dict[DICT_ARXML] = arxml_lst
            else:
                res_dict[DICT_ARXML] = None

            if len(vsysvar_list)>0:
                res_dict[DICT_VSYSVASR] = vsysvar_list
            else:
                res_dict[DICT_VSYSVASR] = None
            self.local_filesys = res_dict
            log_debug("Local Directory: %s"%self.local_filesys)
        return self.local_filesys
    
    # Function to return paths with double backslash 
    # (YAML requiers either single front slash or double back slash for it's working)
    def raw_string(self,path):
        rw_string_filepath = path.encode('unicode_escape').decode()
        return rw_string_filepath

    # Version details of a particular YAML file
    def add_version(self):
        log_debug('Adding version information node')
        version_details = { NODE_VERSION : NODE_VERSION_DATA }
        self.yaml_config_dict.update(version_details)
        return True

    # method to add database to the yaml file
    def add_database(self,network_name_node= True):
        log_debug('Adding database node')
        status = False
        file = self.file_finding()
        arxml = []
        db_details = {}
        try:
            if file[DICT_ARXML] is not None:
                # If there are multiple arxml files present in the folder, it takes the first file.
                arxml = file[DICT_ARXML][0]
                status = True
            else:
                log_error("Did not find any ARXML files")
        except UnboundLocalError:
            log_exception('Could not find key ARXML in local file system')
        except IndexError:
            log_exception('Local file system does not have any ARXML files')
        except Exception as e:
            log_exception('Unknown Exception while adding database node:',e)
        if self.network_type.lower() == CANFD:
            db_details = {NODE_DATABASES: [{DB_NODE_PROP_NAME: self.vECU_name, DB_NODE_PROP_FILE_PATH: arxml }]}
        elif self.network_type.lower() == ETHERNET:
            db_details = {NODE_DATABASES: [{DB_NODE_PROP_NAME: MAIN, DB_NODE_PROP_FILE_PATH: arxml}]}
            if network_name_node:
                db_details = {NODE_DATABASES: [{DB_NODE_PROP_NAME: MAIN, DB_NODE_PROP_FILE_PATH: arxml,DB_NODE_PROP_NETWORK_NAME: MAIN}]}
        else:
            log_debug('Network name not supported: %s'%(self.network_type))
        self.yaml_config_dict.update(db_details)
        return status

    # method to add system variables to the yaml file
    def add_sysvar(self,sysvar_node = True):
        # system variables can be added to the yaml file based on the bool value of sysvae_node 
        log_debug('Adding system_variable node')
        status = False
        file = self.file_finding()
        filepath = []
        try:
            if file[DICT_VSYSVASR] is not None:
                filepath = file[DICT_VSYSVASR]
                status = True
            else:
                log_error('Did not find any vsysvar files')
        except Exception as e:
            log_debug('Failed to add system variable node: ',e) 
        if sysvar_node:
            sys_var_details = {NODE_SYSTEM_VARIABLES: [{SYS_VAR_NODE_PROP_FILE_PATH: filepath}]}
            self.yaml_config_dict.update(sys_var_details)
        else:
            log_debug('Not adding the system variables node')
        return status

    '''
    Inside add_network method it calls a class called network_node()
    which has a method named add_node, which add's node depending on the
    network type and properties defined in that network 
    '''
    def add_network(self):
        log_debug('Adding network node')
        status = False
        network_obj = network_node(nw_type=self.network_type)
        nw_details = network_obj.add_node(vECU_name=self.vECU_name)
        if nw_details is not None:
            self.yaml_config_dict.update(nw_details)
            status = True
        return status

    '''
    Inside add_simulation_nodes method it calls a class called simulation_node()
    which has a method named add_node, which add's node depending on the type of simulation
    node and properties defined in that node 
    '''    
    def add_simulation_nodes(self):
        log_debug('Adding simulation node')
        status = False

        '''
        simobj:[Class used to create simulation nodes, which adds nodes]
        for canfd network, user need to add 
        node_name:
        file-path:
        vecu_name - for the network-assignment property
        modelling libraries

        for ethernet network:
        node_name:
        file-path:
        vecu_name
        set the db_node true or false as required
        set the filepath_node true of false as required
        modeling-libraries
        
        '''

        simobj = simulation_node(nwtype=self.network_type)
        if self.network_type.lower() == CANFD:
            node_VectorSimulation = simobj.add_node(node_name=SIM_NODE_VECTOR_SIMULATION_NODE,filepath=can_file_canfd_vector_sim,
                                                       vECU_name=self.vECU_name,modelling_libraries=[vmodule_canfd_vector_sim_SecMgr,
                                                       vmodule_canfd_vector_sim_AsrPDUIL2,vmodule_canfd_vector_sim_AsrPDUIL],filepath_node=True,modelling_libraries_node=True)
            node_VirtualTarget = simobj.add_node(node_name= SIM_NODE_VIRTUAL_TARGET,filepath=can_file_canfd_virtual_target,vECU_name=self.vECU_name,
                                                    modelling_libraries=[vmodule_canfd_virtual_target_LIBB2],filepath_node=True,modelling_libraries_node=True)
        
        elif self.network_type.lower() == ETHERNET:
            node_VectorSimulation = simobj.add_node(node_name= SIM_NODE_ETH_SIMULATION_NODE,vECU_name=MAIN,
                                                    modelling_libraries=[vmodule_ethernet_vector_simulation])
            node_VirtualTarget = simobj.add_node(node_name=self.vECU_name,filepath=can_file_ethernet_virtual_target,
                                                       vECU_name=self.vECU_name,modelling_libraries=[vmodule_ethernet_virtual_target],
                                                       db_node=True,filepath_node=True)
        else:
            log_debug('Network name not supported: %s'%(self.network_type))
        node_details = {NODE_SIMULATION_NODE:[]}
        if self.network_type.lower() == ETHERNET and self.vECU_type.lower() == VTT:
            status = True
            node_details = {NODE_SIMULATION_NODE:[node_VectorSimulation,node_VirtualTarget]}
        elif self.network_type.lower() == CANFD and self.vECU_type.lower() == VTT:
            status = True
            node_details = {NODE_SIMULATION_NODE:[node_VectorSimulation,node_VirtualTarget]}
        elif self.network_type.lower() == ETHERNET and self.vECU_type.lower() == SILVER:
            status = True
            node_details = {NODE_SIMULATION_NODE:[node_VectorSimulation]}    
        elif self.network_type.lower() == CANFD and self.vECU_type.lower() == SILVER:
            status = True
            node_details = {NODE_SIMULATION_NODE:[node_VectorSimulation]}
        else:
            status = False
            log_error('Failed to add Simulation nodes. Unknown network type: %s'%(self.network_type))

        self.yaml_config_dict.update(node_details)
        return status
    
    # Creating logging method to add a test_logging.blf file
    def add_logging(self):
        log_debug('adding Test_Logging.blf file')
        log_details = {LOG_NODE_LOGGING:{LOG_NODE_FILE_NAME:LOG_NODE_TEST_LOGGING_BLF}}
        self.yaml_config_dict.update(log_details)
        return True

    # Creating yaml file to dump all the final output
    def create_yaml(self,filename):
        log_debug('Created yaml file: %s'%(filename))
        try:
            with open(filename,'w') as file:
                yaml.dump(self.yaml_config_dict,file, sort_keys= False)
        except yaml.YAMLError as e:
            log_exception('An error has occurred while trying to dump the data to the file')
        return True


def main():
    obj = YAML_Config(vECU_name='CAL_XX',network_type='canfd',vECU_type='vtt',database_folder=FOLDER_DATABASE)
    obj.add_version()
    obj.add_sysvar()
    obj.add_database()
    obj.add_network()
    obj.add_simulation_nodes()
    obj.add_logging()
    obj.create_yaml(OUTPUT_FILE)
    return

if __name__ == '__main__':
    logger.debug("-"*80)
    main()
    logger.debug("-"*80)
