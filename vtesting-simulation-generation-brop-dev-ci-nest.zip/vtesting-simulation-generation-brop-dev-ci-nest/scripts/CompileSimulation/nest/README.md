To generate the YAML files, run generate_yaml.py file, the usage is as below

usage: generate_yaml.py [-h] -i VECU_NAME -n {canfd,ethernet} -t {vtt,silver} -d DATABASE

Generate the NEST yaml file

options:
  -h, --help            show this help message and exit
  -i VECU_NAME, --vECU_name VECU_NAME
                        Diagnostic name of the vECU to be analyzed
  -n {canfd,ethernet}, --network_type {canfd,ethernet}
                        Network type: canfd | ethernet
  -t {vtt,silver}, --vECU_type {vtt,silver}
                        vECU_type: vtt | silver
  -d DATABASE, --database DATABASE
                        path to the database folder for all the files
