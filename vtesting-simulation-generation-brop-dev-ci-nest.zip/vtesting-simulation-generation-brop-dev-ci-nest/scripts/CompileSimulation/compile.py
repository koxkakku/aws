# -*- coding: utf-8 -*-

'''
Created by: STEPHIG
Date: 24-02-2023
Desc: API to compile YML based configuration and VTUexe files.

Arguments:
    filetype: Type of file to be compiled
        vtu: Compile *.vtuexe file
        yml: Compile YML file. If the input filename is a directory, then the 
            name of the expected YML file must be venvironment.yml
        all: Compile YML file followed by VTUEXE file
        
    filename: Relative/absolute path of file to be compiled. 
        In case of directory it must contain required files in the correct 
        format. Use help to get details.
    dest: Directory to save compilation (Default: Current working directory)

Usage:
    python compile.py <filetype> <filename> <dest>
    
    python compile.py vtu C:/Test/Config1/test.vtuexe Default.venvironment Output/
    python compile.py vtu C:/Test/Config1/ Default.venvironment Output/
    
    python compile.py yml C:/Test/Config1/venvironment.yml Compiled/
    python compile.py yml C:/Test/Config1/ Compiled/

    python compile.py all C:/Test/Config1/ Compiled/

Remarks: In case of YML you can pass the directory of configuration
containing the YML file instead of the actual YML filename.
Please note that in this case the name of the YML file must be venvironment.yml
'''

# Imports ---------------------------------------------------------------------
import os
import argparse as ap
import subprocess as sp

from Logger import LogHandler

# Constants -------------------------------------------------------------------
COMPILATION_TIMEOUT = 5*60

# YML Compile constants
YCC_TOOL = "C:\\Program Files\\Vector CANoe4SW Server Edition 16\\Exec64\\environment-make.exe"
YCC_SYS_ARCH = "Win32"
YCC_TIMEOUT = COMPILATION_TIMEOUT

# vTestUnit Compile Tool
VTUC_TOOL = "C:\\Program Files\\Vector CANoe4SW Server Edition 16\\Exec64\\test-unit-make.exe"
VTUC_TIMEOUT = COMPILATION_TIMEOUT

# Command line options
CLI_TYPE_VTU = "vtu"
CLI_TYPE_YML = "yml"
CLI_TYPE_DUAL = "all"

# Logging functions -----------------------------------------------------------
# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# Functions -------------------------------------------------------------------

# Compiled YML file to generate environment
# Arguments:
#    filename: Name of yml file to be compiled OR
#    filename: Name of directory containing venvironment.yml file
#    dest: Directory to store compiled environment files
# Return:
#    status: 
#       True: Compiled successfully
#       False: Failed to Compile
def compile_env(filename,dest="."):
    status = False
    err = True
    log_info("Start compiling environment: %s"%(filename))

    # TODO: Add some file validation here before proceeding
    if os.path.isdir(filename):
        # This is a directory. Search for yml file inside
        pass
    else:
        # This is a file. Validate extension and get filename
        pass

    # Create destination folder
    try:
        dest = os.path.abspath(dest)
        if not os.path.exists(dest):
            os.makedirs(dest)
            err = False
        else:
            # Path exists
            err = False
    except Exception as e:
        log_error("Failed to create output directory: %s"% e)

    # Start compilation if everything went well so far
    if not err:
        # Generate command line argument
        # TODO: Should I use a class for this?
        cmd = [YCC_TOOL,filename,"-A%s"%(YCC_SYS_ARCH),"-o%s"%(dest)]
        # Execute subprocess and wait for completion
        try:
            exec_out = sp.run(cmd, capture_output=True, check=True, 
                timeout=YCC_TIMEOUT)
            log_info("Compiled successfully!!!")
            log_debug("retcode: %d"%(exec_out.returncode))
            log_info("Output: \n%s"%(exec_out.stdout.decode("utf-8")))
            log_debug("Error: \n%s"%(exec_out.stderr.decode("utf-8")))
            status = True
        except sp.TimeoutExpired as e:
            log_error("Timeout occured during compilation!")
            log_debug("Error: \n%s"%(e.stderr.decode("utf-8")))
            log_info("Output: \n%s"%(e.stdout.decode("utf-8")))
        except sp.CalledProcessError as e:
            log_error("Error during compilation. Exit code: %d" % (e.returncode))
            log_info("Error: \n%s"%(e.stderr.decode("utf-8")))
            log_debug("Output: \n%s"%(e.stdout.decode("utf-8")))
        except Exception as e:
            log_error("Unhandled exception during compilation: %s"%(e))
            log_info("Error: \n%s"%(e.stderr.decode("utf-8")))
    return status

# Compiled vtuexe file(s) along with compiled environment to generate vTestUnit 
# Arguments:
#    vfile: VTU EXE filename
#    envfile: Compiled environment file
#    dest: Directory to store compiled vtestunit files
# Return:
#    status: 
#       True: Compiled successfully
#       False: Failed to Compile
def compile_vtu(vtufile, envfile, dest="."):
    status = False
    err = True
    log_info("Start compiling VT unit: %s"%(vtufile))

    # TODO: Add some file validation here before proceeding
    if os.path.isdir(vtufile):
        # This is a directory.
        pass
    else:
        # This is a file. Validate extension and get filename
        pass

    # Create destination folder
    try:
        dest = os.path.abspath(dest)
        if not os.path.exists(dest):
            os.makedirs(dest)
            err = False
        else:
            # Path exists
            err = False
    except Exception as e:
        log_error("Failed to create output directory: %s"% e)

    # Start compilation if everything went well so far
    if not err:
        # Generate command line argument
        # TODO: Should I use a class for this?
        cmd = [VTUC_TOOL,vtufile,"-e%s"%(envfile),"-o%s"%(dest)]
        # Execute subprocess and wait for completion
        try:
            exec_out = sp.run(cmd, capture_output=True, check=True, 
                timeout=YCC_TIMEOUT)
            log_info("Compiled successfully!!!")
            log_debug("retcode: %d"%(exec_out.returncode))
            log_info("Output: \n%s"%(exec_out.stdout.decode("utf-8")))
            log_debug("Error: \n%s"%(exec_out.stderr.decode("utf-8")))
            status = True
        except sp.TimeoutExpired as e:
            log_error("Timeout occured during compilation!")
            log_debug("Error: \n%s"%(e.stderr.decode("utf-8")))
            log_info("Output: \n%s"%(e.stdout.decode("utf-8")))
        except sp.CalledProcessError as e:
            log_error("Error during compilation. Exit code: %d" % (e.returncode))
            log_info("Error: \n%s"%(e.stderr.decode("utf-8")))
            log_debug("Output: \n%s"%(e.stdout.decode("utf-8")))
        except Exception as e:
            log_error("Unhandled exception during compilation: %s"%(e))
            log_info("%s"%(e.stdout.decode("utf-8")))
    return status

# Compile YML file to generate environment and use this to compile vtuexe files 
# in given directory.
# Arguments:
#    filename: Name of directory containing venvironment.yml file
#    dest: Directory to store compiled environment files
# Return:
#    status:
#       True: Compiled successfully
#       False: Failed to Compile
# NOTE: Not sure about use case. Will not add to CLI until confirmed.
def compile_dual(filename,dest="."):
    status = False
    
    envstatus = compile_env(filename=filename,dest=dest)
    if envstatus:
        # compiled successfully. Proceed ahead
        envfilename = os.path.join(filename,"Default.venvironment")
        status = compile_vtu(vtufile=filename,envfile=envfilename,dest=dest)
        
    return status

# CLI -------------------------------------------------------------------------

# CLI options for compiling VTUEXE file
def cli_vtu(subparser):
    vparser=subparser.add_parser(CLI_TYPE_VTU, \
        help="Compile VTUEXE file")
    vargs=vparser.add_argument_group("Arguments for vtuexe")
    
    # Input vtuexe file OR dir containing vtuexe file(s)
    vargs.add_argument("-i","--input",
        metavar="Input",
        help="Path to vtuexe file OR directory containing vtuexe file(s)",
        type=str,
        required=True,
        default=None)

    # Compiled environment
    vargs.add_argument("-e","--env",
        metavar="Environment",
        help="Path to compiled environment",
        type=str,
        required=True,
        default=None)

    # Output folder
    vargs.add_argument("-o","--output",
        metavar="Output",
        help="Path to store output files",
        type=str,
        default="Output")
    
    return

# CLI options for compiling YML file
def cli_yml(subparser):
    vparser=subparser.add_parser(CLI_TYPE_YML, \
        help="Compile YML file")
    vargs=vparser.add_argument_group("Arguments for YML")
    
    # Input YML file OR dir containing venvironment.yml
    vargs.add_argument("-i","--input",
        metavar="Input",
        help="Path to YML file OR directory containing venvironment.yml",
        type=str,
        required=True,
        default=None)
    
    # Output folder
    vargs.add_argument("-o","--output",
        metavar="Output",
        help="Path to store compiled environment",
        type=str,
        default="Output")
    
    return

# CLI options for compiling YML file followed by vtuexe file
def cli_dual(subparser):
    vparser=subparser.add_parser(CLI_TYPE_DUAL, \
        help="Compile configuration with YML and VTUEXE files")
    vargs=vparser.add_argument_group("Arguments:")
    
    # Input YML file OR dir containing venvironment.yml
    vargs.add_argument("-i","--input",
        metavar="Input",
        help="Path to directory containing venvironment.yml and *.vtuexe files",
        type=str,
        required=True,
        default=None)
    
    # Output folder
    vargs.add_argument("-o","--output",
        metavar="Output",
        help="Path to store compiled files",
        type=str,
        default="Output")
    
    return

# Command line Interface to control the script from the terminal
def cli_handler():
    parser = ap.ArgumentParser()
    subparser=parser.add_subparsers(title="Types",
        help="List of valid file types",
        dest="type" )
    
    cli_vtu(subparser)
    cli_yml(subparser)
    # cli_dual(subparser)
    args = parser.parse_args()
    arglist = list()

    if args.type == CLI_TYPE_VTU:
        arglist.append(args.input)
        arglist.append(args.env)
        arglist.append(args.output)
    elif args.type == CLI_TYPE_YML:
        arglist.append(args.input)
        arglist.append(args.output)
    elif args.type == CLI_TYPE_DUAL:
        arglist.append(args.input)
        arglist.append(args.output)
    else:
        # Invalid type
        pass
    return args.type,arglist

# API -------------------------------------------------------------------------

def compile():
    type,arglist = cli_handler()
    
    # Compile files based on user input
    if type == CLI_TYPE_YML:
        compile_env(filename=arglist[0],dest=arglist[1])
    elif type == CLI_TYPE_VTU:
        compile_vtu(vtufile=arglist[0],envfile=arglist[1],dest=arglist[2])
    elif type == CLI_TYPE_DUAL:
        compile_dual(filename=arglist[0],dest=arglist[1])
    return

def test():
    log_info("Testing compilation API...")
    
    if compile_env(filename="CU_1", dest="Output"):
        log_info("Compilation completed.")
    else:
        log_error("Failed to compile.")
    
    if compile_vtu(vtufile="CU_1", envfile="Output\Default.venvironment", dest="Output"):
        log_info("Compilation completed.")
    else:
        log_error("Failed to compile.")
    return

if __name__ == "__main__":
    log_info("-"*80)
    
    compile()
    # test()
    log_info("-"*80)
    pass

# End of file -----------------------------------------------------------------
