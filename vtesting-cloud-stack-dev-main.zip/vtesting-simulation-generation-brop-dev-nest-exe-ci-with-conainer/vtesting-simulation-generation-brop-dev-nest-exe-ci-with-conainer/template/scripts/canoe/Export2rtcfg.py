# -----------------------------------------------------------------------------
# Example: Test Feature Set via Python
# 
# This sample demonstrates how to start the test modules and test 
# configurations via COM API using a Python script.
# The script uses the included PythonBasicEmpty.cfg configuration but is  
# working also with any other CANoe configuration containing test modules  
# and test configurations. 
# 
# Limitations:
#  - only the first test environment is supported. If the configuration 
#    contains more than one test environment, the other test environments 
#    are ignored
#  - the script does not wait for test reports to be finished. If the test
#    reports are enabled, they may run in the background after the test is 
#    finished
# -----------------------------------------------------------------------------
# Copyright (c) 2017 by Vector Informatik GmbH.  All rights reserved.
# -----------------------------------------------------------------------------

import time, os, msvcrt
from win32com.client import *
from win32com.client.connect import *
import sys, getopt
import pathlib
import subprocess

def DoEvents():
    pythoncom.PumpWaitingMessages()
    time.sleep(.1)
def DoEventsUntil(cond):
    while not cond():
        DoEvents()

class CanoeSync(object):
    """Wrapper class for CANoe Application object"""
    Started = False
    Stopped = False
    ConfigPath = ""
    RTCFGPath = ""
    def __init__(self):
       
        app = DispatchEx('CANoe.Application')   
        app.Visible = False
        app.Configuration.Modified = False
        ver = app.Version
        print('Loaded CANoe version ', 
            ver.major, '.', 
            ver.minor, '.', 
            ver.Build, '...', sep='')
        self.App = app
        self.Measurement = app.Measurement  
        self.CANoe4SWServer = app.Configuration.CANoe4Server
        self.Running = lambda : self.Measurement.Running
        self.WaitForStart = lambda: DoEventsUntil(lambda: CanoeSync.Started)
        self.WaitForStop = lambda: DoEventsUntil(lambda: CanoeSync.Stopped)
        WithEvents(self.App.Measurement, CanoeMeasurementEvents)

    def Load(self, cfgPath):
        # current dir must point to the script file
        cfg = os.path.dirname(pathlib.Path(__file__).parent.resolve())
        print('current dir ' + cfg)
        cfg = os.path.join (cfg, cfgPath)
        print('CANoe Project dir ' + cfg)
        print('Opening: ', cfg)
        self.ConfigPath = os.path.dirname(cfg)
        self.Configuration = self.App.Configuration
        self.App.Open(cfg)
        print('cfg loaded to CANoe')

    def LoadTestSetup(self, testsetup):
        self.TestSetup = self.App.Configuration.TestSetup
        path = os.path.join(self.ConfigPath, testsetup)
        testenv = self.TestSetup.TestEnvironments.Add(path)
        testenv = CastTo(testenv, "ITestEnvironment2")
         # TestModules property to access the test modules
        self.TestModules = []
        self.TraverseTestItem(testenv, lambda tm: self.TestModules.append(CanoeTestModule(tm)))
    
    def Quit(self):
        print('Closing CANoe4SW')
        self.Configuration.Modified = False
        self.App.Quit
        
        time.sleep(10)
         # make sure the CANoe is close properly, otherwise enforce taskkill
        output = subprocess.check_output('tasklist', shell=True)

        if "CANoe32.exe" in str(output):
            os.system("taskkill /im CANoe32.exe /f 2>nul >nul")
        if "CANoe64.exe" in str(output):
            os.system("taskkill /im CANoe64.exe /f 2>nul >nul")
        self.application = None

    def LoadTestConfiguration(self, testcfgname, testunits):
        """ Adds a test configuration and initialize it with a list of existing test units """
        tc = self.App.Configuration.TestConfigurations.Add()
        tc.Name = testcfgname
        tus = CastTo(tc.TestUnits, "ITestUnits2")
        for tu in testunits:
            tus.Add(tu)
        # TestConfigs property to access the test configuration
        self.TestConfigs = [CanoeTestConfiguration(tc)]

    def Start(self): 
        if not self.Running():
            self.Measurement.Start()
            self.WaitForStart()

    def Stop(self):
        if self.Running():
            self.Measurement.Stop()
            self.WaitForStop()
       
    def Export(self, rtcfgPath, arch):
        print('Exporting to CANoe4SW')
        rtcfg = os.path.dirname(pathlib.Path(__file__).parent.resolve())
        print('current dir ' + rtcfg)
        rtcfg = os.path.join (rtcfg, rtcfgPath)
        print('CANoe Export file ' + rtcfg)
        exportError = ""
        test = self.CANoe4SWServer.ExportConfigurationForArchitecture(rtcfg, arch, exportError)
        print('Return value from Exported to Path: ', test)
        if exportError != "":
            print('Error message while export ',exportError)
        print('rtcfg Exported to Path: ', rtcfg)
        
    def RunTestModules(self):
        """ starts all test modules and waits for all of them to finish"""
        # start all test modules
        for tm in self.TestModules:
            tm.Start()
    
        # wait for test modules to stop
        while not all([not tm.Enabled or tm.IsDone() for tm in app.TestModules]):
            DoEvents()

    def RunTestConfigs(self):
        """ starts all test configurations and waits for all of them to finish"""
        # start all test configurations
        for tc in self.TestConfigs:
            tc.Start()
    
        # wait for test modules to stop
        while not all([not tc.Enabled or tc.IsDone() for tc in app.TestConfigs]):
            DoEvents()

    def TraverseTestItem(self, parent, testf):
        for test in parent.TestModules: 
            testf(test)
        for folder in parent.Folders: 
            found = self.TraverseTestItem(folder, testf)

class CanoeMeasurementEvents(object):
    """Handler for CANoe measurement events"""
    def OnStart(self): 
        CanoeSync.Started = True
        CanoeSync.Stopped = False
        print("< measurement started >")
    def OnStop(self) : 
        CanoeSync.Started = False
        CanoeSync.Stopped = True
        print("< measurement stopped >")

class CanoeTestModule:
    """Wrapper class for CANoe TestModule object"""
    def __init__(self, tm):
        self.tm = tm
        self.Events = DispatchWithEvents(tm, CanoeTestEvents)
        self.Name = tm.Name
        self.IsDone = lambda: self.Events.stopped
        self.Enabled = tm.Enabled
    def Start(self):
        if self.tm.Enabled:
            self.tm.Start()
            self.Events.WaitForStart()

class CanoeTestConfiguration:
    """Wrapper class for a CANoe Test Configuration object"""
    def __init__(self, tc):        
        self.tc = tc
        self.Name = tc.Name
        self.Events = DispatchWithEvents(tc, CanoeTestEvents)
        self.IsDone = lambda: self.Events.stopped
        self.Enabled = tc.Enabled
    def Start(self):
        if self.tc.Enabled:
            self.tc.Start()
            self.Events.WaitForStart()

class CanoeTestEvents:
    """Utility class to handle the test events"""
    def __init__(self):
        self.started = False
        self.stopped = False
        self.WaitForStart = lambda: DoEventsUntil(lambda: self.started)
        self.WaitForStop = lambda: DoEventsUntil(lambda: self.stopped)
    def OnStart(self):
        self.started = True
        self.stopped = False        
        print("<", self.Name, " started >")
    def OnStop(self, reason):
        self.started = False
        self.stopped = True 
        print("<", self.Name, " stopped >")

# -----------------------------------------------------------------------------
# main
# -----------------------------------------------------------------------------

if __name__ == "__main__":

    argv = sys.argv[1:]
    inputfile = ''
    outputfile = ''
    arch = 0
    try:
        opts, args = getopt.getopt(argv,"hi:o:a:",["ifile=","ofile=","arch="])
    except getopt.GetoptError:
        print ('Export2rtcfg.py -i <input.cfg> -o <output.rtcfg> -a <x86|x64|linux>')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('Export2rtcfg.py -i <input.cfg> -o <output.rtcfg>')
            sys.exit()
        elif opt in ("-i", "--ifile"):
            inputfile = arg
            print ('Input file set to ', inputfile)
        elif opt in ("-o", "--ofile"):
            outputfile = arg
            print ('Output file set to ', outputfile)
        elif opt in ("-a", "--arch"):
            if arg == "x86":
                arch = 0
            elif arg == "x64":
                arch = 1
            elif arg == "linux":
                arch = 2
            print ('Arch set to ', arch , ' ', arg)
                 

    app = CanoeSync()

    # loads the sample configuration
    app.Load(inputfile)

    # start the measurement
    #app.Start()    

    # wait for 10 sec to end  program
    #time.sleep(10)

    # stops the measurement
    #app.Stop()
    #time.sleep(10)

    app.Export(outputfile,arch)

    app.Quit()
