# Simulation generation repository (work in progress)

1. [Introduction](#introduction)
2. [Folder Structure](#folder-structure)
3. [Pipelines](#pipelines)
    1. [Main Pipeline](#main-pipeline)
    2. [Child Pipelines](#child-pipelines)
4. [Branches](#branches)
    1. [Branch "main"](#branch-main)
    2. [Branch "dev-main"](#branch-dev-main)
    3. [Branch "dev-testingType1"](#branch-dev-testingtype1)
    4. [Branch "dev-testingType1-feature-1"](#branch-dev-testingtype1-feature-1)

## Introduction

Repository for the generation of the BROP simulation NEST, DIVA, TLS, NTS, securityCompound and GWD

## Folder Structure

|Folder             |Description    
|---                |---            
|scripts            | Global scripts used by main pipeline or by all child pipeline 
|docs               | Folder with documentation for this repository
|template           | Template folder for the generation of the simulation. <br>Contains a testing pipeline ([template.gitlab-ci.yml](template\template.gitlab-ci.yml)) and a skeleton pipeline ([skeleton.gitlab-ci.yml](template\skeleton.gitlab-ci.yml)). <br>The template job has some example jobs for different scenarios 
|diva               | Folder with child pipeline for the diva simulation generation  and specific tools/scripts
|gwd                | Folder with the child pipeline for the gwd simulation generation and its specific tools/scripts
|nest               | Folder with child pipeline for the nest simulation generation  and its specific tools/scripts
|nts                | Folder with child pipeline for the nts simulation generation    and its specific tools/scripts
|securityCompound   | Folder with child pipeline for the securityCompound simulation generation and its specific tools/scripts
|tls                | Folder with child pipeline for the tls simulation generation  and its specific tools/scripts

## Pipelines

### Main Pipeline

The main pipeline triggers one of the child pipelines in the simulation generation folders depending on the TESTRUN ID of the job or if manually started by the variable INTEGRATION_JOB.

#### Main Pipeline Variables

|Variable       |Default value                  |Description                                                            
|---            |---                            |---
| TESTRUN_ID    | $TESTRUN_ID from upstream job | The TestRun ID to identify the test job parameter in the database      
| ECU           | $ECU from upstream job        | The ECU for which the simulation should be build  
| UPLOAD_RESULTS| true                          | Boolean value to for testing. If set to false Results should not be uploaded  
| LOG_LEVEL     | DEBUG                         | The LogLevel all tools should provide  

### Child Pipelines

Each simulation generation folder contains a pipeline script which will be triggered by the main pipeline if the user json requests a generation.

## Branches

<img src="./docs/diagramms/gitlab_branch_workflow.drawio.svg">

### Branch "main"

Main branch for production. Pipeline is triggered by pipeline in main branch of vtesting-simulation-integration. If triggered manually parameter for correct starting should be provided  Persistent protected Branch
  
### Branch "dev-main"

Main dev branch with all Testing types merged. Ready for testing before merge to main branch.If pipeline is triggered manually default values for the simulation generation must be provided. Persistent protected Branch.

### Branch "dev-testingType1"
*   dev-nest, dev-tls, ...

Main Testing type branch for one Type (e.g. NEST,TLS,DiVa...). All features for a specific type are merged. Persistent protected Branch

### Branch "dev-testingType1-feature-1" 
* dev-nest-new-folder, dev-nest-TEDAG12345, ... 

Feature Branch with new features of a Testing type. Deleted after future is merged merged in dev-testingType1.
