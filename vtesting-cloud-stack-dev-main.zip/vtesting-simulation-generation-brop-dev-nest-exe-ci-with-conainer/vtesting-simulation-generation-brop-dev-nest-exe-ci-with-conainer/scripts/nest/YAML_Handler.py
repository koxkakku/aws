"""
Created by: SYARAGA
Date: 09-10-2023
Desc: API's to add properties to the yaml file

"""

# Import section ------------------------------------------
import yaml
import json

# constants

# version
from constants import NODE_VERSION
from constants import NODE_VERSION_DATA

# system variables
from constants import NODE_SYSTEM_VARIABLES
from constants import SYS_VAR_NODE_PROP_FILE_PATH

# symbol mapping properties
from constants import NODE_SYMBOL_MAPPING
from constants import NODE_SYMBOL_MAP_FILE_PATH

# database node properties
from constants import NODE_DATABASES
from constants import DB_NODE_PROP_NAME
from constants import DB_NODE_PROP_FILE_PATH
from constants import DB_NODE_PROP_NETWORK_NAME

# ethernet networks properties
from constants import NODE_ETHERNET_NETWORKS
from constants import NW_NODE_PROP_NAME
from constants import NW_NODE_PROP_DATABASE

# canfd network properties
from constants import NODE_CANFD_NETWORKS
from constants import NW_NODE_PROP_NAME
from constants import NW_NODE_PROP_DATABASE
from constants import NW_NODE_PROP_APP_CHANNEL
from constants import NW_NODE_PROP_MODE
from constants import NW_NODE_PROP_ISO
from constants import NW_NODE_PROP_DATA_BAUDRATE
from constants import NW_NODE_PROP_ARBITRATION_BAUDRATE
from constants import NW_NODE_PROP_MAPPING
from constants import NW_NODE_PROP_MAPPING_INTERNAL

# simulation node constants
from constants import NODE_SIMULATION_NODE
from constants import SIM_NODE_PROP_NAME
from constants import SIM_NODE_PROP_FILE_PATH
from constants import SIM_NODE_PROP_NETWORK_ASSIGNMENTS
from constants import SIM_NODE_PROP_NETWORK
from constants import SIM_NODE_PROP_DATABASE_NODE
from constants import SIM_NODE_PROP_MODELLING_LIBRARIES
from constants import SIM_NODE_PROP_TCP_IP_STACK
from constants import SIM_NODE_PROP_SELECTED_STACK
from constants import SIM_NODE_PROP_INDIVIDUAL

# security profile constants
from constants import NODE_SECURITY
from constants import SEC_NETWORK_PROFILE_ASSIGNMENTS
from constants import SEC_NETWORK
from constants import SEC_PROFILE_ID
from constants import SECUIRTY_VALUE

# log constants 
from constants import LOG_NODE_LOGGING
from constants import LOG_NODE_FILE_NAME
from constants import LOG_NODE_TEST_LOGGING_BLF

from Logger import LogHandler

# # Create logger for file
# if __name__ == '__main__':
#     logger = LogHandler()
#     logger.setup()
# else:
#     logger = LogHandler(__name__)

# NOTE: Mandatory for NEST tool since it is not being initialized before import
logger = LogHandler(__name__)
logger.setup()

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return


class BaseNode:
    def __init__(self,nodetype):
        self.nodetype = nodetype
        pass

    def get_nodetype(self):
        return self.nodetype

# class API to add version info
class Version(BaseNode):
    def __init__(self):
        self.version = NODE_VERSION_DATA
        BaseNode.__init__(self,NODE_VERSION)
        return
    
    def get_node_data(self):
        retval = {self.nodetype: self.version}
        return retval

# class API to add system_variables info
class SystemVariables(BaseNode):

    # input : list of files
    def __init__(self,files):
        self.files = files
        BaseNode.__init__(self,NODE_SYSTEM_VARIABLES)
        return
    
    def get_node_data(self):
        retval = {
            self.nodetype:[{
                SYS_VAR_NODE_PROP_FILE_PATH:self.files
                }]}
        return retval

# class API to add symbol mappping
class SymbolMapping(BaseNode):

    # Input : filepath (single file)
    def __init__(self,file):
        self.file = file
        BaseNode.__init__(self,NODE_SYMBOL_MAPPING)
        return
    
    def get_node_data(self):
        retval = {self.nodetype: [{
            NODE_SYMBOL_MAP_FILE_PATH : self.file
        }]}
        return retval

# class api to add database
class Database(BaseNode):

    # input: arguments with name and filepath to arxml
    def __init__(self):
        self.data = list()
        BaseNode.__init__(self,NODE_DATABASES)
        return
    
    def add_node(self,name,filepath):
        node_data = dict()
        node_data[DB_NODE_PROP_NAME] = name
        node_data[DB_NODE_PROP_FILE_PATH] = filepath
        node_data[DB_NODE_PROP_NETWORK_NAME] = name
        self.data.append(node_data)
        return

    def get_node_data(self):
        if not self.data:
            retval = None
        else:
            retval = dict()
            retval[self.nodetype] = self.data
        return retval

# class API to add ethernet networks
class EthernetNetworks(BaseNode):

    # input : node name (network under test)
    def __init__(self):
        self.data = list()
        BaseNode.__init__(self,NODE_ETHERNET_NETWORKS)
        return
    
    def add_node(self,nodename):
        node_data = dict()
        node_data[NW_NODE_PROP_NAME] = nodename
        node_data[NW_NODE_PROP_DATABASE] = nodename
        self.data.append(node_data)
        return

    def get_node_data(self):
        if not self.data:
            retval = None
        else:
            retval = {self.nodetype: self.data}
        return retval

# class API to add canfd networks    
class CanfdNetworks(BaseNode):

    # input : arguments with baud, fdbaud and nwname
    def __init__(self):
        self.data = list()
        BaseNode.__init__(self,NODE_CANFD_NETWORKS)
        return
    
    def add_node(self,nwname,baud,fdbaud):
        node_data = {}
        node_data[NW_NODE_PROP_NAME] = nwname
        node_data[NW_NODE_PROP_DATABASE] = nwname
        node_data[NW_NODE_PROP_APP_CHANNEL] = 1
        node_data[NW_NODE_PROP_MODE] = NW_NODE_PROP_ISO
        node_data[NW_NODE_PROP_ARBITRATION_BAUDRATE] = int(baud)
        node_data[NW_NODE_PROP_DATA_BAUDRATE] = int(fdbaud)
        node_data[NW_NODE_PROP_MAPPING] = NW_NODE_PROP_MAPPING_INTERNAL
        self.data.append(node_data)
        return
    
    def get_node_data(self):
        if not self.data:
            retval = None
        else:
            retval = {self.nodetype: self.data }
        return retval

# class API to add simulation node for can network     
class SimulationNodeCan(BaseNode):

    # input : nodename, nwname, canfilepath and modeling_libraries_lst
    def __init__(self):
        self.data = list()
        BaseNode.__init__(self,NODE_SIMULATION_NODE)
        return
    
    def add_node(self,nodename,nwname,canfile=None,modeling_libraries=None):
        node_data = dict()
        node_data[SIM_NODE_PROP_NAME] = nodename
        if canfile is not None:
            node_data[SIM_NODE_PROP_FILE_PATH] = canfile
        node_data[SIM_NODE_PROP_NETWORK_ASSIGNMENTS] = [{SIM_NODE_PROP_NETWORK : nwname}]
        node_data[SIM_NODE_PROP_DATABASE_NODE] = False
        if modeling_libraries is not None:
            node_data[SIM_NODE_PROP_MODELLING_LIBRARIES] = modeling_libraries
        self.data.append(node_data)
        return

    def get_node_data(self):
        if not self.data:
            retval = None
        else:
            retval = {self.nodetype: self.data }
        return retval

# class API to add simulation node for ethernet network     
class SimulationNodeEthernet(BaseNode):

    # input : arguments with nodename, nwname, canfile, modeling_libraries_lst
    def __init__(self):
        self.data = list()
        BaseNode.__init__(self,NODE_SIMULATION_NODE)
        return
    
    def add_node(self,nodename,nwname,canfile=None,modeling_libraries=None):
        node_data = dict()
        node_data[SIM_NODE_PROP_NAME] = nodename
        if canfile is not None:
         node_data[SIM_NODE_PROP_FILE_PATH] = canfile
        node_data[SIM_NODE_PROP_TCP_IP_STACK] = {SIM_NODE_PROP_SELECTED_STACK : SIM_NODE_PROP_INDIVIDUAL}
        node_data[SIM_NODE_PROP_NETWORK_ASSIGNMENTS] = [{SIM_NODE_PROP_NETWORK : nwname}]
        node_data[SIM_NODE_PROP_DATABASE_NODE] = False
        if modeling_libraries is not None:
            node_data[SIM_NODE_PROP_MODELLING_LIBRARIES] = modeling_libraries
        
        self.data.append(node_data)
        return

    def get_node_data(self):
        if not self.data:
            retval = None
        else:
            retval = {self.nodetype: self.data }
        return retval

# class API to add security profile    
class SecurityProfile(BaseNode):

    #input : arguments with nwname under test
    def __init__(self):
        self.data = list()
        BaseNode.__init__(self,NODE_SECURITY)
        return
    
    def add_node(self,nwname):
        node_data = dict()
        node_data[SEC_NETWORK] = nwname
        node_data[SEC_PROFILE_ID] = SECUIRTY_VALUE  # Hardcoded for now
        self.data.append(node_data)
        return
    
    def get_node_data(self):
        if not self.data:
            retval = None
        else:
            retval = {
                self.nodetype: { SEC_NETWORK_PROFILE_ASSIGNMENTS : self.data }
                }
        return retval

# class API to add logging 
class Logging(BaseNode):

    def __init__(self):
        BaseNode.__init__(self,LOG_NODE_LOGGING)
        return
    
    def get_node_data(self):
        retval = {self.nodetype: {
            LOG_NODE_FILE_NAME : LOG_NODE_TEST_LOGGING_BLF
        }}
        return retval

# class API to create yaml file
class CreateConfig:

    # input : arguments with filename and list of node objects
    def __init__(self,filename,data):
        self.filename = filename
        self.nodelist = data
        return
    
    def yaml_dump(self,data):
        status = False
        try:
            # NOTE: Issue: YAML dump sometimes prints identifiers instead of data
            # Solution: Found this solution on StackOverflow.
            # https://stackoverflow.com/a/51272986
            # No idea why this works. Praying nothing goes wrong.
            # Tested with PyYAML v6.0.1
            yaml.Dumper.ignore_aliases = lambda *args : True
            logger.info("Creating file: %s"%(self.filename))
            with open(self.filename,'w') as file:
                yaml.dump(data, file, sort_keys=False)
            status = True
        except Exception as e:
            log_exception('An exception occurred while trying to write to YAML file',e)
        return status

    def _json_dump(self,data,filename="nest_config.json"):
        try:
            with open(filename,"w") as f:
                json.dump(data,f,indent=4)
        except Exception as e:
            log_exception("Failed to write to JSON",e)
        return

    def log_add_data(self):
        lst = [node.get_node_data() for node in self.nodelist]
        self._json_dump(lst)
        return

    # Generate YAML file with all nodes.
    # Extracts information from list of nodes and add to dictionary before 
    # writing to YAML file.
    def create(self):
        status = False
        yaml_dict = dict()  # Dictionary with all nodes
        added_nodes = list()  # List of nodes already added to dictionary
        node_count = 0  # Number of nodes processed correctly
        
        logger.info("Gathering data from nodes to generate configuration.")
        # Add data to dicionary before writing to YAML file
        try:
            for node in self.nodelist:
                nodedata = node.get_node_data()
                if nodedata is not None:
                    # Get type of node
                    nodetype = node.get_nodetype()
                    # Check if nodetype was already processed
                    if nodetype in added_nodes:
                        # DO NOT take action if duplicate node is of specific types
                        if (nodetype in [NODE_VERSION,LOG_NODE_LOGGING]):
                            logger.info("Duplicate entry of node %s"%(nodetype))
                        
                        elif (nodetype  == NODE_SECURITY):
                            logger.info("Found another security node")
                            # FIXME: Check for duplicate security profile entries
                            # Merge both nodes
                            try:
                                _ndata = nodedata[nodetype][SEC_NETWORK_PROFILE_ASSIGNMENTS]
                                yaml_dict[nodetype][SEC_NETWORK_PROFILE_ASSIGNMENTS].extend(_ndata)
                            except Exception as e:
                                # Hmmm.... Something went wrong.
                                # Reduce this node from the count
                                node_count -= 1
                                # Log exception
                                log_exception("Exception while merging node %s: "%(nodetype),e)
                        else:
                            # Merge both nodes
                            try:
                                _ndata = nodedata[nodetype]
                                yaml_dict[nodetype].extend(_ndata)
                            except Exception as e:
                                # Hmmm.... Something went wrong.
                                # Reduce this node from the count
                                node_count -= 1
                                # Log exception
                                log_exception("Exception while merging node %s: "%(nodetype),e)
                    else:
                        # Add as new entry to dictionary
                        yaml_dict.update(nodedata)
                    
                    # Update list of processed nodes
                    added_nodes.append(nodetype)
                else:
                    # Found an empty node
                    logger.info("Found an empty node. Will not be added to file.")
                    logger.debug("Empty node: %s"%str(node))
                # Updated number of processed nodes
                node_count += 1
        except Exception as e:
            log_exception("Encountered an Exception while extracting information from nodes",e)
        
        # Create the YAML configuration ONLY if all nodes were processed correctly
        if (node_count == len(self.nodelist)):
            # Log data to JSON file
            self._json_dump(data=yaml_dict)
            status = self.yaml_dump(yaml_dict)
        else:
            logger.error("There was an issue while processing one or more nodes. Aborting write to YAML file.")
        return status
    


if __name__ == "__main__":
    pass
