"""
Created by: SYARAGA
Date: 06-09-2023
Desc: scripts to extract data from INI file for NEST Tool

"""
# Import section
import os 
import json 

from Logger import LogHandler

from configparser import ConfigParser

# Import constants related to INI

from constants import NEST_INI_FILE

#database section
from constants import INI_SECTION_DB
from constants import INI_KEY_DB_ARXML

#configuration section
from constants import INI_SECTION_CONFIG
from constants import INI_KEY_CONFIG_ECU_TYPE
from constants import INI_KEY_CONFIG_ECU_KIND
from constants import INI_KEY_CONFIG_NW

#ecu vtt section
from constants import INI_SECTION_DLL
from constants import INI_KEY_VTT_ECU
from constants import INI_KEY_VTT_HSM
from constants import INI_KEY_VTT_SYSVAR

# Extension constants
from constants import EXT_DLL
from constants import EXT_VMODULE

# Logging functions -----------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return


"""
class INI_Parser
input : NEST.ini file
output : API to extract data from ini file
"""
class INI_Parser():

    ini_data = False

    def __init__(self,filename):
        self.filename = filename
        self.config = ConfigParser()
        return
    
    # Load INI file
    def load_ini(self):
        status = False
        if self.ini_data is False:
            if os.path.isfile(self.filename):
                try:
                    self.config.read(self.filename)
                    status = True
                    self.ini_data = True
                except Exception as e:
                    log_exception("Exception while reading file",e)
            else:
                log_error("File not found %s"%(self.filename))
        else:
            status = True
        return status
    
    # Function to return paths with double backslash 
    # (YAML requiers either single front slash or double back slash for it's working)
    def raw_string(self,path):
        rw_string_filepath = None
        if path is not None:
            rw_string_filepath = path.encode('unicode_escape').decode()
        return rw_string_filepath

    # Generic API to extract string value from INI
    def read_value(self,section,item):
        retval = None
        if self.config.has_option(section,item):
            retval = self.config.get(section,item)
        else:
            log_debug("Value not found [%s][%s]"%(section,item))
        return retval
    
    # Generic API to extract list value from INI
    def read_list(self,section,item):
        retval = None
        if self.config.has_option(section,item):
            l_temp = self.config.get(section,item)
            try:
                retval = list(json.loads(l_temp))
            except Exception as e:
                print("Failed to read list from [%s][%s]"%(section,item),e)
        else:
            # not found
            log_debug("Value not found [%s][%s]"%(section,item))
        return retval
    
    # get network name
    def get_nw_name(self):
        nw_name = None
        if self.load_ini():
            try:
                nw_name = self.read_value(INI_SECTION_CONFIG,INI_KEY_CONFIG_NW)
            except Exception as e:
                log_exception("An unexpected error occurred:", str(e))
        return nw_name

    # get ecu_arxml file    
    def get_ecu_arxml(self):
        arxml_file = None
        if self.load_ini():
            try:
                arxml_file = self.read_value(INI_SECTION_DB,INI_KEY_DB_ARXML)
            except Exception as e:
                log_exception("An unexpected error occurred:", str(e))
        return arxml_file
    
    # get ecu type (Standard or VSM or Gateway)
    def get_ecu_type(self):
        ecu_type = {}
        if self.load_ini():
            try:
                ecu_type = self.read_value(INI_SECTION_CONFIG,INI_KEY_CONFIG_ECU_TYPE)
            except Exception as e:
                log_exception("An unexpected error occurred:", str(e))
        return ecu_type
    
    # get ecu type (VTT or Silver)
    def get_ecu_kind(self):
        ecu_kind = {}
        if self.load_ini():
            try:
                ecu_kind = self.read_value(INI_SECTION_CONFIG,INI_KEY_CONFIG_ECU_KIND)
            except Exception as e:
                log_exception("An unexpected error occurred:", str(e))
        return ecu_kind
    
    # get ecu file (vmodule (dll))
    def get_ecu_file(self):
        vmodule_file_value = None
        if self.load_ini():
            try:
                vmodule_file_ini = self.raw_string(self.read_value(INI_SECTION_DLL,INI_KEY_VTT_ECU))
                if vmodule_file_ini is not None:
                  vmodule_file_value = vmodule_file_ini.replace(EXT_DLL,EXT_VMODULE)
                else:
                    log_debug('NonType error occured')
            except Exception as e:
                log_exception("An unexpected error occurred:", str(e))
        return vmodule_file_value
    
    # get vhsm vmodule file
    def get_vhsm_file(self):
        vmodule_file_value = None
        if self.load_ini():
            try:
                vmodule_file_ini = self.raw_string(self.read_value(INI_SECTION_DLL,INI_KEY_VTT_HSM))
                if vmodule_file_ini is not None:
                  vmodule_file_value = vmodule_file_ini.replace(EXT_DLL,EXT_VMODULE)
                else:
                    log_debug('NonType error occured')
            except Exception as e:
                log_exception("An unexpected error occurred:", str(e))
        return vmodule_file_value
    
    # adding both ecu.vmodule and vhsm.vmodule file together in a list
    def get_vmodule_file(self):
        vmodule_list = []
        ecu_vmodule = self.get_ecu_file()
        vhsm_vmodule = self.get_vhsm_file()
        if ecu_vmodule is not None:
            if ecu_vmodule.lower() != 'none':
                vmodule_list.append(ecu_vmodule)
        if vhsm_vmodule is not None:
            if vhsm_vmodule.lower() != 'none':
                vmodule_list.append(vhsm_vmodule)
        return vmodule_list
    
    # get vsysvar files from ini
    def get_vsysvar_file(self):
        vsysvar_lst = []
        if self.load_ini():
            try:
                vsysvar_value = self.read_list(INI_SECTION_DLL,INI_KEY_VTT_SYSVAR)
                for elements in vsysvar_value:
                    value = self.raw_string(elements)
                    vsysvar_lst.append(value)
            except Exception as e:
                log_exception("An unexpected error occurred:", str(e))
        return vsysvar_lst
        
if __name__ == "__main__":
    print("-"*100)
    obj = INI_Parser(filename=NEST_INI_FILE)
    # print(obj.get_vsysvar_file())
    print(obj.get_vmodule_file())
    print(obj.get_nw_name())
    print(obj.get_ecu_arxml())
    print(obj.get_ecu_file())
    print(obj.get_ecu_kind())
    print("-"*100)
