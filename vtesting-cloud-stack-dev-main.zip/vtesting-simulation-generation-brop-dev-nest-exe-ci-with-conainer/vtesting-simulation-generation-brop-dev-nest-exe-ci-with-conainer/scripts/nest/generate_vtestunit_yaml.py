"""
Created by: SYARAGA
Date: 11-07-2023
Desc: dynamic generation of vtestunit.yaml file

"""

# Import section 
import os
import yaml
import argparse as ap

from Logger import LogHandler
from INI_parser import INI_Parser

# Constants ------------------------------------------------------------------
# Node version strings
NODE_VERSION = 'version'
NODE_VERSION_DATA = '2.0.0'
FILENAME = 'NEST.vtestunit.yaml'

# default values 
DEFAULT_VTESTUNIT_YAML = 'default.vtestunit.yaml'

# Folder name for files
CAPL = 'CAPL'

# test_unit_information strings
TEST_UNIT_INFORMATION = 'test-unit-information'
TUI_CAPTION = 'caption'
TUI_DESCRIPTION = 'description'
TUI_VERSION = 'version'
TUI_TEST_DESIGNERS = 'test-designer'
TUI_NAME = 'name'
TUI_DEPARTMENT = 'department'

# test_unit_implementation strings
TEST_UNIT_IMPLEMENTATION = 'test-unit-implementation'
TUP_SOURCE_FILE_PATH = 'source-file-path'
TUP_MODELLING_LIB_PATH = 'modeling-library-path'

#Extensions to find the files
EXT_YAML = '.yaml'
EXT_CAN = '.can'
EXT_VTESTUNIT_YAML = '.vtestunit.yaml'
YAML ='yaml'
VTESTTREE = 'vtesttree'
XML_TESTER_GW = 'XML_Tester_GW'
XML_TESTER_STANDARD = 'XML_Tester_ECU'
XML_TESTER_VSM = 'XML_Tester_VSM'

# different ecu types
GATEWAY = 'GATEWAY'
VSM = 'VSM'

#Modelling library path vmodule files
ASRPDUIL_VMODULE = 'Asrpduil.vmodule'
ASRPDUIL2_VMODULE = 'AsrPDUIL2.vmodule'
SECMGRCANOECLIENT_VMODULE = 'SecMgrCANoeClient.vmodule'
FLEXRAYTPISO_VMODULE = 'FlexRayTPISO.vmodule'
OSEK_TP_VMODULE = 'osek_tp.vmodule'
DOIP_VMODULE = 'DoIP.vmodule'
CANOEILNL_AUTOSAR_ETH_VMODULE = 'CANoeILNL_AUTOSAR_Eth.vmodule'
VHDEVDLL_VMODULE = 'VHDevDLL.vmodule'
X509API_VMODULE = 'X509Api.vmodule'
DAG_ETMBACKENDACCESS_VMODULE = 'DAG_ETMBackendAccess.vmodule'
DAG_ZENZEFINODELAYER_VMODULE = 'DAG_ZenzefiNodeLayer.vmodule'

# Logging functions -----------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# vmodule files for the NEST use case 
VMODULE_FILES_NEST = [
            {TUP_MODELLING_LIB_PATH: ASRPDUIL_VMODULE},
            {TUP_MODELLING_LIB_PATH: ASRPDUIL2_VMODULE},
            {TUP_MODELLING_LIB_PATH: SECMGRCANOECLIENT_VMODULE},
            {TUP_MODELLING_LIB_PATH: FLEXRAYTPISO_VMODULE},
            {TUP_MODELLING_LIB_PATH: OSEK_TP_VMODULE},
            {TUP_MODELLING_LIB_PATH: DOIP_VMODULE},
            {TUP_MODELLING_LIB_PATH: CANOEILNL_AUTOSAR_ETH_VMODULE},
            {TUP_MODELLING_LIB_PATH: VHDEVDLL_VMODULE},
            {TUP_MODELLING_LIB_PATH: X509API_VMODULE},
            {TUP_MODELLING_LIB_PATH: DAG_ETMBACKENDACCESS_VMODULE},
            {TUP_MODELLING_LIB_PATH: DAG_ZENZEFINODELAYER_VMODULE}]

class Vtestunit_yaml():
    '''
    Main class
    '''
    yaml_config_dict = {}

    def __init__(self,ini_file):
        self.ini_file = ini_file
        return

    # Function to return paths with double backslash 
    # (YAML requiers either single front slash or double back slash for it's working)
    def raw_string(self,path):
        rw_string_filepath = path.encode('unicode_escape').decode()
        return rw_string_filepath

    def get_vtesttree_file(self):
        log_debug('Searching for vetesttree file with appropriate ecu type')
        ini_obj = INI_Parser(self.ini_file)
        ecu_type = ini_obj.get_ecu_type()
        capl_files = list()
        yaml_files = list()
        for files in os.listdir(CAPL):
            capl_files.append(files.split('.'))
        for i in range(len(capl_files)):   
            if ecu_type == GATEWAY:
                keys = [VTESTTREE,YAML,XML_TESTER_GW]
                if all(key in capl_files[i] for key in keys):
                    yaml_files.append('.'.join(capl_files[i]))
                else:
                    pass
            elif ecu_type == VSM:
                keys = [VTESTTREE,YAML,XML_TESTER_VSM]
                if all(key in capl_files[i] for key in keys):
                    yaml_files.append('.'.join(capl_files[i]))
                else:
                    pass
            else:
                keys = [VTESTTREE,YAML,XML_TESTER_STANDARD]
                if all(key in capl_files[i] for key in keys):
                    yaml_files.append('.'.join(capl_files[i]))
                else:
                    pass
        return yaml_files

    # Adding version info node to the yaml file
    def add_version(self):
        log_debug('Adding version information node')
        version_details = { NODE_VERSION : NODE_VERSION_DATA }
        self.yaml_config_dict.update(version_details)
        return True
    
    # Adding test_unit_infor node to the yaml file
    '''
            ex: caption: SmokeTest BROP
                description: Validation of Virtual ECU
                version: v1.0
                test-designers:
                    - name: A
                     department: RD/ICS
                    - name: B
                     department: PND456
    '''
    def add_test_unit_information(self):
        log_debug('Adding test_unit_information node')
        # TODO: Data to be updated later
        test_unit_info_details = {TEST_UNIT_INFORMATION:{
            TUI_CAPTION:'Smoke Test BROP',
            TUI_DESCRIPTION:'Validation of virtual ECU',
            TUI_VERSION : 'v1.0',
            TUI_TEST_DESIGNERS : [{TUI_NAME: 'A',TUI_DEPARTMENT : 'RD/ICS'},
                {TUI_NAME:'B',TUI_DEPARTMENT:'RD/ICI'}]}}
        self.yaml_config_dict.update(test_unit_info_details)
        return True
    
    # Adding test_unit_implementation node to the yaml file
    '''
    ex: - source-file-path: XML_Tester.vtesttree
        - source-file-path: CAPL_Test.can
    '''
    def add_test_unit_implementation(self,modell_lib_node = True):
        status = False
        vtesttree_filepath = None
        vtesttree_file = None
        log_debug('Adding test_unit_implementation node')
        vtesttres_file_lst = self.get_vtesttree_file()
        if len(vtesttres_file_lst) > 0:
            vtesttree_file = os.path.join(CAPL,vtesttres_file_lst[0])
            vtesttree_filepath = self.raw_string(path=vtesttree_file)
        else:
            log_error('Could not find vtesttree files in CAPL folder')
        can_filepath = r'CAPL\\CAPL_Test_Wrapper.can'
        test_unit_impl_details = {
            TEST_UNIT_IMPLEMENTATION:[
                {TUP_SOURCE_FILE_PATH: vtesttree_filepath},
                {TUP_SOURCE_FILE_PATH: can_filepath}
                        ]}
        self.yaml_config_dict.update(test_unit_impl_details)
        if modell_lib_node :
            # Add list of DLL files for NEST
            test_unit_impl_details[TEST_UNIT_IMPLEMENTATION] += VMODULE_FILES_NEST
            self.yaml_config_dict.update(test_unit_impl_details)  
        return status

    # Creating yaml file to dump all the final output
    def create_vtestunit_yaml(self):
        status = False
        log_debug('Created yaml file: %s'%(FILENAME))
        try:
            with open(FILENAME,'w') as file:
                yaml.dump(self.yaml_config_dict,file, sort_keys= False)
                status = True
                log_info('File sucessfully generated: %s'%(FILENAME))
        except yaml.YAMLError as e:
            log_exception('An error has occurred while trying to dump the data to the file')
        return status
    
# Command line handler
def cli_handler():
    # Create parser
    parser=ap.ArgumentParser(description="Generate the *.vtestunit.yaml file")
   
    # Add argument to the sample ui_json file
    parser.add_argument("-i", "--nest_ini",
        type=str,
        help="path to the sample nest_input.ini file",
        required=True)

    args = parser.parse_args()  
    return args.nest_ini
    
def main():
    ini_file = cli_handler()
    obj = Vtestunit_yaml(ini_file=ini_file)
    obj.add_version()
    obj.add_test_unit_information()
    obj.add_test_unit_implementation()
    obj.create_vtestunit_yaml()
    return

if __name__ == '__main__':
    logger.debug("-"*80)
    main()
    logger.debug("-"*80)
    