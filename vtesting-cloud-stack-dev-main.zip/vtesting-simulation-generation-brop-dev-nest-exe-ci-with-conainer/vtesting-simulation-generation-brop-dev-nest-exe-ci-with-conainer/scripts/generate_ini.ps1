# Script to generate a compiled configuration and vTestunit to be used for 
# testing virtual ECU in CANoe4SW-SE.
# Argument: UserInput JSON file
# Generated artifacts: 
#   default.venvironment
#   *.vtestunit
# Usage:
# .\generate.ps1 path_to_user.json 
# .\generate.ps1 user_input.json 

# Tested on Powershell with CANoe4SW SE v17 sp3

# Tool defintions
$DIR_TOOL_INI='C:/NEST;'

# Update directory of CANoe4SW tools to Path
$env:Path=$DIR_TOOL_INI + $env:Path

$DIR_TOOL_NEST='C:/NEST/Executable;'

# Update directory of CANoe4SW tools to Path
$env:Path=$DIR_TOOL_NEST + $env:Path

$TOOL_INI_MAKE="generate_INI.exe"
$TOOL_NEST="nest.exe"


# Get user JSON as input
if ( !$args )
{
    Write-Output "Please provide a user JSON file as input"
    exit 1
}
else
{
    $UI_JSON_FILE=$args[0]
}

Write-Output "JSON: $UI_JSON_FILE"

# Separator text
$SEPARATOR="-"*80




# Smoke ------------------------------------------------------------------------

Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""
Write-Output "Generating $FILE_CONFIG..."
Write-Output ""
Write-Output "$SEPARATOR"
Write-Output ""

# Change working directory to Appropriate test suite

# Generate configuration YAML
Write-Output "Generate Configuration NEST INI file ./$UI_JSON_FILE"
$process = Start-Process -NoNewWindow -Wait -PassThru -FilePath python.exe -ArgumentList "generate_ini.py -u ./$UI_JSON_FILE"
$retval=$process.ExitCode
if ($retval -ne 0){
    Write-Output "$SEPARATOR"
    Write-Output "Error during generation of INI File"
    Write-Output "$SEPARATOR"
    exit 1
}
Write-Output "Move nest ini file to Database"

Move-Item -Path "NEST_input.ini" -Destination "Database" -Force

Write-Output "current directory.."

PWD



