"""
Created by: SYARAGA
Date: 24-07-2023
Desc: Strings defined for the generation of vexecplan file
 
"""

# json parser constant
JSP_BROP = "brop"
JSP_TEST_DATA = "test_data"
JSP_NEST = "nest"
JSP_TO_TEST = "to_test"

# Extension
EXT_XML = '.xml'
EXT_VEXECPLAN = '.vexecplan'

# Folder name
FILES = 'files'

# XML file constants
XML_TESTGROUP = 'testgroup'
XML_TESTCASE = 'testcase'
XML_TITLE = 'title'

# VEXECPLAN file constants
VEXE_TESTGROUP = 'TestCases'
VEXE_TESTCASE = 'TestCase'
VEXE_NAME = 'Name'

# Output file
OUTPUT_VEXECPLAN = 'output.vexecplan'
