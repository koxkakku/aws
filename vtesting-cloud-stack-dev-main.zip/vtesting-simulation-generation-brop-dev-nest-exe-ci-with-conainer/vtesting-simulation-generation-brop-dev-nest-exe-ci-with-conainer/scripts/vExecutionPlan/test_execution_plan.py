"""
Created by: SYARAGA
Date: 20-07-2023
Desc: script to generate *.vexecplan file dynamically

TODO:
CLI:
    - UI.json (Which test to run+which reference files to be used)
"""

# Import section
import os
import json
import argparse as ap

from Logger import LogHandler
from xml.etree import ElementTree as ET

# Import constants

#json parser constants
from constants import JSP_BROP
from constants import JSP_NEST
from constants import JSP_TEST_DATA
from constants import JSP_TO_TEST

# Extension constants
from constants import EXT_XML
from constants import EXT_VEXECPLAN

# XML constants
from constants import XML_TESTCASE
from constants import XML_TESTGROUP
from constants import XML_TITLE

# VEXECPLAN constants
from constants import VEXE_NAME
from constants import VEXE_TESTCASE
from constants import VEXE_TESTGROUP

# Folder files
from constants import FILES

# Output Vexecplan file
from constants import OUTPUT_VEXECPLAN

# Namespace defination for handling xml files with xmlns(namespace)
NAMESPACE_KEY="ExecutionPlan"
NAMESPACE_VAL="http://www.vector.com/CANoeExecutionAdapter/ExecutionPlan"
NAMESPACE={NAMESPACE_KEY:NAMESPACE_VAL}

# Logging functions -----------------------------------------------------------

# Create logger for file
if __name__ == '__main__':
    logger = LogHandler()
    logger.setup()
else:
    logger = LogHandler(__name__)

def log_debug(msg=''):
    logger.debug(msg)
    return

def log_info(msg=''):
    logger.info(msg)
    return

def log_exception(msg='', e=''):
    logger.exception("%s: %s" % (msg, e))
    return

def log_error(msg=''):
    logger.error(msg)
    return

# Class for generating vexecplan 
class Vexecplan_file_gen():

    # Input for ui_json file
    def __init__(self,ui_josn_file):
        self.ui_json_file = ui_josn_file
        pass

    # function to add the namespace    
    def vp_frame_tagname(self,tag):
        return "%s:%s"%(NAMESPACE_KEY,tag)
    
    # Get first next generation node with tag with namespace (logic)
    def get_child_with_tag_ns(self,node,tag,Namespace = None):
        retval = None
        try:
            if node is not None:
                retval = node.find(tag,NAMESPACE)
        except Exception as e:
            logger.exception("get_child: %s"%e)
        return retval
    
    # Get first next generation node with tag wihtout nameshpace
    def get_child_with_tag(self,node,tag):
        return self.get_child_with_tag_ns(node,tag)
    
    # Get first next generation node with tag with namespace
    def vp_get_child_with_tag(self,node,tag):
        return self.get_child_with_tag_ns(node,tag,NAMESPACE)
    
    # Get list of all next generation nodes with tag with namespace (logic)
    def get_children_with_tag_ns(self,node,tag,Namespace = None):
        retval = list()
        try:
            if node is not None:
                retval = node.findall(tag,Namespace)
        except Exception as e:
            logger.exception("get_children: %s"%e)
        return retval
    
    # Get list of all next generation nodes with tag wihtout namespace
    def get_children_with_tag(self,node,tag):
        return self.get_children_with_tag_ns(node,tag)
    
    # Get list of all next generation nodes with tag with namespace
    def vp_get_children_with_tag(self,node,tag):
        return self.get_children_with_tag_ns(node,tag,NAMESPACE)
    
    '''input : extension, folder_name
       output : dict with filextension as key and filepatha as value
    '''
    def file_finding(self,extension,folder_name):
        file_list = []
        res_dict = {}
        for root,dirs,files in os.walk(folder_name):
            for file in files:
                if file.endswith(extension):
                    filepath = os.path.join(root,file)
                    file_list.append(filepath)
        if len(file_list)>0:
            res_dict[extension] = file_list
        else:
            res_dict[extension] = None
        log_debug("Local Directory: %s"%res_dict)
        return res_dict
    
    # Load ui_json file to get the data
    def load_ui_json(self,input_json_path):
        ui_json_data = None
        with open(input_json_path) as infile:
            try:
                # load file and copy key, values into _data
                ui_json_data = json.load(infile)
                logger.info("UI_Json loaded succesfully: %s" %(input_json_path))
            except Exception as e:
                logger.exception("Exception raise while load json")
            finally:
                # close files
                infile.close()
        return ui_json_data
    
    '''Input : loaded ui_json data
       Output : list of tesgroups present in ui_json
    '''
    def get_test_group_data(self):
        test_group_list = None
        ui_json_data = self.load_ui_json(input_json_path=self.ui_json_file)
        try:
            # TODO: Take test type from CLI
            test_info = ui_json_data[JSP_BROP][JSP_TEST_DATA][JSP_NEST][JSP_TO_TEST]
            for key,value in test_info.items():
             test_group_list = value
        except Exception as e:
            pass
        return test_group_list
    
    '''input: extension of a file(.xml,.vexecplan), folder_name
       output: loads the respective file and returns root value
    '''
    def load_xml_vexecplan_file(self,extension,folder_name):
        root=None
        file = self.file_finding(extension=extension, folder_name=folder_name)
        filepath = None
        try:
            if file[extension] is not None:
                filepath = file[extension]
                logger.info("parsing file: %s"%filepath)
                try:
                    root = ET.parse(filepath[0]).getroot()
                except:
                    root = None
            else:
                log_error('Did not find any files with this extension: %s'%(extension))
        except Exception as e:
            log_exception('Failed to load the file with this extension: %s'%(extension))
        return root

    # returns a list of testcase from the xml file
    def get_testcase_lst_from_xml(self):
        testcase_lst = []
        testcase_data = []
        testgroup_name = None
        testcase_name = None
        # TODO: Should I take path to XMLTester file from CLI?
        xml_data = self.load_xml_vexecplan_file(extension=EXT_XML,folder_name=FILES)
        ui_json_testgroup_data = self.get_test_group_data()
        testgroups = self.get_children_with_tag_ns(node=xml_data,tag=XML_TESTGROUP)
        
        # TODO: Use alternative approach instead of using nested for loops
        # ------------------------------------------------
        for group_item in testgroups:
            testgroup_name = group_item.attrib[XML_TITLE]
            for names in ui_json_testgroup_data:
                if names == testgroup_name:
                    testcase = self.get_children_with_tag_ns(node=group_item,tag=XML_TESTCASE)
                    for case_item in testcase:
                        testcase_name = case_item.attrib[XML_TITLE]
                        data_lst = [testcase_name]
                        testcase_lst.append(data_lst)
                else:
                    # TODO: Do not log an error here
                    log_error("Invalid testgroups found")
        # ------------------------------------------------
        # OR
        # ------------------------------------------------
        
        # testgroupnames = [i.attrib[XML_TITLE] for i in self.get_children_with_tag_ns(node=xml_data,tag=XML_TESTGROUP)]
        # for group_item in ui_json_testgroup_data:
        #     if group_item in testgroupnames:
        #         testcase = self.get_children_with_tag_ns(node=group_item,tag=XML_TESTCASE)
        #         for case_item in testcase:
        #             testcase_name = case_item.attrib[XML_TITLE]
        #             data_lst = [testcase_name]
        #             testcase_lst.append(data_lst)
        #     else:
        #         # Ignore this group
        #         pass

        testcase_data = [item for sublist in testcase_lst for item in sublist]
        return testcase_data
    
    # validates the testcases present in xml and with ths user_input from ui_json file
    def validate_testcases(self):
        ET.register_namespace("",NAMESPACE_VAL)
        vexecplan_data = self.load_xml_vexecplan_file(extension=EXT_VEXECPLAN,folder_name=FILES)
        testgroup = self.vp_get_child_with_tag(node=vexecplan_data,tag=self.vp_frame_tagname(VEXE_TESTGROUP))
        user_testcase_data = self.get_testcase_lst_from_xml()
        testcase_lst = self.vp_get_children_with_tag(node=testgroup,tag=self.vp_frame_tagname(VEXE_TESTCASE))
        for case in testcase_lst:
            testcase_name = self.get_child_with_tag(node=case,tag=self.vp_frame_tagname(VEXE_NAME)).text
            if testcase_name in user_testcase_data:
                pass
            else:
                testgroup.remove(case)
        return vexecplan_data

    # creates the vexecplan file with the validated data
    def create_vexecplan(self):
        log_info('Created vexecplan file: %s'%(OUTPUT_VEXECPLAN))
        vexecplan_data = self.validate_testcases()
        ntree = ET.ElementTree(vexecplan_data)
        ntree.write("output.vexecplan",xml_declaration=True,encoding='utf-8',method="xml")
        return True

# Command line handler
def cli_handler():
    # Create parser
    parser=ap.ArgumentParser(description="Generate the vexecplan file")
   
    # Add argument to the sample ui_json file
    parser.add_argument("-u", "--ui_json",
        type=str,
        help="path to the sample brop_ui_json file",
        required=True)

    args = parser.parse_args()  
    return args.ui_json

def generate():
    ui_json_file = cli_handler()
    # main class that adds all the nodes
    obj = Vexecplan_file_gen(ui_json_file)
    obj.create_vexecplan()
    return 

if __name__ == '__main__':
    logger.debug("-"*80)
    generate()
    logger.debug("-"*80)
        