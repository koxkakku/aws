﻿using Amazon.CDK;
using Amazon.CDK.AWS.EC2;
using Constructs;
using VtestingCloudStack.Common;

namespace VtestingCloudStack.Stacks;

/**
 * A bastion stack to allow admins to apply some administrative tasks.
 * Caution: Do not forget to undeploy it when finished with administration.
 */
public class VTestingBastionStack : Stack
{
    internal VTestingBastionStack(Construct scope, string id, VTestingStackContext ctx,
        IStackProps props = null) : base(
        scope, id, props)
    {
        var stackNamePrefix = ctx.Env + "-" + ctx.AppName;
        var vpc = Vpc.FromLookup(this, $"{stackNamePrefix}-vpc", new VpcLookupOptions
        {
            VpcName = $"{stackNamePrefix}-vpc"
        });

        var bastionId = "bastion".Id(stackNamePrefix);
        var bastion = new BastionHostLinux(this, bastionId, new BastionHostLinuxProps
        {
            Vpc = vpc,
            InstanceName = bastionId,
            SubnetSelection = new SubnetSelection { SubnetGroupName = VpcSubnets.Transfer },
            SecurityGroup = SecurityGroup.FromLookupByName(this, "bastion-ssh-sg",
                $"{stackNamePrefix}-common-ssh-security-group", vpc)
        });
        bastion.SetTag(Common.Tags.Name, _ => bastionId);
    }
}