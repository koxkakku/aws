using System.Collections.Generic;
using Amazon.CDK;
using Amazon.CDK.AWS.IAM;
using Amazon.CDK.AWS.SecretsManager;
using Constructs;
using VtestingCloudStack.Common;

namespace VtestingCloudStack.Stacks;

using ObjectDict = Dictionary<string, object>;

public class VTestingCommonStack : Stack
{
    private readonly VTestingStackContext _ctx;
    private readonly string _stackNamePrefix;

    public VTestingCommonStack(Construct scope, string id, VTestingStackContext ctx, IStackProps props = null) : base(
        scope, id, props)
    {
        _ctx = ctx;
        _stackNamePrefix = _ctx.Env + "-" + _ctx.AppName;

        CreatePowerUserRole();
        CreateDeveloperRole();
        CreateCiCdTechnicalUserAndRole();
    }

    /**
     * Creates a technical cicd user for deploying resources. Perhaps we need to switch to some OpenId exchange.
     */
    private User CreateCiCdTechnicalUserAndRole()
    {
        string id = "cicd-user-policy";
        var cicdPolicy = new ManagedPolicy(this, id.Id(_stackNamePrefix), new ManagedPolicyProps()
        {
            ManagedPolicyName = id.Id(_stackNamePrefix),
            Description = "Allows CI cicd user to deploy and manage resources within some permission boundary"
        });
        cicdPolicy.AddStatements(new PolicyStatement(new PolicyStatementProps()
            {
                Sid = "ManageRoles",
                Effect = Effect.ALLOW,
                Actions = new[]
                {
                    "iam:PassRole*",
                    "iam:GetRole",
                    "iam:CreateRole",
                    "iam:PutRolePolicy",
                    "iam:DeleteRolePolicy",
                    "iam:DeleteRole",
                    "iam:List*",
                    "iam:SimulatePrincipalPolicy",
                    "iam:AttachRolePolicy",
                    "iam:DetachRolePolicy",
                    "iam:PutRolePermissionsBoundary"
                },
                Resources = new[] { "*" }
            }),

            // .. can assume cdk roles (bootstrapped by cdk)
            new PolicyStatement(new PolicyStatementProps()
            {
                Sid = "AssumeCDKRoles",
                Effect = Effect.ALLOW,
                Actions = new[]
                {
                    "sts:AssumeRole"
                },
                Resources = new[] { $"arn:aws:iam::{_ctx.Account}:role/cdk-*-deploy-role-{_ctx.Account}-{_ctx.Region}" }
            }));

        // .. let's create a group for ci/cd functional users like cicd
        id = "cicd-group".Id(_stackNamePrefix);
        var ciGroup = new Group(this, id, new GroupProps()
        {
            GroupName = id,
            ManagedPolicies = new[]
            {
                ManagedPolicy.FromManagedPolicyArn(this, "aws-powerUserAccess-policy",
                    "arn:aws:iam::aws:policy/PowerUserAccess"),
                cicdPolicy
            }
        });

        // .. create a cicd user for deploying resources with the defined group.
        id = "cicd-user".Id(_stackNamePrefix);
        var user = new User(this, id, new UserProps
        {
            UserName = id,
            Groups = new IGroup[]
            {
                ciGroup
            },
            PermissionsBoundary = CreateCiCdTechnicalUserPermissionBoundary()
        });

        id = "cicd-user-access-key".Id(_stackNamePrefix);
        var accessKey = new AccessKey(this, id, new AccessKeyProps { User = user });

        id = "cicd-user-access-key-secret";
        new Secret(this, id.Id(_stackNamePrefix), new SecretProps
        {
            SecretStringValue = accessKey.SecretAccessKey,
            SecretName = $"/technical/user/{id}".Id(_stackNamePrefix, ""),
            Description = "Access Key and secret for cicd integration"
        });
        return user;
    }

    private ManagedPolicy CreateCiCdTechnicalUserPermissionBoundary()
    {
        var restrictToAccountAndAppResources = $"arn:aws:iam::{_ctx.Account}:role/*{_ctx.AppName}*";
        var conditionOnlyForOurRegion = new ObjectDict()
        {
            {
                "StringEquals", new ObjectDict()
                {
                    {
                        "aws:RequestedRegion", new[]
                        {
                            "eu-central-1"
                        }
                    }
                }
            }
        };

        var policyBoundaryName = "cicd-user-permission-boundary".Id(_stackNamePrefix);
        var permissionBoundaryPolicy = new ManagedPolicy(this, policyBoundaryName, new ManagedPolicyProps()
        {
            ManagedPolicyName = policyBoundaryName,
            Description = "Permission boundary to limit permissions of roles created by CI/CD user."
        });

        permissionBoundaryPolicy.AddStatements(new PolicyStatement[]
            {
                // ..  add reading iam information and simulating policies.
                new(new PolicyStatementProps
                    {
                        Sid = "AllowReadIam",
                        Effect = Effect.ALLOW,
                        Actions = new[]
                        {
                            "iam:Get*",
                            "iam:List*",
                            "iam:SimulatePrincipalPolicy"
                        },
                        Resources = new[] { "*" }
                    }
                ),
                // .. allowed services to be touched by cicd user only in specific region (eu-central-1).
                new(new PolicyStatementProps
                    {
                        Sid = "AllowServicesToDeploy",
                        Effect = Effect.ALLOW,
                        Actions = new[]
                        {
                            "cognito-idp:*",
                            "dynamodb:*",
                            "ec2:*",
                            "events:*",
                            "kms:*",
                            "lambda:*",
                            "logs:*",
                            "s3:*",
                            "schemas:*",
                            "secretsmanager:*",
                            "sns:*",
                            "sqs:*",
                            "ecr:*",
                            "ecs:*",
                            "rds:*",
                            "ssm:*", // Alow SSM parameter store.
                            "xray:*",
                        },
                        Resources = new[] { "*" },
                        Conditions = conditionOnlyForOurRegion
                    }
                ),
                new(new PolicyStatementProps
                    {
                        Sid = "AllowBuildToInvalidateCache",
                        Effect = Effect.ALLOW,
                        Actions = new[]
                        {
                            "cloudfront:ListDistributions",
                            "cloudfront:CreateInvalidation",
                        },
                        Resources = new[] { "*" }
                    }
                ),

                // .. allow cloud formation deployments.
                new(new PolicyStatementProps
                    {
                        Sid = "AllowCloudFormationDeployments",
                        Effect = Effect.ALLOW,
                        Actions = new[]
                        {
                            "cloudformation:CreateStack",
                            "cloudformation:DescribeStackEvents",
                            "cloudformation:DescribeStackResources",
                            "cloudformation:DescribeStackResource",
                            "cloudformation:DescribeStacks",
                            "cloudformation:GetTemplate",
                            "cloudformation:ListStackResources",
                            "cloudformation:UpdateStack",
                            "cloudformation:ValidateTemplate",
                            "cloudformation:DeleteStack"
                        },
                        Resources = new[] { "*" },
                        Conditions = conditionOnlyForOurRegion
                    }
                ),

                // .. allow validation of any stack.
                new(new PolicyStatementProps
                    {
                        Sid = "AllowCloudFormationStackValidation",
                        Effect = Effect.ALLOW,
                        Actions = new[]
                        {
                            "cloudformation:ValidateTemplate"
                        },
                        Resources = new[] { "*" },
                        Conditions = conditionOnlyForOurRegion
                    }
                ),
                // .. allow passing an roles that start with the application name to resources
                new(new PolicyStatementProps
                    {
                        Sid = "AllowPassingRoleToAppResources",
                        Effect = Effect.ALLOW,
                        Actions = new[]
                        {
                            "iam:PassRole"
                        },
                        Resources = new[] { restrictToAccountAndAppResources },
                        Conditions = new ObjectDict()
                        {
                            {
                                "StringEquals", new ObjectDict()
                                {
                                    {
                                        "iam:PassedToService",
                                        new[]
                                        {
                                            "lambda.amazonaws.com", "ecs.amazonaws.com", "ec2.amazonaws.com",
                                            "rds.amazonaws.com", "ecs-tasks.amazonaws.com"
                                        }
                                    }
                                }
                            }
                        }
                    }
                ),

                // .. deny removal of permission boundary from any role
                new(new PolicyStatementProps
                    {
                        Sid = "DenyPermissionsBoundaryRemoval",
                        Effect = Effect.DENY,
                        Actions = new[]
                        {
                            "iam:DeleteRolePermissionsBoundary"
                        },
                        Resources = new[] { "arn:aws:iam:::role/*" }
                    }
                ),

                // .. allow roles to be deleted 
                new(new PolicyStatementProps
                    {
                        Sid = "AllowDeleteRole",
                        Effect = Effect.ALLOW,
                        Actions = new[]
                        {
                            "iam:DetachRolePolicy",
                            "iam:DeleteRolePolicy",
                            "iam:DeleteRole"
                        },
                        Resources = new[] { "arn:aws:iam:::role/*" }
                    }
                ),
                // .. can assume cdk roles (bootstrapped by cdk)
                new(new PolicyStatementProps()
                {
                    Sid = "AssumeCDKRoles",
                    Effect = Effect.ALLOW,
                    Actions = new[]
                    {
                        "sts:AssumeRole"
                    },
                    Resources = new[]
                    {
                        $"arn:aws:iam::{_ctx.Account}:role/cdk-*-deploy-role-{_ctx.Account}-{_ctx.Region}",
                        $"arn:aws:iam::{_ctx.Account}:role/cdk-*-lookup-role-{_ctx.Account}-{_ctx.Region}",
                        $"arn:aws:iam::{_ctx.Account}:role/cdk-*-file-publishing-role-{_ctx.Account}-{_ctx.Region}"
                    }
                })
            }
        );

        // .. self reference and self protection!
        permissionBoundaryPolicy.AddStatements(new PolicyStatement[]
            {
                // .. deny permission boundary alternation.
                new(new PolicyStatementProps
                    {
                        Sid = "DenyPermissionBoundaryAlternation",
                        Effect = Effect.DENY,
                        Actions = new[]
                        {
                            "iam:CreatePolicyVersion",
                            "iam:DeletePolicy",
                            "iam:DeletePolicyVersion",
                            "iam:SetDefaultPolicyVersion"
                        },
                        Resources = new[] { $"arn:aws:iam::{_ctx.Account}:policy/{policyBoundaryName}" }
                    }
                ),
                // .. allow permissions boundaries to be applied
                new(new PolicyStatementProps
                    {
                        Sid = "AllowUpsertRoleIfPermBoundaryIsBeingApplied",
                        Effect = Effect.ALLOW,
                        Actions = new[]
                        {
                            "iam:CreateRole",
                            "iam:PutRolePolicy",
                            "iam:PutRolePermissionsBoundary",
                        },
                        Resources = new[] { "arn:aws:iam:::role/*", "arn:aws:iam:::policy/*" },
                        Conditions = new ObjectDict()
                        {
                            {
                                "StringEquals", new ObjectDict()
                                {
                                    {
                                        "iam:PermissionsBoundary",
                                        new[]
                                        {
                                            $"arn:aws:iam::{_ctx.Account}:policy/{policyBoundaryName}"
                                        }
                                    }
                                }
                            }
                        }
                    }
                )
            }
        );
        return permissionBoundaryPolicy;
    }

    /**
    * Creates the PowerUserRole with all needed permissions: Provides full access to AWS services and resources, but
    * does not allow management of Users, groups and permissions.
    *
    * We are applying the following docu: https://pages.git.i.mercedes-benz.com/ccoe/aws-guide/AWS_IDP/Adminpage-User-Guide.html#manage-aws-roles
    *
    * It seems that CDK is not allowing to attache a new audience to the open api provider (0_o). Do it manually.
    */
    private Role CreatePowerUserRole()
    {
        var openApiProvider = OpenIdConnectProvider.FromOpenIdConnectProviderArn(this, "openapi-provider",
            $"arn:aws:iam::{_ctx.Account}:oidc-provider/idp.aws.corpinter.net");
        const string roleName = "PowerUser";
        return new Role(this, roleName.Id(_stackNamePrefix), new RoleProps
        {
            RoleName = roleName,
            AssumedBy = new FederatedPrincipal(
                openApiProvider.OpenIdConnectProviderArn,
                new ObjectDict
                {
                    {
                        "ForAnyValue:StringEquals", new ObjectDict
                        {
                            {
                                "idp.aws.corpinter.net:aud", $"{_ctx.Account}-{roleName}"
                            }
                        }
                    }
                },
                "sts:AssumeRoleWithWebIdentity"),
            ManagedPolicies = new[]
            {
                // .. for execution, like getting images from ECR, ...
                ManagedPolicy.FromManagedPolicyArn(this, "policy-PowerUserAccess",
                    "arn:aws:iam::aws:policy/PowerUserAccess")
            },
            MaxSessionDuration = Duration.Hours(12)
        });
    }


    /**
    * Creates the Developer with all needed permissions:
    *
    * We are applying the following docu: https://pages.git.i.mercedes-benz.com/ccoe/aws-guide/AWS_IDP/Adminpage-User-Guide.html#manage-aws-roles
    *
    * It seems that CDK is not allowing to attache a new audience to the open api provider (0_o). Do it manually.
    */
    private Role CreateDeveloperRole()
    {
        var openApiProvider = OpenIdConnectProvider.FromOpenIdConnectProviderArn(this, "openapi-provider-developer",
            $"arn:aws:iam::{_ctx.Account}:oidc-provider/idp.aws.corpinter.net");
        const string roleName = "Developer";
        return new Role(this, roleName.Id(_stackNamePrefix), new RoleProps
        {
            RoleName = roleName,
            AssumedBy = new FederatedPrincipal(
                openApiProvider.OpenIdConnectProviderArn,
                new ObjectDict
                {
                    {
                        "ForAnyValue:StringEquals", new ObjectDict
                        {
                            {
                                "idp.aws.corpinter.net:aud", $"{_ctx.Account}-{roleName}"
                            }
                        }
                    }
                },
                "sts:AssumeRoleWithWebIdentity"),
            ManagedPolicies = new[]
            {
                // .. for execution, like getting images from ECR, ...
                ManagedPolicy.FromManagedPolicyArn(this, "policy-developer-permissions",
                    "arn:aws:iam::aws:policy/ReadOnlyAccess")
            },
            MaxSessionDuration = Duration.Hours(12)
        });
    }
}