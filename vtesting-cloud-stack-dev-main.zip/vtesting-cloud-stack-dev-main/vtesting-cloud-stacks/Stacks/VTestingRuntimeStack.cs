using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Amazon.CDK;
using Amazon.CDK.AWS.EC2;
using Amazon.CDK.AWS.ECS;
using Amazon.CDK.AWS.IAM;
using Amazon.CDK.AWS.KMS;
using Amazon.CDK.AWS.RDS;
using Amazon.CDK.AWS.Route53;
using Amazon.CDK.AWS.Route53.Targets;
using Amazon.CDK.AWS.S3;
using Amazon.CDK.AWS.SecretsManager;
using Constructs;
using VtestingCloudStack.Common;
using InstanceProps = Amazon.CDK.AWS.EC2.InstanceProps;
using Secret = Amazon.CDK.AWS.SecretsManager.Secret;

namespace VtestingCloudStack.Stacks;

/**
 * The actual stack meant to be created.
 */
public class VTestingRuntimeStack : Stack
{
    private readonly VTestingStackContext _ctx;
    private readonly string _stackNamePrefix;

    public VTestingRuntimeStack(Construct scope, string id, VTestingStackContext ctx, IStackProps props = null) : base(
        scope, id, props)
    {
        _ctx = ctx;
        _stackNamePrefix = _ctx.Env + "-" + _ctx.AppName;

        var kmsKey = Alias.FromAliasName(this, "aws-secretsmanager", "alias/aws/secretsmanager");
        var vTestingVpc = CreateVpc();

        // .. for creation of DNS entries
        var privateZone = new PrivateHostedZone(this, "private-zone".Id(_stackNamePrefix), new PrivateHostedZoneProps
        {
            ZoneName = $"{_stackNamePrefix}.stack",
            Vpc = vTestingVpc,
            Comment = "The private zone for dns names of the vtesting.stack"
        });

        var rdCorpintraNetZone = new PrivateHostedZone(this, "rd.corpintra-private-zone".Id(_stackNamePrefix),
            new PrivateHostedZoneProps
            {
                ZoneName = "rd.corpintra.net",
                Vpc = vTestingVpc,
                Comment = "Private zone for dns name for resolution of on-prem resources."
            });

        // .. creation of ecs cluster and all needed ecs-related things.
        var ecsCluster = CreateEcsCluster(vTestingVpc);
        var repositorySecret = CreateImageRepositorySecrets();

        // .. will be used by the service
        var taskRole = CreateTaskRole();

        // .. role must be able to get repositorySecret and will be used by the ecs 
        var taskExecutionRole = CreateTaskExecutionRole(kmsKey, repositorySecret);

        // .. s3 input configuration bucket with access rights for task role
        var s3Configuration = CreateS3Bucket("simulation-configuration");
        s3Configuration.GrantAccessTo(taskRole, new[] { "s3:Get*" });

        var s3Reporting = CreateS3Bucket("simulation-reporting");
        s3Reporting.GrantAccessTo(taskRole, new[] { "s3:*Object" });

        // .. Security groups that can be used to allow access to instances if needed (will only be created 
        // as ready to be used resources).
        CreateCommonSecurityGroup(vTestingVpc);
        var taskSecurityGroup = CreateTaskSecurityGroup(vTestingVpc);

        // .. create RDS instance for P:TA in database subnet (for communication with ECS prepared). 
        var ptaDatabase = CreatePtaDatabase(vTestingVpc, taskSecurityGroup);
        var ptaDatabaseDns = ptaDatabase.CreateAlias(privateZone, "pta.database");

        // .. create the vector licenses server
        var vectorLicenseServer =
            CreateVectorLicenseServer(vTestingVpc, new List<ISecurityGroup> { taskSecurityGroup });
        var vectorLicenseDns = vectorLicenseServer.CreateAlias(privateZone, "vector.license");

        // .. create vpc service interfaces
        Dictionary<string, InterfaceVpcEndpoint>
            createdLicenceServerEndpoints = new Dictionary<string, InterfaceVpcEndpoint>();

        foreach (var endpoint in ctx.LicenceServerEndpointInterfaces)
        {
            createdLicenceServerEndpoints.Add(
                endpoint.Name,
                CreateInterfaceVpcEndpoint(
                    endpoint.Name,
                    endpoint.ServiceName,
                    vTestingVpc,
                    taskSecurityGroup,
                    endpoint.OpenPorts,
                    VpcSubnets.License,
                    rdCorpintraNetZone,
                    endpoint.DnsRecords));
        }

        // .. outputs
        // @formatter:off
        taskExecutionRole.ToOutput(this, "ecs-task-execution-role".Id(_stackNamePrefix), "Use this task execution role for your task definitions");
        taskRole.ToOutput(this, "ecs-task-role".Id(_stackNamePrefix), "Use this task role for your task definitions (cluster simulation)");
        repositorySecret.ToOutput(this, "secret-repository-credentials".Id(_stackNamePrefix), "Use this secret for the task definition to access Bertrandt's repository");
        ecsCluster.ToOutput(this, "ecs-runtime".Id(_stackNamePrefix), "Use this task role (arn) for your task definitions (cluster simulation)");
        ptaDatabase.ToOutput(this, "database-pta".Id(_stackNamePrefix), "P:TA testing case database.");
        ptaDatabaseDns.ToOutput(this, "database-pta".Id(_stackNamePrefix), "P:TA testing case database DNS.");
        taskSecurityGroup.ToOutput(this, "ecs-security-group".Id(_stackNamePrefix), "Use this security group for your task definitions (cluster simulations). The security group will allow you to get access to all needed database.");
        vectorLicenseServer.ToOutput(this, "vector-license-server".Id(_stackNamePrefix), "The vector license server for thme CANoe simulation tasks.");
        vectorLicenseDns.ToOutput(this, "vector-license-server".Id(_stackNamePrefix), "The vector license server for the CANoe simulation tasks DNS.");
        s3Configuration.ToOutput(this, "simulation-configuration".Id(_stackNamePrefix), "S3 bucket holding all simulation configurations (input) for simulation runs.");
        s3Configuration.ToOutput(this, "simulation-reporting".Id(_stackNamePrefix), "S3 bucket for storing reports and outputs of simulation runs.");

        foreach (var createdEndpoint in createdLicenceServerEndpoints)
        {
            createdEndpoint.Value.ToOutput(this, createdEndpoint.Key.Id(_stackNamePrefix), $"VPC Endpoint Interface definition for {createdEndpoint.Key} licence server access.");
        }
        // @formatter:on
    }

    private InterfaceVpcEndpoint CreateInterfaceVpcEndpoint(string name,
        string interfaceServiceName,
        IVpc vTestingVpc,
        ISecurityGroup grantedSecurityGroup,
        List<int> endpointOpenPorts,
        string subnets, PrivateHostedZone targetHostedZone,
        List<string> targetHostedZoneARecords)
    {
        var endpointSecurityGroupId = $"{name}-security-group".Id(_stackNamePrefix);
        var endpointSecurityGroup = new SecurityGroup(this, endpointSecurityGroupId, new SecurityGroupProps
        {
            SecurityGroupName = endpointSecurityGroupId,
            Description = $"Security group to access the {endpointSecurityGroupId}",
            Vpc = vTestingVpc,
            AllowAllOutbound = false
        });
        endpointSecurityGroup.SetTag(Common.Tags.Name, _ => endpointSecurityGroupId);

        var vpcEndpointOptions = new InterfaceVpcEndpointProps()
        {
            Service = new InterfaceVpcEndpointService(interfaceServiceName),
            Vpc = vTestingVpc,
            Subnets = new SubnetSelection { SubnetGroupName = subnets },
            SecurityGroups = new ISecurityGroup[] { endpointSecurityGroup },
            Open = true, // Represents the open policy in the definition
            PrivateDnsEnabled = false,
        };

        // .. securities for accessing database through granted security group.
        foreach (var openPort in endpointOpenPorts)
        {
            endpointSecurityGroup.Connections.AllowFrom(grantedSecurityGroup, Port.Tcp(openPort),
                $"Allows access to {endpointSecurityGroupId}");
        }

        var interfaceVpcEndpointId = $"{name}-vpc-endpoint".Id(_stackNamePrefix);
        var interfaceVpcEndpoint = new InterfaceVpcEndpoint(this, interfaceVpcEndpointId, vpcEndpointOptions);

        // .. add endpoint to hosted zone
        foreach (var aliasRecord in targetHostedZoneARecords)
        {
            new ARecord(this, $"{aliasRecord}-vpc-endpoint".Id(_stackNamePrefix), new ARecordProps
            {
                Zone = targetHostedZone,
                RecordName = aliasRecord,
                Target = RecordTarget.FromAlias(new InterfaceVpcEndpointTarget(interfaceVpcEndpoint))
            });
        }

        // See: Tagging is currently not working: https://github.com/aws/aws-cdk/issues/8463 
        interfaceVpcEndpoint.SetTag(Common.Tags.Name, _ => interfaceVpcEndpointId);

        return interfaceVpcEndpoint;
    }

    /**
     * Creates a s3 bucket
     */
    private Bucket CreateS3Bucket(string name)
    {
        var bucketName = name.Id(_stackNamePrefix);
        var bucket = new Bucket(this, bucketName, new BucketProps
        {
            Versioned = true,
            BucketName = bucketName,
            BlockPublicAccess = BlockPublicAccess.BLOCK_ALL,
            PublicReadAccess = false,
            AutoDeleteObjects = _ctx.Env == Envs.dev,
            RemovalPolicy = _ctx.Env == Envs.dev ? RemovalPolicy.DESTROY : RemovalPolicy.RETAIN
        });
        return bucket;
    }

    /**
     * Creates the vector license server instance.
     */
    private Instance_ CreateVectorLicenseServer(IVpc vpc, List<ISecurityGroup> allowedConnectionFromPeers)
    {
        var sgId = "license-vector-security-group".Id(_stackNamePrefix);
        var licenseSecurityGroup = new SecurityGroup(this, sgId, new SecurityGroupProps
        {
            SecurityGroupName = sgId,
            Description = "Security group used by vector license server.",
            Vpc = vpc,
            AllowAllOutbound = false
        });

        // TODO: Restrict to ne only able to ping to vector server!
        licenseSecurityGroup.Connections.AllowToAnyIpv4(Port.Tcp(22352), "Allows access to Vector servers (TCP)");
        // TODO: Restrict to ne only able to ping to vector server!
        licenseSecurityGroup.Connections.AllowToAnyIpv4(Port.Udp(22352), "Allows access to Vector servers (UDP)");
        // TODO: Restrict to ne only able to ping to vector server!
        licenseSecurityGroup.Connections.AllowToAnyIpv4(Port.Tcp(22350), "Allows access to Vector servers (TCP)");
        // TODO: Restrict to ne only able to ping to vector server!
        licenseSecurityGroup.Connections.AllowToAnyIpv4(Port.Udp(22350), "Allows access to Vector servers (UDP)");
        licenseSecurityGroup.Connections.AllowToAnyIpv4(Port.Tcp(443),
            "Allow access to Vector Server to download client software");

        allowedConnectionFromPeers.ForEach(group =>
            {
                licenseSecurityGroup.Connections.AllowFrom(group, Port.Tcp(22350),
                    "Allows simulation clusters to verify license (TCP).");
                licenseSecurityGroup.Connections.AllowFrom(group, Port.Udp(22350),
                    "Allows simulation clusters to verify license (UDP).");
                licenseSecurityGroup.Connections.AllowFrom(group, Port.Tcp(22352),
                    "Allows simulation clusters to verify license (TCP).");
                licenseSecurityGroup.Connections.AllowFrom(group, Port.Udp(22352),
                    "Allows simulation clusters to verify license (UDP).");
            }
        );
        licenseSecurityGroup.SetTag(Common.Tags.Name, _ => sgId);

        var keyPairId = "license-vector-ssh-key-pair".Id(_stackNamePrefix);
        var key = new CfnKeyPair(this, keyPairId, new CfnKeyPairProps
        {
            KeyName = keyPairId
        });

        var installScript = UserData.ForLinux();
        installScript.AddCommands(
            "wget -U 'Mozilla/5.0 (Windows NT 5.2; rv:2.0.1) Gecko/20100101 Firefox/4.0.1' 'https://www.vector.com/de/de/download/download-action/?tx_vecdownload_download%5Baction%5D=download&tx_vecdownload_download%5Bcontroller%5D=Download&tx_vecdownload_download%5Bdownload%5D=43474&cHash=56abf9daa2d768de98e7d40d410fc63c' -O vector-license-client-linux.zip");
        installScript.AddCommands("unzip vector-license-client-linux.zip");
        installScript.AddCommands("sudo yum -y install *.rpm");
        installScript.AddCommands("VectorLicenseClient -v");

        var instanceId = "license-vector".Id(_stackNamePrefix);
        return new Instance_(this, instanceId, new InstanceProps
        {
            Vpc = vpc,
            // .. with the lookup we are going to store the state.
            MachineImage = MachineImage.Lookup(new LookupMachineImageProps()
            {
                Name = "amzn2-ami-hvm-2.0.20230320.0-x86_64-gp2",
                Owners = new[] { "amazon" }
            }),
            InstanceType = InstanceType.Of(InstanceClass.T2, InstanceSize.NANO),
            InstanceName = instanceId,
            VpcSubnets = new SubnetSelection { SubnetGroupName = VpcSubnets.License },
            SecurityGroup = licenseSecurityGroup,
            KeyName = key.KeyName,
            UserData = installScript
        });
    }

    private void CreateCommonSecurityGroup(IVpc vTestingVpc)
    {
        var id = "common-ssh-security-group".Id(_stackNamePrefix);
        var commonSecurityGroup = new SecurityGroup(this, id, new SecurityGroupProps
        {
            SecurityGroupName = id,
            Description = "Security group can be assigned to an Bastion for instance",
            Vpc = vTestingVpc,
            AllowAllOutbound = true
        });
        commonSecurityGroup.SetTag(Common.Tags.Name, _ => id);

        id = "common-ssh-allow-security-group".Id(_stackNamePrefix);
        var commonAllowSecurityGroup = new SecurityGroup(this, id, new SecurityGroupProps
        {
            SecurityGroupName = id,
            Description =
                "Security group used by admins to assign to non-bastion instance to be able to connect to from bastion.",
            Vpc = vTestingVpc,
            AllowAllOutbound = false
        });

        // .. only output to 22 of security group above.
        commonSecurityGroup.Connections.AllowFromAnyIpv4(Port.Tcp(22),
            "Everyone from the internet is able to connect to the instance.");
        commonAllowSecurityGroup.Connections.AllowFrom(commonSecurityGroup, Port.Tcp(22),
            "Allows connections from bastion to non-bastion instance.");
        commonAllowSecurityGroup.SetTag(Common.Tags.Name, _ => id);

        id = "common-https-allow-security-group".Id(_stackNamePrefix);
        var commonAllowHttpsSecurityGroup = new SecurityGroup(this, id, new SecurityGroupProps
        {
            SecurityGroupName = id,
            Description =
                "Security group used by admins to assign to non-bastion instance to be able to connect to https.",
            Vpc = vTestingVpc,
            AllowAllOutbound = false
        });
        commonAllowSecurityGroup.Connections.AllowToAnyIpv4(Port.Tcp(443));
        commonAllowHttpsSecurityGroup.SetTag(Common.Tags.Name, _ => id);
    }

    /**
     * Creates the security group for the task definitions. This security group will be later adapted and extended
     * to allow access to several databases laying ind other/isolated subnets.
     */
    private ISecurityGroup CreateTaskSecurityGroup(IVpc vpc)
    {
        var id = "ecs-service-security-group".Id(_stackNamePrefix);
        var ecsSecurityGroup = new SecurityGroup(this, "security-group", new SecurityGroupProps
        {
            SecurityGroupName = id,
            Description =
                "Security group used by ecs services and tasks.",
            Vpc = vpc,
            AllowAllOutbound = false
        });

        // .. the ecs runtime is able to communicate with the internet. 
        // .. TODO: Couldn't we open it only one 1 specific ip address?
        ecsSecurityGroup.Connections.AllowToAnyIpv4(Port.Tcp(443),
            "Allow access to the internet (for bertrandt git repository)");

        ecsSecurityGroup.SetTag(Common.Tags.Name, _ => id);
        return ecsSecurityGroup;
    }

    /**
     * Creates the PTA database for storing all information we need for our test cases.
     */
    private DatabaseInstance CreatePtaDatabase(IVpc vpc, IConnectable grantedSecurityGroup)
    {
        const string dbUsername = "master";
        const int dbPost = 1433;

        var ptaDatabaseMasterSecretName = "secret-database-pta-credentials".Id(_stackNamePrefix);
        var ptaDatabaseMasterSecret = new Secret(this, ptaDatabaseMasterSecretName, new SecretProps
        {
            SecretName = "/database/master/credentials".Id(_stackNamePrefix),
            Description = "Password for accessing P:TA database",
            GenerateSecretString = new SecretStringGenerator
            {
                SecretStringTemplate = "{\"username\":\"" + dbUsername + "\"}",
                GenerateStringKey = "password",
                PasswordLength = 16,
                ExcludePunctuation = true
            }
        });

        var ptaDatabaseSecurityGroupId = "pta-security-group".Id(_stackNamePrefix);
        var ptaSecurityGroup = new SecurityGroup(this, ptaDatabaseSecurityGroupId, new SecurityGroupProps
        {
            SecurityGroupName = ptaDatabaseSecurityGroupId,
            Description = $"Security group to access the {ptaDatabaseSecurityGroupId}",
            Vpc = vpc,
            AllowAllOutbound = false
        });
        ptaSecurityGroup.SetTag(Common.Tags.Name, _ => ptaDatabaseSecurityGroupId);

        var ptaDatabaseId = "database-pta".Id(_stackNamePrefix);
        var ptaDatabase = new DatabaseInstance(this, ptaDatabaseId, new DatabaseInstanceProps
        {
            InstanceIdentifier = ptaDatabaseId,
            Engine = DatabaseInstanceEngine.SqlServerEx(new SqlServerExInstanceEngineProps
                { Version = SqlServerEngineVersion.VER_15 }),
            Vpc = vpc,
            MultiAz = false,
            AllocatedStorage = 20.0,
            InstanceType = InstanceType.Of(InstanceClass.T3, InstanceSize.SMALL),
            AvailabilityZone = "eu-central-1a",
            SecurityGroups = new ISecurityGroup[] { ptaSecurityGroup },
            PubliclyAccessible = false,
            VpcSubnets = new SubnetSelection { SubnetGroupName = VpcSubnets.Database },
            DeletionProtection = _ctx.Env != Envs.dev,
            DeleteAutomatedBackups = _ctx.Env == Envs.dev,
            BackupRetention = _ctx.Env == Envs.dev ? Duration.Days(0) : Duration.Days(30),
            RemovalPolicy = _ctx.Env == Envs.dev ? RemovalPolicy.DESTROY : RemovalPolicy.RETAIN,
            Credentials = Credentials.FromSecret(ptaDatabaseMasterSecret)
        });

        // .. securities for accessing database through granted security group.
        ptaSecurityGroup.Connections.AllowTo(grantedSecurityGroup, Port.Tcp(dbPost),
            $"Allows access to database {ptaDatabaseId} from security group {ptaDatabaseSecurityGroupId}");
        ptaSecurityGroup.Connections.AllowFrom(grantedSecurityGroup, Port.Tcp(dbPost),
            $"Allows access from security group {ptaDatabaseSecurityGroupId} to database {ptaDatabaseId}");

        return ptaDatabase;
    }

    /**
    * Creates the ECS task role for giving task definitions a set of appropriated permissions.
    */
    private Role CreateTaskRole()
    {
        var taskRoleName = "ecs-role-task".Id(_stackNamePrefix);
        var taskRole = new Role(this, taskRoleName, new RoleProps
        {
            RoleName = taskRoleName,
            AssumedBy = new ServicePrincipal("ecs-tasks.amazonaws.com"),
            InlinePolicies = new Dictionary<string, PolicyDocument>
            {
                {
                    taskRoleName, new PolicyDocument(new PolicyDocumentProps
                    {
                        Statements = new[]
                        {
                            new PolicyStatement(new PolicyStatementProps
                            {
                                Effect = Effect.ALLOW,
                                Actions = new[]
                                {
                                    // .. TODO: Give some correct permissions for what ever you want/need.
                                    "cloudwatch:DeleteAlarms",
                                    "cloudwatch:DescribeAlarms",
                                    "cloudwatch:PutMetricAlarm"
                                },
                                Resources = new[] { "arn:aws:cloudwatch:*:*:alarm:*" }
                            })
                        }
                    })
                }
            }
        });
        return taskRole;
    }

    /**
     * Creates the task execution role. This role will be used by ECS to provision the task definition. It is not
     * the Task role which will be used by the simulation clusters. The latter will be used to allow the Service/Task
     * to make requests to AWS resources (e.g. dynamodb, rds, etc.).
     */
    private Role CreateTaskExecutionRole(IKey kmsKey, ISecret repositorySecret)
    {
        var taskExecutionRoleName = "ecs-role-task-execution".Id(_stackNamePrefix);
        var taskExecutionRole = new Role(this, taskExecutionRoleName, new RoleProps
        {
            RoleName = taskExecutionRoleName,
            AssumedBy = new ServicePrincipal("ecs-tasks.amazonaws.com"),
            ManagedPolicies = new[]
            {
                // .. for execution, like getting images from ECR, ...
                ManagedPolicy.FromManagedPolicyArn(this, "service-role-AmazonECSTaskExecutionRolePolicy",
                    "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"),

                // .. for cloudwatch log. Everything we need is in this managed policy.
                ManagedPolicy.FromManagedPolicyArn(this, "service-role-AWSOpsWorksCloudWatchLogs",
                    "arn:aws:iam::aws:policy/AWSOpsWorksCloudWatchLogs")
            }
        });

        taskExecutionRole.AddToPolicy(new PolicyStatement(new PolicyStatementProps
        {
            Sid = "secrets",
            Effect = Effect.ALLOW,
            Actions = new[] { "kms:Decrypt", "ssm:GetParameters", "secretsmanager:GetSecretValue" },
            Resources = new[] { repositorySecret.SecretArn, kmsKey.KeyArn }
        }));

        return taskExecutionRole;
    }

    /**
     * The task definitions may pull images of restricted repositories. This secret holds the credentials to access
     * the repo.
     */
    private Secret CreateImageRepositorySecrets()
    {
        // .. create secrets for repo.
        var repositorySecretName = "secret-repository-credentials".Id(_stackNamePrefix);
        var repositorySecret = new Secret(this, repositorySecretName, new SecretProps
        {
            SecretName = _stackNamePrefix + "/repository/credentials",
            Description = "Credentials for accessing Bertrand's images",
            SecretObjectValue = new Dictionary<string, SecretValue>
            {
                { "username", new SecretValue("changeit") },
                { "password", new SecretValue("changeit") }
            }
        });

        return repositorySecret;
    }

    /**
    * Creates the vtesting ecs runtime.
    */
    private Cluster CreateEcsCluster(IVpc vTestingVpc)
    {
        var clusterName = "ecs-runtime".Id(_stackNamePrefix);
        // .. creation of the ECS cluster.
        var vTestingRuntime = new Cluster(this, clusterName, new ClusterProps
        {
            Vpc = vTestingVpc,
            ClusterName = clusterName,
            ContainerInsights = true
        });

        return vTestingRuntime;
    }

    /**
    * Creates the vpc for the vtesting-cloud-stack.
    */
    private Vpc CreateVpc()
    {
        var vpcName = "vpc".Id(_stackNamePrefix);
        var vTestingVpc = new Vpc(this, vpcName,
            new VpcProps
            {
                MaxAzs = 2,
                VpcName = vpcName,
                EnableDnsHostnames = true,
                EnableDnsSupport = true,
                IpAddresses = IpAddresses.Cidr("172.16.0.0/16"),
                SubnetConfiguration = new ISubnetConfiguration[]
                {
                    new SubnetConfiguration
                    {
                        Name = VpcSubnets.Runtime,
                        // 4096 IP Addresses
                        CidrMask = 20,
                        SubnetType = SubnetType.PRIVATE_WITH_EGRESS
                    },
                    new SubnetConfiguration
                    {
                        Name = VpcSubnets.License,
                        // 32 IP Addresses
                        CidrMask = 27,
                        SubnetType = SubnetType.PRIVATE_WITH_EGRESS
                    },
                    new SubnetConfiguration
                    {
                        Name = VpcSubnets.Database,
                        // 32 IP Addresses
                        CidrMask = 27,
                        SubnetType = SubnetType.PRIVATE_ISOLATED
                    },
                    new SubnetConfiguration
                    {
                        Name = VpcSubnets.Transfer,
                        MapPublicIpOnLaunch = true,
                        // 32 IP Addresses
                        CidrMask = 27,
                        SubnetType = SubnetType.PUBLIC
                    }
                }
            });

        // .. rearranging some tags for all created subnets
        var privateSubNets = vTestingVpc.PrivateSubnets;
        var publicSubnets = vTestingVpc.PublicSubnets;
        var isolatedSubnet = vTestingVpc.IsolatedSubnets;
        var allSubnets = privateSubNets.Union(publicSubnets).Union(isolatedSubnet).ToArray();

        allSubnets.SetTag(Common.Tags.team, _ctx.ResponsibleTeam);

        allSubnets.SetTag(Common.Tags.team, _ctx.ResponsibleTeam);
        allSubnets.SetTag(Common.Tags.env, _ctx.Env.ToString());
        privateSubNets.SetTag(
            Common.Tags.Name,
            it =>
                vpcName + "-" + it.AvailabilityZone + "-private-" + Regex.Replace(it.Node.Id, "Subnet[0-9]", ""));
        publicSubnets.SetTag(
            Common.Tags.Name,
            it =>
                vpcName + "-" + it.AvailabilityZone + "-public-" + Regex.Replace(it.Node.Id, "Subnet[0-9]", ""));
        isolatedSubnet.SetTag(
            Common.Tags.Name,
            it =>
                vpcName + "-" + it.AvailabilityZone + "-isolated-" + Regex.Replace(it.Node.Id, "Subnet[0-9]", ""));

        var s3VpcEndpoint = "vpc-s3-endpoint".Id(_stackNamePrefix);
        vTestingVpc.AddGatewayEndpoint(s3VpcEndpoint, new GatewayVpcEndpointOptions
        {
            Service = GatewayVpcEndpointAwsService.S3,
            Subnets = new ISubnetSelection[] { new SubnetSelection { SubnetGroupName = VpcSubnets.Runtime } }
        });
        return vTestingVpc;
    }
}