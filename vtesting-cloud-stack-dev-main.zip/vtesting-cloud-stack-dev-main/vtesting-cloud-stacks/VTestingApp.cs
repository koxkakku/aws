﻿using System;
using System.Collections.Generic;
using Amazon.CDK;
using Constructs;
using Newtonsoft.Json;
using VtestingCloudStack.Common;
using VtestingCloudStack.Stacks;
using Environment = Amazon.CDK.Environment;
using Tags = Amazon.CDK.Tags;

namespace VtestingCloudStack;

/**
 * vTesting application . The application consists of some runtimes, licence servers and other environment constructs in
 * order to run simulation clusters.
 */
public static class VTestingApp
{
    // ReSharper disable once UnusedParameter.Global
    public static void Main(string[] args)
    {
        var app = new App();

        // .. we expect to get a stage variable to generate at all.
        var environmentContextId = app.Node.TryGetContext("stage");
        if (environmentContextId is null || !Enum.IsDefined(typeof(Envs), environmentContextId))
            throw new ArgumentException("stage argument was not set.");

        // .. the stage variable must identify a stage.
        var vTestingStackContextItems =
            (Dictionary<string, object>)app.Node.TryGetContext(environmentContextId.ToString()!);
        if (vTestingStackContextItems is null || vTestingStackContextItems.Count == 0)
            throw new ArgumentException("The passed stage argument {0} does not references a context in your cdk.json.",
                environmentContextId.ToString());

        // .. let's add the env variable to the dictionary to operate on the same structure.
        vTestingStackContextItems.Add("env", environmentContextId);
        string jsonContext = JsonConvert.SerializeObject(vTestingStackContextItems);
        var vTestingStackContext = VTestingStackContext.CreateInstance(jsonContext);

        // .. assemble some stacks
        CreateCommonStack(app, vTestingStackContext);
        CreateRuntimeStack(app, vTestingStackContext);
        CreateBastionStack(app, vTestingStackContext);

        app.Synth();
    }

    public static VTestingRuntimeStack CreateRuntimeStack(App app, VTestingStackContext ctx)
    {
        var stack = new VTestingRuntimeStack(app, $"{ctx.Env}-{ctx.AppName}", ctx, new StackProps
        {
            Env = new Environment
            {
                Account = ctx.Account,
                Region = ctx.Region
            }
        });

        // .. let's tag every node of the stack with our common tags.
        Tags.Of(app).Add(Common.Tags.team.ToString(), ctx.ResponsibleTeam);
        Tags.Of(app).Add(Common.Tags.env.ToString(), ctx.Env.ToString());

        return stack;
    }

    private static VTestingBastionStack CreateBastionStack(Construct app, VTestingStackContext ctx)
    {
        // .. only when needed a bastion
        return new VTestingBastionStack(app, $"{ctx.Env}-{ctx.AppName}-bastion", ctx, new StackProps
        {
            Env = new Environment
            {
                Account = ctx.Account,
                Region = ctx.Region
            }
        });
    }

    /**
     * All commons used by all stacks (something like permissions, policies, etc.)
     */
    public static VTestingCommonStack CreateCommonStack(App app, VTestingStackContext ctx)
    {
        var commonContext =
            new VTestingStackContext(Envs.com, ctx.AppName, ctx.Account, ctx.Region, ctx.ResponsibleTeam,
                new List<VTestingStackContext.EndpointInterface>());

        // .. "common" stack does not have any other environments. 
        var stack = new VTestingCommonStack(app, $"{commonContext.Env}-{commonContext.AppName}", commonContext,
            new StackProps
            {
                Env = new Environment
                {
                    Account = commonContext.Account,
                    Region = commonContext.Region
                }
            });

        // .. let's tag every node of the stack with our common tags.
        Tags.Of(app).Add(Common.Tags.team.ToString(), commonContext.ResponsibleTeam);
        Tags.Of(app).Add(Common.Tags.env.ToString(), commonContext.Env.ToString());

        return stack;
    }
}