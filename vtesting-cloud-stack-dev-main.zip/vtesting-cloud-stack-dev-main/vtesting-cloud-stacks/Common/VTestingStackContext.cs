﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace VtestingCloudStack.Common;

/**
 * VTestStackContext provides some variables for the to be built up stacks. Those variables will be loaded from the
 * cdk.json (context) an can differ.
 */
public class VTestingStackContext
{
    public VTestingStackContext(Envs env, string appName, string account, string region, string team,
        List<EndpointInterface> licenceServerEndpointInterfaces)
    {
        Env = env;
        Account = account;
        Region = region;
        AppName = appName;
        ResponsibleTeam = team;
        LicenceServerEndpointInterfaces = licenceServerEndpointInterfaces;
    }

    [JsonProperty("env")] [Required] public Envs Env { get; set; }

    [JsonProperty("account")] [Required] public string Account { get; set; }

    [JsonProperty("region")] [Required] public string Region { get; set; }

    [JsonProperty("appName")] [Required] public string AppName { get; set; }

    [JsonProperty("responsibleTeam")]
    [Required]
    public string ResponsibleTeam { get; set; }

    [JsonProperty("licenceServerEndpointInterfaces")]
    public List<EndpointInterface> LicenceServerEndpointInterfaces { get; set; }

    public static VTestingStackContext CreateInstance(string jsonContext)
    {
        // Deserialize the JSON string to VTestingStackContext object
        VTestingStackContext context = JsonConvert.DeserializeObject<VTestingStackContext>(jsonContext);

        // Validate the deserialized object
        var validationResults = new List<ValidationResult>();
        var validationContext = new ValidationContext(context);
        if (!Validator.TryValidateObject(context, validationContext, validationResults, true))
        {
            // Loop through the validationResults and throw an exception or log the error messages
            throw new ArgumentException(
                "VTestingStackContext is not initialized completely. Please, check your cdk.json");
        }

        // If validation is successful, return the context
        return context;
    }

    public class EndpointInterface
    {
        [JsonProperty("name")] public string Name { get; set; }

        [JsonProperty("serviceName")] public string ServiceName { get; set; }

        [JsonProperty("openPorts")] public List<int> OpenPorts { get; set; }

        [JsonProperty("dnsRecords")] public List<string> DnsRecords { get; set; }
    }
}