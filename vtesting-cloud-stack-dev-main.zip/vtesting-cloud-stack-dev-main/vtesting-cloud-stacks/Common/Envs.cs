﻿// ReSharper disable InconsistentNaming
// ReSharper disable UnusedMember.Global

namespace VtestingCloudStack.Common;

public enum Envs
{
    // .. common stack is always needed.
    com,
    dev,
    nonprod,
    prod
}