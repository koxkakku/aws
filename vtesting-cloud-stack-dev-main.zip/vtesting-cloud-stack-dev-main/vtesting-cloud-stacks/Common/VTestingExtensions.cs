﻿using System;
using System.Collections.Generic;
using Amazon.CDK;
using Amazon.CDK.AWS.EC2;
using Amazon.CDK.AWS.ECS;
using Amazon.CDK.AWS.IAM;
using Amazon.CDK.AWS.RDS;
using Amazon.CDK.AWS.Route53;
using Amazon.CDK.AWS.S3;
using Amazon.CDK.AWS.SecretsManager;
using Constructs;

namespace VtestingCloudStack.Common;

/**
 * Let's add some extension functions to make our life easier.
 */
public static class VTestingExtensions
{
    /**
     * Handy operation to tag a set of subnets.
     */
    public static void SetTag(this IEnumerable<ISubnet> subnets, Tags tag, string value)
    {
        foreach (var subnet in subnets) Amazon.CDK.Tags.Of(subnet).Add(tag.ToString(), value);
    }

    /**
     * Handy operation to tag a set of subnets but is also able to reuse the subset information to derive the its value.
     * <param name="tag">The tag to be set to the construct.</param>
     * <param name="lambda">
     *     Lambda function will pass you the current subnet allowing you to determine the tags value by
     *     getting attributes from the subnet itself.
     * </param>
     * <param name="subnets">Enumeration of subset (this)</param>
     */
    public static void SetTag(this IEnumerable<ISubnet> subnets, Tags tag, Func<ISubnet, string> lambda)
    {
        foreach (var subnet in subnets) subnet.SetTag(tag, lambda);
    }

    /**
     * Generic function to set tags for any kind of contract.
     */
    public static void SetTag<T>(this T construct, Tags tag, Func<T, string> lambda) where T : IConstruct
    {
        Amazon.CDK.Tags.Of(construct).Add(tag.ToString(), lambda(construct));
    }

    public static string Id(this string path, string prefix, string sep = "-")
    {
        return (prefix + sep + path).ToLower();
    }

    public static void ToOutput(this IRole role, Construct scope, string id, string description)
    {
        new CfnOutput(scope, $"{id}-arn-output", new CfnOutputProps
        {
            ExportName = $"{id}-arn",
            Value = role.RoleArn,
            Description = description
        });

        new CfnOutput(scope, $"{id}-name-output", new CfnOutputProps
        {
            ExportName = $"{id}-name",
            Value = role.RoleName,
            Description = description
        });
    }

    public static void ToOutput(this ISecret construct, Construct scope, string id, string description)
    {
        new CfnOutput(scope, $"{id}-arn-output", new CfnOutputProps
        {
            ExportName = $"{id}-arn",
            Value = construct.SecretArn,
            Description = description
        });

        new CfnOutput(scope, $"{id}-name-output", new CfnOutputProps
        {
            ExportName = $"{id}-name",
            Value = construct.SecretName,
            Description = description
        });
    }

    public static void ToOutput(this ISecurityGroup construct, Construct scope, string id, string description)
    {
        new CfnOutput(scope, $"{id}-output", new CfnOutputProps
        {
            ExportName = $"{id}-id",
            Value = construct.SecurityGroupId,
            Description = description
        });
    }

    public static void ToOutput(this ICluster construct, Construct scope, string id, string description)
    {
        new CfnOutput(scope, $"{id}-arn-output", new CfnOutputProps
        {
            ExportName = $"{id}-arn",
            Value = construct.ClusterArn,
            Description = description
        });
        new CfnOutput(scope, $"{id}-name-output", new CfnOutputProps
        {
            ExportName = $"{id}-name",
            Value = construct.ClusterName,
            Description = "Use this task role (name) for your task definitions (cluster simulation)"
        });
    }

    public static void ToOutput(this IDatabaseInstance construct, Construct scope, string id, string description)
    {
        new CfnOutput(scope, $"{id}-arn-output", new CfnOutputProps
        {
            ExportName = $"{id}-arn",
            Value = construct.InstanceArn,
            Description = description
        });
        new CfnOutput(scope, $"{id}-hostname-output", new CfnOutputProps
        {
            ExportName = $"{id}-hostname",
            Value = construct.InstanceEndpoint.Hostname,
            Description = description
        });
        new CfnOutput(scope, $"{id}-port-output", new CfnOutputProps
        {
            ExportName = $"{id}-port",
            Value = construct.DbInstanceEndpointPort,
            Description = description
        });
    }

    public static void ToOutput(this Instance_ construct, Construct scope, string id, string description)
    {
        new CfnOutput(scope, $"{id}-id-output", new CfnOutputProps
        {
            ExportName = $"{id}-id",
            Value = construct.InstanceId,
            Description = description
        });
        new CfnOutput(scope, $"{id}-hostname-output", new CfnOutputProps
        {
            ExportName = $"{id}-hostname",
            Value = construct.InstancePrivateDnsName,
            Description = description
        });
    }

    public static void ToOutput(this RecordSet construct, Construct scope, string id, string description)
    {
        new CfnOutput(scope, $"{id}-dns-output", new CfnOutputProps
        {
            ExportName = $"{id}-dns",
            Value = construct.DomainName,
            Description = description
        });
    }

    /**
    * Creates a dns alias for an EC2 instance and a given zone.
    */
    public static CnameRecord CreateAlias(this Instance_ construct, PrivateHostedZone zone,
        string alias)
    {
        return new CnameRecord(construct, $"{construct.Node.Id}-dns", new CnameRecordProps
        {
            Zone = zone,
            RecordName = alias,
            DomainName = construct.InstancePrivateDnsName
        });
    }

    /**
     * Create a dns alias for a RDS instance and a given zone.
     */
    public static CnameRecord CreateAlias(this DatabaseInstance construct, PrivateHostedZone zone,
        string alias)
    {
        return new CnameRecord(construct, $"{construct.Node.Id}-dns", new CnameRecordProps
        {
            Zone = zone,
            RecordName = alias,
            DomainName = construct.DbInstanceEndpointAddress
        });
    }

    public static void GrantAccessTo(this Bucket construct, IRole role, string[] allowActions)
    {
        role.AttachInlinePolicy(new Policy(construct, $"{construct.Node.Id}-policy", new PolicyProps
        {
            PolicyName = $"{construct.Node.Id}-policy",
            Statements = new[]
            {
                new PolicyStatement(new PolicyStatementProps
                {
                    Effect = Effect.ALLOW,
                    Actions = new[] { "s3:ListBucket" },
                    Resources = new[] { $"{construct.BucketArn}/*" }
                }),
                new PolicyStatement(new PolicyStatementProps
                {
                    Effect = Effect.ALLOW,
                    Actions = allowActions,
                    Resources = new[] { $"{construct.BucketArn}/*" }
                })
            }
        }));
    }

    public static void ToOutput(this Bucket construct, Construct scope, string id, string description)
    {
        new CfnOutput(scope, $"{id}-s3-output", new CfnOutputProps
        {
            ExportName = $"{id}-s3",
            Value = construct.BucketName,
            Description = description
        });
    }

    public static void ToOutput(this InterfaceVpcEndpoint construct, Construct scope, string id, string description)
    {
        new CfnOutput(scope, $"{id}-vpc-endpoint-output", new CfnOutputProps
        {
            ExportName = $"{id}-vpc-endpoint",
            Value = construct.VpcEndpointId,
            Description = description
        });
    }
}