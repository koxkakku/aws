﻿namespace VtestingCloudStack.Common;

/**
 * A kind of enumeration for our subnets.
 */
public static class VpcSubnets
{
    public const string Runtime = "vtesting-runtime";
    public const string License = "license-services";
    public const string Database = "vtesting-databases";
    public const string Transfer = "vtesting-transfer";
}