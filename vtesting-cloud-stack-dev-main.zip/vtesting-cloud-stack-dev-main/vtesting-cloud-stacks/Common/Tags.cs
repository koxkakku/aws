﻿// ReSharper disable InconsistentNaming

namespace VtestingCloudStack.Common;

public enum Tags
{
    team,
    env,

    // .. Name written in capital because of AWS naming conventions.
    Name
}