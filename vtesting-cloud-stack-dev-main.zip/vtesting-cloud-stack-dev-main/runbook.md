﻿# vTesting AWS Cloud Stacks (powered by AWS CDK) - Run Book

<!-- TOC -->

* [vTesting AWS Cloud Stacks (powered by AWS CDK) - Run Book](#vtesting-aws-cloud-stacks--powered-by-aws-cdk----run-book)
    * [Connect to a RDS Instance in a Private Subnet from Internet](#connect-to-a-rds-instance-in-a-private-subnet-from-internet)
        * [1. Launch and Configure your EC2 Instance (Jump-Host), and then Configure the Network Setting of the Instance.](#1-launch-and-configure-your-ec2-instance--jump-host---and-then-configure-the-network-setting-of-the-instance)
        * [2. Connect to the RDS DB Instance from your Local Machine (establish a SSH Tunnel)](#2-connect-to-the-rds-db-instance-from-your-local-machine--establish-a-ssh-tunnel-)
* [Create a vtesting-stack-bastion (if needed)](#create-a-vtesting-stack-bastion--if-needed-)

<!-- TOC -->

## Connect to a RDS Instance in a Private Subnet from Internet

I want to connect from my local machine to the for instance `dev-vtesting-database-pta` rds which is laying in the
private subnet (e.g. `dev-vtesting-vpc-eu-central-1a-isolated-vtesting-databases`) to install additional structures or
select records.

We are going to apply the following steps:

1. Launch and Configure your EC2 Instance, and then Configure the Network Setting of the Instance.
2. Connect to the RDS DB Instance from your Local Machine (establish a SSH Tunnel).

### 1. Launch and Configure your EC2 Instance (Jump-Host), and then Configure the Network Setting of the Instance.

1. Open the Amazon EC2 console, and then choose Launch instance.
2. Select an Amazon Machine Image (AMI).
3. Choose an instance type, and then choose Next: Configure Instance Details.
4. For Network, choose the VPC that the RDS DB instance uses (`dev-vtesting-vpc`)
5. For Subnet, select the subnet that has an internet gateway in its routing table. If you don't already have an
   internet gateway, then you can add it to the subnet after the EC2 instance is
   created (`dev-vtesting-vpc-eu-central-1a-public-vtesting-transfer`)
6. For Auto-assign public IP, make sure that Enable is selected.
7. Choose Next: Add Storage, and then modify storage as needed.
8. Choose Next: Configure Security Group, choose Add Rule, and then enter the following:
    * Type: Enter Custom TCP Rule.
    * Protocol: Enter CP.
    * Port Range: Enter 22.
9. Create the EC2 Instance
10. Select the created EC2 instance and edit the security groups. Associate the following security group to the EC2
    instance: `dev-vtesting-ecs-service-security-group`. This security group will allow you the talk with the RDS
    instance (IP addresses are not necessary)

If needed you can also check if you are able to connect to the db instance directly from the ec2 jump-host instance.
Feel free to test it before you start with the next step. It may be necessary to install some clients on the ec2 (e.g.
mysql, sqlcmd, ...).

### 2. Connect to the RDS DB Instance from your Local Machine (establish a SSH Tunnel)

The most easies way to connect to the rds db instance from the local database client is to establish a ssh tunnel
directly to the rds db instance. When working with windows it may be necessary to use ssh clients like _Putty_. For
Linux based systems
things become much easier:

Adapt and execute the following command:

```bash
ssh -i "YOUR_EC2_KEY" -L LOCAL_PORT:RDS_ENDPOINT:REMOTE_PORT EC2_USER@EC2_HOST -N -f
```

For instance:

```bash
ssh -i vtesting-adam.pem -4 -L 1433:dev-vtesting-database-pta.cxgr1cp7us2l.eu-central-1.rds.amazonaws.com:1433 ec2-user@ec2-3-122-205-79.eu-central-1.compute.amazonaws.com -N -f
```

Now, the tunnel between you local environment and the rds db instance (through the jump-host) is established. You are
able to connect with any client of your choice directly to the rds db instance. Use for this:

* hostname = localhost
* port = 1433

# Create a vtesting-stack-bastion (if needed)

The vtesting stack also provide for administrative purposes a `[env]-vtesting-stack-bastion`. If needed administrators
are able to create a bastion host in the `[env]-...-public-vtesting-transfer` public subnet to access via `SSH` hidden
private resources. In order to create such an bastion you can execute the following `cdk` command:

```bash
cdk.cmd deploy dev-vtesting-stack -c stage=dev
```

This will deploy a bastion in your dev stage. Some appropriated security groups will also be created or used (which you
may need to extend).

Before you can use the bastion you need also to provide your public key. After creation grep the `instanceId`, extend
the command and execute it:

```bash
aws ec2-instance-connect send-ssh-public-key --instance-id  <instance-id> --instance-os-user ec2-user --ssh-public-key file://<full-path-to-your-public-ssh-key>
```