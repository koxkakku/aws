using Amazon.CDK;
using Amazon.CDK.Assertions;
using VtestingCloudStack;
using VtestingCloudStack.Common;
using VtestingCloudStack.Stacks;
using StringDict = System.Collections.Generic.Dictionary<string, string>;
using ObjectDict = System.Collections.Generic.Dictionary<string, object>;


namespace VTestingCloudStackUnitTests;

public class VtestingCommonStackUnitTest
{
    private VTestingStackContext _ctx;
    private string _stackNamePrefix;
    private Template _template;

    private VTestingCommonStack _vTestingStack;

    [SetUp]
    public void Setup()
    {
        var app = new App();
        _ctx = new VTestingStackContext(Envs.dev, "vtesting-stack", "111111", "eu-central-1", "devs",
            new List<VTestingStackContext.EndpointInterface>());

        _vTestingStack = VTestingApp.CreateCommonStack(app, _ctx);
        _stackNamePrefix = _ctx.Env + "-" + _ctx.AppName;
        _template = Template.FromStack(_vTestingStack);
    }

    [Test]
    public void Ensure_That_Stack_Is_Complete()
    {
        _template.ResourceCountIs("AWS::IAM::Role", 2);
        _template.HasResource("AWS::IAM::Role", Match.ObjectLike(new ObjectDict
        {
            {
                "Properties", new ObjectDict
                {
                    {
                        "AssumeRolePolicyDocument", new ObjectDict
                        {
                            {
                                "Statement", new[]
                                {
                                    new ObjectDict
                                    {
                                        { "Action", "sts:AssumeRoleWithWebIdentity" },
                                        { "Effect", "Allow" },
                                        {
                                            "Principal", new ObjectDict
                                            {
                                                {
                                                    "Federated",
                                                    $"arn:aws:iam::{_ctx.Account}:oidc-provider/idp.aws.corpinter.net"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {
                        "ManagedPolicyArns", new[] { "arn:aws:iam::aws:policy/PowerUserAccess" }
                    },
                    {
                        "RoleName", "PowerUser"
                    }
                }
            }
        }));
        _template.HasResource("AWS::IAM::Role", Match.ObjectLike(new ObjectDict
        {
            {
                "Properties", new ObjectDict
                {
                    {
                        "AssumeRolePolicyDocument", new ObjectDict
                        {
                            {
                                "Statement", new[]
                                {
                                    new ObjectDict
                                    {
                                        { "Action", "sts:AssumeRoleWithWebIdentity" },
                                        { "Effect", "Allow" },
                                        {
                                            "Principal", new ObjectDict
                                            {
                                                {
                                                    "Federated",
                                                    $"arn:aws:iam::{_ctx.Account}:oidc-provider/idp.aws.corpinter.net"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {
                        "ManagedPolicyArns", new[] { "arn:aws:iam::aws:policy/ReadOnlyAccess" }
                    },
                    {
                        "RoleName", "Developer"
                    }
                }
            }
        }));
    }
}