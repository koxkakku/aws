using Amazon.CDK;
using Amazon.CDK.Assertions;
using VtestingCloudStack;
using VtestingCloudStack.Common;
using VtestingCloudStack.Stacks;
using StringDict = System.Collections.Generic.Dictionary<string, string>;
using ObjectDict = System.Collections.Generic.Dictionary<string, object>;


namespace VTestingCloudStackUnitTests;

public class VtestingRuntimeStackUnitTest
{
    private string? _stackNamePrefix;
    private Template? _template;

    private VTestingRuntimeStack? _vTestingStack;

    [SetUp]
    public void Setup()
    {
        var app = new App();
        var ctx = new VTestingStackContext(Envs.dev, "vtesting-stack", "111111", "eu-central-1", "devs",
            new List<VTestingStackContext.EndpointInterface>());

        _vTestingStack = VTestingApp.CreateRuntimeStack(app, ctx);
        _stackNamePrefix = ctx.Env + "-" + ctx.AppName;
        _template = Template.FromStack(_vTestingStack);
    }

    [Test]
    public void Ensure_That_Stack_Is_Complete()
    {
        _template.ResourceCountIs("AWS::EC2::VPC", 1);
        _template.ResourceCountIs("AWS::IAM::Role", 4);
        _template.ResourceCountIs("AWS::RDS::DBInstance", 1);
        _template.ResourceCountIs("AWS::ECS::Cluster", 1);
        _template.ResourceCountIs("AWS::EC2::Instance", 1);
    }

    [Test]
    public void Ensure_That_Vpc_Settings()
    {
        _template.ResourceCountIs("AWS::EC2::VPC", 1);

        _template.HasResource("AWS::EC2::VPC", Match.ObjectLike(new ObjectDict
        {
            {
                "Properties", new ObjectDict
                {
                    { "EnableDnsHostnames", true },
                    { "EnableDnsSupport", true },
                    { "InstanceTenancy", "default" }
                }
            }
        }));
    }


    // TODO: Not ready. But we know how to test the stack with this clumsy cdk in c# (further tests will be implemented later).
    [Test]
    public void Ensure_That_Roles_are_Defined_as_Expected()
    {
        // .. testing of  ecs execution role.
        var ecsRoleTask = _template.FindResources("AWS::IAM::Role", Match.ObjectLike(new ObjectDict
        {
            {
                "Properties", new ObjectDict
                {
                    {
                        "AssumeRolePolicyDocument", new ObjectDict
                        {
                            {
                                "Statement", new[]
                                {
                                    new ObjectDict
                                    {
                                        { "Action", "sts:AssumeRole" },
                                        { "Effect", "Allow" },
                                        {
                                            "Principal", new ObjectDict
                                            {
                                                {
                                                    "Service", "ecs-tasks.amazonaws.com"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {
                        "RoleName", "ecs-role-task-execution".Id(_stackNamePrefix)
                    }
                }
            }
        }));
        var roleId = ecsRoleTask.Keys.First();
        Assert.That(roleId, Is.Not.Null);
        _template.HasResource("AWS::IAM::Policy", Match.ObjectLike(new ObjectDict
        {
            {
                "Properties", new ObjectDict
                {
                    {
                        "PolicyDocument", new ObjectDict
                        {
                            {
                                "Statement", new[]
                                {
                                    new ObjectDict
                                    {
                                        {
                                            "Action",
                                            Match.ArrayWith(
                                                new object[]
                                                {
                                                    "kms:Decrypt",
                                                    "ssm:GetParameters",
                                                    "secretsmanager:GetSecretValue"
                                                })
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {
                        "Roles", new[]
                        {
                            new StringDict { { "Ref", roleId } }
                        }
                    }
                }
            }
        }));

        // .. testing of the ecs role for tasks.
        _template.HasResource("AWS::IAM::Role", Match.ObjectLike(new ObjectDict
        {
            {
                "Properties", new ObjectDict
                {
                    {
                        "RoleName", "ecs-role-task".Id(_stackNamePrefix)
                    }
                }
            }
        }));
    }
}