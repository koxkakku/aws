# Welcome to the vTesting Cloud Stack (powered by AWS CDK)

![landing-image.png](docs/ressources/project-logo.png)

<!-- TOC -->

* [Welcome to the vTesting Cloud Stack (powered by AWS CDK)](#welcome-to-the-vtesting-cloud-stack--powered-by-aws-cdk-)
    * [Stacks Defined in this Project](#stacks-defined-in-this-project)
        * [com-vtesting-stack (Common Stack)](#com-vtesting-stack--common-stack-)
        * [[env]-vtesting-stack (Runtime Stack)](#env--vtesting-stack--runtime-stack-)
            * [Requirements after Stack Creation](#requirements-after-stack-creation)
                * [1. Set (Alter) Repository Secrets](#1-set--alter--repository-secrets)
                * [2. Init the P:TA Database Schema](#2-init-the-p--ta-database-schema)
                * [3. Active Vector License (_vector-license.[env]
                  -vesting.stack_)](#3-active-vector-license--vector-licenseenv-vestingstack-)
        * [[env]-vtesting-stack-bastion (Admin Jump Host)](#env--vtesting-stack-bastion--admin-jump-host-)
    * [Big Picture - Architecture and Design](#big-picture---architecture-and-design)
        * [Subnets](#subnets)
        * [Security Groups](#security-groups)
        * [Building and Processing of Simulation Clusters](#building-and-processing-of-simulation-clusters)
    * [Defined Stages in the `cdk.json`](#defined-stages-in-the-cdkjson)
    * [Useful CDK / Dotnet Commands](#useful-cdk--dotnet-commands)

<!-- TOC -->

This stack defines the needed infrastructure for running _vTesting_ simulations in AWS. The stack extends the normal
behavior of _AWS CDK_ by introducing _stages_ context parameters identifying the stage on which the stack shall be
deployed. The stack only ships the needed environment settings but no container logic at all.

We are using the _AWS Cloud Development Kit (CDK)_ in order to define our stack in a type-safe and less error-prone
manner. Just a small reminder what the [_CDK's_](https://github.com/aws/aws-cdk) purpose is:

> The AWS Cloud Development Kit (AWS CDK) is an open-source software development framework to define cloud
> infrastructure in code and provision it through AWS CloudFormation.
> It offers a high-level object-oriented abstraction to define AWS resources imperatively using the power of modern
> programming languages. Using the CDK?s library of infrastructure constructs, you can easily encapsulate AWS best
> practices in your infrastructure definition and share it without worrying about boilerplate logic.

To work on this project you need install some tools, e.g. _AWS CLI_, _AWS CDL_, _Node_, etc. Follow
the [install.md](./docs/install.md) guide to setup your development environment.

## Stacks Defined in this Project

The projects implements several stacks that can are required or optional for the vTesting project:

* **com-vtesting-stack**: Common stack for creating some general settings, like common roles or users (no related to
  runtime)
* **[env]-vtesting-stack**: Runtime stack for created all resources for the purpose of running simulation clusters. The
  stack will be provisioned into a stage/environment.
* **[env]-vtesting-stack-bastion**: Stack creates a bastion (jump host) to get access to private subnets and instances.
  Should only live temporary and should only be used for administrative tasks.

### com-vtesting-stack (Common Stack)

Common stack for creating some general settings, like common roles or users (no related to runtime). Like:

* Role and permissions for `PowerUser`

### [env]-vtesting-stack (Runtime Stack)

Runtime stack for created all resources for the purpose of running simulation clusters. The stack will be provisioned
into a stage/environment.

#### Requirements after Stack Creation

The stack is going to create almost everything we need to run simulation clusters. After a completely _fresh_ cdk stack
deploy some actions must be applied:

##### 1. Set (Alter) Repository Secrets

In the account/stage the deployment was applied we need to set the `dev-vtesting/repository/credentials` secret
appropriately. Those credentials will be used to authenticate against a image registry.

* Navigate to the _Secrets Manager_ in the _AWS Management Console_
* Enter correct values for username and password
* Save!

##### 2. Init the P:TA Database Schema

The stack will provide the `[env]-vtesting-database-pta` RDS instance. Before the application is able to operate
with this instance, some schema and db user DML statements must be executed.

* Thus, connect with the RDS instance as `master` db user (if you do not known how to connect to the RDS in a
  provide subnet check the [runbook](runbook.md))
* Execute the following lines in order to create the needed user (change if necessary the credentials)

```sql
CREATE
DATABASE [test.db] ON PRIMARY
    ( NAME = N'test.db', FILENAME = N'D:\RDSDBDATA\DATA\test.db.mdf' , SIZE = 5120 KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024 KB ),
    FILEGROUP [TA_ATTACHMENT_TS]
        ( NAME = N'TA_ATTACHMENT_TS', FILENAME = N'D:\RDSDBDATA\DATA\TA_ATTACHMENT_TS.ndf' , SIZE = 5120 KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024 KB ),
    FILEGROUP [TA_PROGRAM_TS]
        ( NAME = N'TA_PROGRAM_TS', FILENAME = N'D:\RDSDBDATA\DATA\TA_PROGRAM_TS.ndf' , SIZE = 5120 KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024 KB ),
    FILEGROUP [TA_PROTOCOL_TS]
        ( NAME = N'TA_PROTOCOL_TS', FILENAME = N'D:\RDSDBDATA\DATA\TA_PROTOCOL_TS.ndf' , SIZE = 5120 KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024 KB )
    LOG ON
    ( NAME = N'test.db_log', FILENAME = N'D:\RDSDBDATA\DATA\test.db_log.ldf' , SIZE = 1536 KB , MAXSIZE = 2048 GB , FILEGROWTH = 10%)
    COLLATE Latin1_General_CI_AS
GO

use [test.db]
GO
CREATE
LOGIN [provetech] WITH PASSWORD =N'PROVEtech:TA', CHECK_POLICY = OFF
GO
CREATE
USER [provetech] FOR LOGIN [provetech]
GO
ALTER
ROLE db_owner ADD MEMBER provetech
GO
ALTER
LOGIN [provetech] WITH DEFAULT_DATABASE = [test.db]
GO
```

##### 3. Active Vector License (_vector-license.[env]-vesting.stack_)

The vtesting stack also provides a vector license server. Purchased licenses must be first activated before any
simulation clusters
can be run. The license server is can be accessed via a bastion host.

* If necessary, connect the license carrier where the licenses are to be activated.
* Open the command line interface.
* Enter the following command and set the parameters according to your use case:

```bash
VectorLicenseClient -activate -activationKey <key> -licenses <License list> [-dongle | -local | -deviceSerial <serial>] [-verbose]
```

### [env]-vtesting-stack-bastion (Admin Jump Host)

Stack creates a bastion (jump host) to get access to private subnets and instances. Should only live temporary and
should only be used for administrative tasks.

## Big Picture - Architecture and Design

The processing of vTesting simulations demands a setup of multiple AWS services. This is the architecture of the
_vtesting-cloud-stack_ in a a nutshell:

![vtesting-cloud-stack-vpc.png](docs/ressources/vtesting-cloud-stack-vpc.png)

### Subnets

| Subnet Name                | Usage                                      | Description / Examples                      | Type                                           | CdrMask |
|----------------------------|--------------------------------------------|---------------------------------------------|------------------------------------------------|---------|
| private-vtesting-runtime   | Subnet for AWS ECS (Runtime of Simulation) | Service or tasks with simulation containers | PRIVATE_WITH_EGRESS (internet access outbound) | 20      |
| isolated-vtesting-license  | Subnet for license services                | CANoe4SW SE license server                  | PRIVATE_WITH_EGRESS (internet access outbound) | 27      |
| isolated-vtesting-database | Database for test case storage             | P:TA                                        | PRIVATE_ISOLATED (no internet access)          | 27      |
| public-vtesting-transfer   | Public transfer                            | Public transfer DMZ network                 | PUBLIC (internet access inbound and outbound)  | 27      |

### Security Groups

| Security Group                      | Description                                                                                           | Type     | Destination/Source/IP               | Port  | Protocol |
|-------------------------------------|-------------------------------------------------------------------------------------------------------|----------|-------------------------------------|-------|----------|
| vtesting-ecs-service-security-group | Security group for all simulation clusters running in the vTesting stack.                             | Outbound | vtesting-pta-security-group         | 1433  | TCP      |
|                                     |                                                                                                       | Inbound  | vtesting-pta-security-group         | 1433  | TCP      |
| vtesting-pta-security-group         | Access to the P:TA rds instance.                                                                      | Outbound | vtesting-ecs-service-security-group | 1433  | TCP      |
|                                     |                                                                                                       | Inbound  | vtesting-ecs-service-security-group | 1433  | TCP      |
| license-vector-security-group       | Access to the Vector License EC2 instance.                                                            | Outbound | 0.0.0.0/0                           | 22352 | TCP      |
|                                     |                                                                                                       | Inbound  | vtesting-ecs-service-security-group | 22352 | TCP      |
|                                     |                                                                                                       | Outbound | 0.0.0.0/0                           | 22352 | UDP      |
|                                     |                                                                                                       | Inbound  | vtesting-ecs-service-security-group | 22352 | UDP      |
| common-ssh-security-group           | Common security group to access via SSH to bastion. Only for administrative purposes created.         | Outbound | 0.0.0.0/0                           | All   | All      |
|                                     |                                                                                                       | Inbound  | 0.0.0.0/0                           | All   | All      |
| common-ssh-allow-security-group     | Common security group to allow SSH to non-bastion instance. Only for administrative purposes created. | Outbound | common-ssh-security-group           | All   | All      |
|                                     |                                                                                                       | Inbound  | common-ssh-security-group           | 22    | TCP      |

### Building and Processing of Simulation Clusters

The main underlying runtime for processing simulation clusters is the _AWS Elastic Container Service_ (_ECS_). The so
called _task definitions_ will
be created by other build processes to assemble simulation clusters consisting of e.g. the _ControlApp_, _Simulator 1_
and _Bus_. Those _task definitions can be executed as a Service or a Task on the _ECS_ instance defined by this project.

```puml

@startuml
!includeurl https://raw.githubusercontent.com/fidildev/plantuml/master/fidilstyle.iuml

title Execution of Simulation Clusters Powered by vtesting-cloud-stack
box "BO.OS" 
 actor user
 user -> frontend: Configures simulation cluster\nconsisting of different vEUCs
 frontend -> Gitlab: Triggers build of simulation cluster
end box
participant Gitlab
box "vtesting-cloud-stack"

 Gitlab -> Gitlab: Builds with CDK ECS task definition
 note left
  Additional resources can
  also be provisioned.
 end note
 participant "AWS Cloud Formation" as cf 
 Gitlab -> cf: Deploys stack (task definition) to AWS
 cf -> cf: Provisioning of task\ndefinition (simulation cluster)
 cf --> Gitlab: Gets references to\ntask definition (ARN)
 participant "AWS ECS" as ecs
 Gitlab -> ecs: Triggers Deployment to ECS Cluster (provided by vtesting-cloud-stack)
 ecs -> ecs: Executes simulation cluster
 ecs -> s3: Outputs \nreports and results 
 ecs --> Gitlab: Confirms successful execution
 Gitlab --> frontend: Provides results refs or parameters
 frontend --> user: Gets results presented 
end box
@enduml
```

## Defined Stages in the `cdk.json`

The stack uses the `cdk.json` file in the project's root directory to define common variables per _stage_. E.g.:

```json
{
  "dev": {
    "appName": "vtesting",
    "account": "886118892370",
    "region": "eu-central-1",
    "responsibleTeam": "vtesting-team"
  },
  "int": {
    "appName": "vtesting",
    "account": "",
    "region": "eu-central-1",
    "responsibleTeam": "vtesting-team"
  },
  "prod": {
    "appName": "vtesting",
    "account": "",
    "region": "eu-central-1",
    "responsibleTeam": "vtesting-team"
  }
}
```

The benefit of using those stages is that we are able to stream-line naming conventions, add additional attributes and
build the CDK stack dynamically depending on passed stage values/parameters.

The DevOps is able to chose the set of defined values per stage by passing a _context_ argument when executing the `cdk`
commands. We have the following pattern:

```bash
cdk.cmd synth --profile [AWS_PROFILE] -c stage=[STAGE_IDENTIFIER] 
```

* `[AWS_PROFILE]`: Pointing to AWS credentials you defined in your `.aws/credentials`. `--profile` can be omitted when
  appropriated environment variables for the _AWS CLI_ will be exported.
* `[STAGE_IDENTIFIER]`: The identifier of the stage according to your `cdk.json`. In our example we can
  pass: `stage=dev`,  `stage=int` or `stage=prod`

## Useful CDK / Dotnet Commands

* `dotnet build`            compile this vtesting stack
* `dotnet test`             execute all unit tests of the vtesting stack
* `cdk ls -c stage=dev`     list all stacks in the app for `dev` stage
* `cdk synth -c stage=dev`  emits the synthesized CloudFormation template for `dev` stage.
* `cdk deploy -c stage=dev` deploy this stack to your default AWS account/region
* `cdk diff -c stage=dev`   compare deployed stack with current state
* `cdk docs`                open CDK documentation2

Enjoy!