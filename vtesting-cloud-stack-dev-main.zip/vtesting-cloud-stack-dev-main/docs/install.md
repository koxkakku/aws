﻿# vTesting AWS Cloud Stacks (powered by AWS CDK) - Installation Guide

<!-- TOC -->

* [vTesting AWS Cloud Stacks (powered by AWS CDK) - Installation Guide](#vtesting-aws-cloud-stacks--powered-by-aws-cdk----installation-guide)
    * [Prerequisites for Development - Installation Guide](#prerequisites-for-development---installation-guide)
        * [1. zScaler (Proxy) Preparations](#1-zscaler--proxy--preparations)
        * [2. Installing .Net Framework](#2-installing-net-framework)
        * [3. Installation of _AWS CDK_](#3-installation-of-aws-cdk)
            * [3.1 Installation of _node_ and _npm_](#31-installation-of-node-and-npm)
                * [3.2  Add zScaler certificate to node environment (aka. NODE_EXTRA_CA_CERTS)](#32--add-zscaler-certificate-to-node-environment--aka-nodeextracacerts-)
            * [3.3 Installation of _AWS CDK CLI_](#33-installation-of-aws-cdk-cli)
        * [4. Installation of _AWS CLI_](#4-installation-of-aws-cli)
            * [4.1 Add zScaler certificate to AWS CLI environment](#41-add-zscaler-certificate-to-aws-cli-environment)
    * [CDK Interactions](#cdk-interactions)
        * [Setup / Bootstrapping of CDK Environment into the Account](#setup--bootstrapping-of-cdk-environment-into-the-account)

<!-- TOC -->

## Prerequisites for Development - Installation Guide

Before we are able to develop and run the stack we need some tools on your system. A small overview:

* .Net Framework
* AWS CDK (we need also node and npm to run and install the tool)
* AWS CLI

### 1. zScaler (Proxy) Preparations

For any reason many companies are using the zScaler proxy (man in the middle) within their networks. Download of
resources from the internet through the JDK, Node or Python would result in SSL corruption-issues. To overcome the
problem we will add the zScaler (root) certificate and create some env variable to have one single entry:

1. Download the zScaler root certificate with for instance your browser.
   This [site](https://smarie.github.io/develop-behind-proxy/know_your_proxy/) provides a good description and put it in
   a local directory (e.g. `~/.certs/zscaler-certificate.pem)
2. Create an envrionment variable to be able to locate and reuse the stored certificate

```bash
setx ZSCALER_ROOT_CERT "%USERPROFILE%\.certs\zscaler-root-ca.pem"
```

### 2. Installing .Net Framework

1. You can use Bertrandt's Software Center to install _Microsoft .Net SDK X64 (version 6.0.xxx)_

### 3. Installation of _AWS CDK_

The _CDK_ is a CLI which allows us to interact with AWS's CloudFormation in order to create and delete stacks. The
_CDK_ is available as _npm_ package. Let's start to install _node_ and _npm_ first.

#### 3.1 Installation of _node_ and _npm_

1. Download the latest node _Windows Binary (.zip)_ from the [site](https://nodejs.org/en/download/)
2. Unpack the sources in your home directory (I prefer something like `~/bin/node-v18.13.0-win-x64)
3. Extend the `PATH` environment variable with `~/bin/node-v18.13.0-win-x64`

Now you should be able to call _node_ and _npm_ from the command line.

```bash
node -v
```

and

```bash
npm -v
```

4. Let's also configure the proxy to gather packages from the internet

```bash
npm config set proxy http://127.0.0.1:9000
npm config set https-proxy http://127.0.0.1:9000
```

##### 3.2  Add zScaler certificate to node environment (aka. NODE_EXTRA_CA_CERTS)

1. As for the JDK zScaler settings (see [here](#add-zscaler-certificate-to-jdk)) we need first to download the
   certificate and persist it locally (e.g. `~/.certs)
2. Create a env variable:

```bash
NODE_EXTRA_CA_CERTS = %ZSCALER_ROOT_CERT%
```

or use directly a CMD command:

```bash
setx NODE_EXTRA_CA_CERTS %ZSCALER_ROOT_CERT%
```

3. Restart the cmd or bash

Now, you should be able to execute _AWS CLI_ and _AWS CDL_ commands without any ssl validation issues bricking
processes.

#### 3.3 Installation of _AWS CDK CLI_

After the installation of _node_ and _npm_ we are able to install the CDK command line interface into our home
directory (without administrator privileges).

```bash
npm install cdk -g 
```

To verify if the _cdk_ was installed successfully you can execute the following command:

```bash[config](..%2F..%2F.aws%2Fconfig)
cdk.cmd -h
```

Voilà here we have some help pages:

```
Usage: cdk -a <cdk-app> COMMAND

Commands:
  cdk list [STACKS..]             Lists all stacks in the app      [aliases: ls]
  cdk synthesize [STACKS..]       Synthesizes and prints the CloudFormation
                                  template for this stack       [aliases: synth]
  cdk bootstrap [ENVIRONMENTS..]  Deploys the CDK toolkit stack into an AWS
...
```

### 4. Installation of _AWS CLI_

1. Install python from Bertrandt's Software-Center (use the most recent one)
2. To overcome some proxy issues configure the following env variables (proxy settings that will be used by python)

* HTTP_PROXY = http://127.0.0.1:9000
* HTTPS_PROXY = http://127.0.0.1:9000

3. In order to install python's package manager called pip we must execute the following commands:
    1. Download the get-pip.py file from https://bootstrap.pypa.io/get-pip.py or execute the curl:
    ```bash
    curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
    ```
    2. Change the directory and execute:
    ```bash
    python get-pip.py --trusted-host pypi.org --trusted-host files.pythonhosted.org
    ```
    3. Add official mirrows as trusted hosts due to zScaler SSL bricking:

    ```bash
    pip config set global.trusted-host "pypi.org files.pythonhosted.org pypi.python.org"
    ```
4. Start the installation of *awscli*

```bash
pip install awscli
``` 

5. Test if awscli is on your system, now:

```bash
aws help
``` 

you will get something like this:

```bash
C:\Users\lukasada>aws help
aws
^^^
Description
_____*
The AWS Command Line Interface is a unified tool to manage your AWS
services.
Synopsis
____
...
```

#### 4.1 Add zScaler certificate to AWS CLI environment

> _Caution:_ When set than the AWS CLI will work but CDK not! Use it better with `--no-verify-ssl` argument. Instead,
> you should adjust your `~/.aws/config`:
>
> ```bash
> [default]
> region = eu-central-1
> output = json
> ca_bundle = C:\Users\lukasada\.certs\zscaler-root-ca.pem
> ```

As the _nvm_, _jdk_ or _pip_ also the _AWS CLI* tool will fail due to zScaler ssl off-loading. The zScaler
corrupts the communication between the above tools and network resulting in ssl verification errors.

To solve such issues for the _AWS CLI_ we also need to provide a link to the zScaler root certificate. Let's do this:

1. As for the JDK zScaler settings (see [here](#add-zscaler-certificate-to-jdk)) we need first to download the
   certificate and persist it locally (e.g. `~/.certs)
2. Create a env variable:

```bash
AWS_CA_BUNDLE = %ZSCALER_ROOT_CERT%
```

or use directly a CMD command:

```bash
setx AWS_CA_BUNDLE %ZSCALER_ROOT_CERT%
```

3. Restart the cmd or bash

Now, you should be able to execute _AWS CLI_ and _AWS CDL_ commands without any ssl validation issues bricking
processes.

## CDK Interactions

### Setup / Bootstrapping of CDK Environment into the Account

Before we are able to work with the _AWS CDK_ we need first to apply a `bootstrap` in the target account. The
following command will create the so called `CDKToolkit` stack in the target account and region in order to be able to
use `AWS CDK`:

```bash
cdk bootstrap aws://[TARGET_ACCOUNT]/eu-central-1 --verbose
```

Once installed we are able to apply and trigger the _vTesting Stacks_ defined in this project (see next sections):