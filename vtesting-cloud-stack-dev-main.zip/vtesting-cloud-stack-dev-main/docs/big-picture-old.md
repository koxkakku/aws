﻿# Big Picture - Sequence to Execute a Simulation Cluster

```plantuml
@startuml
!includeurl https://raw.githubusercontent.com/fidildev/plantuml/master/fidilstyle.iuml
autonumber

actor "MB.OS Tester" as user_tester

box "MB.OS"
    participant "MB.OS Frontend" as frontend
end box

box "vTesting Backend"
    participant "vTesting API" as vtesting_api_backend
    database "Dynamodb\nvTesting Simulation\nRuns" as vtesting_state_simulation_runs
'    database "Dynamodb\n"
end box

box "vTesting-Runtime"
    participant gitlab
'    participant jfrog
    participant "AWS ECS\nCluster" as runtime
end box

participant "Output Folder"

user_tester -> frontend: Configures simulation cluster\nconsisting of different vECUs

== Triggering of vTesting Simulation Runs == 

frontend -> frontend: Provides based on the user\nconfiguration a <i>User Json</i>

frontend -> vtesting_api_backend: Triggers a simulation run
vtesting_api_backend -> vtesting_api_backend: Validates the <i>User Json</i>
alt validation failed
   vtesting_api_backend --> frontend: Returns failed\nvalidation error
end
vtesting_api_backend -> vtesting_api_backend: Parses <i>User Json</i> file
vtesting_api_backend -> vtesting_api_backend: Creates <b>simulation run id</b>!
note left
 We will provide an own simulation 
 run ID which will be used to reference
 all stuff related to the triggered
 simulation run by the user!
 (also the pipeline)
end note
vtesting_api_backend -> vtesting_state_simulation_runs: Writes simulation data (feed)
vtesting_state_simulation_runs --> vtesting_api_backend
vtesting_api_backend -> vtesting_state_simulation_runs: Prepares additional records\nfor simulation run
vtesting_state_simulation_runs --> vtesting_api_backend
note left
We can also embed some 
additional steps
end note
vtesting_api_backend -> gitlab: Triggers <b>async</b> pipeline
note right
Do we want to pass the 
<b>simulation run id</b> 
to the gitlab pipeline
for referencing purposes?
end note
gitlab -->vtesting_api_backend: Returns Pipeline ID
vtesting_api_backend -> vtesting_state_simulation_runs: Assign pipeline id to <b>simulation run id</b>\n and store
   
== Executing Simulation and Monitoring == 

gitlab -> gitlab: Makes some\ncrazy stuff 
gitlab -> vtesting_state_simulation_runs: Updates the status\nof the simulation
note right
Caution! Gitlab may only know
the <b>pipeline id</b> not the
<b>simulation run id</b>
end note
vtesting_state_simulation_runs --> gitlab 

gitlab -> runtime: Executes simulation run
runtime -> runtime: 
   
@enduml
```

```plantuml
@startuml
!includeurl https://raw.githubusercontent.com/fidildev/plantuml/master/fidilstyle.iuml

autonumber

actor "Tester" as user

box "MB.OS"  
 participant "MB.OS Frontend\nBackend" as frontend
' database "Testing Capabilities" as cap
 participant "Application / Packages" as ecu_repo

 user -> frontend: Configures simulation cluster\nconsisting of different vEUCs

 user -> frontend: Wählt aus vorhandenen Application vECUs aus

 frontend -> ecu_repo: Holt vorhandene Applications (ECUs) aus
 note left
      Bei einem <b>Verbundstest</b> (verschiedene ECUs)
      muss ggf. noch eine "Capabilities" Datenbank
      abgefragt werden. 
 end note
 
 ecu_repo --> frontend
 frontend --> user
 
 user -> frontend: Bestätigt Auswahl / Konfiguration
 frontend -> frontend: Generiert auf Grundlager der Eingabe\neine <b>UserJson</b>
 
 
' participant "MB.OS Backend" as os_backend


' frontend -> Gitlab: Triggers build of simulation cluster
end box

box "Gitlab\nIntegation/Deployment"
participant Gitlab

frontend -> Gitlab: Triggered eine definierte Pipeline per POST mit <b>UserJson</b>
Gitlab --> frontend: Eine Integtation Pipeline ID
participant integration
participant "vtesting-stack" as stack

Gitlab -> integration:
... Can take several minutes  ...
user -> frontend: Status abhole (refresh)
frontend -> Gitlab: Get auf REST Pipeline Resource mit Pipeline ID 

note right
Wie genaue wollen wir den Status der 
Pipeline prüfen und ggf. an MB.OS weitergeben.

Abschließend per Curl in der Pipeline und Ref 
bereitgestellt durch das Frontend? 
end note

Gitlab --> frontend
frontend --> user: Zeigt status
integration --> Gitlab

Gitlab -> stack: Provisioniert den stack als TASK inklusive Test-Anweisung
... Can take several minutes  ...
'stack --> Gitlab: Liefert URL des Simulation Services der ControlApp zurück
stack -> stack: Provisioniert
stack -> stack: Führt test aus
stack -> stack: Macht Reporting und speichert Traces (in bspw. S3)
stack -> stack: Entfernt alle Resourcen (Container) nach Abarbeitung
stack --> Gitlab: Meldet Abschluss

note left
Welche Status wollen wir
an das Frontend zurückliefern?
end note

Gitlab -> stack: Entfernt der Task Definition

note left
Wollen wir die GitLab Log Outputs
am Frontend anbieten?
end note

stack --> Gitlab 
end box


 ' Sämtliche Daten werden in Jfrog abgelegt werden
 ' Brauchen wir diese Daten?!
 ' > vECUs, RXML, 
 ' > Ja, Daten die wir für den Aufbau des Simulation Clusters benötigen
' participant jFrog
 

'participant Gitlab

'box "vtesting-cloud-stack"
' Gitlab -> Gitlab: Builds with CDK ECS task definition
' note left
'  Additional resources can
'  also be provisioned.
' end note
'
' participant "AWS Cloud Formation" as cf 
'
' Gitlab -> cf: Deploys stack (task definition) to AWS
' cf -> cf: Provisioning of task\ndefinition (simulation cluster)
' cf --> Gitlab: Gets references to\ntask definition (ARN)
'
' participant "AWS ECS" as ecs
'
' Gitlab -> ecs: Triggers Deployment to ECS Cluster (provided by vtesting-cloud-stack)
' ecs -> ecs: Executes simulation cluster
' ecs -> s3: Outputs \nreports and results 
'
' ecs --> Gitlab: Confirms successful execution
' Gitlab --> frontend: Provides results refs or parameters
' frontend --> user: Gets results presented 
'end box
@enduml
``` 