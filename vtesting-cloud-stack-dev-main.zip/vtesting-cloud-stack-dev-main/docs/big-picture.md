﻿# Besprechungen

## 17.03.2023 Design Besprechung

* Frontend
    * Capabilities Datenbank wird aufgebaut
    * :question: Wir kennen noch nicht den gesamten UseCase, ob wir an alle Systeme (Starc, Diagnose, usw.) herantreten
      müssen
    * Vorhandene Dienste liefern ggf. die Daten in einer guten und tauglichen Form. Damit werden wir niciht
      notwendigerweise ein Endpunkt/Backend brahcen.
    * Aktuell wissen wir noch nicht ganz, welche Dritt-Systeme wir alles brauchen und welche nicht
* vTesting-Backends
    * :heart: Bereits jetzt ist klar, dass ein _Simulation Run_ ggf. aus einer Sequenz von unterschiedlichen GitLab
      Pipelines
      bestehen kann. Das spricht sogar noch mehr für den Einsatz einer `simulation-run-id`
    * Möglicher Endpunkt für den Status eines Simulation runs: `vtesting/api/simulation/{simulation-run-id}/status`

# Big Picture - Sequence to Run a Simulation Cluster Task

The sequence diagram depicts the interaction between the _MB.OS Frontend_ (_vTesting Frontend_), _vTesting Backend_ and
_vTesting Runtime_ in a high level manner. Implementation and internal details were deliberately hidden.

```plantuml
@startuml
!includeurl https://raw.githubusercontent.com/fidildev/plantuml/master/fidilstyle.iuml
autonumber

actor "MB.OS Tester" as user_tester

box "MB.OS"
    participant "MB.OS Frontend" as frontend
end box

box "vTesting Backend"
    participant "vTesting API" as vtesting_api_backend
    database "Dynamodb\nvTesting Simulation\nRuns" as vtesting_state_simulation_runs
end box

box "vTesting-Runtime"
    participant gitlab
'    participant jfrog
    participant "AWS ECS\nCluster" as runtime
end box

participant "AWS S3 \nsimulation-reporting" as reporting

user_tester -> frontend: Configures simulation cluster\nconsisting of different vECUs

== Triggering of vTesting Simulation Runs == 

frontend -> frontend: Provides based on the user\nconfiguration a <i>User Json</i>

frontend -> vtesting_api_backend: Triggers a simulation run
vtesting_api_backend -> vtesting_api_backend: Validates the <i>User Json</i>
note right
Für die validierung könnte
man final noch die capabilities
ansprechen.
end note
alt validation failed
   vtesting_api_backend --> frontend: Returns failed\nvalidation error
end
vtesting_api_backend -> vtesting_api_backend: Parses <i>User Json</i> file
vtesting_api_backend -> vtesting_api_backend: Creates <b>simulation run id</b>!
note left
 We will provide an own simulation 
 run ID which will be used to reference
 all stuff related to the triggered
 simulation run by the user!
 (also the pipeline)
end note
vtesting_api_backend -> vtesting_state_simulation_runs: Writes simulation data (feed)
vtesting_state_simulation_runs --> vtesting_api_backend
vtesting_api_backend -> vtesting_state_simulation_runs: Prepares additional records\nfor simulation run
vtesting_state_simulation_runs --> vtesting_api_backend
note left
We can also embed some 
additional steps
end note
vtesting_api_backend -> gitlab: Triggers <b>async</b> pipeline
note right
Do we want to pass the 
<b>simulation run id</b> 
to the gitlab pipeline
for referencing purposes?
end note
gitlab -->vtesting_api_backend: Returns Pipeline ID
vtesting_api_backend -> vtesting_state_simulation_runs: Assign pipeline id to <b>simulation run id</b>\n and store
vtesting_api_backend --> frontend: Provides <b>simulation run id</b>
frontend --> user_tester: Presents the created simulation run
 
== Executing Simulation and Monitoring == 

gitlab -> gitlab: Makes some\ncrazy stuff 
gitlab -> vtesting_state_simulation_runs: Updates the status\nof the simulation
note right
Caution! Gitlab may only know
the <b>pipeline id</b> not the
<b>simulation run id</b>
end note
vtesting_state_simulation_runs --> gitlab 

user_tester -> frontend: Checks simulation run status
frontend -> vtesting_api_backend: Status endpoint call\nwith <b>simulation run id</b>
vtesting_api_backend -> vtesting_state_simulation_runs: Reads status 
vtesting_state_simulation_runs --> vtesting_api_backend
vtesting_api_backend --> frontend
frontend --> user_tester

gitlab -> gitlab: Makes some\nmore crazy stuff 
gitlab -> vtesting_state_simulation_runs: Updates the status\nof the simulation
vtesting_state_simulation_runs --> gitlab
gitlab -> runtime: Executes simulation run <b>async</b>
runtime --> gitlab
gitlab -> vtesting_state_simulation_runs: Updates the status\nof the simulation
vtesting_state_simulation_runs --> gitlab
gitlab -> runtime: Checks periodically the\nstatus of simulation run
runtime --> gitlab: Not finished yet
runtime -> runtime: Finished simulation run
runtime -> reporting: Writes simulation\nrun outputs
reporting --> runtime
runtime -> runtime: Deprovision task

== Finalizing Simulation Run (Preparation of Reports) ==
gitlab -> runtime: Checks periodically the\nstatus of simulation run
runtime --> gitlab: Finished!!

gitlab -> vtesting_state_simulation_runs: Updates the status\nof the simulation
vtesting_state_simulation_runs --> gitlab


== Get What you Ordered (Reporting) == 
gitlab -> runtime: Makes some house-keeping\nand cleanups


user_tester -> frontend: Checks simulation run status
frontend -> vtesting_api_backend: Status endpoint call\nwith <b>simulation run id</b>
vtesting_api_backend -> vtesting_state_simulation_runs: Reads status 
vtesting_state_simulation_runs --> vtesting_api_backend
vtesting_api_backend --> frontend
frontend --> user_tester
@enduml
```